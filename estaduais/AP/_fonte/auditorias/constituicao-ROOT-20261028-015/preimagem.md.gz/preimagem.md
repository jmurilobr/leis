---
titulo: "Constituição do Estado do Amapá"
uf: "AP"
tipo: "Constituição Estadual"
numero: ""
data: 1991-12-20
ementa: ""
versao_texto: "Edição de 2025; atualizada até EC 71, de 17/06/2025"
publicacao: ""
fonte: "http://silegis.al.ap.leg.br/proposicaopdf/2CEatualizadaeconsolidadaateEC071comSumario.pdf"
baixado_em: 2026-10-13
---
# Constituição do Estado do Amapá

ESTADO DO AMAPÁ ASSEMBLEIA LEGISLATIVA

CONSTITUIÇÃO DO ESTADO DO AMAPÁ Texto promulgado em 20 de dezembro de 1991, atualizado até a Emenda Constitucional nº 0071, de 17.06.2025.

Macapá – AP, 2025

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 1

SUMÁRIO

Preâmbulo

### Título I Dos Princípios Fundamentais (arts. 1º a 3º) 10

### Título II Direitos e Garantias Fundamentais 10 Dos Direitos e Deveres Individuais e Coletivos

#### Capítulo I 10 (arts. 4º e 5º)

#### Capítulo II Dos Direitos Políticos e Sociais (arts. 5º-A a 5º- E) 11

### Título III Da Organização do Estado e Municípios 12

#### Capítulo I Do Estado 12

##### Seção I Das Disposições Preliminares (arts. 6º a 8º) 12

##### Seção II Dos Bens do Estado (art. 9º) 12

##### Seção III Da Competência do Estado (arts. 10 a 12) 13

#### Capítulo II Dos Municípios 15

##### Seção I Disposições Gerais (arts. 13 a 16) 15

##### Seção II Da Competência dos Municípios (art. 17) 15

##### Seção III Da Câmara Municípal (arts. 18 a 27) 16

##### Seção IV Do Prefeito e do Vice-Prefeito (arts. 28 a 34) 19 Da Criação, Incorporação, Fusão e

##### Seção V 20 Desmembramento dos Municípios (arts. 35 a 36)

##### Seção VI Da Intervenção (arts. 37 a 38) 21

##### Seção VII Da Assistência aos Municípios (arts. 39 a 41) 22

#### Capítulo III Da Administração Pública 22

##### Seção I Disposições Gerais (arts. 42 a 46) 22

##### Seção II Dos Servidores Públicos Civis (arts. 47 a 66) 27

##### Seção III Dos Servidores Públicos Militares (arts. 67 a 74) 31

### Título IV Da Segurança Pública 34

#### Capítulo I Disposições Gerais (arts. 75 a 78) 34

#### Capítulo II Da Polícia Civil (arts. 79 a 81) 35

#### Capítulo III Da Polícia Militar (arts. 82 a 85) 36

#### Capítulo IV Do Corpo de Bombeiros Militar (arts. 86 a 87) 36

#### Capítulo V Da Polícia Técnico-Científica (arts. 88 a 90) 37

#### Capítulo VI Da Polícia Penal (art.90-A) 37

### Título V Da Organização dos Poderes do Estado 38

#### Capítulo I Do Poder Legislativo 38

##### Seção I Da Assembleia Legislativa (arts. 91 a 93) 38 Das Atribuições da Assembleia Legislativa (arts.

##### Seção II 38 94 a 95) Dos Direitos e Deveres dos Deputados (arts. 96 a

##### Seção III 42 99)

##### Seção IV Das Reuniões (art. 100) 44

##### Seção V Das Comissões (art. 101) 45

##### Seção VI Do Processo Legislativo 46

###### Subseção I Das Disposições Gerais (art. 102) 46

###### Subseção II Das Emendas à Constituição (art. 103) 46

###### Subseção III Das Leis (arts. 104 a 109) 47

###### Subseção IV Da Iniciativa Popular (art. 110) 49 Da Fiscalização Contábil, Financeira e

##### Seção VII 49 Orçamentária (arts. 111 a 114)

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 2

Da Procuradoria da Assembleia Legislativa (art.

##### Seção VIII 55 115)

#### Capítulo II Do Poder Executivo 55 Do Governador e do Vice-Governador (arts. 116 a

##### Seção I 55 118)

##### Seção II Das Atribuições do Governador (art. 119) 56 Da Responsabilidade do Governador (arts. 120 a

##### Seção III 58 121)

##### Seção IV Dos Secretários de Estado (arts. 122 a 123) 59

#### Capítulo III Do Poder Judiciário 59

##### Seção I Disposições Gerais (arts. 124 a 131) 59

##### Seção II Do Tribunal de Justiça (arts. 132 a 133) 65

##### Seção III Dos Tribunais do Júri (art. 134) 68 Do Juiz de Direito, dos Juízes de Direito Auxiliares

##### Seção IV e dos Juízes de Direito Substitutos (arts. 135 a 69 137)

##### Seção V Da Justiça Militar (arts. 138 a 139) 69

##### Seção VI Dos Juizados Especiais (art. 140) 70

##### Seção VII Da Justiça de Paz (art. 141) 70

##### Seção VIII Do Controle da Constitucionalidade (art. 142) 70

##### Seção IX Dos Serviços Notariais e de Registro (art. 143) 71

#### Capítulo IV Das Funções Essencias à Justiça (arts. 144 a 151) 72

##### Seção I Do Ministério Público (arts. 144 a 151) 72 Do Ministério Público junto ao Tribunal de Contas

###### Subseção I 76 (art. 152)

##### Seção II Da Procuradoria-Geral do Estado (art. 153) 77

##### Seção III Da Defensoria Pública (arts. 154 a 158) 79

##### Seção IV Da Advocacia (art. 159) 80

### Título VI Da Tributação, do Orçamento e das Finanças 80

#### Capítulo I Dos Princípios Gerais (arts. 160 a 162) 80

#### Capítulo II Da Tributação 81 Das Limitações do Poder de Tributar (arts. 163 a

##### Seção I 81 165)

##### Seção II Dos Tributos (art. 166) 82 Dos Impostos Pertencentes ao Estado (arts. 167 a

##### Seção III 82 169)

##### Seção IV Dos Impostos Pertencentes ao Município (art. 170) 84 Da Repartição das Receitas Tributáveis (arts. 171

##### Seção V 84 a 173)

#### Capítulo III Do Orçamento (arts. 174 a 180) 85

#### Capítulo IV Das Finanças Públicas (arts. 181 a 185) 91

### Título VII Da Ordem Econômica 91

#### Capítulo I Dos principios Gerais (arts. 186 a 193) 91

#### Capítulo II Da Política Urbana 93

##### Seção I Do Desenvolvimento Urbano (arts. 194 a 198) 93

##### Seção II Da Habitação (art. 199) 96

##### Seção III Do Saneamento (arts. 200 a 204) 96 Da Política Agrária, Fundiária, Agrícola e

#### Capítulo III 97 Extrativista Vegetal (arts. 205 a 218)

#### Capítulo IV Da Política Pesqueira (arts. 219 a 221) 102

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 3

#### Capítulo V Dos Transportes (arts. 222 a 226) 102

#### Capítulo VI Dos Recursos Naturais 104

##### Seção I Disposições Gerais (arts. 227 a 230) 104

##### Seção II Dos Recursos Hídricos (arts. 231 a 238) 104

##### Seção III Dos Recursos Minerais (arts. 239 a 241) 105

#### Capítulo VII Da Indústria e Comércio (arts. 242 a 244) 106

#### Capítulo VIII Da Defesa do Consumidor (arts. 245 a 249) 107

#### Capítulo IX Do Turismo (arts. 250 a 251) 107

### Título VIII Da Ordem Social 108

#### Capítulo I Disposição Geral (art. 252) 108

#### Capítulo II Da Seguridade Social (arts. 253 a 278) 108

##### Seção I Disposições Gerais (arts. 253 a 254) 108

##### Seção II Da Saúde (arts. 255 a 268) 109

##### Seção III Da Previdência Social (arts. 269 a 271) 113

##### Seção IV Da Assistência Social (arts. 272 a 278) 115

#### Capítulo III Da Educação (arts. 279 a 291) 116

#### Capítulo IV Da Cultura (arts. 292 a 295) 121

#### Capítulo V Da Ciência e da Tecnologia (arts. 296) 122

#### Capítulo VI Do Desporto e do Lazer (arts. 297 a 298) 123

#### Capítulo VII Da Comunicação Social (arts. 299 a 303) 124 Da Família, da Criança, do Adolescente, do Portador

#### Capítulo VIII 124 de Deficiência e do Idoso (arts. 304 a 309)

#### Capítulo IX Do Meio Ambiente (arts. 310 a 328) 126

#### Capítulo X Da Mulher (art. 329) 129

#### Capítulo XI Dos Índios (arts. 330 a 332) 129

#### Capítulo XII Dos Afro-brasileiros (art. 332-A) 130

#### Capítulo XIII Dos Direitos Humanos (arts. 333 a 334) 131

#### Capítulo IV Da Política Penitenciária (arts. 335 a 338) 131 Das Disposições Constitucionais Gerais (arts.

### Título IX 132 339 a 357) Ato das Disposições Constitucionais

### Título X 135 Transitórias (arts. 1º à 63)

Emendas Constitucionais

Emenda Constitucional nº 01, de 29/03/94 149

Emenda Constitucional nº 02, de 30/11/95 150

Emenda Constitucional nº 03, de 30/11/95 154

Emenda Constitucional nº 04, de 30/11/95 152

Emenda Constitucional nº 05, de 14/03/96 153

Emenda Constitucional nº 06, de 28/05/96 155

Emenda Constitucional nº 07, de 20/08/96 156

Emenda Constitucional nº 08, de 06/11/96 157

Emenda Constitucional nº 09, de 28/08/97 158

Emenda Constitucional nº 10, de 19/12/97 159

Emenda Constitucional nº 11, de 20/11/98 160

Emenda Constitucional nº 12, de 24/09/09 161

Emenda Constitucional nº 13, de 29/09/09 162

Emenda Constitucional nº 14, de 20/12/99 163

Emenda Constitucional nº 15, de 24/05/00 172

Emenda Constitucional nº 16, de 20/06/00 173

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 4

Emenda Constitucional nº 17, de 03/07/00 174

Emenda Constitucional nº 18, de 04/07/00 175

Emenda Constitucional nº 19, de 22/11/00 176

Emenda Constitucional nº 20, de 12/12/00 177

Emenda Constitucional nº 21, de 12/12/00 179

Emenda Constitucional nº 22, de 18/01/01 180

Emenda Constitucional nº 23, de 18/01/01 182

Emenda Constitucional nº 24, de 15/08/01 183

Emenda Constitucional nº 25, de 03/10/01 184

Emenda Constitucional nº 26, de 27/02/02 185

Emenda Constitucional nº 27, de 09/09/02 186

Emenda Constitucional nº 28, de 27/12/02 187

Emenda Constitucional nº 29, de 27/12/02 188

Emenda Constitucional nº 30, de 29/04/03 189

Emenda Constitucional nº 31, de 07/05/03 190

Emenda Constitucional nº 32, de 23/03/04 192

Emenda Constitucional nº 33, de 30/03/05 193

Emenda Constitucional nº 34, de 01/02/04 194

Emenda Constitucional nº 35, de 21/03/96 195

Emenda Constitucional nº 36, de 08/08/06 222

Emenda Constitucional nº 37, de 04/06/07 224

Emenda Constitucional nº 38, de 05/06/07 225

Emenda Constitucional nº 39, de 11/09/07 226

Emenda Constitucional nº 40, de 04/03/08 227

Emenda Constitucional nº 41, de 27/05/08 228

Emenda Constitucional nº 42, de 30/06/09 229

Emenda Constitucional nº 43, de 30/06/09 231

Emenda Constitucional nº 44, de 21/12/09 233

Emenda Constitucional nº 45, de 27/06/12 234

Emenda Constitucional nº 46, de 03/07/12 235

Emenda Constitucional nº 47, de 03/07/12 236

Emenda Constitucional nº 48, de 13/10/14 238

Emenda Constitucional nº 49, de 22/12/14 239

Emenda Constitucional nº 50, de 30/12/14 240

Emenda Constitucional nº 51, de 31/12/14 242

Emenda Constitucional nº 52, de 24/08/15 243

Emenda Constitucional nº 53, de 24/08/15 246

Emenda Constitucional nº 54, de 12/04/17 247

Emenda Constitucional nº 55, de 03/05/17 248

Emenda Constitucional nº 56, de 03/05/17 249

Emenda Constitucional nº 57, de 19/12/17 250

Emenda Constitucional nº 58, de 27/11/18 252

Emenda Constitucional nº 59, de 29/10/19 253

Emenda Constitucional nº 60, de 19/12/19 255

Emenda Constitucional nº 61, de 04/03/20 257

Emenda Constitucional nº 62, de 30/04/20 259

Emenda Constitucional nº 63, de 31/08/21 260

Emenda Constitucional nº 64, de 31/03/22 261

Emenda Constitucional nº 65, de 30/08/22 262

Emenda Constitucional nº 66, de 20/12/22 263

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 5

Emenda Constitucional nº 67, de 25/10/23 265

Emenda Constitucional nº 68, de 11/04/24 266

Emenda Constitucional nº 69, de 12/06/24 268

Emenda Constitucional nº 70, de 12/06/24 270

Emenda Constitucional nº 71, de 17/06/25 271

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 6

Nota da Secretaria Legislativa

As alterações decorrentes das Emendas Constitucionais já estão incorporadas ao texto principal. Ao final do caput dos artigos alterados, estão informadas, entre parênteses, as Emendas modificadoras.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 7

“Feliz a nação cujo Deus é o Senhor, e o povo que Ele escolheu para sua herança.” (Salmo 33, versículo 12)

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 8

CONSTITUIÇÃO DO ESTADO DO AMAPÁ

PREÂMBULO

Nós, os primeiros Deputados Estaduais, representantes do povo amapaense, reunidos em Assembleia Estadual Constituinte para instituir o ordenamento básico e reafirmar os valores que fundamentam os objetivos e princípios da Constituição da República Federativa do Brasil, invocando a proteção de Deus, inspirados no ideal de a todos garantir justiça, liberdade e bem estar, promulgamos a CONSTITUIÇÃO DO ESTADO DO AMAPÁ.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 9

### TÍTULO I Dos Princípios Fundamentais

**Art. 1º** O Estado do Amapá, integrante da República Federativa do Brasil, rege-se por esta Constituição e pelas leis que adotar, nos limites de sua autonomia e do território sob sua jurisdição.

**Art. 1º** O Estado do Amapá, integrante da República Federativa do Brasil, rege-se por esta Constituição e pelas Leis que adotar, observado os princípios da Constituição Federal, nos limites de sua autonomia e no território sob sua jurisdição. (redação dada pela Emenda Constitucional nº 14, de 20.12.1999)

**§ 1º** Todo o poder emana do povo e será exercido por seus representantes eleitos, ou diretamente, nos termos da Constituição Federal e desta Constituição.

**§ 2º** São Poderes do Estado, independentes e harmônicos entre si, o Legislativo, o Executivo e o Judiciário.

**§ 3º** Salvo as exceções previstas nesta Constituição é vedado a qualquer dos Poderes delegar atribuições, e quem for investido na função de um deles não poderá exercer a de outro.

**Art. 2º** São princípios fundamentais do Estado, dentre outros constantes, expressa ou implicitamente na Constituição Federal, os seguintes:

I - o respeito à unidade da Federação, a esta Constituição, à Constituição Federal e à inviolabilidade dos direitos e garantias fundamentais por elas estabelecidos;

II - a defesa dos direitos humanos;

III - defesa da igualdade;

IV - respeito à moralidade e à probidade administrativas;

IV - respeito aos princípios da legalidade, impessoalidade, moralidade, publicidade e eficiência; (redação dada pela Emenda Constitucional nº 14, de 20.12.1999)

V - separação e livre exercício dos Poderes;

VI - autonomia municipal;

VII - a defesa do meio ambiente e da qualidade da vida;

VIII - garantia da aplicação da justiça e da distribuição de rendas;

IX - nos processos administrativos, qualquer que seja seu objeto, observar-se-ão, entre outros requisitos de validade, a igualdade entre os administradores, presteza nas decisões e o devido processo legal e especialmente quanto à exigência da publicidade, do contraditório, da ampla defesa e do despacho sempre fundamentado;

X - erradicar a pobreza e reduzir as desigualdades sociais e regionais. (incluído pela Emenda Constitucional n. 69, de 12.06.2024)

**Art. 3º** A soberania popular será exercida pelo sufrágio universal e pelo voto direto e secreto, nos termos desta Constituição e da Lei, mediante: (revogado pela

Emenda Constitucional nº 35, de 21.03.2006)

I - plebiscito; CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 10

II - referendo;

III - iniciativa popular. TÍTULO II

Direitos e Garantias Fundamentais

#### CAPÍTULO I Dos Direitos e Deveres Individuais e Coletivos

**Art. 4º** É mantida a integridade territorial do Estado, que só poderá ser alterada mediante aprovação de sua população, por meio de plebiscito, e por lei complementar federal.

**Art. 4º** É mantida a integridade territorial do Estado do Amapá que só poderá ser alterada mediante aprovação de sua população, através de plebiscito, e pelo Congresso Nacional, por lei complementar. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

**Art. 5º** Todos são iguais perante a lei, sem distinção de qualquer natureza, garantindo-se aos brasileiros e aos estrangeiros residentes no Estado a inviolabilidade do direito à vida, à liberdade, à igualdade, à segurança e à propriedade, nos termos da Constituição Federal e nos seguintes:

**Art. 5º** Todos são iguais perante a lei, sem distinção de qualquer natureza, nos termos do art. 5º da Constituição Federal: (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

I - ninguém será privado do exercício de direito à saúde e à educação, ou por ele prejudicado, nem dos serviços essenciais à saúde e à educação;

II - as autoridades competentes são obrigadas a tomar providências imediatas a pedido de quem sofra ameaça à vida, à liberdade ou ao patrimônio, sob pena de responsabilidade;

III - as autoridade competentes garantirão a livre reunião e as manifestações pacíficas, individuais e coletivas;

IV - ninguém será prejudicado, discriminado ou sofrerá restrição ao exercício de atividade ou prática de ato legítimo, em razão de litígio ou denúncia contra agentes do Poder Público;

V - a proteção do consumidor será promovida pelo Estado, através da implantação de sistema de defesa de seus direitos, na forma da lei;

VI - serão gratuitos para os comprovadamente pobres, na forma da lei:

a) os registros civis de nascimento e óbito, bem como as respectivas certidões;

b) a expedição de carteira de identidade.

VII - cabe ao Estado propiciar assistência jurídica gratuita e defensor aos necessitados, na forma da lei;

VIII - constitui infração disciplinar, punível com a pena de demissão a bem do serviço público, a prática de violência, tortura ou coação contra o cidadão, pelos agentes do Poder Público;

IX - qualquer cidadão poderá apresentar queixa à autoridade policial civil ou militar que promover atos que atentem contra a integridade física ou moral das pessoas, sendo obrigatória a apuração dos fatos e das responsabilidades decorrentes, no prazo de sessenta dias, a partir da data da denúncia;

IX - qualquer cidadão poderá apresentar queixa à autoridade policial civil, penal ou militar que promover atos que atentem contra a integridade física ou moral das pessoas, sendo obrigatória a apuração dos fatos e das responsabilidades

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 11

decorrentes, no prazo de sessenta dias, a partir da data da denúncia; (redação dada pela

Emenda Constitucional nº 61, de 04.03.2020)

X - as delegacias, penitenciárias, estabelecimentos prisionais e casas de recolhimento compulsório, de qualquer natureza, sob pena de responsabilidade de seus diligentes, manterão livro de registro, contendo integral relação dos internos;

XI - qualquer pessoa processada ou submetida à prisão terá o direito de:

a) comunicar-se com a família ou pessoa que indicar;

b) permanecer calado;

c) ter assistência da família e de advogado;

d) identificar os responsáveis pela sua condução.

XII - é livre a expressão da atividade intelectual, artística, científica e de comunicação, independentemente de censura e licença;

XIII - ninguém será internado compulsoriamente, em razão de doença mental, salvo em casos excepcionais definidos em parecer médico, e pelo prazo máximo de quarenta e oito horas, findo o qual só se dará a permanência mediante a determinação judicial;

XV - é assegurado o livre exercício dos cultos religiosos e garantida à proteção aos locais de cultos e ás suas liturgias;

XVI - é livre o acesso de ministros e de membros de confissão religiosa para a prestação de assistência espiritual nas entidades civis e militares de internação coletiva.

XVI - é livre o acesso de Ministros e de membros de confissão religiosa para a prestação de assistência espiritual nas entidades civis e militares de internação coletiva, respeitada a proporcionalidade confessional, vedadas todas as formas de proselitismo e atos que possam incomodar os outros internos. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

#### CAPÍTULO II Dos Direitos Políticos e Sociais (incluído pela Emenda Constitucional nº 35, de 21.03.2006)

**Art. 5º-A** A soberania popular, no âmbito do Estado do Amapá, será exercida pelo sufrágio universal e pelo voto direto e secreto, com valor igual para todos, e, nos termos da lei, mediante:

I - plebiscito;

II - referendo;

III - iniciativa popular.

**Art. 5º-B** Através de plebiscito o eleitorado se manifestará, especificamente, sobre fato, medida, decisão política, programa ou obra pública e, pelo referendo, sobre emenda à Constituição, sobre lei e sobre projetos de emenda à Constituição e de lei.

**§ 1º** Podem requerer plebiscito ou referendo:

I - um por cento do eleitorado estadual;

II - o Governador do Estado;

III - um terço, pelo menos, dos membros da Assembleia Legislativa.

**§ 2º** A realização de plebiscito ou referendo depende de aprovação da maioria absoluta dos membros da Assembleia Legislativa.

**§ 3º** A decisão do eleitorado, através de plebiscito ou referendo, será válida quando tomada por maioria de votos, desde que tenha votado mais da metade do eleitorado estadual e, tratando-se de emenda a esta Constituição, quando tomada por maioria absoluta de votos, não computados os em branco e os nulos.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 12

**§ 4º** Convocado o plebiscito ou referendo, o Presidente da Assembleia Legislativa dará ciência à Justiça Eleitoral, a qual caberá, nos limites de sua circunscrição, adotar as medidas necessárias a sua realização.

**Art. 5º-C** A iniciativa popular será exercida na forma dos arts. 103, IV e 110 desta Constituição.

**Parágrafo único.** Os projetos de emenda à Constituição e de lei, apresentados mediante iniciativa popular, terão inscrição prioritária na Ordem do Dia da Assembleia Legislativa, no prazo de quarenta e cinco dias de seu recebimento, garantindo-se sua defesa em Plenário por qualquer dos cidadãos que o tiverem subscrito.

**Art. 5º-D** São direitos sociais a educação, a saúde, o trabalho, a moradia, o lazer, a segurança, a previdência social, a proteção à maternidade e à infância, a assistência aos desamparados, na forma da Constituição Federal e desta Constituição.

**Art. 5º-E** Fica assegurada a presença da sociedade civil, na forma da lei, por meio de suas entidades representativas, nos Conselhos Estaduais e demais órgãos de composição colegiada, de caráter deliberativo, consultivo, normativo e fiscalizador.

**Parágrafo único.** O orçamento do Estado alocará para cada Secretaria Estadual os recursos necessários para o custeio das atividades dos respectivos Conselhos.

**§ 1º** O orçamento do Estado alocará para cada Secretaria Estadual os recursos necessários para o custeio das atividades dos respectivos conselhos. (anterior parágrafo único, transformado em § 1º pela Emenda Constitucional n. 65, de 30.08.2022)

**§ 2º** O disposto no parágrafo anterior não se aplica: (incluído pela Emenda Constitucional n. 65, de 30.08.2022)

I - Ao Conselho Estadual de Educação que, na forma da lei, será entidade autônoma e se constituirá em uma unidade orçamentária e de despesa, vinculada diretamente ao Governador. (incluído pela Emenda Constitucional n. 65, de 30.08.2022)

II - Aos conselhos vinculados à Secretaria de Estado da Educação que, na forma da lei, poderão se constituir, individualmente, em unidades orçamentárias e de despesas. (incluído pela Emenda Constitucional n. 65, de 30.08.2022)

### TÍTULO III Da Organização do Estado e Municípios

#### CAPÍTULO I Do Estado

##### SEÇÃO I Das Disposições Preliminares

**Art. 6º** A organização político-administrativa do Estado compreende os Municípios, regidos por Leis Orgânicas próprias, observados os princípios da Constituição Federal e os desta Constituição.

**Art. 7º** A cidade de Macapá é a Capital do Estado e nela os Poderes têm sua sede.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 13

**Parágrafo único.** O Governador, com autorização da Assembleia Legislativa, poderá decretar a transferência da Capital, temporariamente, para outra cidade do território do Estado.

**Art. 8º** São símbolos do Estado, a bandeira, o hino e o brasão, adotados à data da promulgação desta constituição.

##### SEÇÃO II Dos Bens do Estado

**Art. 9º** São bens do Estado, na forma disposta pela Constituição Federal:

I - as terras devolutas situadas em seu território não compreendidas entre as da União;

II - os rios de curso exclusivo no território do Estado;

III - as águas superficiais ou subterrâneas, fluentes, emergentes e em depósito, ressalvadas, neste caso, na forma da lei, as decorrentes de obras da União;

IV - as ilhas fluviais e lacustres não pertencentes à União;

V - as áreas, nas ilhas oceânicas e costeiras, que estiverem sob seu domínio, excluídas aquelas sob domínio da União, dos Municípios ou de terceiros;

VI - os terrenos marginais dos rios e lagos navegáveis que corram ou fiquem situados em seu território;

VII - os terrenos marginais dos rios que, ainda que não navegáveis, contribuam com suas águas para tornar outros navegáveis;

VIII - os bens que atualmente lhe pertencem e os que lhe vierem a ser atribuídos;

IX - as terras dos extintos aldeamentos indígenas;

X - os inventos e a criação intelectual surgidos sob remuneração ou custeio público estadual, direto ou indireto.

**Parágrafo único.** A alienação, gratuita ou onerosa, e a concessão de bens imóveis do Estado do Amapá dependerão de prévia autorização da Assembleia Legislativa. (incluído pela Emenda Constitucional nº 35, de 21.03.2006)

##### SEÇÃO III Da Competência do Estado

**Art. 10.** O Estado exerce, em seu território, toda a competência que não lhe seja vedada pela Constituição Federal.

**Art. 11.** Compete ao Estado, em comum com a União e Municípios:

I - zelar pela guarda desta Constituição, das leis e das instituições democráticas e conservar o patrimônio público;

II - cuidar da saúde e assistência pública, da proteção e garantia das pessoas portadoras de deficiência;

III - proteger os documentos, as obras e outros bens de valor histórico artístico e cultural, os monumentos, as paisagens naturais notáveis e os sítios arqueológicos;

IV - impedir a evasão, a destruição, e a descaracterização de obras de arte e de outros bens de valor histórico ou cultural;

V - proporcionar à população meios de acesso à cultura, à educação e à ciência;

VI - combater as causas da pobreza e os fatores da marginalização com vistas a promover a integração social e a emancipação econômica dos carentes;

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 14

VII - registrar, acompanhar e fiscalizar as concessões de direitos de pesquisa e exploração de recursos hídricos e minerais em seu território;

VIII - proteger o meio ambiente e combater a poluição em qualquer de suas formas;

IX - preservar as florestas, a fauna e a flora;

X - fomentar a produção agropecuária e organizar o abastecimento de alimentos básicos;

XI - promover programas de construção de moradias e a melhoria das condições habitacionais e de saneamento básico;

XII - cooperar com os demais Estados e Municípios da Região Amazônica e da União, na preservação do sistema ecológico, das riquezas naturais da região e da soberania nacional;

XIII - estabelecer e implantar políticas de educação para a segurança do trânsito;

**Art. 12.** Compete ao Estado legislar sobre:

I - sistema tributário estadual, instituição de impostos, taxas e contribuições de melhorias;

II - orçamento, diretrizes orçamentárias, plano plurianual, operações de crédito, dívida pública e empréstimos externos, a qualquer título, pelo Poder Executivo;

III - juntas comerciais;

IV - custas dos serviços forenses;

V - produção e consumo;

VI - florestas, caça, pesca, fauna, conservação da natureza, defesa do solo e dos recursos naturais, proteção ao meio ambiente e controle da poluição;

VII - proteção do patrimônio histórico, cultural, turístico e paisagístico;

VIII - responsabilidade por danos ao meio ambiente, ao consumidor e a bens e direitos de valor artístico, estético, histórico, turístico e paisagístico;

IX - educação, cultura, ensino e desporto;

X - criação, composição e funcionamento dos juizados especiais das pequenas causas cíveis e de infrações penais de menor potencial ofensivo, observado o disposto no art. 98, I, da Constituição Federal;

XI - procedimentos em matéria processual;

XII - previdência social, proteção e defesa da saúde;

XIII - assistência jurídica e defensoria pública;

XIV - proteção e integração social dos portadores de deficiência;

XV - proteção à infância e à juventude;

XVI - organização, garantias, direitos e deveres da polícia civil;

XVI - organização, garantias, direitos e deveres da polícia civil e da polícia penal; (redação dada pela Emenda Constitucional nº 61, de 04.03.2020)

XVII - criação e extinção de Secretárias de Estado;

XVIII - organização administrativa do Ministério Público, da Defensoria Pública e da Procuradoria-Geral do Estado.

**§ 1º** O Estado, no exercício de sua competência suplementar, observará as normas gerais estabelecidas pela União.

**§ 2º** Inexistindo lei federal sobre norma geral, o Estado poderá exercer competência legislativa plena para atender às suas peculiaridades.

**§ 3º** A superveniência de lei federal sobre norma geral suspende a eficácia da lei estadual sobre a mesma matéria, no que com ela for incompatível.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 15

**§ 4º** O Estado poderá celebrar contratos e convênios com entidades de direito público e privado.

#### CAPÍTULO II Dos Municípios

##### SEÇÃO I Disposições Gerais

**Art. 13.** Os Municípios gozam de autonomia, nos termos assegurados pela Constituição Federal, por esta Constituição, e reger-se-ão por sua respectiva Lei Orgânica.

**Parágrafo único.** A Lei Orgânica do Município será votada em dois turnos, com interstício mínimo de dez dias, e aprovada por dois terços dos membros da Câmara Municipal, que a promulgará.

**Art. 14.** Os Municípios, por meio de lei municipal, poderão dividir-se em distritos e estes em subdistritos, atendidos os requisitos previstos em lei complementar, garantida a participação popular.

**Art. 15.** Para execução de suas leis, serviços ou decisões, os Municípios poderão celebrar convênios com a União, o Estado ou outros Municípios.

**Art. 16.** Os Municípios que não possuírem sistema previdenciário próprio poderão vincular-se ao sistema previdenciário estadual, nos termos da lei, ou associar-se a outros Municípios para tal fim.

**Art. 16.** Os Municípios poderão instituir regime próprio de previdência para seus servidores, observados os princípios e normas estabelecidos pela Constituição Federal e por esta Constituição. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

##### SEÇÃO II Da Competência dos Municípios

**Art. 17.** Compete aos municípios:

I - legislar sobre assuntos de interesse local;

II - suplementar a legislação federal e a estadual, no que couber;

III - instituir e arrecadar os tributos de sua competência, bem como aplicar suas rendas, com a obrigação de prestar contas e publicar balancetes nos prazos fixados em lei;

IV - adquirir bens, inclusive por meio de desapropriação por necessidade ou por utilidade pública, nos termos da legislação federal;

V - organizar e prestar, diretamente ou sob regime de concessão ou permissão, os serviços públicos de interesse local, incluído o de transporte coletivo, que tem caráter essencial e que poderá ser explorado, se diretamente, por empresa pública ou sociedade de economia mista, submetidas ao regime jurídico das empresas privadas;

V - organizar e prestar, diretamente ou sob regime de concessão ou permissão, os serviços públicos de interesse local, incluído o de transporte coletivo que tem caráter essencial, o de táxi convencional e o transporte alternativo de moto- táxi, que poderão ser explorados diretamente, por empresas públicas, sociedade de economia mista ou entidade de classe, submetidas ao regime jurídico das empresas privadas; (redação dada pela Emenda Constitucional nº 14, de 20.12.1999)

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 16

VI - manter, com a cooperação técnica e financeira da União e do Estado, programas de educação pré-escolar e de ensino fundamental;

VII - prestar, com a cooperação técnica e financeira da União e do Estado, serviços de atendimento à saúde da população;

VIII - promover, no que couber, adequado ordenamento territorial local, mediante planejamento e controle do uso, do parcelamento e da ocupação do solo urbano;

IX - promover a proteção do patrimônio histórico-cultural local, observada a legislação e a ação fiscalizadora federal e estadual;

X - garantir a defesa do meio ambiente e da qualidade de vida, no âmbito de seu território;

XI - instituir fundos municipais de desenvolvimento para executar as funções públicas de interesse comum;

XII - criar, através de lei, guardas municipais destinadas à proteção de seus bens, serviços, instalações e fiscalização das atividades que envolvam o meio ambiente, respeitadas as competências estadual e federal;

XII - constituir guardas municipais destinadas à proteção de seus bens, serviços e instalações, conforme dispuser a lei, bem como a colaborar com o Estado no policiamento ostensivo e preventivo, de acordo com disposições legais e acordos estabelecidos, respeitadas as competências federal e estadual; (redação dada pela

Emenda Constitucional nº 35, de 21.03.2006)

XIII - criar, organizar e manter o Arquivo Público Municipal.

XIV - conceder, com a colaboração técnica e financeira de entidades representativas do transporte coletivo, transporte gratuito a estudantes de estabelecimentos de ensino situado no Município, na forma da lei. (incluído pela Emenda Constitucional nº 14, de 20.12.1999)

XIV - garantir, com a colaboração técnica e financeira do Estado, gratuidade nos transportes coletivos urbanos aos estudantes dos estabelecimentos de ensino situados nas sedes municipais, na forma estabelecida em lei complementar. (redação dada pela Emenda Constitucional nº 32, de 23.03.2004)

##### SEÇÃO III Da Câmara Municipal

**Art. 18.** O Poder Legislativo, nos Municípios, é exercido pela Câmara Municipal, composta de Vereadores eleitos pelo povo para mandato de quatro anos, observado o disposto no art. 29 da Constituição Federal.

**Art. 19.** A administração financeira da Câmara Municipal será exercida pela Mesa Executiva, conforme a Lei Orgânica do Município.

**Art. 19.** O total da despesa do Poder Legislativo Municipal, incluídos os subsídios dos Vereadores e excluídos os gastos com inativos, não poderá ultrapassar os percentuais previstos nos incisos I a IV do art. 29-A da Constituição Federal, relativos ao somatório da receita tributária e das transferências previstas no § 5º do

art. 153 e nos arts. 158 e 159, efetivamente realizado no exercício anterior. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

**Parágrafo único.** A Câmara Municipal não gastará mais de 70% (setenta por cento) de sua receita com folha de pagamento, incluído o gasto com o subsídio de seus Vereadores. (incluído pela Emenda Constitucional nº 35, de 21.03.2006)

**Art. 20.** Mediante requerimento de um terço de seus membros, a Câmara Municipal poderá criar Comissão Parlamentar de Inquérito para apurar fato determinado, por prazo definido, com poderes de investigação próprios das

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 17

autoridades judiciais, além de outros previstos na Lei Orgânica respectiva, sendo suas conclusões encaminhadas ou não ao Ministério Público, para que este promova a responsabilidade civil ou criminal dos infratores.

**Art. 20.** Mediante requerimento de um terço de seus membros, a Câmara Municipal poderá criar Comissão Parlamentar de Inquérito para apurar fato determinado, por prazo definido, com poderes de investigação próprios das autoridades judiciais, além de outros previstos na Lei Orgânica respectiva, sendo suas conclusões encaminhadas ou não ao Ministério Público, para que este promova a responsabilidade civil ou criminal dos infratores.

**Parágrafo único.** Compete à Câmara Municipal processar e julgar originariamente o Prefeito nos crimes de responsabilidade. (incluído pela Emenda Constitucional nº 35, de 21.03.2006)

**Art. 21.** As contas da Mesa Executiva da Câmara Municipal, após o parecer prévio emitido pelo Tribunal de Contas do Estado, serão apreciadas pelo plenário da Câmara Municipal.

**Art. 21.** As contas da Mesa Diretora das Câmaras Municipais serão julgadas pelo Tribunal de Contas do Estado. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

**Art. 22.** As contas dos Municípios ficarão, durante sessenta dias, anualmente, à disposição de qualquer contribuinte, para exame e apreciação, que poderá questionar-lhes a legitimidade, nos termos da lei.

**Art. 23.** Os Vereadores estão sujeitos às mesmas proibições e incompatibilidades previstas nesta Constituição para os membros da Assembleia Legislativa, no que couber, observado o previsto no art. 38, inciso III, da Constituição Federal.

**Art. 24.** Os recursos correspondentes às dotações orçamentárias, compreendidos os créditos suplementares e especiais, destinados ao Poder Legislativo municipal, ser-lhe-ão entregues até o dia vinte de cada mês.

**Art. 24.** Os recursos correspondentes às dotações previstas no orçamento anual, compreendidos os créditos suplementares e especiais, destinadas ao Poder Legislativo Municipal, ser-lhes-ão entregues até o dia vinte de cada mês, sob pena de crime de responsabilidade do Prefeito Municipal. (redação dada pela Emenda Constitucional nº 14, de 20.12.1999)

**Art. 25.** A fiscalização do Município será exercida pelo Poder Legislativo Municipal, mediante controle externo, e pelos sistemas de controle interno do Poder Executivo Municipal, na forma da lei.

**§ 1º** O controle externo da Câmara Municipal será exercido com o auxílio do Tribunal de Contas do Estado.

**§ 1º** O controle externo, a cargo da Câmara Municipal, será exercido com o auxílio do Tribunal de Contas. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

**§ 2º** O parecer prévio, emitido pelo Tribunal de Contas do Estado, sobre as contas que o Prefeito de anualmente prestar, somente deixará de prevalecer por decisão de dois terços da Câmara Municipal.

**§ 3º** É vedada a criação de Tribunais, Conselhos ou órgãos de contas municipais.

**Art. 26.** A remuneração do Prefeito, do Vice-Prefeito e dos Vereadores será fixada antes da data das eleições do último ano de uma legislatura, para vigorar na subsequente, observado o disposto na Constituição Federal.

**Art. 26.** Os subsídios do Prefeito, do Vice-Prefeito e dos Secretários Municipais serão fixados por lei de iniciativa da Câmara Municipal, observado o que

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 18

dispõe os Arts. 42, XI, 47, § 4º, desta Constituição e os Arts. 150, II,153, II e 153, § 2º, I da constituição Federal. (redação dada pela Emenda Constitucional nº 14, de 20.12.1999)

**Art. 26.** Os subsídios do Prefeito, do Vice-Prefeito e dos Secretários Municipais serão fixados por lei de iniciativa da Câmara Municipal, observado o que dispõem os arts. 42, XI e 47, § 4º desta Constituição e os arts. 150, II, 153, III e 153,

§ 2º, I da Constituição Federal. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

**§ 1º** Não tendo sido fixada a remuneração na legislatura anterior, ficam mantidos os valores vigentes em dezembro do último ano da legislatura anterior, permitido o reajuste equivalente ao que for concedido ao funcionalismo municipal.

**§ 1º** Os subsídios dos Vereadores serão fixados por lei de iniciativa da Câmara Municipal, nos limites estabelecidos pela Constituição Federal. (redação dada pela Emenda Constitucional nº 14, de 20.12.1999)

**§ 1º** O subsídio dos vereadores será fixado por lei de iniciativa das respectivas Câmaras Municipais, observado o que dispõe a Constituição Federal, os critérios estabelecidos na respectiva Lei Orgânica e os limites máximos fixados no inciso VI do art. 29 da Constituição Federal. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

**§ 2º** Tratando-se de Município novo, a primeira remuneração será fixada pela Câmara Municipal.

**§ 2º** A remuneração dos servidores municipais e os subsídios a que trata este artigo, somente poderão ser fixados ou alterados por Lei específica, observada iniciativa privativa em cada caso, assegurada revisão geral anual, sempre na mesma data e sem distinção de índices. (redação dada pela Emenda Constitucional nº 14, de 20.12.1999)

**§ 2º** A lei a que se referem o caput deste artigo e o § 1º deverá ser aprovada e publicada antes da data das eleições municipais. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

**Art. 27.** As Câmaras Municipais terão o número de Vereadores proporcional à população do Município, observados os seguintes limites:

I - até vinte mil habitantes, nove Vereadores;

II - de vinte mil e um a sessenta mil habitantes, onze Vereadores;

III - de sessenta mil e um a cento e vinte mil habitantes, treze Vereadores;

IV - de cento e vinte mil e um a duzentos mil habitantes, quinze Vereadores

V - de duzentos mil e um a quatrocentos mil habitantes, dezessete Vereadores;

VI - de quatrocentos mil e um a oitocentos mil habitantes, dezenove Vereadores;

VII - de oitocentos mil e um a um milhão de habitantes, vinte e um Vereadores;

VIII - acima de um milhão de habitantes, trinta e três vereadores.

**Art. 27.** As Câmaras municipais terão o número de Vereadores proporcional à população do Município, observados os seguintes limites: (redação dada pela Emenda Constitucional nº 14, de 20.12.1999)

**Art. 27.** O número de Vereadores das Câmaras Municipais será fixado nas respectivas Leis Orgânicas proporcionalmente à população do Município, observados os limites estabelecidos no inciso IV do art. 29 da Constituição Federal. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

I - até dez mil habitantes, nove Vereadores; (redação dada pela Emenda Constitucional nº 14, de 20.12.1999)

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 19

II - de dez mil e um a vinte mil habitantes, onze Vereadores; (redação dada pela Emenda Constitucional nº 14, de 20.12.1999)

III - de vinte mil e um a trinta mil habitantes, treze Vereadores; (redação dada pela Emenda Constitucional nº 14, de 20.12.1999)

IV - de trinta mil e um a cem mil habitantes, quinze Vereadores; (redação dada pela Emenda Constitucional nº 14, de 20.12.1999)

V - de cinquenta mil e um a cem mil habitantes, dezessete Vereadores; (redação dada pela Emenda Constitucional nº 14, de 20.12.1999)

VI - de cem mil e um a duzentos e cinquenta mil habitantes, dezenove Vereadores; (redação dada pela Emenda Constitucional nº 14, de 20.12.1999)

VII - de duzentos e cinquenta mil e um a um milhão de habitantes, vinte e um Vereadores; (redação dada pela Emenda Constitucional nº 14, de 20.12.1999)

**Parágrafo único.** O aumento do número de vagas de que trata este artigo, não implicará em aumento dos percentuais constitucionais devido às Câmaras Municipais. (incluído pela Emenda Constitucional nº 14, de 20.12.1999)

##### SEÇÃO IV Do Prefeito e do Vice-Prefeito

**Art. 28.** O Poder Executivo Municipal é exercido pelo Prefeito e Vice- Prefeito, auxiliados pelos secretários ou diretores municipais.

**Art. 29.** O Prefeito e o Vice-Prefeito tomarão posse perante a Câmara Municipal e prestarão o compromisso de defender, cumprir e fazer cumprir a Constituição Federal, a Estadual, e Lei Orgânica respectiva e as leis inerentes ao Município.

**§ 1º** Se a Câmara não estiver instalada ou deixar de reunir-se para esse efeito, o Prefeito e o Vice-Prefeito tomarão posse, dentro dos quinze dias subsequentes à data fixada para esta, perante o juiz de direito mais antigo da comarca ou de seu substituto legal.

**§ 2º** Se, decorrido esse prazo, o Prefeito ou Vice-Prefeito, salvo motivo de força maior, não tiver assumido o cargo, este será declarado vago pela Câmara Municipal.

**Art. 30.** O Prefeito será substituído, no caso de impedimento, e sucedido, no de vaga, pelo Vice-Prefeito.

**Parágrafo único.** No caso de impedimento do Prefeito e do Vice-Prefeito ou vacância dos respectivos cargos, serão chamados a ocupar o cargo, sucessivamente, o Presidente da Câmara Municipal e o juiz de direito mais antigo da comarca.

**Art. 31.** Vagando os cargos de Prefeito e Vice-Prefeito, far-se-á nova eleição noventa dias após aberta a última vaga.

**Parágrafo único.** Ocorrendo vacância de ambos os cargos no último ano do mandato, o cargo será exercido pelo Presidente da Câmara Municipal.

**§ 1º** Ocorrendo a vacância nos últimos dois anos do mandato do Prefeito, a eleição para ambos os cargos será feita trinta dias depois da última vaga, pela Câmara Municipal, na forma da lei. (incluído pela Emenda Constitucional nº 14, de 20.12.1999)

**§ 2º** Em qualquer dos casos, os substitutos deverão completar o período de seus antecessores. (incluído pela Emenda Constitucional nº 14, de 20.12.1999)

**Art. 32.** O Prefeito e o Vice-Prefeito residirão no Município e dele não poderão se ausentar durante o exercício do mandato, salvo se a ausência não ultrapassar quinze dias, exigindo-se licença prévia da Câmara Municipal para viagem ao exterior por qualquer tempo.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 20

**Art. 33.** As proibições e incompatibilidades dos Vereadores aplicam-se no que couber, ao Prefeito e ao Vice-Prefeito.

**Art. 34.** São crimes de responsabilidade os atos do Prefeito que atentem contra as Constituições Federal e do Estado, a Lei Orgânica do Município e, especialmente, contra:

I - a existência do Município;

II - o livre exercício do Poder Legislativo estadual ou municipal, do Poder Judiciário e do Ministério Público;

III - o livre exercício dos direitos políticos, individuais e sociais;

IV - - a segurança interna do Município;

V - a probidade na administração;

VI - a Lei Orçamentária;

VII - o cumprimento das leis e das decisões judiciais.

**Art. 34.** Constitui crime de responsabilidade do Prefeito Municipal: (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

I - efetuar repasse que supere os limites definidos no art. 29 - A da Constituição Federal; (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

II - não enviar o repasse até o dia vinte de cada mês; ou (redação dada pela

Emenda Constitucional nº 35, de 21.03.2006)

III - enviá-lo a menor em relação à proporção fixada na Lei Orçamentária. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

**Parágrafo único.** Constitui crime de responsabilidade do Presidente da Câmara Municipal o desrespeito ao parágrafo único do art. 19 desta Constituição. (incluído pela Emenda Constitucional nº 35, de 21.03.2006)

##### SEÇÃO V Da Criação, Incorporação, Fusão e Desmembramento dos Municípios

**Art. 35.** Além de outras exigências previstas em lei complementar estadual, a criação, a incorporação, a fusão e o desmembramento de Municípios far- se-ão por lei estadual, obedecendo aos seguintes requisitos:

**Art. 35.** A criação, a incorporação, a fusão e o desmembramento de municípios far-se-á por lei estadual, dentro do período determinado por lei complementar federal, obedecendo aos seguintes requisitos: (redação dada pela Emenda Constitucional nº 14, de 20.12.1999)

I - consulta prévia, mediante plebiscito, aos eleitores domiciliados na área a ser incorporada, fundida ou desmembrada;

I - consulta prévia, mediante plebiscito, às populações dos municípios envolvidos, após divulgação dos estudos de viabilidade Municipal, apresentados e publicados na forma da lei; (redação dada pela Emenda Constitucional nº 14, de 20.12.1999)

II - preservação da continuidade e da unidade histórico-cultural do ambiente urbano;

III - não inclusão da área encravada no Município de origem.

**§ 1º** O procedimento de criação, incorporação, fusão e desmembramento de Municípios terá início mediante representação dirigida à Assembleia Legislativa, subscrita, no mínimo, por cem eleitores residentes e domiciliados nas áreas diretamente interessadas.

**§ 2º** O projeto de criação, incorporação, fusão e desmembramento de Municípios apresentará a área da unidade proposta em divisas claras, precisas e contínuas.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 21

**§ 3º** A aprovação prevista no inciso I deste artigo dar-se-á pelo voto da maioria simples, exigindo-se o comparecimento da maioria absoluta do eleitorado.

**§ 4º** Se o resultado do plebiscito for desfavorável à proposição, esta não poderá ser renovada na mesma legislatura.

**§ 5º** É vedada a criação de município inviabilizando economicamente o Município de origem.

**§ 6º** Nenhum Município será criado com denominação igual à de outro já existente no País.

**§ 7º** É defeso a denominação de Municípios com nomes de pessoa viva.

**§ 8º** O Plebiscito para criação de Município poderá ser realizado por ocasião da realização de eleição municipal, na forma disciplinada pelo Tribunal Regional Eleitoral. (incluído pela Emenda Constitucional nº 14, de 20.12.1999)

**Art. 36.** Quando da criação de Município, ficam asseguradas aos servidores municipais estáveis, que exerçam suas funções na área do Município criado, as seguintes prerrogativas:

I - direito de opção pelo quadro de servidores do Município desmembrado, garantida a irredutibilidade do salário e nível funcional;

II - manutenção, aos optantes, das vantagens fixas já adquiridas.

**Parágrafo único.** A Prefeitura do Município criará quadro de pessoal para absorver os servidores optantes.

##### SEÇÃO VI Da Intervenção

**Art. 37.** O Estado não intervirá nos Municípios, exceto quando:

I - deixar de ser paga, sem motivo de força maior, por dois anos consecutivos, a dívida fundada;

II - não forem prestadas contas devidas, na forma da lei;

III - não tiver sido aplicado o mínimo exigido da receita municipal na manutenção e desenvolvimento do ensino;

III - não tiver sido aplicado o mínimo exigido da receita municipal na manutenção e desenvolvimento do ensino e nas ações e serviços públicos de saúde; (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

IV - o Tribunal de Justiça do Estado der provimento à representação para assegurar a observância de princípios constantes nesta Constituição, ou para prover a execução de lei, de ordem ou de decisão judicial.

**Parágrafo único.** Durante o período da intervenção, a Lei Orgânica Municipal não poderá ser alterada, salvo se a intervenção for decretada em decorrência de fatos gerados pela ilegalidade ou inconstitucionalidade dela.

**Art. 38.** A decretação de intervenção dependerá:

I - nos casos dos incisos I, II e III do artigo anterior, de representação fundamentada da respectiva Câmara ou do Tribunal de Contas do Estado;

II - no caso do inciso IV, do artigo anterior, de solicitação do Tribunal de Justiça do Estado.

**§ 1º** A intervenção será decretada pelo Governador do Estado, de ofício, ou mediante solicitação da Câmara Municipal respectiva, aprovada por maioria absoluta de seus membros, ou do Tribunal de Contas do Estado.

**§ 2º** Decretada a intervenção, o Governador nomeará interventor, que assumirá seus encargos perante a Mesa da Câmara Municipal ou, se for o caso, perante a autoridade judiciária competente, mediante a prestação de juramento de

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 22

cumprir as Constituições Federal e Estadual, observando as leis e os limites do

decreto de intervenção.

**§ 3º** O decreto de intervenção, que especificará a amplitude, o prazo e as condições de sua execução e que, se couber, nomeará o interventor, será submetido à apreciação da Assembleia Legislativa, no prazo de vinte e quatro horas.

**§ 4º** Na hipótese do inciso IV, parte final, do artigo anterior, dispensada a apreciação pela Assembleia Legislativa, o decreto limitar-se-á a suspender a execução do ato impugnado, se essa medida bastar ao restabelecimento da normalidade.

**§ 5º** Cessados os motivos da intervenção as autoridades afastadas de seus cargos a estes voltarão, salvo impedimento legal, sem prejuízo da apuração de responsabilidade administrativa, civil e criminal decorrente de seus atos.

**§ 6º** O interventor, no prazo de trinta dias após a cessação da intervenção, prestará contas à Assembleia Legislativa, por intermédio do Governador do Estado, devendo o Tribunal de contas, conforme o caso, emitir parecer sobre as contas prestadas.

##### SEÇÃO VII Da Assistência aos Municípios

**Art. 39.** O Estado prestará assistência técnica e financeira aos Municípios, compatível com as políticas de desenvolvimento do Estado, definidas como prioridades no plano plurianual.

**§ 1º** A Polícia Militar poderá, por solicitação dos Municípios, incumbir-se da orientação e treinamento das respectivas guardas municipais, quando instituídas em lei, para a proteção de seus bens, serviços e instalações, além da defesa civil.

**§ 2º** O Estado prestará atendimento às localidades rurais e ribeirinhas, através de Unidades Móveis de Saúde.

**Art. 40.** O Estado, em colaboração com os Municípios, implantará bibliotecas públicas e espaços culturais, favorecendo o acesso e difusão da cultura, especialmente da amapaense.

**Art. 41.** O Estado implantará, na sede de cada Município, serviços básicos de saúde pública para atendimento da população.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 23

#### CAPÍTULO III Da Administração Pública

##### SEÇÃO I Disposições Gerais

**Art. 42.** A administração pública direta, indireta ou fundacional, de qualquer dos Poderes do Estado e dos Municípios, obedecerá aos princípios de legalidade, impessoalidade' moralidade, publicidade e, também, ao seguinte:

**Art. 42.** A administração pública direta e indireta de qualquer dos Poderes do Estado e dos Municípios, obedecerá aos princípios da legalidade, impessoalidade, moralidade, publicidade e eficiência e, também, o seguinte: (redação dada pela Emenda Constitucional nº 14, de 20.12.1999)

I - os cargos, empregos e funções públicas são acessíveis aos brasileiros que preencham os requisitos estabelecidos em lei;

I - os cargos, empregos e funções públicas são acessíveis aos brasileiros que preencham os requisitos estabelecidos em lei, assim como aos estrangeiros, na forma da Lei; (redação dada pela Emenda Constitucional nº 14, de 20.12.1999)

II - a investidura em cargo público depende de aprovação prévia, em concurso público de provas ou de provas e títulos, ressalvadas as nomeações para cargo em comissão, declarado em lei, de livre nomeação e exoneração;

II - a investidura em cargo ou emprego público depende de aprovação prévia em concurso público de provas ou de provas e títulos, de acordo com a natureza e a complexidade do cargo ou emprego, na forma prevista em lei, ressalvadas as nomeações para cargo em comissão declarado em lei de livre nomeação e exoneração; (redação dada pela Emenda Constitucional nº 14, de 20.12.1999)

III - o prazo de validade do concurso público será de até dois anos, prorrogável uma vez por igual período, e a nomeação do candidato aprovado obedecerá à respectiva ordem de classificação;

IV - durante o prazo improrrogável previsto no edital de convocação, o aprovado em concurso público de provas ou de provas e títulos será convocado com prioridade sobre novos concursados para assumir cargo ou emprego, na carreira;

V - os cargos em comissão e as funções de confiança serão exercidos, preferencialmente, por servidores ocupantes de cargo de carreira técnica ou profissional, nos casos e condições previstos em lei;

V - As funções de confiança, exercidas exclusivamente por servidores ocupantes de cargo efetivo, e os cargos em comissão, a serem preenchidos por servidores de carreira nos casos, condições e percentuais mínimos previstos em lei, destina-se apenas às atribuições de direção, chefia e assessoramento; (redação dada pela Emenda Constitucional nº 14, de 20.12.1999)

VI - é garantida ao servidor público civil a livre associação sindical;

VII - o direito de greve será exercido nos termos e nos limites definidos em lei complementar federal;

VII - o direito de greve será exercido nos termos e nos limites definidos em lei específica; (redação dada pela Emenda Constitucional nº 14, de 20.12.1999)

VIII - a lei reservará percentual dos cargos e empregos públicos para os portadores de deficiência, garantindo as adaptações necessárias para a sua participação nos concursos públicos, e definirá os critérios de sua admissão;

IX - a lei estabelecerá os casos de contratação por tempo determinado, para atender a necessidade temporária de excepcional interesse público;

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 24

X – revisão geral da remuneração dos servidores públicos, sem distinção de índices entre servidores civis e militares, far-se-á sempre na mesma data;

X - a remuneração dos servidores públicos estaduais e o subsídio de que trata o § 4º do Art. 47, somente poderão ser fixados ou alterados por lei específica, observada a iniciativa privativa em cada caso, assegurada revisão geral anual, sempre na mesma data e sem distinção de índices; (redação dada pela Emenda Constitucional nº 14, de 20.12.1999)

X - a remuneração dos servidores públicos estaduais e o subsídio de que trata o § 4º do art. 47, somente poderão ser fixados ou alterados por lei específica, observada a iniciativa privativa em cada caso, assegurada revisão geral anual, sempre no dia 1º do mês de abril e sem distinção de índices; (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

XI - a lei fixara o limite máximo e a relação de valores entre a maior e menor remuneração dos servidores públicos observados, como limites máximos e no âmbito dos respectivos Poderes, os valores percebidos como remuneração em espécie a qualquer titulo, por membros dos Poderes Legislativo, Judiciário Procurador-Geral de Justiça e Secretários de Estado;

XI - a remuneração e o subsídio dos ocupantes de cargos, funções e empregos públicos da administração direta, autárquica e fundacional, dos membros de qualquer dos Poderes do Estado e dos Municípios, dos detentores de mandato eletivo e dos demais agentes políticos e os proventos, pensões ou outra espécie remuneratória, percebidos cumulativamente ou não, incluídas as vantagens pessoais ou de qualquer outra natureza, não poderão exceder o subsídio mensal, em espécie, dos Desembargadores do Tribunal de Justiça do Estado; (redação dada pela Emenda Constitucional nº 14, de 20.12.1999)

XI - a remuneração e o subsídio dos ocupantes de cargos, funções e empregos públicos da administração direta, autárquica e fundacional, dos membros de qualquer dos Poderes do Estado e dos Municípios e os proventos, pensões ou outra espécie remuneratória, percebidos cumulativamente ou não, incluídas as vantagens pessoais ou de qualquer outra natureza, não poderão exceder o subsídio mensal, em espécie, dos Desembargadores do Tribunal de Justiça, limitado a noventa inteiros e vinte e cinco centésimos por cento do subsídio mensal, em espécie, dos Ministros do Supremo Tribunal Federal, ressalvada a exceção prevista no § 12 do art. 37 da Constituição Federal; (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

XII - é vedada a vinculação ou equiparação de vencimentos, de remuneração de pessoal do serviço público, para efeito de remuneração de pessoal de serviço público, ressalvado o disposto no art. 39, § 1º, da Constituição Federal;

XII - é vedada a vinculação ou equiparação de quaisquer espécies remuneratórias para efeito de remuneração de pessoal do serviço público; (redação dada pela Emenda Constitucional nº 14, de 20.12.1999)

XIII - os acréscimos pecuniários percebidos por servidor não serão computados nem acumulados para fins de concessão de acréscimos ulteriores sob o mesmo título ou idêntico fundamento;

XIII - os acréscimos pecuniários percebidos por servidor público não serão computados nem acumulados para fim de concessão de acréscimos ulteriores; (redação dada pela Emenda Constitucional nº 14, de 20.12.1999)

XIV - os vencimentos dos servidores públicos, civis e militares, são irredutíveis e a remuneração observará o que dispõem os arts. 37, XI, XII, 150, II, 153, III e 153, § 2º, I, da Constituição Federal;

XIV - o subsídio e os vencimentos dos ocupantes de cargos e empregos públicos são irredutíveis, ressalvado o disposto nos incisos XI e XIII deste artigo, no §

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 25

4º do art. 47 e nos arts. 150, II, 153, III e 153, § 2º, I, da Constituição Federal; (redação dada pela Emenda Constitucional nº 14, de 20.12.1999)

XV - é vedada a acumulação remunerada de cargos públicos, exceto quando houver compatibilidade de horários:

XV - é vedada a acumulação remunerada de cargos públicos, exceto quando houver compatibilidade de horários, observado em qualquer caso o disposto no inciso XI: (redação dada pela Emenda Constitucional nº 14, de 20.12.1999)

a) a de dois cargos de professor;

b) a de um cargo de professor com outro técnico ou científico;

c) de dois cargos privativos de médico;

c) a de dois cargos ou empregos privativos de profissionais de saúde, com profissões regulamentadas. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

XVI - a proibição de acumular, a que se refere o inciso anterior, estende- se a empregos e funções e abrange autarquias, empresas públicas, sociedades de economia mista e fundações instituídas ou mantidas pelo Poder Público;

XVI - a proibição de acumular estende-se a empregos e funções e abrange autarquias, fundações, empresas públicas, sociedades de economia mista, suas subsidiárias, e sociedades controladas, direta ou indiretamente, pelo Poder Público; (redação dada pela Emenda Constitucional nº 14, de 20.12.1999)

XVII - a administração fazendária e seus agentes fiscais de rendas, aos quais compete exercer, privativamente, a fiscalização de tributos estaduais, terão, dentro de suas áreas de competência e jurisdição, precedência sobre os demais setores administrativos, na forma da lei;

XVIII - a criação, transformação, fusão, cisão, incorporação, privatização ou extinção das sociedades de economia mista, autarquias, fundações e empresas públicas dependem de prévia aprovação da Assembleia Legislativa;

XVIII - somente por lei específica poderá ser criada autarquia e autorizada a instituição de empresa pública, de sociedade de economia mista e de fundação, cabendo à lei complementar, neste último caso, definir as áreas de sua atuação; (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

XIX - depende de autorização legislativa, em cada caso, a criação de subsidiárias das entidades mencionadas no inciso anterior, assim como a participação de qualquer delas em empresa privada;

XX - é obrigatória a declaração pública de bens, antes da posse e depois do desligamento, de todo dirigente de empresa pública, sociedade de economia mista, autarquia e fundação instituída ou mantida pelo Poder Público;

XXI - os órgãos da administração direta ou indireta ficam obrigados a constituir Comissão Interna de Prevenção de Acidentes - CIPA - e, quando assim o exigirem suas atividades, Comissão de Controle Ambiental, visando á proteção da vida, do meio ambiente e das condições de trabalho dos seus servidores, na forma da lei;

XXII - ao servidor público que tiver sua capacidade de trabalho reduzida, em decorrência de acidente de trabalho ou doença do trabalho, será garantida a transferência para locais ou atividades compatíveis com sua situação;

XXIII - é vedada a estipulação de limite de idade para ingresso, por concurso público, na administração direta, empresa pública, sociedade de economia mista, autarquia e fundações instituídas ou mantidas pelo Poder Público, respeitando- se apenas o limite constitucional para aposentadoria compulsória;

XXIV - os recursos provenientes dos descontos compulsórios dos servidores públicos, bem como a contrapartida do Estado, destinados à formação de CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 26

fundo próprio de previdência, deverão ser postos, mensalmente, à disposição da entidade estadual responsável pela prestação do benefício, na forma que a lei dispuser;

XXV - a administração pública direta e indireta, as universidades públicas e as entidades de pesquisa técnica e científica oficiais ou subvencionadas pelo Estado prestarão ao Ministério Público o apoio especializado ao desempenho das funções da Curadoria de Proteção de Acidentes do Trabalho, da Curadoria da Defesa do Meio Ambiente e de outros interesses coletivos e difusos;

XXVI - lei estadual assegurará e disciplinará a prestação de serviços extraordinários e a respectiva forma de remuneração devida aos servidores que desempenham atividades de caráter essencial;

XXVII - os vencimentos dos cargos do Poder Legislativo e do Poder Judiciário não poderão ser superiores aos pagos pelo Poder Executivo;

XXVIII - ao Estado é vedado celebrar contratos com empresas que, comprovadamente, desrespeitaram normas de segurança, de medicina do trabalho e de preservação do meio ambiente.

XXVIII - ao Estado é vedado celebrar contratos com empresas ou pessoas físicas que, comprovadamente, desrespeitem normas de segurança, de medicina do trabalho, de preservação do meio ambiente e, em especial, os direitos e garantias fundamentais estabelecidos na Constituição Federal; (redação dada pela

Emenda Constitucional nº 35, de 21.03.2006)

XXIX - ressalvados os casos especificados na legislação, as obras, serviços, compras e alienações serão contratados mediante licitação pública que assegure igualdade de condições a todos os concorrentes, com cláusulas que estabeleçam obrigações de pagamento, mantidas as condições efetivas da proposta, nos termos da lei, o qual somente permitirá as exigências de qualificação técnica e econômica indispensáveis à garantia do cumprimento das obrigações. (incluído pela

Emenda Constitucional nº 35, de 21.03.2006)

**§ 1º** A publicidade dos atos, programas, obras, serviços e campanhas da administração pública direta, indireta, fundações e órgãos controlados pelo Poder Público deverá ter caráter educacional, informativo e de orientação social, dela não podendo constar nomes, símbolos e imagens que caracterizem promoção pessoal de autoridades ou servidores públicos.

**§ 2º** A inobservância do disposto nos incisos II, III e IV deste artigo implicará a nulidade do ato e a punição da autoridade responsável, nos termos da lei.

**§ 3º** As pessoas jurídicas de direito público e as de direito privado, prestadoras de serviços públicos, responderão pelos danos que seus agentes, nessa qualidade, causarem a terceiros, assegurado o direito de regresso contra o responsável nos casos de dolo ou culpa.

**§ 4º** Os atos de improbidade administrativa importarão a suspensão dos direitos políticos, a perda da função pública e a indisponibilidade de bens até o ressarcimento ao erário, na forma e gradação previstas em lei federal, sem prejuízo da ação penal cabível.

**§ 5º** O servidor aposentado, no exercício de mandato eletivo ou de cargo em comissão, ou quando contratado para prestação de serviços públicos, poderá perceber a remuneração dessas atividades cumulada com os proventos da aposentadoria.

**§ 5º** O servidor aposentado, no exercício de mandato eletivo ou de cargo em comissão ou quando contratado para prestação de serviços públicos, poderá perceber a remuneração dessas atividades acumulada com os proventos da

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 27

aposentadoria, respeitado o limite previsto no inciso XI, do art. 42. (redação dada pela

Emenda Constitucional nº 14, de 20.12.1999)

**§ 5º** É vedada a percepção simultânea de proventos de aposentadoria decorrentes do art. 40 ou dos arts. 42 e 142 da Constituição Federal com a remuneração de cargo, emprego ou função pública, ressalvados os cargos acumuláveis na forma da Constituição Federal, os cargos eletivos e os cargos em comissão declarados em lei de livre nomeação e exoneração. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

**§ 6º** Não serão computadas, para efeito dos limites remuneratórios de que trata o inciso XI do caput deste artigo, as parcelas de caráter indenizatório previstas em lei. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

**§ 7º** A lei disciplinará as formas de participação do usuário na administração pública direta e indireta, regulando especialmente: (incluído pela Emenda Constitucional nº 14, de 20.12.1999)

I - as reclamações relativas à prestação dos serviços públicos em geral, assegurada a manutenção de serviço de atendimento ao usuário e a avaliação periódica, externa e interna, da qualidade dos serviços; (incluído pela Emenda Constitucional nº 14, de 20.12.1999)

II - o acesso dos usuários a registros administrativos e à informação sobre atos do Governo, observado o disposto no art. 5º, X e XXXIII, da Constituição Federal; (incluído pela Emenda Constitucional nº 14, de 20.12.1999)

III - a disciplina da representação contra o exercício negligente ou abusivo de cargo, emprego ou função na administração pública. (incluído pela Emenda Constitucional nº 14, de 20.12.1999)

**Art. 43.** As leis e atos administrativos de efeitos externos serão publicados no órgão oficial do Estado, para que produzam os seus efeitos regulares, podendo ser resumida a publicação dos atos não normativos.

**Art. 43.** As leis e os atos administrativos de efeitos externos, do Poder Executivo e do Poder Legislativo, serão obrigatórios e gratuitamente publicados no órgão oficial do Estado, para que produzam os seus efeitos regulares, podendo ser resumida a publicação dos atos normativos. (redação dada pela Emenda Constitucional nº 14, de 20.12.1999)

**Art. 43.** As leis e atos administrativos de efeitos externos serão publicados no órgão oficial do Estado, para que produzam os seus efeitos regulares, podendo ser resumida a publicação dos atos não normativos.

**Art. 43.** As leis, os atos normativos e administrativos dos Poderes Executivo, Legislativo, Judiciário e Ministério Público serão, obrigatória e gratuitamente, publicados no Diário Oficial do Estado, para que produzam seus regulares e legais efeitos. (redação dada pela Emenda Constitucional nº 17, de 03.07.2000)

**§ 1º** Os atos não normativos poderão ter reduzida sua publicação. (incluído pela Emenda Constitucional nº 17, de 03.07.2000)

**§ 2º** Os Poderes Legislativo e Judiciário poderão instituir, mediante Resolução, o Diário Legislativo e o Diário do Judiciário, para publicação específica dos atos de sua competência, sem embargo da publicação obrigatória das leis e atos normativos referida no caput deste artigo. (incluído pela Emenda Constitucional nº 17, de 03.07.2000)

**Art. 44.** Os serviços públicos serão remunerados por tarifa previamente fixada pelo órgão executivo competente, na forma que a lei estabelecer.

**Art. 45.** É vedado ao Estado e Município, salvo autorização prévia das respectivas Casas Legislativas, efetuarem despesas relativas à locação de imóveis para servidores públicos, inclusive dirigentes da administração direta, indireta, autárquica e fundacional, ressalvadas as exceções legais. CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 28

**Art. 46.** A lei regulará o uso de carros oficiais destinados ao serviço público.

##### SEÇÃO II Dos Servidores Públicos Civis

**Art. 47.** O Estado e os Municípios instituirão, no âmbito de sua competência, regime jurídico único e planos de carreira para os servidores da administração pública direta, das autarquias e das fundações públicas.

**Art. 47.** O Estado e os Municípios instituirão conselho de política de administração e remuneração de pessoal integrado por servidores designados pelos respectivos Poderes. (redação dada pela Emenda Constitucional nº 14, de 20.12.1999)

**§ 1º** O regime jurídico único, de que trata este artigo, poderá ser o estatutário ou o celetista, adotando-se o que melhor atender às necessidades da administração direta, das autarquias e das fundações, podendo ser um ou outro em cada um dos três setores, desde que seja único no setor respectivo.

**§ 1º** A fixação dos padrões de vencimentos e dos demais componentes do sistema remuneratório observará: (redação dada pela Emenda Constitucional nº 14, de 20.12.1999)

I - a natureza, o grau de responsabilidade e a complexidade dos cargos componentes de cada carreira; (incluído pela Emenda Constitucional nº 14, de 20.12.1999)

II - os requisitos para investidura; (incluído pela Emenda Constitucional nº 14, de 20.12.1999)

III - a peculiaridade dos cargos. (incluído pela Emenda Constitucional nº 14, de 20.12.1999)

**§ 2º** A lei assegurará aos servidores da administração direta isonomia de vencimentos para cargos de atribuições iguais ou assemelhadas do mesmo Poder, ou entre servidores dos Poderes Executivo, Legislativo e Judiciário, ressalvadas as vantagens de caráter individual e as relativas à natureza ou local de trabalho.

**§ 2º** O Estado manterá escolas de governo para a formação e o aperfeiçoamento dos servidores públicos, constituindo-se a participação nos cursos um dos requisitos para promoção na carreira, facultada, para isso, a celebração de convênios ou contratos entre os entes federados. (redação dada pela Emenda Constitucional nº 14, de 20.12.1999)

**§ 2º** O Estado manterá escolas de governo para formação e o aperfeiçoamento dos servidores públicos, constituindo-se a participação nos cursos um dos requisitos para promoção na carreira, facultada, para isso, a celebração de convênios ou contratos com os demais entes federados, ou entre o Estado e os Municípios com instituições de ensino superior que ofereçam cursos afins. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

**§ 3º** Aplicam-se aos servidores ocupantes de cargos públicos o disposto no art. 7º, IV, VII, VIII, IX, XII, XIII, XV, XVI. XVII, XVIII, XIX, XX, XXII e XXX, da Constituição Federal, podendo a lei estabelecer requisitos diferenciados de admissão quando a natureza do cargo o exigir. (incluído pela Emenda Constitucional nº 14, de 20.12.1999)

**§ 4º** O membro de Poder, o detentor de mandato eletivo, os Secretários Estaduais e Municipais serão remunerados exclusivamente por subsídio fixado em parcela única, vedado o acréscimo de qualquer gratificação, adicional, abono, prêmio, verba de representação ou outra espécie remuneratória, obedecido em qualquer caso, o disposto no art. 42, X e XI. (incluído pela Emenda Constitucional nº 14, de 20.12.1999)

**§ 5º** Lei do Estado e dos Municípios poderão estabelecer a relação entre a maior e a menor remuneração dos servidores públicos estaduais e municipais,

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 29

obedecido em qualquer caso, o disposto no art. 42, XI. (incluído pela Emenda Constitucional nº 14, de 20.12.1999)

**§ 6º** Os Poderes Executivo, Legislativo e Judiciário publicarão anualmente os valores do subsídio e da remuneração dos cargos e empregos públicos. (incluído pela Emenda Constitucional nº 14, de 20.12.1999)

**§ 7º** Lei do Estado e do Município disciplinarão a aplicação de recursos orçamentários provenientes da economia com despesas correntes em cada órgão, autarquia e fundação, para aplicação no desenvolvimento de programas de qualidade e produtividade, treinamento e desenvolvimento, modernização, reaparelhamento e racionalização do serviço público, inclusive sob a forma de adicional ou prêmio de produtividade. (incluído pela Emenda Constitucional nº 14, de 20.12.1999)

**§ 8º** A remuneração dos servidores públicos organizados em carreira poderá ser fixado nos termos do § 4º. (incluído pela Emenda Constitucional nº 14, de 20.12.1999)

**§ 9º** É garantida a liberação do servidor público para exercício de mandato eletivo em diretoria de entidade sindical representativa da categoria de servidores públicos, de âmbito estadual, com ônus para o órgão de origem, sem prejuízo da remuneração integral, com todos seus benefícios, inclusive verbas indenizatórias, sendo-lhe assegurados todos os direitos, vantagens e progressão ou ascensão funcional do cargo como se em exercício efetivamente estivesse; (incluído pela Emenda Constitucional nº 67, de 25.10.2023)

**§ 10** Em qualquer caso que exija o afastamento para o exercício de mandato eletivo, o tempo de serviço será contado para todos os efeitos legais, exceto para promoção por merecimento; (incluído pela Emenda Constitucional nº 67, de 25.10.2023)

**§ 11** A garantia prevista no §9º deste artigo será exercida no mínimo por 2 (dois) representantes do sindicato, sendo acrescida de mais um representante por cada 1000 (mil) servidores em atividade, não podendo ultrapassar a 6 (seis) membros, devidamente indicados pela entidade. (incluído pela Emenda Constitucional nº 67, de 25.10.2023)

**Art. 48.** O Estado e os Municípios deverão dotar seus planos de cargos e salários objetivando o atendimento à demanda de técnicos de nível médio e superior, de acordo com as necessidades locais, vedado o desvio de função e garantida a ascensão funcional imediata, constatada a existência de vaga e mediante concurso, sempre que o servidor comprovar qualificação de nível superior ao da função que exerce.

**Art. 48.** O Estado e os Municípios deverão dotar seus planos de cargos e salários objetivando o atendimento à demanda de técnicos de nível médio e superior, de acordo com as necessidades locais, vedado o desvio de função. (redação dada pela

Emenda Constitucional nº 35, de 21.03.2006)

**Parágrafo único.** A Administração Pública implementará política de recursos humanos que atenda ao princípio da valorização do servidor público, investindo na sua capacitação, aprimoramento e atualização profissionais, subsidiando cursos de graduação de nível superior, especialização, mestrado e doutorado, visando prepará-lo para um desempenho qualificado de suas atribuições funcionais. (incluído pela Emenda Constitucional nº 35, de 21.03.2006)

**Art. 49.** Aplica-se aos servidores estaduais, para efeito de estabilidade, o disposto no art. 41 da Constituição Federal.

**§ 1º** A Administração Pública Estadual tem o prazo de cinco anos para anular o Ato Administrativo gerador de efeitos favoráveis para os destinatários, salvo comprovada má-fé. (incluído pela Emenda Constitucional nº 51, de 31.12.2014)

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 30

**§ 2º** No caso de efeitos patrimoniais contínuos, o prazo de decadência contar-se-á da percepção do primeiro pagamento. (incluído pela Emenda Constitucional nº 51, de 31.12.2014)

**Art. 50.** A lei assegurará à servidora gestante mudança de função nos casos em que for recomendada, sem prejuízo de seus vencimentos e salários e demais vantagens do cargo ou função original.

**Art. 51.** O índice de reajuste dos vencimentos dos servidores observará o percentual proposto pelo Poder Executivo, com a aprovação do Poder Legislativo.

**Art. 52.** O Poder Público estadual assegurará aos seus servidores, além do que estabelece o art. 39 da Constituição Federal, adicional de interiorização, correspondente até cinquenta por cento dos vencimentos, quando designados para exercerem atividades em Município do interior do Estado, por tempo indeterminado, conforme dispuser a lei.

**Art. 53.** Ao servidor público será assegurado o direito de remoção para igual cargo ou emprego no lugar de residência do cônjuge, se este também for servidor do Estado.

**Parágrafo único.** O disposto neste artigo aplica-se ao titular do mandato eletivo federal ou estadual ou municipal.

**Art. 54.** O tempo de serviço público federal, estadual ou municipal será computado integralmente para os efeitos de aposentadoria e de disponibilidade.

**Art. 54.** O tempo de contribuição federal, estadual ou municipal será contado para efeito de aposentadoria e o tempo de serviço correspondente para efeito de disponibilidade. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

**Art. 55.** O servidor será aposentado:

I - por invalidez permanente, percebendo proventos integrais, se ela for decorrente de acidente em serviço, moléstia profissional ou doença grave, contagiosa ou incurável, a serem especificadas em lei, recebendo, nos demais casos, proventos proporcionais;

II - compulsoriamente, aos setenta anos de idade, com proventos proporcionais ao tempo de serviço;

III - voluntariamente:

a) aos trinta e cinco anos de serviço, se homem, e aos trinta anos, se mulher, com proventos integrais;

b) aos trinta anos de efetivo exercício em funções de magistério, se professor, e vinte e cinco, se professora, com proventos integrais, acrescidos das vantagens e gratificações conquistadas, satisfeito o requisito de tempo de ,•'< serviço, independentemente da natureza da sua investidura;

c) aos trinta anos de serviço, se homem, e aos vinte e cinco anos, se mulher, com proventos proporcionais ao tempo de serviço;

d) aos sessenta e cinco anos de idade, se homem, e aos sessenta anos, se mulher, com proventos proporcionais ao tempo de serviço.

**§ 1º** A lei disporá sobre a aposentadoria em cargos ou empregos temporários.

**§ 2º** Os proventos da aposentadoria serão revistos, na mesma proporção e na mesma data, sempre que se modificar a remuneração dos servidores em atividade, sendo também estendidos aos inativos quaisquer benefícios ou vantagens posteriormente concedidos aos servidores em atividade, inclusive quando decorrentes da transformação ou reclassificação do cargo ou função em que se deu a aposentadoria, na forma da lei.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 31

**§ 3º** O benefício da pensão por morte corresponderá à totalidade dos vencimentos ou proventos do servidor falecido, até o limite estabelecido em lei, observado o disposto no parágrafo anterior.

**Art. 55.** Aplicam-se aos servidores estaduais, para efeito do regime de previdência e aposentadoria, o disposto no art. 40 e seus parágrafos, da Constituição Federal. (redação dada pela Emenda Constitucional nº 14, de 20.12.1999)

**Art. 55.** Aplica-se aos servidores públicos estaduais, titulares de cargos de provimento efetivo, para efeito do regime de previdência e aposentadoria, o disposto no art. 40 e seus parágrafos, da Constituição Federal. (redação dada pela

Emenda Constitucional nº 35, de 21.03.2006)

**Art. 56.** O exercício de mandato eletivo por parte do servidor público obedecerá ao disposto no art. 38 da Constituição Federal.

**Art. 57.** O Estado manterá, na forma da lei, regime previdenciário, e assistencial próprio, objetivando a promoção dos direitos relativos à saúde, previdência e assistência social dos servidores de sua administração pública direta, autarquias e fundações públicas.

**Art. 58.** O regime previdenciário e assistencial será custeado pela administração estadual centralizada, autárquica ou fundacional, na qualidade de empregadora, e pelos próprios servidores, além de outras fontes, na forma da lei.

**Parágrafo único.** Nenhum benefício ou serviço do regime previdenciário e assistencial do estado poderá ser criado, majorado ou estendido sem a correspondente fonte de custeio total.

**Art. 59.** Nenhuma pensão, globalmente ou pelo somatório das cotas individuais componentes, poderá ser inferior ao menor nível da escala de vencimentos do funcionalismo estadual.

**Art. 60.** A previdência estadual poderá instituir, através de lei, pensão especial, de caráter facultativo e complementar, custeada por contribuições adicionais dos instituidores.

**Art. 60.** O Estado e os Municípios, desde que instituam regime de previdência complementar para os seus respectivos servidores titulares de cargo efetivo, poderão fixar, para o valor das aposentadorias e pensões a serem concedidas pelo regime de que trata este artigo, o limite máximo estabelecido para os benefícios do regime geral de previdência social de que trata o artigo 201 da Constituição Federal. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

**Parágrafo único.** O regime de previdência complementar de que trata este artigo será instituído por lei de iniciativa do Poder Executivo, observado o disposto no art. 202 e seus parágrafos da Constituição Federal, no que couber, por intermédio de entidades fechadas de previdência complementar, de natureza pública, que oferecerão aos respectivos participantes planos de benefícios somente na modalidade de contribuição definida. (incluído pela Emenda Constitucional nº 35, de 21.03.2006)

**Art. 61.** O benefício da pensão por morte será concedido, atendendo-se ao prescrito no §§ 4º e 5º do art. 40 da Constituição Federal.

**Art. 61.** O benefício da pensão por morte será concedido, atendendo-se ao prescrito no § 7 º, do art. 40 da Constituição Federal. (redação dada pela Emenda Constitucional nº 14, de 20.12.1999)

**§ 1º** O valor da pensão por morte será rateado, na forma da lei, entre os dependentes do servidor falecido e, extinguindo-se o direito de um deles, a cota correspondente será acrescida às demais, procedendo-se a um novo rateio entre os pensionistas remanescentes.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 32

**§ 2º** O órgão ou entidade previdenciária do Estado não poderá retardar o início do pagamento do benefício por mais de quarenta dias após o protocolo do requerimento, comprovada a evidência do fato gerador.

**Art. 62.** Ao servidor público, quando adotante, ficam estendidos os direitos que assistem ao pai e à mãe naturais, na forma a ser regulada por lei.

**Art. 63.** É assegurado aos servidores da administração direta e indireta o atendimento gratuito de seus filhos e dependentes, desde o nascimento até seis anos de idade, em creches e pré-escolas, na forma da lei.

**Art. 64.** O pagamento da remuneração mensal dos servidores públicos ativos, inativos ou pensionistas do Estado e das autarquias será realizado até o quinto dia útil do mês subsequente ao da aquisição do direito.

**Parágrafo único.** O pagamento da gratificação natalina será efetuado até o dia vinte do mês de dezembro.

**Art. 65.** Aplica-se, aos servidores públicos civis do Estado, o disposto no

**§ 1º** do art. 40 da Constituição Federal.

**Art. 65.** Os servidores estaduais e municipais que ocupavam empregos transformados em cargos públicos por lei estadual ou municipal, passaram automaticamente à condição de servidores públicos estatutários, na data da publicação das respectivas leis, usufruindo, desde então, de todos os direitos e vantagens inerentes ao novo regime. (redação dada pela Emenda Constitucional nº 14, de 20.12.1999)

**Art. 65-A.** No caso de extinção, fusão, incorporação ou transferência de propriedade para iniciativa privada ou para a União Federal, de empresa pública ou sociedade de economia mista, que tenha sido constituída à época do extinto Território Federal do Amapá e que tenha passado a integrar o patrimônio do Estado do Amapá, por força do artigo 14, § 2º do ADCT da Constituição Federal, de 05 de outubro de 1988 e do disposto no artigo 16, da Lei Complementar nº 41 de 22 de dezembro 1981, o empregado que tenha ingressado mediante prévio concurso público no quadro de pessoal de qualquer das pessoas jurídicas elencadas, poderá, mediante opção ser aproveitado no quadro de pessoal da administração pública estadual, nos termos da Lei. (incluído pela Emenda Constitucional nº 55, de 03.05.2017)

**Art. 66.** Os vencimentos, a remuneração e os proventos dos servidores públicos de qualquer dos Poderes, em nível estadual ou municipal, da administração direta e indireta, não serão objeto de arresto, sequestro ou penhora, exceto nos caso de prestação de pensão alimentícia resultante de decisão judicial.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 33

##### SEÇÃO III Dos Servidores Públicos Militares

**Art. 67.** São servidores militares estaduais os integrantes da Polícia Militar e do Corpo de Bombeiros Militar.

**§ 1º** Aplica-se, no que couber, aos servidores a que se refere este artigo, o disposto no art. 42 da Constituição Federal.

**§ 2º** No que não colidir com a legislação específica, aplica-se aos servidores mencionados neste artigo o disposto na seção anterior.

**§ 3º** O servidor militar demitido por ato administrativo, se absolvido pela justiça, na ação referente ao ato que deu causa à demissão, será reintegrado na corporação com todos os direitos restabelecidos.

**§ 4º** O oficial da Polícia Militar e do Corpo de Bombeiros Militar só perderá o posto e a patente se for julgado indigno do oficialato ou com ele incompatível, por decisão do Tribunal de Justiça.

**§ 5º** O oficial condenado na Justiça comum ou militar a pena privativa de liberdade superior a dois anos, por sentença transitada em julgado, será submetido ao julgamento previsto no parágrafo anterior.

**§ 6º** O direito do servidor militar de ser transferido para a reserva ou ser reformado será assegurado, ainda que respondendo a inquérito ou processo em qualquer jurisdição, nos casos previstos em lei específica.

**§ 7º** Será transferido "ex-officio" para a reserva remunerada e promovido ao posto imediatamente superior o oficial que tiver exercido o cargo de Comandante- Geral da Polícia Militar e do Corpo de Bombeiros Militar, em caráter efetivo, no prazo mínimo de dezoito meses, com todos os direitos e vantagens do cargo.

**§ 7º** Será transferido para a reserva remunerada o Comandante Geral da Polícia Militar e do Corpo de Bombeiro Militar, com todos os direitos e vantagens do cargo, na forma da Lei. (redação dada pela Emenda Constitucional nº 16, de 20.06.2000)

**§ 7º** Serão transferidos para reserva remunerada o Comandante Geral da Polícia Militar, o Comandante Geral do Corpo de Bombeiros Militar, os Chefes dos Gabinetes Militares dos Poderes e do Ministério Público Estadual, que possuam o tempo de serviço para inatividade, com todos os direitos e vantagens pecuniárias do cargo e que tenham exercido os respectivos cargos pelo período mínimo de 18 meses, ininterruptos ou alternados, preservados os direitos e vantagens concedidos aos Oficiais já transferidos para a reserva remunerada. (redação dada pela Emenda Constitucional nº 49, de 22.12.2014) (revogado pela Emenda Constitucional nº 54, de 12.04.2017)

**§ 8º** A lei disporá sobre os limites de idade, a estabilidade, e outras condições de transferência do servidor militar para a inatividade.

**§ 9º** Aplica-se aos servidores a que se refere este artigo, o disposto no

art. 40, §§ 7º e 8º, da Constituição Federal. (Redação dada pela Emenda Constitucional nº 14, de 1999)

**§ 10** Aplica-se aos servidores a que se refere este artigo o disposto no

art. 7º, VIII, XII, XVII, XVIII, e XIX, da constituição Federal.

**§ 11** O soldado, cabo, sargento ou subtenente da Polícia Militar e do Corpo de Bombeiros Militar que tenha o segundo grau completo ou equivalente poderá submeter-se à seleção para a formação de oficiais. (revogado pela Emenda Constitucional nº 64, de 31.03.2022)

**§ 12** A transferência para a reserva remunerada a pedido será concedida mediante requerimento do servidor militar que conte mais de 25 (vinte e cinco) anos de serviço, se mulher, assegurado à promoção ao posto ou graduação imediatamente

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 34

superior ao seu, por ocasião da passagem à inatividade. (incluído pela Emenda Constitucional nº 26, de 27.02.2002)

**§ 12** A transferência para a reserva remunerada a pedido será concedida mediante requerimento do servidor militar estadual que conte mais de 25 (vinte e cinco) anos de serviço, assegurada a promoção ao posto ou graduação imediatamente superior ao seu, por ocasião da passagem à inatividade. (redação dada pela Emenda Constitucional nº 49, de 22.12.2014)

**§ 13** Ficam assegurados aos militares da ativa que se encontrem nomeados até a data de promulgação desta Emenda ou que tenham exercido mediante nomeação os cargos de Comandante Geral da Polícia Militar, Comandante Geral do Corpo de Bombeiros Militar, Chefes de Gabinetes Militares dos Poderes e do Ministério Público Estadual, os direitos e vantagens pecuniárias, no ato da passagem à inatividade, desde que completem o requisito mínimo de 18 meses ininterruptos ou alternados, sendo preservados os direitos e vantagens concedidos aos Oficiais já transferidos para a reserva remunerada. (incluído pela Emenda Constitucional nº 54, de 12.04.2017)

**Art. 68.** O acesso ao Quadro de Oficiais da Polícia Militar é privativo e exclusivo de brasileiro nato que tenham concluído, com aproveitamento, o curso de formação de oficiais PM e BM, nas academias de Polícia Militar e de Bombeiros Militar.

**Art. 68.** Os Quadros de Oficiais da Polícia Militar do Amapá – PMAP e do Corpo de Bombeiros Militar do Amapá – CBMAP deverão ser formados pelos seguintes Quadros: Quadro de Oficiais Combatentes (QOC), Quadro de Oficiais da Administração (QOA), Quadro de Oficiais de Saúde (QOS), Quadro de Oficiais Complementares (QOC), Quadro de Oficiais Músicos (QOM) e Quadro Especial de Oficiais (QEO). (redação dada pela Emenda Constitucional n. 65, de 30.08.2022)

**§ 1º** Os integrantes dos Quadros Oficiais Combatentes, de Saúde, Complementares, Oficiais da Administração e de Músicos poderão alcançar até o posto de Coronel; e os do Quadro Especial de Oficiais até o posto de Major, com acesso privativo e exclusivo aos referidos Quadros de Oficiais aos brasileiros natos que preencham os requisitos e tenham concluído os cursos de formação previstos no Estatuto dos Militares do Estado do Amapá. (incluído pela Emenda Constitucional n. 65, de 30.08.2022) (revogado pela Emenda Constitucional n. 68, de 11.04.2024)

**§ 2º** Não poderá haver distinção de idade para o ingresso nos Quadros de Praças e Oficiais da Polícia Militar e Corpo de Bombeiros Militar do Estado do Amapá. (incluído pela Emenda Constitucional n. 65, de 30.08.2022) (revogado pela

Emenda Constitucional n. 68, de 11.04.2024)

**Art. 68.** Os requisitos do acesso aos Quadros de Oficiais da Polícia Militar e do Corpo de Bombeiros Militar serão definidos em lei complementar, sendo privativo a brasileiros, aprovados em concurso público, possuidores de graduação de nível superior e que tenham concluído, com aproveitamento, o curso de formação de oficiais ou o respectivo curso de habilitação, realizado em estabelecimento de ensino próprio ou de polícia militar ou de corpo de bombeiros militar de outra unidade federada ou de Territórios. (redação dada pela Emenda Constitucional n. 68, de 11.04.2024)

**Parágrafo único.** O Quadro de Oficiais Especialistas (QOE), integrado por Oficiais oriundos da carreira das praças será constituído pelos oficiais possuidores do respectivo curso de habilitação, nos termos da legislação específica, admitida a promoção até o posto de Tenente-coronel. (redação dada pela Emenda Constitucional n. 68, de 11.04.2024)

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 35

**Art. 69.** O militar alistável é elegível, respeitadas as condições previstas no art. l4, § 8º, da Constituição Federal.

**Art. 70.** Os proventos da inatividade dos servidores militares não serão inferiores aos vencimentos percebidos nos mesmos postos e graduações da ativa, observado o tempo de serviço.

**Art. 71.** Os proventos da inatividade serão revistos, na mesma proporção e na mesma data, sempre que se modificar a remuneração dos servidores militares em atividade, sendo também estendidos aos inativos quaisquer benefícios ou vantagens posteriores concedidas aos servidores em atividades, inclusive quando decorrentes de transformação ou reclassificação de cargos ou funções em que se deu a inatividade, na forma da lei.

**Art. 72.** Aos servidores militares serão garantidas assistência médica e social através da política de seguridade do Estado.

**Art. 73.** A remuneração dos servidores militares obedecerá à política salarial do Estado.

**Art. 74.** O servidor militar gozará de assistência jurídica integral e gratuita do Estado, através do órgão de assistência social ou assemelhado da Corporação, nos casos em que se veja processado em decorrência do serviço.

### TÍTULO IV Da Segurança Pública

#### CAPÍTULO I Disposições Gerais

**Art. 75.** A segurança pública, dever do Estado, direito e responsabilidade de todos, é exercidas para a preservação da ordem pública e incolumidade das pessoas e do patrimônio, através dos seguintes órgãos, subordinados ao Governador do Estado:

I - Polícia Civil;

II - Polícia Militar;

III - Corpo de Bombeiros Militar;

IV - Polícia Técnico-Científica;

V - Superintendência de Administração Penitenciária do Estado do Amapá - SUAP. (incluído pela Emenda Constitucional nº 50, de 30.12.2014)

V – Polícia Penal. (incluído pela Emenda Constitucional nº 50, de 30.12.2014) (redação dada pela Emenda Constitucional nº 61, de 04.03.2020)

**Parágrafo único.** A remuneração dos servidores policiais integrantes dos órgãos relacionados neste artigo será fixada na forma do § 4º do art. 47 desta Constituição. (incluído pela Emenda Constitucional nº 35, de 21.03.2006)

**Art. 76.** A lei disciplinará a organização e o funcionamento dos órgãos responsáveis pela segurança pública, de maneira a garantir a eficiência de suas atividades, definindo suas competências, estruturando suas carreiras e fixando direitos, deveres, vantagens e regime de trabalho de seus integrantes.

**§ 1º** É dever dos órgãos responsáveis pela segurança pública dar aos policiais civis e militares, formação, capacitação e treinamentos especializados para o trato das questões relativas à criança e ao adolescente.

**§ 1º** É dever dos órgãos responsáveis pela segurança pública dar aos policiais civis e militares, formação, capacitação e treinamento especializados para o trato das questões relativas ao idoso, à criança e ao adolescente e a mulher. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 36

**§ 1º** É dever dos órgãos responsáveis pela segurança pública dar aos policiais civis, penais e militares, formação, capacitação e treinamento especializados para o trato das questões relativas ao idoso, à criança, ao adolescente e a mulher. (redação dada pela Emenda Constitucional nº 61, de 04.03.2020)

**§ 2º** É assegurada autonomia administrativa e financeira aos serviços periciais, cuja estrutura será definida na forma da lei.

**§ 3º** A Polícia Técnica terá seu quadro organizado em carreira, cujo ingresso depende de concurso público de provas e títulos.

**§ 4º** Fica assegurada isonomia de remuneração dos peritos e médicos legistas com os delegados de polícia, na mesma classe e padrão. (revogado pela Emenda Constitucional nº 35, de 21.03.2006)

**§ 5º** O Poder Executivo promoverá a instalação, progressivamente, em todos os municípios do Estado, de delegacias de polícia especializadas em assuntos relativos às pessoas relacionadas no § 1º deste artigo. (incluído pela Emenda Constitucional nº 35, de 21.03.2006)

**§ 6º** A Superintendência de Administração Penitenciária do Estado do Amapá – SUAP, órgão permanente, assegurada a autonomia administrativa, atividade exclusiva do Estado essencial à função jurisdicional dirigida por agente, por educador de execução penal, de carreira, conforme requisitos a que se refere o art. 75 da Lei nº 7.210, de 11 de julho de 1984, destina-se, além das atribuições definidas em lei, a custódia dos apenados pela Justiça do Estado do Amapá, à segurança interna e externa das unidades penais, à escolta penal, a recaptura de foragidos das unidades penais, ao serviço de inteligência penal, à intervenção em conflitos das unidades penais, à fiscalização do cumprimento das penas alternativas e condicionais, à ressocialização do apenado e às medidas de reinserção social ao egresso. (incluído pela Emenda Constitucional nº 50, de 30.12.2014) (Revogado pela Emenda Constitucional nº 61, de 04.03.2020)

**Art. 77.** O policial civil ou militar denunciado por crime de abuso de autoridade, será imediatamente afastado de seu cargo ou função, até a sentença transitada em julgado.

**Art. 77.** O policial civil, penal ou militar denunciado por crime de abuso de autoridade, será imediatamente afastado de seu cargo ou função, até a sentença transitada em julgado. (redação dada pela Emenda Constitucional nº 61, de 04.03.2020)

**Art. 78.** A prevenção dos eventos desastrosos, o socorro e a assistência aos atingidos por tais eventos e a recuperação dos danos causados serão coordenados pela Defesa Civil, que disporá de organização sistêmica, dela fazendo parte:

I - os órgãos públicos estaduais;

II - os órgãos públicos federais e municipais;

III - as entidades classistas, assistenciais, clubes de serviços, autoridades eclesiásticas e a comunidade em geral.

#### CAPÍTULO II Da Polícia Civil

**Art. 79.** À Polícia Civil, órgão permanente, dirigida pelo Delegado-Geral, subordinado ao Secretário de Estado de Justiça e Segurança Pública, de livre escolha, nomeação e exoneração pelo Governador do Estado, entre os delegados de polícia de carreira, bacharéis em Direito, incumbe, ressalvada a competência da União, as funções de Polícia Judiciária e a apuração das infrações penais, exceto as militares.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 37

**Art. 79.** À polícia civil, instituição permanente, com autonomia administrativa e financeira, orientada com base na hierarquia, disciplina e respeito aos direitos humanos, dirigida por delegado de polícia de carreira da classe especial, de livre nomeação e exoneração pelo Governador do Estado, incumbe, ressalvada a competência da União, exercer com exclusividade, as funções de polícia judiciária e a apuração de infrações penais, exceto as militares. (incluído pela Emenda Constitucional nº 35, de 21.03.2006)

**Parágrafo único.** Aos integrantes da carreira de delegados de polícia fica assegurada, nos termos do art. 241 da Constituição Federal, isonomia de vencimentos.

**Parágrafo único.** Os vencimentos dos Delegados de Polícia Civil não serão inferiores aos percebidos pelas carreiras a que se refere o art. 135 da Constituição Federal, observada, para esse efeito, a correlação entre as respectivas classes e entrâncias e assegurada a revisão de remuneração, em igual percentual, sempre que forem revistos aqueles. (redação dada pela Emenda Constitucional nº 9, de 28.08.1997) (revogado pela Emenda Constitucional nº 35, de 21.03.2006)

**§ 1º** O titular da polícia civil será nomeado pelo Governador do Estado dentre os delegados integrantes da classe especial da carreira. (incluído pela Emenda Constitucional nº 35, de 21.03.2006)

**§ 2º** Os delegados de polícia de carreira, bacharéis em direito, aprovados em concurso público de provas ou de provas e títulos, serão remunerados na forma do § 9º do art. 144 da Constituição Federal, aplicando-se-lhes as vedações referidas no inciso II do art. 148 desta Constituição. (incluído pela Emenda Constitucional nº 35, de 21.03.2006)

**§ 3º** Os Delegados de Polícia do Estado integrarão a Carreira Jurídica do Poder Executivo do Amapá. (incluído pela Emenda Constitucional nº 35, de 21.03.2006)

**Art. 80.** Lei Orgânica e estatuto disciplinarão a organização, o funcionamento, os direitos, deveres, vantagens e regime de trabalho da Polícia Civil e de seus integrantes, servidores especiais, assegurado na estruturação das carreiras o mesmo tratamento dispensado, para efeito de escalonamento e promoção, aos delegados de polícia, respeitadas as leis federais concernentes.

**Art. 81.** O policial civil condenado à pena privativa de liberdade superior a dois anos, por sentença transitada em julgado, será imediatamente demitido do serviço público.

#### CAPÍTULO III Da Polícia Militar

**Art. 82.** A Polícia Militar, órgão permanente e regular, força auxiliar e reserva do Exército, é dirigida por Comandante-Geral, nomeado pelo Governador do Estado, dentre oficiais da Corporação, do último posto.

**Art. 82.** A Polícia Militar, órgão permanente e regular, força auxiliar e reserva do Exército, é dirigida por Comandante-Geral, nomeado pelo Governador do Estado, dentre os oficiais da ativa do Quadro de Oficiais de Estado-Maior (ǪOEM) pertencente ao último posto da corporação. (redação dada pela Emenda Constitucional n. 68, de 11.04.2024)

**Art. 83.** À Polícia Militar incumbe, além de outras atribuições que a lei estabelecer, o policiamento ostensivo fardado e preservação da ordem pública.

**Art. 84.** Lei complementar de organização básica da Polícia Militar, estatuto, leis ordinárias e demais normas disciplinarão a organização, funcionamento, direitos, deveres e vantagens da corporação e de seus integrantes, respeitadas as leis federais concernentes.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 38

**Art. 85.** O Comando-Geral da Polícia Militar deverá, no início de cada semestre, programar cursos, palestras e similares sobre direitos humanos e relações públicas, para toda a corporação militar.

#### CAPÍTULO IV Do Corpo de Bombeiros Militar

**Art. 86.** O Corpo de Bombeiros Militar é instituição permanente, força auxiliar e reserva do Exército, organizado com base na hierarquia e disciplina militares, subordinando-se ao Governador do Estado e competindo-lhe, dentre outras atribuições previstas em lei, executar:

I - serviço de prevenção e extinção de incêndio, de proteção, busca e salvamento;

II - socorro de emergência;

III - perícia em local de incêndio;

IV - proteção balneária por guarda-vidas;

V - prevenção de acidentes e incêndios na orla marítima e fluvial;

VI - proteção e prevenção contra incêndio florestal;

VII - atividades de defesa civil, inclusive planejamento e coordenação das mesmas;

VIII - estudar, analisar, planejar, exigir e fiscalizar todo o serviço de segurança contra incêndio do Estado;

IX - embargar, interditar obras, serviços, habitações e locais de diversões públicas que não ofereçam condições de segurança para funcionamento.

**Parágrafo único.** O Corpo de Bombeiros Militar, sob a sua orientação pedagógica e operacional, promoverá a formação de grupos de voluntários de combate a incêndios, organizando-os em repartições públicas, empresas privadas, edifícios e em locais dos diversos bairros das cidades.

**Art. 87.** O Comandante-Geral do Corpo de Bombeiros Militar será nomeado pelo Governador do Estado, escolhido dentre oficiais da ativa da Corporação, do último posto do quadro de combatentes, observado o disposto na legislação federal.

**Art. 87.** O Comandante-Geral do Corpo de Bombeiros Militar será nomeado pelo Governador do Estado, escolhido dentre os oficiais da ativa do Quadro de Oficiais de Estado-Maior (ǪOEM) pertencente ao último posto da corporação.(redação dada pela

Emenda Constitucional n. 68, de 11.04.2024)

#### CAPÍTULO V Da Polícia Técnico-Científica

**Art. 88.** Cabe à Polícia Técnico-Científica a realização de perícias criminais, médico-legais, identificação civil e criminal e desenvolvimento de estudos e pesquisas em convênio com a Fundação Universidade Federal do Amapá, na sua área de atuação.

**Art. 89.** A Polícia Técnico-Científica, dirigida por perito, com notório conhecimento científico e experiência funcional, de livre escolha, nomeação e exoneração pelo Governador do Estado, terá seu quadro de pessoal organizado através de estatuto próprio.

**Art. 90.** O cargo de perito é privativo de médico, dentista, farmacêutico, químico, engenheiro, biólogo e contador, dependendo o respectivo ingresso de

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 39

provimento condicionado à: habilitação por concurso público de provas ou de provas e títulos.

**Art. 90.** O cargo de perito é privativo de médico, dentista, farmacêutico, químico, engenheiro, biólogo, enfermeiro e contador, dependendo o respectivo ingresso de provimento condicionado à habilitação por concurso público de provas ou de provas e títulos. (redação dada pela Emenda Constitucional nº 33, de 30.03.2005)

**Art. 90.** O cargo de perito é privativo de pessoas portadoras de diploma de nível superior, obtido em curso devidamente reconhecido pelo Ministério da Educação e Cultura, dependendo o ingresso na carreira de aprovação em concurso público de provas e títulos. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

#### CAPÍTULO VI Da Polícia Penal (incluído pela Emenda Constitucional nº 61, de 04.03.2020)

**Art. 90-A.** À Polícia Penal, instituição permanente, com autonomia administrativa e financeira, estruturada em carreira única, dirigida por Policial Penal, essencial à segurança pública e à execução penal, incumbe a segurança dos estabelecimentos penais. (incluído pela Emenda Constitucional nº 61, de 04.03.2020)

### TÍTULO V Da Organização dos Poderes do Estado

#### CAPÍTULO I Do Poder Legislativo

##### SEÇÃO I Da Assembleia Legislativa

**Art. 91.** O Poder Legislativo é exercido pela Assembleia Legislativa, constituída de Deputados Estaduais representantes do povo, eleitos pelo sistema proporcional, através do voto direto e secreto para uma legislatura de quatro anos.

**Parágrafo único.** O número de Deputados Estaduais corresponderá ao triplo da representação do Estado na Câmara Federal e, atingindo o número de trinta e seis, será acrescido de tantos quantos forem os Deputados Federais acima de doze.

**Art. 92.** A Assembleia Legislativa funcionará em sessões públicas, presente pelo menos um terço de seus membros.

**Parágrafo único.** O direito de opção de que trata o presente artigo, esgotar-se-á em cento e vinte dias da data da promulgação da Constituição.

**Art. 92.** A Assembleia Legislativa funcionará em sessões públicas, presentes pelos menos um quarto de seus membros. (redação dada pela Emenda Constitucional nº 39, de 11.09.2007)

**§ 1º** Salvo disposição constitucional em contrário, as deliberações da Assembleia Legislativa e de suas Comissões serão tomadas por maioria de votos, presente a maioria absoluta de seus membros.

**§ 2º** O voto será público, salvo nos seguintes casos:

a) no julgamento de Deputado ou do Governador;

b) na eleição dos membros da Mesa e de seus substitutos;

c) na aprovação prévia de conselheiros do Tribunal de Contas indicados pelo Governador;

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 40

d) na deliberação sobre prisão de Deputado em flagrante de crime inafiançável e na autorização, ou não, para a respectiva formação de culpa;

e) na deliberação para destituição de Procurador-Geral de Justiça;

f) na deliberação sobre vetos do Poder Executivo.

**Art. 93.** Ao Poder Legislativo é assegurada autonomia administrativa e financeira e sua proposta orçamentária será elaborada dentro dos limites a serem fixados pela lei de diretrizes orçamentárias.

##### SEÇÃO II Das Atribuições da Assembleia Legislativa

**Art. 94.** Compete à Assembleia Legislativa, com sanção do Governador do Estado, não exigida esta para o especificado no art. 95 desta Constituição, dispor sobre todas as matérias de competência do Estado, especialmente sobre:

I - sistema tributário estadual, instituição de impostos, taxas, contribuição de melhoria e contribuição social;

II - plano plurianual, diretrizes orçamentárias, orçamento anual, operações de crédito a qualquer título e dívida pública;

III - planos e programas estaduais, regionais e setoriais de desenvolvimento;

IV - criação, transformação e extinção de cargos, empregos e funções públicas e fixação de alteração dos respectivos vencimentos, salários ou vantagens;

V - fixação e modificação do efetivo da Polícia Militar;

VI - criação, estruturação e atribuições das Secretárias e órgãos da administração pública estadual, direta e indireta, autárquica e fundacional;

VII - criação, incorporação, fusão e desmembramento de Municípios;

VIII - bens de domínio do Estado e normas gerais sobre alienação, concessão, cessão, permuta, arrendamento e aquisição dos mesmos;

IX - organização administrativa e judiciária do Ministério Público, da Procuradoria-Geral do Estado, da Defensoria Pública e do Tribunal de Contas;

IX - organização administrativa e judiciária do Ministério Público, da Procuradoria-Geral do Estado, e da Defensoria Pública; (redação dada pela Emenda Constitucional nº 22, de 18.01.2001)

X - proteção, recuperação e incentivo à preservação do meio ambiente;

XI - limites do território estadual, bens do domínio do Estado e proteção do patrimônio público;

XII - matéria de legislação concorrente, na forma do art. 24 da Constituição Federal;

XIII - fixação e alteração da remuneração dos membros do Poder Judiciário, do Ministério Público e dos servidores auxiliares, respeitados os princípios de isonomia previstos na Constituição Federal e nesta Constituição;

XIII - fixação dos subsídios dos membros do Poder Judiciário, do Ministério Público e dos servidores auxiliares, observado o que dispõe os art. 42, XI e 47, § 4º, desta Constituição e 150, II, 152, III e 153, § 2º, I, da Constituição Federal; (redação dada pela Emenda Constitucional nº 14, de 20.12.1999)

XIV - normas de direito financeiro;

XV - normas de privatização de empresa estatal de qualquer espécie;

XVI - disciplinar a restrição à participação em concorrências públicas e ao acesso a benefícios e a créditos oficiais de responsável por atos de degradação ao meio ambiente;

**Art. 95.** Compete privativamente à Assembleia Legislativa: CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 41

I - eleger sua Mesa e constituir suas comissões;

I - eleger os membros da Mesa Diretora, com mandato de dois anos, permitida a reeleição e constituir suas comissões. (redação dada pela Emenda Constitucional nº 7, de 31.10.1996)

I - eleger os membros da Mesa Diretora e constituir suas comissões; (redação dada pela Emenda Constitucional nº 28, de 30.12.2003)

I - eleger os membros da Mesa Diretora, com mandato de dois anos, permitida a reeleição e constituir suas comissões. (redação dada pela Emenda Constitucional nº 31, de 07.05.2003)

II - dispor, através de resolução, sobre a organização, funcionamento, polícia, criação, transformação ou extinção de cargos, empregos e funções de seus serviços e fixação ou alteração da respectiva remuneração, observados os parâmetros estabelecidos na lei de diretrizes orçamentárias;

II - dispor, através de Resolução, sobre sua organização, funcionamento, polícia, criação, transformação ou extinção dos cargos, empregos e funções de seus serviços, e a iniciativa de lei para a fixação da respectiva remuneração, observados os parâmetros estabelecidos na Lei de Diretrizes Orçamentárias. (redação dada pela

Emenda Constitucional nº 14, de 20.12.1999)

II - Dispor através de Lei, sobre sua organização, funcionamento, polícia, criação, transformação ou extinção dos cargos, empregos e funções de seus serviços, e a iniciativa de lei para a fixação da respectiva remuneração, observados os parâmetros estabelecidos na Lei de Diretrizes Orçamentárias. (redação dada pela Emenda Constitucional nº 53, 24.08.de 2015)

III - elaborar seu Regimento Interno;

IV - dar posse ao governador e ao Vice-Governador eleitos, conhecer de suas renúncias, conceder ao Governador licença para interromper o exercício de suas funções, ausentar-se do Estado por mais de quinze dias ou afastar-se do País;

V - apreciar os relatórios do Governador do Estado sobre execução dos planos de Governo;

VI - julgar anualmente, as contas do Governador e, se este não as prestar até sessenta dias da abertura da sessão legislativa, eleger Comissão para tomá-las, determinando providência para a punição dos culpados;

VII - fiscalizar e controlar, diretamente, os atos do Poder Executivo, incluídos os da administração indireta;

VIII - suspender a execução, no todo ou em parte, de lei declarada inconstitucional por decisão definitiva do Tribunal de Justiça do Estado ou instância superior;

IX - sustar os atos normativos do Poder Executivo que exorbitem do Poder regulamentar ou dos limites de delegação legislativa;

X - convocar Secretários de Estado para prestarem informações, pessoalmente, no prazo de trinta dias, sobre assuntos de suas pastas, previamente determinados, importando em crime de responsabilidade a ausência sem justificação adequada;

XI - processar e julgar o Governador do Estado nos crimes de responsabilidade, e o Vice-Governador do Estado nos crimes de mesma natureza conexos com os daquele;

XI - processar e julgar: (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

a) o Governador e o Vice-Governador do Estado nos crimes de responsabilidade, bem como os Secretários de Estado nos crimes da mesma natureza conexos com aqueles; (incluída pela Emenda Constitucional nº 35, de 21.03.2006)

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 42

b) o Procurador Geral de Justiça e o Procurador-Geral do Estado nos crimes de responsabilidade. (incluída pela Emenda Constitucional nº 35, de 21.03.2006)

XII - fixar a remuneração:

a) do Governador e do Vice-Governador do Estado para cada exercício financeiro, sendo a do Vice-Governador equivalente à dos Deputados Estaduais;

b) dos Deputados Estaduais, em cada legislatura, para vigorar na subsequente.

XII - fixar através de lei específica, os subsídios: (redação dada pela Emenda Constitucional nº 14, de 20.12.1999)

a) do Governador, do Vice-Governador e dos Secretários de Estado, observado o que dispõe os art. 42, XI e 47, § 4º, desta Constituição, e 150, II, 152, II, e 153, § 2º, I da Constituição Federal. (redação dada pela Emenda Constitucional nº 14, de 20.12.1999)

b) dos deputados estaduais, observado o que dispõe os art. 42, XI, e 47,

**§ 4º** desta Constituição, e os art. 150, II, 152, II e 153, § 2º, I da Constituição Federal. (redação dada pela Emenda Constitucional nº 14, de 20.12.1999)

XIII - autorizar referendo e convocar plebiscito, na forma da lei;

XIV - declarar a perda de mandato de Deputado;

XV - apreciar e deliberar os vetos do Governador do Estado;

XVI - aprovar, por maioria absoluta e voto secreto, a indicação ou a destituição do Procurador-Geral de Justiça;

XVI - aprovar, por maioria absoluta e voto secreto, a destituição do Procurador-Geral de Justiça; (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

XVII - julgar, anualmente, as contas da Mesa da Assembleia Legislativa, do Tribunal de Justiça, do Ministério Público e do Tribunal de Contas, aplicando-se, em cada caso, o disposto no inciso VI, deste artigo;

XVII - julgar, anualmente, as contas do Tribunal de Contas do Estado, aplicando-se, quando for o caso, o previsto no inciso VI deste artigo; (redação dada pela

Emenda Constitucional nº 35, de 21.03.2006)

XVIII - mudar temporariamente sua sede;

XIX - solicitar ao Governador do Estado, na forma do Regimento Interno, informações sobre atos de sua competência privativa;

XX - autorizar ou aprovar convênios, acordos ou contratos com os governos federal, estadual ou municipal, entidades de direito público ou privado, de que resultem para o Estado quaisquer encargos não estabelecidos na lei orçamentária.

XX - Aprovar convênios, acordos ou contratos com os Governos federal, estaduais ou municipais e com entidades de direito público ou privado, de que resultem para o Estado quaisquer encargos não estabelecidos na lei orçamentária; (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

XXI - aprovar previamente, por voto secreto, após arguição pública, o nome do Presidente do Banco do Estado indicado pelo Governador.

XXI - apreciar, trimestralmente os relatórios das atividades do Tribunal de Contas do Estado; (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

XXII - elaborar o seu Regimento Interno;

XXIII - solicitar, pelo voto da maioria absoluta de seus membros, intervenção federal no Estado, quando houver coação ou impedimento do livre exercício do Poder Legislativo;

XXIV - aprovar, após arguição, pelo voto secreto da maioria de seus membros, os nomes dos presidentes de empresas estatais e fundacionais;

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 43

XXIV - aprovar, após arguição, pelo voto secreto da maioria de seus membros, os nomes dos presidentes de fundações públicas; (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

XXIV - aprovar, após arguição, pela maioria de seus membros, os nomes dos Procuradores Gerais de Justiça, dos presidentes de fundações estaduais, agências de fomento, sociedades de economia mista e empresas públicas. (redação dada pela Emenda Constitucional nº 53, 24.08.de 2015) (expressão tachada foi declarada inconstitucional, em controle concentrado, pelo Supremo Tribunal Federal, no julgamento da ADIN nº 6.608).

XXV - convocar o Procurador-Geral de justiça, o Procurador-Geral do Estado e o Defensor Público Geral, para prestarem informações sobre assuntos previamente determinados, no prazo de 30 dias, sujeitando-se estes às penas da lei, na ausência sem justificativa;

XXVI - requisitar informações dos Secretários de Estados e do Procurador-Geral de justiça sobre assuntos relacionados com suas pastas ou instituições, importando crime de responsabilidade a recusa ou não atendimento, no prazo de trinta dias, e o fornecimento de informações falsas; (expressão tachada foi declarada inconstitucional, em controle concentrado, pelo Supremo Tribunal Federal, no julgamento da ADIN nº 5.300)

XXVII - zelar pela preservação de sua competência legislativa em face da atribuição normativa de outros Poderes;

XXVIII - escolher dois terços dos membros do Tribunal de Contas do Estado, após arguição em sessão pública;

XXIX - aprovar, previamente, em escrutínio secreto, após arguição em sessão pública, a escolha dos titulares dos cargos de conselheiro do Tribunal de Conta indicados pelo Governador do Estado;

XXX - avaliar periodicamente a funcionalidade do Sistema Tributário Estadual, em sua estrutura e seus componentes e o desempenho da administração tributária do Estado. (incluído pela Emenda Constitucional nº 35, de 21.03.2006)

##### SEÇÃO III Dos Direitos e Deveres dos Deputados

**Art. 96.** Os Deputados são invioláveis por suas opiniões, palavras e votos.

**§ 1º** Desde a expedição do diploma, os Deputados não poderão ser presos, salvo em flagrante de crime inafiançável, nem processados criminalmente, sem prévia licença da Assembleia Legislativa;

**§ 2º** O indeferimento do pedido de licença ou a ausência de deliberação suspende a prescrição enquanto durar o mandato;

**§ 3º** No caso de flagrante de crime inafiançável, os autos serão remetidos, dentro de vinte e quatro horas, à Assembleia Legislativa, para que ela, pelo voto secreto da maioria de seus membros, resolva sobre a prisão e autorize, ou não, a formação de culpa;

**§ 4º** Os Deputados serão submetidos a julgamento perante o Tribunal de Justiça do Estado;

**§ 5º** Os Deputados não serão obrigados a testemunhar sobre informações recebidas ou prestadas em razão do exercício do mandato, nem sobre as pessoas que lhes confiaram ou deles receberam informações;

**§ 6º** A incorporação às Forças Armadas de Deputados, embora militares e ainda que em tempo de guerra, dependerá de prévia licença da Assembleia Legislativa;

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 44

**§ 7º** As imunidades de Deputados subsistirão durante o estado de sítio, só podendo ser suspensas mediante o voto de dois terços dos membros da Assembleia Legislativa, nos casos de atos praticados fora do seu recinto que sejam incompatíveis com a execução da medida.

**Art. 96.** Os Deputados são invioláveis, civil e penalmente, por quaisquer de suas opiniões, palavras e votos. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

**§ 1º** Os Deputados, desde a expedição do diploma, serão submetidos a julgamento perante o Tribunal de Justiça do Estado do Amapá. (redação dada pela

Emenda Constitucional nº 35, de 21.03.2006)

**§ 2º** Desde a expedição do Diploma, os Deputados não poderão ser presos, salvo em flagrante de crime inafiançável. Nesse caso, os autos serão remetidos dentro de vinte e quatro horas à Assembleia Legislativa, para que, pelo voto da maioria de seus membros, resolva sobre a prisão. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

**§ 3º** Recebida a denúncia contra Deputado, por crime ocorrido após a diplomação, o Tribunal de Justiça dará ciência à Assembleia Legislativa, que, por iniciativa de partido político nela representado e pelo voto da maioria de seus membros, poderá, até a decisão final, sustar o andamento da ação. (redação dada pela

Emenda Constitucional nº 35, de 21.03.2006)

**§ 4º** O pedido de sustação será apreciado pela Assembleia Legislativa no prazo improrrogável de quarenta e cinco dias do seu recebimento pela Mesa Diretora. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

**§ 5º** A sustação do processo suspende a prescrição enquanto durar o mandato. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

**§ 6º** Os Deputados não serão obrigados a testemunhar sobre informações recebidas ou prestadas em razão do exercício do mandato, nem sobre as pessoas que lhes confiaram ou deles receberam informações. (redação dada pela

Emenda Constitucional nº 35, de 21.03.2006)

**§ 7º** A incorporação às Forças Armadas de Deputados, embora militares e ainda que em tempo de guerra, dependerá de prévia licença da Assembleia Legislativa. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

**§ 8º** As imunidades de Deputados subsistirão durante o estado de sítio, só podendo ser suspensas mediante o voto de dois terços dos membros da Assembleia Legislativa, nos casos de atos praticados fora do recinto da Assembleia, que sejam incompatíveis com a execução da medida. (incluído pela Emenda Constitucional nº 35, de 21.03.2006)

**Art. 97.** Os Deputados não poderão:

I - desde a expedição de diploma:

a) firmar ou manter contrato com pessoa jurídica de direito público, autarquia, empresa pública, sociedade de economia mista ou empresa concessionária de serviço público, salvo quando o contrato obedecer a cláusulas uniformes;

b) aceitar ou exercer cargo, função ou emprego remunerado, inclusive os de que sejam demissíveis ad nutum, nas entidades constantes da alínea anterior.

II - desde a posse:

a) ser proprietários, controladores ou diretores de empresa que goze de favor decorrente de contrato com pessoa jurídica de direito público, ou nela exercer função remunerada;

b) ocupar cargo ou função desde que sejam demissíveis ad nutum, nas entidades referidas no inciso I, alínea a;

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 45

c) patrocinar causa em que seja interessada qualquer das entidades a que se refere o inciso I, alínea a;

d) ser titulares de mais de um cargo ou mandato público eletivo.

**Art. 98.** Perderá o mandato o Deputado:

I - que infringir qualquer das proibições estabelecidas no artigo anterior;

II - cujo procedimento for declarado incompatível com o decoro parlamentar;

III - que deixar de comparecer, em cada sessão legislativa, à terça parte das sessões ordinárias, salvo licença ou missão autorizada pela Assembleia;

IV - que perder ou tiver suspensos os direitos políticos;

V - quando o decretar a Justiça Eleitoral, nos casos previstos na constituição Federal;

VI - que sofrer condenação criminal em sentença transitada em julgado.

**§ 1º** Além de outros casos a serem definidos no regimento Interno, considerar-se-á incompatível com o decoro parlamentar o abuso das prerrogativas asseguradas ao Deputado, ou a percepção, no exercício do cargo, de vantagens indevidas, e o envolvimento em crimes definidos como hediondos e a tráfico ilícito de entorpecentes e drogas afins.

**§ 2º** Nos casos dos incisos I, II e VI, a perda de mandato será decidida pela Assembleia Legislativa, por voto secreto e maioria absoluta, mediante provocação da Mesa ou de partido político representado na Assembleia, assegurada ampla defesa.

**§ 2º** Nos casos dos incisos I, II e VI, a perda de mandato será decidida pela Assembleia Legislativa por maioria absoluta, mediante provocação da Mesa ou de partido politico representado na Assembleia assegurada ampla defesa. (redação dada pela Emenda Constitucional nº 56, de 03.05.2017)

**§ 3º** Nos casos dos incisos III, IV e V, a perda será declarada pela Mesa, de ofício ou mediante provocação de qualquer de seus membros, ou de partido político representado na Assembleia Legislativa, assegurada ampla defesa.

**§ 4º** A renúncia de parlamentar submetido a processo que vise ou possa levar à perda do mandato, nos termos deste artigo, terá seus efeitos suspensos até as deliberações finais de que tratam os §§ 2º e 3º. (incluído pela Emenda Constitucional nº 35, de 21.03.2006)

**Art. 99.** Não perderá o mandato o Deputado:

I - investido no cargo de Ministro de Estado, Governador de Território, Secretário de Estado, Secretário de Prefeitura Municipal ou chefe de missão diplomática temporária;

II - licenciado pela Assembleia Legislativa por motivo de doença, ou para tratar, sem remuneração, de interesse particular, desde que, neste caso, o afastamento não ultrapasse cento e vinte dias por sessão legislativa.

**§ 1º** O suplente será convocado nos casos de vaga decorrente da investidura em funções previstas neste artigo ou de licença superior a cento e vinte dias.

**§ 2º** Ocorrendo vaga e não havendo suplente, far-se-á eleição para preenchê-la, se faltarem mais de quinze meses para o término do mandato.

**§ 3º** Na hipótese de inciso I, o Deputado poderá optar pela remuneração do mandato.

##### SEÇÃO IV Das Reuniões

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 46

**Art. 100.** A Assembleia Legislativa reunir-se-á, anualmente, na Capital do Estado, independentemente de convocação, de 15 de fevereiro a 30 de junho e de l2 de agosto a 15 de dezembro.

**Art. 100.** A Assembleia Legislativa reunir-se-á, anualmente, na Capital do Estado, de 02 de fevereiro a 17 de julho e de 1º de agosto a 22 de dezembro. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

**Art. 100.** A Assembleia Legislativa reunir-se-á, anualmente, na capital do Estado, de 02 de fevereiro a 30 de junho e de 1º de agosto a 22 de dezembro. (redação dada pela Emenda Constitucional nº 41, de 27.05.2008)

**§ 1º** As reuniões marcadas para essas datas serão transferidas para o primeiro dia útil subsequente, quando recaírem em sábados, domingos ou feriados.

**§ 2º** A sessão legislativa não será interrompida sem a aprovação do projeto de lei de diretrizes orçamentárias.

**§ 2º** A sessão legislativa não será interrompida sem a aprovação do projeto de lei de diretrizes orçamentárias, exceto no caso previsto no § 12 do Art. 175. (redação dada pela Emenda Constitucional nº 30, de 29.04.2003)

**§ 3º** A Assembleia Legislativa reunir-se-á, em sessão preparatória, a partir de 1º de fevereiro, no primeiro ano da legislatura, para a posse de seus membros e eleição da Mesa, para mandato de dois anos, vedada a recondução para o mesmo cargo na eleição imediatamente subsequente.

**§ 3º** A Assembleia Legislativa reunir-se-á, em Sessão Preparatória, a partir de 1º de fevereiro, no primeiro ano de Legislatura, para a posse de seus membros e eleição da Mesa Diretora, para mandato de dois anos, permitida a reeleição. (redação dada pela Emenda Constitucional nº 7, de 31.10.1996)

**§ 3º** A Assembleia Legislativa reunir-se-á, em Sessão Preparatória, a partir de 1º de fevereiro, no primeiro ano de Legislatura, para a posse de seus membros e eleição da Mesa Diretora, para mandato de dois anos, vedada a recondução para o mesmo cargo na eleição imediatamente subsequente. (redação dada pela Emenda Constitucional nº 28, de 30.12.2003)

**§ 3º** A Assembleia Legislativa reunir-se-á, em Sessão Preparatória, a partir de 1º de fevereiro, no primeiro ano de Legislatura, para a posse de seus membros e eleição da Mesa Diretora, para mandato de dois anos, permitida a reeleição. (redação dada pela Emenda Constitucional nº 31, de 07.05.2003)

**§ 4º** A convocação extraordinária da Assembleia Legislativa poderá ser feita:

**§ 4º** A convocação extraordinária da Assembleia Legislativa far-se-á: (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

I - pelo seu Presidente, para o compromisso e a posse do Governador e Vice-Governador do Estado, bem assim em caso de intervenção federal;

II - pelo seu Presidente, ou a requerimento da maioria de seus membros, ou ainda pelo Governador do Estado, em caso de urgência ou interesse público relevante.

II - pelo seu Presidente, a requerimento da maioria de seus membros ou pelo Governador do Estado, em caso de urgência ou interesse público relevante, em todas as hipóteses deste inciso com a aprovação da maioria absoluta dos seus membros. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

**§ 5º** Na sessão legislativa extraordinária, a Assembleia Legislativa somente deliberará sobre a matéria para a qual foi convocada.

**§ 5º** Na sessão legislativa extraordinária, a Assembleia Legislativa somente deliberará sobre matéria para qual foi convocada, vedado o pagamento de

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 47

parcela indenizatória, em razão da convocação. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

##### SEÇÃO V Das Comissões

**Art. 101.** A Assembleia Legislativa terá comissões permanentes e temporárias, na forma e com as atribuições previstas nesta Constituição, no seu regimento interno ou no ato de regular sua criação.

**§ 1º** Na constituição da Mesa e de cada Comissão, é assegurada, tanto quanto possível, a representação proporcional dos partidos ou dos blocos parlamentares que participam da Assembleia.

**§ 2º** Às Comissões, em razão de sua competência, cabe:

I - discutir e votar projetos de lei que dispensar, na forma do Regimento Interno, a competência do plenário, salvo se houver, por decisão deste, requerimento de um quinto dos membros da Assembleia Legislativa;

II - convocar Secretários de Estado ou dirigentes de órgãos estaduais, para prestarem informações inerentes às suas atribuições, no prazo de trinta dias, sujeitando-se pelo não comparecimento sem justificativa adequada, ao julgamento da Assembleia por crime de responsabilidade;

III - realizar audiência públicas com entidade da sociedade civil;

IV - receber petições, reclamações, representações ou queixas de qualquer pessoa, contra atos ou omissões das autoridades ou entidades públicas ou prestadoras de serviços públicos;

V - solicitar o depoimento de qualquer autoridade ou cidadão;

VI - fiscalizar e apreciar programas de obras, planos estaduais, regionais e setoriais de desenvolvimento e, sobre eles, emitir parecer;

VII - acompanhar a execução orçamentária do Poder Executivo;

VIII - realizar audiências públicas dentro e fora da sede do Poder Legislativo.

**§ 3º** Às Comissões Parlamentares de Inquérito, que terão poderes de investigação próprios das autoridades judiciais, além de outros previstos no Regimento Interno, serão criadas mediante requerimento de um terço dos membros da Assembleia Legislativa, para apuração de fato determinado e por prazo certo, sendo suas conclusões, quando for o caso, encaminhadas ao Ministério Público para que se promova a responsabilidade civil e criminal dos infratores.

**§ 4º** A omissão de informações às Comissões Parlamentares de Inquérito, inclusive as que envolvam sigilo, ou a prestação de informações falsas constitui crime de responsabilidade.

**§ 5º** Durante o recesso, salvo convocação extraordinária, haverá uma comissão representativa da Assembleia Legislativa eleita na última sessão ordinária do período legislativo, com atribuições definidas no Regimento Interno, não podendo deliberar sobre emendas à Constituição e projetos de lei, cuja composição reproduzirá tanto quanto possível, a proporcionalidade da representação dos partidos ou blocos parlamentares.

##### SEÇÃO VI Do Processo Legislativo

###### SUBSEÇÃO I

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 48

Das Disposições Gerais

**Art. 102.** O processo legislativo compreende a elaboração de:

I - emendas à Constituição;

II - leis complementares;

III - leis ordinárias;

IV - leis delegadas;

V - decretos legislativos;

VI - resoluções.

**Parágrafo único.** Lei complementar disporá sobre a elaboração, alteração e consolidação das leis. (incluído pela Emenda Constitucional nº 14, de 20.12.1999)

###### SUBSEÇÃO II Das Emendas à Constituição

**Art. 103.** A Constituição poderá ser emendada mediante proposta:

I - de um terço, no mínimo, dos Deputados Estaduais;

II - do Governador do Estado;

III - de mais da metade das Câmaras Municipais do Estado, manifestando-se, cada uma delas, pela maioria relativa de seus membros;

IV - de cidadãos, mediante iniciativa popular assinada, no mínimo, por um por cento dos eleitores do Estado;

**§ 1º** A Constituição não poderá ser emendada na vigência de intervenção federal no Estado, estado de defesa ou estado de sítio.

**§ 2º** A proposta será discutida e votada em dois turnos, considerando-se aprovada se obtiver, em ambos, três quintos dos votos dos membros da Assembleia Legislativa.

**§ 3º** A emenda à Constituição será promulgada pela Mesa da Assembleia Legislativa.

**§ 4º** Não será objeto de deliberação a proposta de emenda tendente a abolir:

I - o princípio federativo;

II - a separação dos Poderes;

III - os direitos e garantias individuais;

IV - o voto direto, secreto, universal e periódico.

**§ 5º** A matéria constante da proposta de emenda rejeitada ou havida por prejudicada não poderá ser objeto de nova proposta na mesma sessão legislativa.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 49

###### SUBSEÇÃO III Das Leis

**Art. 104.** A iniciativa das leis complementares e ordinárias cabe a qualquer membro ou Comissão da Assembleia Legislativa, ao Governador do Estado, ao Tribunal de Justiça, ao Procurador-Geral de Justiça e aos cidadãos nos casos e na forma prevista nesta Constituição.

**Parágrafo único.** São de iniciativa privativa do Governador do Estado as leis que disponham sobre:

I - a organização, o regime jurídico dos servidores militares e a fixação ou modificação dos efetivos da Polícia Militar;

II - criação de cargos, funções ou empregos públicos na administração direta, autárquica e fundacional do Estado ou aumento de sua remuneração;

III - servidores públicos do Estado, seu regime jurídico, provimento de cargos, estabilidade e aposentadoria de civis, reforma e transferência de militares para a inatividade;

IV - organização da Procuradoria-Geral do Estado, da Defensoria Pública e do Ministério Público estadual;

V - criação, estruturação e atribuições das Secretarias de Estado e órgãos da administração pública estadual;

VI - plano plurianual, diretrizes orçamentárias e orçamento anual;

VII - criação e extinção de sociedade de economia mista e empresa pública, e suas subsidiárias.

**Art. 105.** Não será admitido aumento da despesa prevista:

I - nos projetos de iniciativa exclusiva do Governador do Estado, ressalvado o disposto no art. 176, §§ 3º e 4º, desta Constituição;

II - nos projetos sobre organização dos serviços administrativos da Assembleia Legislativa, dos Tribunais e do Ministério Público.

**Art. 106.** O Governador do Estado poderá solicitar urgência, a qualquer tempo, para apreciação de projetos de sua iniciativa.

**§ 1º** Solicitado e justificado o pedido de urgência na mensagem enviada à Assembleia Legislativa, se esta não se manifestar em até quarenta e cinco dias sobre a proposição, será esta incluída na ordem do dia, sobrestando-se a deliberação quanto aos demais assuntos, para que se ultima a votação.

**§ 2º** O prazo estabelecido no parágrafo anterior não ocorre nos períodos de recesso da Assembleia Legislativa, nem se aplica aos projetos de código.

**Art. 107.** Concluída a votação e aprovação do projeto de lei na forma regimental, será ele enviado ao Governador do Estado que, aquiescendo, o sancionará.

**§ 1º** Se o Governador do Estado considerar o projeto, no todo ou em parte, inconstitucional ou contrário ao interesse público, vetá-lo-á total ou parcialmente, no prazo de quinze dias úteis, contados da data do recebimento, e comunicará, dentro de quarenta e oito horas, ao Presidente da Assembleia Legislativa, os motivos do veto.

**§ 2º** O veto parcial somente abrangerá texto integral de artigo, de parágrafo, de inciso ou de alínea.

**§ 3º** Sendo negada a sanção, as razões do veto serão comunicadas ao Presidente da Assembleia Legislativa.

**§ 4º** Decorrido o prazo de quinze dias, o silêncio do Governador do Estado, importará sanção.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 50

**§ 5º** A Assembleia Legislativa deliberará sobre o veto em uma única discussão e votação, no prazo de trinta dias de seu recebimento, só podendo ser rejeitado pelo voto da maioria absoluta dos Deputados, em escrutínio secreto.

**§ 6º** Esgotado, sem deliberação, o prazo estabelecido no § 5º, o veto será colocado na Ordem do Dia da sessão imediata, sobrestadas as demais proposições até sua votação final.

**§ 7º** Se o veto não for mantido, será o projeto enviado para promulgação, ao Governador do Estado.

**§ 8º** Se a lei não for promulgada dentro de quarenta e oito horas pelo Governador do Estado, no caso do § 7º, o Presidente da Assembleia Legislativa a promulgará e, se este não o fizer em igual prazo, caberá ao Vice-Presidente fazê-lo.

**§ 8º** Se a lei não for promulgada dentro de quarenta e oito horas pelo Governador do Estado, nos casos dos §§ 4º e 7º, o Presidente da Assembleia Legislativa a promulgará, e, se este, não o fizer em igual prazo, caberá ao Vice- Presidente fazê-lo. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006) .Art. 109. Além de outros casos previstos nesta Constituição serão complementares as leis que dispuserem sobre:

I - organização e divisão judiciária;

II - organização do Ministério Público, da Procuradoria-Geral do Estado, da Defensoria Pública, do Tribunal de Contas do Estado e da Polícia Militar.

II - organização do Ministério Público, da Procuradoria-Geral do Estado, da Defensoria Pública e da Polícia Militar; (redação dada pela Emenda Constitucional nº 22, de 18.01.2001)

III - atribuições de Vice-Governador do Estado;

IV - organização do sistema estadual de educação;

V - código de proteção ao meio ambiente.

**Parágrafo único.** As leis complementares terão numeração distinta da numeração das leis ordinárias.

**Parágrafo único.** As leis complementares serão aprovadas por maioria absoluta e terão numeração distinta da numeração das leis ordinárias. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

###### SUBSEÇÃO IV Da Iniciativa Popular

**Art. 110.** A iniciativa popular pode ser exercida pela apresentação à Assembleia Legislativa de projeto de lei ou proposta de emenda à Constituição, devidamente articulados e subscritos por, no mínimo, um por cento do eleitorado estadual, distribuídos em, pelo menos, cinco Municípios, com um mínimo de dois por cento dos eleitores de cada um dos Municípios.

**Art. 110.** A iniciativa popular pode ser exercida pela apresentação à Assembleia Legislativa de projeto de lei, subscrito por, no mínimo, um por cento do eleitorado estadual, distribuído pelo menos por cinco Municípios, com um mínimo de dois por cento dos eleitores de cada um deles, e de proposta de emenda à Constituição na forma do inciso IV do art. 103. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

**Parágrafo único.** Os projetos de lei apresentados através de iniciativa popular terão inscrição prioritária na ordem do dia, no prazo máximo de quarenta e cinco dias, garantindo-se a sua defesa em plenário por um dos cidadãos subscritores, na forma do Regimento Interno da Assembleia Legislativa.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 51

##### SEÇÃO VII Da Fiscalização Contábil, Financeira e Orçamentária

**Art. 111.** A fiscalização contábil, financeira, orçamentária, operacional, e patrimonial do Estado e dos órgãos e entidades da administração pública direta e indireta e de qualquer das entidades constituídas ou mantidas pelo Estado, quanto à legalidade, legitimidade, economicidade, aplicação das subvenções e renúncias de receitas, será exercida pela Assembleia Legislativa, mediante controle externo e pelo sistema de controle interno de cada Poder.

**§ 1º** O controle externo, a cargo da Assembleia Legislativa, será exercido com auxílio do Tribunal de Contas do Estado.

**§ 2º** Prestará contas qualquer pessoa física, jurídica, empresa de cujo capital social o Estado ou Município participe, de forma direta ou indireta, ou entidade pública que arrecade, guarde, gerencie ou administre dinheiros, bens e valores públicos ou pelos quais o Estado ou Município responda, ou em nome destes assuma obrigações de natureza pecuniária.

**§ 2º** Prestará contas qualquer pessoa física ou jurídica, pública ou privada que utilize, arrecade, guarde, gerencie ou administre dinheiro, bens e valores públicos ou pelos quais o Estado responda, ou que, em nome deste, assuma obrigações de natureza pecuniária. (redação dada pela Emenda Constitucional nº 14, de 20.12.1999)

**Art. 112.** Ao Tribunal de Contas compete:

**Art. 112.** O controle externo, a cargo da Assembleia Legislativa, será exercido com o auxílio do Tribunal de Contas do Estado, ao qual compete: (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

I - apreciar as contas prestadas anualmente pelo Governador do Estado, mediante parecer prévio que deverá ser elaborado em sessenta dias, a contar de seu recebimento;

II - apreciar as contas anuais dos Prefeitos e Presidentes de Câmaras Municipais, emitindo parecer prévio dentro do exercício em que forem prestadas;

II - apreciar as contas dos Prefeitos e julgar as contas da Mesa Diretora das Câmaras Municipais, dentro do exercício em que forem prestadas; (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

III - julgar as contas dos administradores e demais responsáveis por dinheiros, bens e valores da administração direta e indireta, incluídas as fundações e as sociedades instituídas e mantidas pelo Poder Público estadual ou municipal e as contas daqueles que derem causa a perda, extravio ou outra irregularidade de que resulte prejuízo ao erário;

IV - apreciar, para fins de registro, a legalidade dos atos de admissão de pessoal, a qualquer título, na administração direta e indireta, incluídas as fundações instituídas e mantidas pelo Poder Público, excetuadas as nomeações para cargos de provimento em comissão, bem como a das concessões de aposentadorias, reformas e pensões, ressalvadas as melhorias posteriores que não alterem o fundamento legal do ato concessório;

V - realizar, por iniciativa própria, da Assembleia Legislativa, de comissão técnica ou de inquérito, inspeções e auditorias de natureza contábil, financeira, orçamentária, operacional e patrimonial, nas unidades administrativas dos Poderes Legislativo, Executivo e Judiciário, e demais entidades referidas no inciso II;

V - realizar, por iniciativa própria, da Assembleia Legislativa, de Comissão técnica ou de inquérito, inspeções e auditorias de natureza contábil, financeira, orçamentária, operacional e patrimonial, nas unidades administrativas dos

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 52

Poderes Legislativo, Executivo e Judiciário, e demais entidades referidas no inciso III; (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

VI - fiscalizar a aplicação de quaisquer recursos repassados pelo Estado a Municípios, mediante convênio, acordo, ajuste ou qualquer outro instrumento congênere, e das subvenções a qualquer entidade de direito privado;

VII - prestar as informações solicitadas pelos Poderes Legislativos estadual e municipal ou por qualquer de suas Comissões, sobre a fiscalização contábil, financeira, orçamentária, operacional e patrimonial e sobre resultados de auditoria e inspeções realizadas;

VIII - aplicar, aos responsáveis pela prática de ilegalidade de despesa, irregularidade de contas, atraso no envio de prestações de contas ou descumprimento de suas decisões, as sanções previstas em lei, que estabelecerá, dentre outras cominações, multa proporcional ao dano causado ao erário;

IX - fiscalizar as contas de empresas ou consórcios interestaduais e intermunicipais de cujo capital social participe o Estado ou Município, conforme o caso, de forma direta ou indireta, nos termos de acordo, convênio ou ato constitutivo;

X - assinalar prazo, quando constatada a ilegalidade ou irregularidade para que o órgão ou entidade adote as providências necessárias ao exato cumprimento da lei, sustando, caso não atendido, a execução do ato impugnado, comunicando o fato, conforme o caso, à Assembleia Legislativa ou à Câmara Municipal;

XI - representar ao Poder competente sobre irregularidade ou abusos apurados;

XII - propor, em caso de irregularidade comprovada, a sustação de contrato, à Assembleia Legislativa ou às Câmaras Municipais, que solicitarão, de imediato, respectivamente, ao Poder Executivo estadual ou Municipal, conforme o caso, as medidas cabíveis;

XIII - adotar as medidas legais cabíveis, se, no prazo de trinta dias, os Poderes Legislativos e Executivos estaduais ou municipais, não adotarem as providências previstas no inciso anterior; (revogado pela Emenda Constitucional nº 35, de 21.03.2006)

XIV - comunicar à Assembleia Legislativa ou a Câmara Municipal, para fins de direito, a falta de remessa, dentro do prazo legal, das contas anuais do governo estadual e das Prefeituras Municipais;

XV - examinar as demonstrações contábeis e financeiras constantes de balancetes mensais, determinando as regularizações necessárias, na forma que a lei estabelecer;

XVI - negar a aplicação de lei ou ato normativo considerado inconstitucional ou ilegal que tenha ou possa vir a ter reflexo no erário estadual ou municipal, incumbindo-lhe, de imediato, justificar a ilegalidade ou propor à Assembleia Legislativa, às Câmaras Municipais ou ao Ministério Público, a arguição de inconstitucionalidade;

XVII - homologar os cálculos das cotas do ICMS devidas aos Municípios;

XVIII - editar acórdãos, atos, resoluções e pareceres prévios, no âmbito de suas atribuições e competências, para o completo desempenho do controle externo, os quais deverão ser cumpridos pelas administrações estadual e municipais, sob pena de responsabilidade, bem como para o seu regular funcionamento;

XIX - elaborar sua proposta orçamentária dentro dos limites estipulados na lei de diretrizes orçamentárias, desvinculada do orçamento da Assembleia Legislativa.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 53

**§ 1º** No caso de contrato, o ato de sustação será adotado diretamente pela Assembleia Legislativa, que solicitará, de imediato, ao Poder Executivo as medidas cabíveis.

**§ 1º** No caso de contrato, o ato de sustação será adotado diretamente pela Assembleia Legislativa ou pelas Câmaras Municipais que solicitarão, de imediato, ao Poder Executivo as medidas cabíveis. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

**§ 2º** Se a Assembleia Legislativa ou o Poder Executivo, no prazo de noventa dias, não efetivar as medidas previstas no parágrafo anterior, o Tribunal decidirá a respeito.

**§ 3º** As decisões do Tribunal de que resulte imputação de débito ou multa terão eficácia de título executivo.

**§ 4º** O Tribunal encaminhará à Assembleia Legislativa, trimestralmente e anualmente, relatório de suas atividades.

**§ 5º** Compete, ainda, ao Tribunal de Contas: (incluído pela Emenda Constitucional nº 20, 12.12.2000) (Revogado pela Emenda Constitucional 22, de 18.01.2001)

I – eleger seus órgãos diretivos 30 (trinta) dias antes do término dos respectivos mandatos, assim o Presidente e o Vice-Presidente, que serão sempre de dois anos, contados do dia 1º de março logo seguinte ao mandato extinto. A Corregedoria será exercida pelo Vice-Presidente; (incluído pela Emenda Constitucional nº 20, 12.12.2000) (Revogado pela Emenda Constitucional 22, de 18.01.2001)

II – elaborar seu Regimento Interno, com observância às normas desta Constituição, às leis e às normas de processo e garantias das partes, onde deverão ficar dispostas as matérias atinentes à competência e funcionamento de seus órgãos administrativos, assim também a organização de sua secretária, câmaras e serviços internos. (incluído pela Emenda Constitucional nº 20, 12.12.2000) (Revogado pela Emenda Constitucional 22, de 18.01.2001)

**Art. 113.** O Tribunal de Contas do Estado, órgão auxiliar do Poder Legislativo, integrado por sete conselheiros, tem sede na Capital do Estado, autonomia administrativa e financeira, quadro próprio de pessoal e jurisdição em todo o território estadual, exercendo no que couber, as atribuições previstas no art. 133 desta Constituição.

**Art. 113.** O Tribunal de Contas do Estado, órgão auxiliar do Poder Legislativo, integrado por sete Conselheiros, tem sede na capital do Estado, autonomia administrativa e financeira, quadro próprio de pessoal e jurisdição em todo o território estadual, exercendo, no que couber, as atribuições previstas no art. 133 desta Constituição. (redação dada pela Emenda Constitucional nº 5, 14.03.1996)

**Art. 113.** O Tribunal de Contas do Estado, órgão auxiliar do Poder Legislativo, integrado por sete Conselheiros, tem sede na capital do Estado, autonomia administrativa e financeira, quadro próprio de pessoal e jurisdição em todo o território estadual, exercendo, no que couber, as atribuições do art. 133 desta Constituição. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

**Art. 113.** O Tribunal de Contas do Estado, integrado por sete Conselheiros, tem sede na capital do Estado, autonomia funcional, administrativa e financeira, quadro próprio de pessoal e jurisdição em todo o território estadual, exercendo, no que couber, as atribuições do art. 96 da Constituição Federal. (redação dada pela Emenda Constitucional nº 37, de 04.06.2007)

**§ 1º** Os Conselheiros do Tribunal de Contas serão nomeados dentre os brasileiros que satisfaçam os seguintes requisitos:

I - mais de trinta e cinco e menos de sessenta e cinco anos de idade;

II - idoneidade moral e reputação ilibada;

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 54

III - notórios conhecimentos jurídicos, contábeis, econômicos e financeiros ou de administração pública;

IV - mais de dez anos de exercício de função ou de efetiva atividade profissional que exija os conhecimentos mencionados no inciso anterior.

**§ 2º** Os cargos de conselheiros do Tribunal de Contas necessários para completar a composição que o órgão terá serão preenchidos por indicação da Assembleia Legislativa, dentre os brasileiros que preencham os requisitos do parágrafo anterior.

**§ 2º** Os Conselheiros do Tribunal de Contas do Estado serão escolhidos. (redação dada pela Emenda Constitucional nº 5, de 1996)

I - um terço pelo Governador do Estado, com aprovação da Assembleia Legislativa, sendo um alternadamente dentre auditores e membros do Ministério Público junto ao tribunal, indicados em lista tríplice pelo Tribunal, segundo os critérios de antiguidade e merecimento; (incluído pela Emenda Constitucional nº 5, de 1996)

I - um terço pelo Governador do Estado, com aprovação da Assembleia Legislativa, sendo dois alternadamente dentre auditores e membros do Ministério Público junto ao Tribunal, indicados em lista tríplice pelo Tribunal, segundo os critérios de antiguidade e merecimento; (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

II - dois terços pela Assembleia Legislativa. (incluído pela Emenda Constitucional nº 5, de 1996)

**§ 3º** Na vacância do cargo de conselheiro, a escolha far-se-á por indicação da Assembleia Legislativa, atendidos os requisitos do § 1º deste artigo.

**§ 3º** Os Conselheiros do Tribunal de Contas terão as mesmas garantias, prerrogativas, impedimentos, vencimentos e vantagens dos Desembargadores do Tribunal de Justiça do Estado, e somente poderão aposentar-se com as vantagens do cargo quando o tiverem exercido efetivamente por mais de cinco anos. (redação dada pela Emenda Constitucional nº 5, de 1996)

**§ 3º** Os Conselheiros do Tribunal de Contas terão as mesmas garantias, prerrogativas, impedimentos, vencimentos e vantagens dos Desembargadores do Tribunal de Justiça do Estado, aplicando-se-lhes, quanto à aposentadoria e pensão, as normas constantes do art. 40 da Constituição Federal. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

**§ 4º** Após passar o Tribunal de Contas a ter sete conselheiros, as vagas que a partir de então se abrirem em suas composições serão preenchidas de modo a se garantir, sempre, ao Poder Legislativo a proporcionalidade de indicação de cinco sétimos dos membros daquele órgão, observados os critérios seguintes:

I - cinco dos conselheiros serão escolhidos pela Assembleia Legislativa;

II - dois dos conselheiros serão escolhidos pelo Governador do Estado, com aprovação da Assembleia Legislativa, dentre auditores do Tribunal de Contas, segundo os critérios de antiguidade e merecimento, indicados, em caso de merecimento, em lista tríplice.

**§ 4º** Os Conselheiros, nas suas faltas e impedimentos serão substituídos pelos auditores. (redação dada pela Emenda Constitucional nº 5, de 1996)

**§ 5º** Os conselheiros do Tribunal de Contas terão as mesmas garantias e prerrogativas, impedimentos, vencimentos, direitos e vantagens dos desembargadores do Tribunal de Justiça do Estado e somente poderão aposentar-se com as vantagens do cargo quando o tiverem exercido efetivamente por mais de cinco anos.

**§ 5º** O auditor, quando em substituição a Conselheiro, terá as mesmas garantias e impedimentos do titular e, quando no exercício das demais atribuições, as

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 55

de juiz de direito da mais elevada entrância do Estado. (redação dada pela Emenda Constitucional nº 5, de 1996)

**§ 6º** Os conselheiros, nas suas faltas e impedimentos, serão substituídos pelos auditores.

**§ 6º** Os auditores do Tribunal de Contas serão nomeados após concurso público de provas ou de provas e títulos, observada a classificação, cumpridos, ainda, os seguintes requisitos: (redação dada pela Emenda Constitucional nº 5, de 1996)

I - título de curso superior em direito, ciências contábeis, econômicas ou administrativas; (incluído pela Emenda Constitucional nº 5, de 1996)

II - idoneidade moral e reputação ilibada. (incluído pela Emenda Constitucional nº 5, de 1996)

**§ 7º** O auditor, quando em substituição a conselheiro, terá as mesmas garantias, vencimento e impedimentos do titular e, quando no exercício das demais atribuições, as de juiz de direito da mais elevada entrância do Estado.

**§ 7º** O auditor somente poderá aposentar-se com as vantagens do cargo, quando o tiver exercido efetivamente, no Tribunal de Contas, por mais de cinco anos. (redação dada pela Emenda Constitucional nº 5, de 1996)

**§ 8º** Os auditores do Tribunal de Contas serão nomeados com base em concurso público de provas ou de provas e títulos, observada a classificação, cumpridos, ainda, os seguintes requisitos:

I - título de curso superior de Direito, Ciências Contábeis, Econômicas ou Administrativa;

II - idoneidade moral e reputação ilibada.

**§ 8º** O Tribunal de Contas do Estado do Amapá será administrado pelo Presidente e Vice-Presidente, com mandato de dois anos, eleitos pelos Conselheiros, a ter início em 1º de março, cuja escolha dar-se-á dez dias antes do início do mandato. (redação dada pela Emenda Constitucional nº 19, de 22.11.2000)

**§ 8º** A fiscalização contábil, financeira, orçamentária, operacional e patrimonial do Tribunal de Contas do Estado será exercida pela Assembleia Legislativa, na forma definida no seu Regimento Interno. (redação dada pela Emenda Constitucional nº 20, 12.12.2000)

**§ 8º** Os Conselheiros elegerão o Presidente e o Vice-Presidente do Tribunal de Contas do Estado do Amapá, para mandato de dois anos, a ter início no dia 15 de março, cuja escolha dar-se-á até quinze dias antes do início do mandato. (redação dada pela Emenda Constitucional nº 22, 18.01.2001)

I - No período compreendido entre o término do mandato da atual administração do Tribunal e o início da próxima, o Tribunal de Contas do Estado do Amapá, será dirigido pelo Conselheiro mais antigo no cargo. (incluído pela Emenda Constitucional nº 22, 18.01.2001)

**§ 8º** Os conselheiros elegerão o Presidente, o 1º e o 2º Vice-Presidentes do Tribunal de Contas, para mandato de dois anos, vedada a reeleição. (redação dada pela Emenda Constitucional nº 27, de 09.09.2002)

**§ 8º** Os conselheiros elegerão o Presidente, o 1º e o 2º Vice-Presidentes do Tribunal de Contas, para mandato de dois anos, permitida a reeleição. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

**§ 9º** O auditor somente poderá aposentar-se com as vantagens de cargo quando o tiver exercido, efetivamente, no Tribunal de Contas, por mais de cinco anos.

**§ 9º** Considerar-se-á eleita a chapa que obtiver a maioria de votos. (redação dada pela Emenda Constitucional nº 27, de 09.09.2002)

**§ 10** Cabendo a escolha de Conselheiro à Assembleia Legislativa, caso o Chefe do Poder Executivo não efetive a nomeação do candidato indicado nas

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 56

quarenta e oito horas que se seguirem ao recebimento da comunicação, o mesmo será investido automaticamente no cargo. (incluído pela Emenda Constitucional nº 2, de 1995)

**Art. 114.** Os Poderes Legislativo, Executivo e Judiciário manterão, de forma integrada, sistema de controle interno com a finalidade de:

I - avaliar o cumprimento das metas previstas no plano plurianual, a execução dos programas de governo e dos orçamentos do Estado;

I - avaliar o cumprimento das metas previstas no plano plurianual, a execução dos programas de governo e dos orçamentos do Estado e dos Municípios; (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

II - comprovar a legalidade e avaliar os resultados, quanto à eficácia das gestões orçamentária, financeira e patrimonial nos órgãos e entidades da administração estadual, bem como da aplicação de recursos públicos por entidade de direito privado;

II - comprovar a legalidade e avaliar os resultados, quanto à eficácia e eficiência, da gestão orçamentária, financeira e patrimonial nos órgãos e entidades das administrações estadual e municipal, bem como da aplicação de recursos públicos por entidades de direito privado; (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

III - exercer o controle das operações de crédito, avais e garantias, e dos direitos e haveres do Estado;

III - exercer o controle das operações de crédito, avais e garantias, bem como dos direitos e haveres do Estado e dos Municípios; (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

IV - apoiar o controle externo no exercício de sua missão institucional.

**§ 1º** Os responsáveis pelo controle interno darão ciência ao Chefe do Poder a que estiverem subordinados, e este ao Tribunal de Contas do Estado, sob pena de responsabilidade solidária, de qualquer irregularidade ou ilegalidade de que tiverem conhecimento.

**§ 1º** Os responsáveis pelo controle interno, ao tomarem conhecimento de qualquer irregularidade ou ilegalidade, dela darão ciência ao Tribunal de Contas da União, sob pena de responsabilidade solidária. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

**§ 2º** Qualquer cidadão, partido político, associação ou sindicato é parte legítima para, na forma da lei, denunciar irregularidades ou ilegalidades perante o Tribunal de Contas do Estado.

##### SEÇÃO VIII Da Procuradoria da Assembleia Legislativa

**Art. 115.** A Procuradoria da Assembleia compete exercer a representação judicial do Poder Legislativo nas ações em que este for parte, ativa ou passiva, sem prejuízo das atribuições da Procuradoria-Geral do Estado.

**Parágrafo único.** Resolução de inciativa da Mesa da Assembleia Legislativa, observando os princípios e regras pertinentes à Constituição Federal e a esta Constituição, disciplinará sua competência e disporá sobre o ingresso na classe inicial, mediante concurso de provas ou de provas e títulos.

**Parágrafo único.** Lei, de iniciativa da Assembleia Legislativa, disciplinará sua competência e o ingresso na classe inicial da carreira, que para todos os fins integra a Advocacia Pública do Estado do Amapá, mediante concurso de provas ou de provas e títulos. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 57

#### CAPÍTULO II Do Poder Executivo

##### SEÇÃO I Do Governador e do Vice-Governador do Estado

**Art. 116.** O Poder Executivo estadual é exercido pelo Governador do Estado, com o auxílio dos Secretários de Estado.

**Art. 117.** O Governador e o Vice-Governador do Estado serão eleitos simultaneamente, noventa dias antes do término do mandato de seus antecessores, e a posse ocorrerá no dia primeiro de janeiro do ano subsequente, observado, quanto ao mais, o disposto no art. 77 da Constituição Federal.

**Art. 117.** A eleição do Governador e do Vice-Governador do Estado, para mandato de 4 (quatro) anos realizar-se-á no primeiro Domingo de outubro, em primeiro turno, e no último Domingo de outubro, em segundo turno, se houver, do ano anterior ao término do mandato de seus antecessores, e a posse ocorrerá em primeiro de janeiro do ano subsequente, observado, quanto ao mais, o disposto no art. 77, da Constituição Federal. (redação dada pela Emenda Constitucional nº 14, de 20.12.1999)

**§ 1º** O Governador e o Vice-Governador prestarão, no ato da posse perante a Assembleia Legislativa, o seguinte compromisso: “Prometo defender, cumprir e fazer cumprir a Constituição do Estado, observar as leis e desempenhar com dedicação e honestidade o mandato que me foi confiado pelo povo amapaense”.

**§ 2º** Se, decorridos dez dias da data fixada para a posse, o Governador ou Vice-Govenador do Estado, salvo motivo de força maior, não tiver assumido o cargo, este será declarado vago pela Assembleia Legislativa.

**§ 3º** Os subsídios do Governador e do Vice-Governador do Estado serão fixados por lei de iniciativa da Assembleia Legislativa, que deverá ser aprovada e publicada antes da data das eleições estaduais, observado o que dispõem os arts. 42, XI e 47, § 4º desta Constituição e os arts. 150, II, 153, III e 153, § 2º, I da Constituição Federal. (incluído pela Emenda Constitucional nº 35, de 21.03.2006)

**Art. 118.** É de quatro anos o mandato do Governador e do Vice- Governador, vedada a reeleição no período subsequente.

**Art. 118.** O Governador e o Vice–Governador do Estado e quem os houver sucedido ou substituído no curso do mandato poderão ser reeleitos para único período subsequente de quatro anos. (redação dada pela Emenda Constitucional nº 14, de 20.12.1999)

**§ 1º** O Governador e o Vice-Governador residirão na Capital do Estado e não poderão, sem prévia permissão da Assembleia Legislativa, ausentar-se do País, por qualquer tempo, ou do Estado por mais de quinze dias, sob pena de perda do cargo.

**§ 1º** O Governador e o Vice-Governador residirão na Capital do Estado e não poderão, sem prévia permissão da Assembleia Legislativa, ausentar-se do País ou do Estado por mais de quinze dias, sob pena de perda do cargo. (redação dada pela

Emenda Constitucional nº 35, de 21.03.2006)

**§ 2º** Substituirá o Governador no caso de impedimento, e suceder-lhe-á, no de vaga, o Vice-Governador.

**§ 3º** Consideram-se impedimentos do Governador, quando em gozo de férias ou por motivo de doença, que o impeça de exercer efetivamente a função. (dispositivo declarado inconstitucional, em controle concentrado, pelo Supremo Tribunal Federal, no julgamento da ADIN nº 887).

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 58

**§ 4º** Em caso de impedimento simultâneo do Governador e do Vice- Govenador ou de vacância de ambos os cargos, serão sucessivamente chamados a exercer o cargo de Governador o Presidente da Assembleia Legislativa e o Presidente do Tribunal de Justiça do Estado.

**§ 5º** Em caso da vacância, o Governador interino comunicará o fato ao Tribunal Regional Eleitoral, que fará nova eleição no prazo de noventa dias, devendo os eleitos completar os períodos de seus antecessores, salvo se a segunda vaga ocorrer a menos de um ano do término do quatriênio, hipótese em que se continuará observando o disposto no parágrafo anterior.

**§ 5º** Vagando os cargos de Governador e Vice–Governador, far-se-á eleição noventa dias de aberta a última vaga. (redação dada pela Emenda Constitucional nº 14, de 20.12.1999)

**§ 6º** Ocorrendo a vacância nos últimos dois anos do período governamental, a eleição para ambos os cargos será feita trinta dias depois da última vaga, pela Assembleia Legislativa, na forma da lei. (incluído pela Emenda Constitucional nº 14, de 20.12.1999)

**§ 7º** Em qualquer dos casos, os substitutos deverão completar o período de seus antecessores. (incluído pela Emenda Constitucional nº 14, de 20.12.1999)

##### SEÇÃO II Das Atribuições do Governador

**Art. 119.** Compete privativamente ao Governador do Estado, além de outras atribuições previstas nesta Constituição:

I - representar o Estado nas suas relações jurídicas, políticas e administrativas, exercendo, com o auxílio dos Secretários de Estado, a direção superior da administração estadual;

II - nomear e exonerar o Procurador da Fazenda Estadual, os dirigentes das autarquias, empresas públicas, sociedades de economia mista de que o Estado detenha o controle acionário;

III - nomear e exonerar os Secretários de Estado;

IV - nomear, observado o disposto no art. 113 desta Constituição, os conselheiros do Tribunal de Contas do Estado;

V - nomear e exonerar o Procurador-Geral do Estado;

VI - nomear o Procurador-Geral de Justiça, mediante a escolha feita em lista tríplice nos termos desta Constituição;

VII - iniciar o processo legislativo, na forma e nos casos previstos nesta Constituição;

VIII - sancionar, promulgar e fazer publicar as leis, expedir decretos e regulamentos para a sua fiel execução;

IX - vetar, total ou parcialmente, projetos de lei aprovados pela Assembleia Legislativa;

X - decretar e fazer executar intervenção em Municípios, na forma da Constituição Federal e desta Constituição;

XI - prestar a Assembleia Legislativa, no prazo de sessenta dias da abertura da sessão legislativa, as contas relativas ao exercício anterior, e apresentar- lhe o relatório de atividades;

XII - remeter mensagem e plano de governo à Assembleia Legislativa, por ocasião da abertura da sessão legislativa, expondo a situação do Estado e solicitando providências que julgar necessárias;

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 59

XIII - enviar à Assembleia o plano plurianual, o projeto de lei das diretrizes orçamentárias e as propostas de orçamento previstos nesta Constituição;

XIV - prestar informações solicitadas pelos Poderes Legislativo e Judiciário, nos casos e prazos fixados em lei;

XIV - prestar, por escrito, as informações solicitadas pelos Poderes Legislativo e Judiciário, no prazo de trinta dias, salvo se outro for determinado por Lei Federal; (redação dada pela Emenda Constitucional nº 15, de 24.05.2000)

XV - exercer o comando supremo da Polícia Militar, promover seus oficiais, nomear e exonerar o Comandante-Geral;

XVI - atribuir caráter jurídico-normativo a pareceres da Procuradoria- Geral do Estado, que serão adotados para a administração pública;

XVII - nomear magistrados, nos casos previstos na Constituição Federal e nesta Constituição;

XVIII - contrair empréstimos e realizar operações de crédito, mediante prévia autorização da Assembleia Legislativa;

XIX - celebrar convênios com a União, o Distrito Federal, com outros Estados e com Municípios para a execução de obras e serviços;

XX - expedir leis delegadas, na forma prevista nesta Constituição;

XXI - decretar situação de emergência e estado de calamidade pública;

XXII - prover e extinguir cargos públicos estaduais, na forma de lei, com as restrições, e usar do poder disciplinar sobre todos os servidores do Poder Executivo;

XXII - prover e extinguir os cargos públicos estaduais na forma da lei; (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

XXIII - determinar o Procurador-Geral do Estado o oferecimento da representação ao Tribunal competente sobre inconstitucionalidade de leis ou atos estaduais ou municipais;

XXIV - delegar por decreto, a autoridade do Executivo, funções administrativas que não sejam de sua exclusiva competência;

XXV - dispor sobre a organização e o funcionamento da administração estadual;

XXV - dispor, mediante decreto, sobre: (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

a) organização e funcionamento da administração estadual, quando não implicar aumento de despesa nem criação ou extinção de órgãos públicos; (incluída pela

Emenda Constitucional nº 35, de 21.03.2006)

b) extinção de funções ou cargos públicos, quando vagos; (incluída pela

Emenda Constitucional nº 35, de 21.03.2006)

XXVI - promover desapropriação, na forma da lei;

XXVII - exercer outras atribuições previstas nesta Constituição.

XXVIII - O prazo para expedir decreto regulamentador de lei, aprovada ou promulgada, para sua fiel execução não poderá ser superior a 120 (cento e vinte) dias, contados a partir da sua publicação, sendo que o não cumprimento do prazo estipulado, acarretará em crime de responsabilidade. (incluído pela Emenda Constitucional nº 45, de 27.06.2012)

##### SEÇÃO III Da Responsabilidade do Governador do Estado

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 60

**Art. 120.** São crimes de responsabilidade os atos do Governador que atentem contra a Constituição Federal, contra a Constituição Estadual e, especialmente contra:

I - a existência da União, Estado ou Município;

II - o livre exercício do Poder Legislativo, do Poder Judiciário, do Ministério Público e dos Poderes constitucionais;

III - o exercício dos direitos políticos, individuais e sociais;

IV - a segurança interna do Estado e do País;

V - a probidade na administração;

VI - a lei orçamentária;

VII - o cumprimento das leis e das decisões judiciais.

**Parágrafo único.** As normas de processo e julgamento de crimes serão definidos em lei.

**Art. 120.** São crimes de responsabilidade do Governador do Estado, os definidos no art. 85 da Constituição Federal e os previstos na legislação federal. (redação dada pela Emenda Constitucional nº 18, de 04.07.2000)

**Parágrafo único.** As normas de processo e julgamento são as definidas na legislação federal e no Regimento Interno da Assembleia Legislativa. (redação dada pela Emenda Constitucional nº 18, de 04.07.2000)

**Art. 121.** O Governador do Estado, admitida a acusação pelo voto de dois terços dos Deputados Estaduais, será submetido a julgamento perante o Superior Tribunal de Justiça, nas infrações penais comuns, ou perante a Assembleia Legislativa, nos crimes de responsabilidade.

**§ 1º** O Governador ficará suspenso de suas funções:

I - nas infrações penais comuns, se recebida a denúncia ou queixa-crime pelo Superior Tribunal de Justiça;

II - nos crimes de responsabilidade, após a instauração do processo pela Assembleia Legislativa.

**§ 2º** Se, decorrido o prazo de cento e oitenta dias, o julgamento não estiver concluído, cessará o afastamento do Governador do Estado, sem prejuízo do regular prosseguimento do processo.

**§ 3º** Enquanto não sobrevier sentença condenatória, nas infrações comuns, o Governador não estará sujeito à prisão.

**§ 4º** O Governador do Estado, na vigência de seu mandato, não pode ser responsabilizado por atos estranhos ao exercício de suas funções. (incluído pela

Emenda Constitucional nº 35, de 21.03.2006)

##### SEÇÃO IV Dos Secretários de Estado

**Art. 122.** Os secretários de Estado serão escolhidos pelo Governador, dentre brasileiros maiores de vinte e um anos e no exercício dos seus direitos políticos.

**Parágrafo único.** O subsídio dos Secretários de Estado será fixado na forma do disposto no § 3º do art. 117 desta Constituição. (incluído pela Emenda Constitucional nº 35, de 21.03.2006)

**Art. 123.** Compete aos Secretários de Estado, além de outras atribuições estabelecidas nesta Constituição e na lei:

I - exercer a orientação, a coordenação e a supervisão dos órgãos e entidades da administração estadual na área de sua competência e referendar atos e

decretos assinados pelo Governador do Estado;

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 61

II - expedir instruções para a execução de preceitos desta Constituição, das leis, decretos e regulamentos nas esferas de suas respectivas competências;

III - apresentar ao Governador do Estado relatório de sua gestão na Secretaria;

IV - praticar os atos para os quais receber delegação de competência do Governador;

V - apresentar declaração de bens no ato da posse e no término do exercício do cargo;

VI - dar resposta, nos termos e prazos estabelecidos no inciso XXVI do

Art. 95, às solicitações de serviços e obras impetradas pelos Poderes Legislativo e Judiciário; (incluído pela Emenda Constitucional nº 15, de 24.05.2000)

VI - responder, no prazo fixado no inciso XXVI do art. 95 desta Constituição, aos pedidos de informações da Assembleia Legislativa. (incluído pela

Emenda Constitucional nº 35, de 21.03.2006)

#### CAPÍTULO III Do Poder Judiciário

##### SEÇÃO I Disposições Gerais

**Art. 124.** São órgãos do Poder Judiciário do Estado:

I - o Tribunal de Justiça;

II - os Juízes de Direito;

III - os Juízes de Direito Auxiliares;

IV - os Juízes de Direito Substitutos;

V - os Tribunais do Júri;

VI - a Justiça Militar;

VII - outros Tribunais e Juízos instituídos por lei.

**§ 1º** Os Tribunais de segundo grau têm sede na Capital e jurisdição em todo o território estadual.

**§ 2º** São assegurados, na forma do art. 99 da Constituição Federal, ao Poder Judiciário, recursos suficientes para manutenção, expansão e aperfeiçoamento de suas atividades jurisdicionais, visando o acesso de todos à Justiça.

**Art. 125.** Ao Poder Judiciário é assegurada autonomia administrativa e financeira, competindo-lhe participar, em conjunto com os demais Poderes, da elaboração da lei de diretrizes orçamentárias, nos termos do art. 99 e seu § 1º da Constituição Federal.

**Art. 125.** Ao Poder Judiciário é assegurada autonomia administrativa e financeira, competindo-lhe, participar, por convocação obrigatória de seu Presidente, de reunião conjunta com os demais Poderes, para a determinação dos índices a serem incluídos na Lei de Diretrizes Orçamentárias, nos termos do art. 99, § 1º, da Constituição Federal, sendo que essa reunião deverá realizar-se até 30 (trinta dias) antes do prazo previsto no § 5º, do art. 175. (redação dada pela Emenda Constitucional nº 14, de 20.12.1999)

**Art. 125.** Ao Poder Judiciário é assegurada autonomia administrativa e financeira. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

**§ 1º** O Tribunal de Justiça, para os fins deste artigo, elaborará proposta orçamentária relativa ao Poder Judiciário dentro dos limites estabelecidos na lei de diretrizes orçamentárias, que, submetida à aprovação pelo seu plenário, será encaminhada ao Poder Executivo. CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 62

**§ 1º** O Tribunal de Justiça elaborará sua proposta orçamentária dentro dos limites estipulados conjuntamente com os demais Poderes na lei de diretrizes orçamentárias. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

**§ 2º** À exceção dos créditos de natureza alimentícia, os pagamentos devidos pela Fazenda Estadual ou Municipal, em virtude de condenação judicial, serão feitos exclusivamente na ordem cronológica da apresentação dos precatórios e à conta dos respectivos créditos, proibida a designação de casos ou de pessoas nas dotações orçamentárias e nos créditos adicionais abertos para esse fim.

**§ 2º** O encaminhamento da proposta, aprovada pelo Tribunal, compete ao Presidente do Tribunal de Justiça. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

**§ 3º** É obrigatória a inclusão, no orçamento das entidades de direito público, de verba necessária aos pagamentos de seus débitos constantes de precatórios judiciais apresentados até primeiro de julho, data em que seus valores serão atualizados, fazendo-se o pagamento até o final do exercício seguinte.

**§ 3º** Se o Tribunal não encaminhar sua proposta orçamentária dentro do prazo estabelecido na lei de diretrizes orçamentárias, o Poder Executivo considerará, para fins de consolidação da proposta orçamentária anual, os valores aprovados na

lei orçamentária vigente, ajustados de acordo com os limites estipulados na forma do

**§ 1º** deste artigo. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

**§ 4º** As dotações orçamentárias e os créditos abertos a que aludem os §§ 2º e 3º deste artigo serão consignados ao Poder Judiciário, recolhendo-se as importâncias respectivas à repartição competente, cabendo ao Presidente do Tribunal de Justiça determinar o pagamento, segundo as possibilidades do depósito, e autorizar, a requerimento do credor e exclusivamente para o caso de preterição de seu direito de precedência o sequestro da quantia necessária à satisfação do débito.

**§ 4º** Se a proposta orçamentária de que trata este artigo for encaminhada em desacordo com os limites estipulados na forma do § 1º, o Poder Executivo procederá aos ajustes necessários para fins de consolidação da proposta orçamentária anual. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

**§ 5º** Se o descumprimento das disposições deste artigo comprometer, a qualquer título, o regular exercício das funções do Poder Judiciário, caberá ao Tribunal de Justiça, pela maioria de seus membros, solicitar, ao Supremo Tribunal Federal, intervenção da União no Estado.

**§ 5º** Durante a execução orçamentária do exercício, não poderá haver a realização de despesas ou a assunção de obrigações que extrapolem os limites estabelecidos na lei de diretrizes orçamentárias, exceto se previamente autorizadas, mediante a abertura de créditos suplementares ou especiais. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

**Art. 125-A.** À exceção dos créditos de natureza alimentícia, os pagamentos devidos pela Fazenda Estadual ou Municipal, em virtude de sentença judiciária, far-se-ão exclusivamente na ordem cronológica de apresentação dos precatórios e à conta dos créditos respectivos, proibida a designação de casos ou de pessoas nas dotações orçamentárias e nos créditos adicionais abertos para este fim. (incluído pela Emenda Constitucional nº 35, de 21.03.2006)

**§ 1º** É obrigatória a inclusão, no orçamento das entidades de direito público, de verba necessária ao pagamento de seus débitos oriundos de sentenças transitadas em julgado, constantes de precatórios judiciários, apresentados até 1º de julho, fazendo-se o pagamento até o final do exercício seguinte, quando terão seus valores atualizados monetariamente. (incluído pela Emenda Constitucional nº 35, de 21.03.2006)

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 63

**§ 2º** Os débitos de natureza alimentícia compreendem aqueles decorrentes de salários, vencimentos, proventos, pensões e suas complementações, benefícios previdenciários e indenizações por morte ou invalidez, fundadas na responsabilidade civil, em virtude de sentença transitada em julgado. (incluído pela

Emenda Constitucional nº 35, de 21.03.2006)

**§ 3º** As dotações orçamentárias e os créditos abertos serão consignados diretamente ao Poder Judiciário, cabendo ao Presidente do Tribunal de Justiça determinar o pagamento segundo as possibilidades do depósito, e autorizar, a requerimento do credor, e exclusivamente para o caso de preterimento de seu direito de precedência, o sequestro da quantia necessária à satisfação do débito. (incluído pela

Emenda Constitucional nº 35, de 21.03.2006)

**§ 4º** O disposto no caput deste artigo, relativamente à expedição de precatórios, não se aplica aos pagamentos de obrigações definidas em lei como de pequeno valor que a Fazenda Estadual ou Municipal deva fazer em virtude de sentença judicial transitada em julgado. (incluído pela Emenda Constitucional nº 35, de 21.03.2006)

**§ 5º** São vedados a expedição de precatório complementar ou suplementar de valor pago, bem como fracionamento, repartição ou quebra do valor da execução, a fim de que seu pagamento não se faça, em parte, na forma estabelecida no § 4º deste artigo e, em parte, mediante expedição de precatório. (incluído pela Emenda Constitucional nº 35, de 21.03.2006)

**§ 6º** A lei poderá fixar valores distintos para o fim previsto no § 4º deste artigo, segundo as diferentes capacidades das entidades de direito público. (incluído pela Emenda Constitucional nº 35, de 21.03.2006)

**§ 7º** O Presidente do Tribunal de Justiça incorrerá em crime de responsabilidade se, por ato comissivo ou omissivo, retardar ou tentar frustrar a liquidação regular de precatório. (incluído pela Emenda Constitucional nº 35, de 21.03.2006)

**Art. 126.** Compete ao Tribunal de Justiça a iniciativa da Lei de Organização e Divisão Judiciárias do Estado e de suas alterações, observados os seguintes princípios:

I - ingresso na carreira, cujo cargo inicial é o de juiz de direito substituto, mediante concurso público de provas e títulos, com a participação da Ordem dos Advogados do Brasil, Secção do Amapá, em todas as suas fases, obedecendo-se, nas nomeações, à respectiva ordem de classificação;

I - ingresso na carreira, cujo cargo inicial será o de juiz substituto, mediante concurso público de provas e títulos, com a participação da Ordem dos Advogados do Brasil em todas as fases, exigindo-se do bacharel em direito, no mínimo, três anos de atividade jurídica e obedecendo-se, nas nomeações, à ordem de classificação; (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

II - promoção de entrância a entrância, por antiguidade e merecimento, observado o seguinte:

II - promoção de entrância para entrância, alternadamente, por antiguidade e merecimento, atendidas as normas fixadas no inciso II do art. 93 da Constituição Federal. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

a) na apuração da antiguidade, o Tribunal de Justiça poderá recusar o juiz de direito mais antigo pelo voto motivado de dois terços de seus membros, conforme procedimento próprio, disciplinado no seu regimento interno, repetindo-se a votação até se fixar a indicação; (revogada pela Emenda Constitucional nº 35, de 21.03.2006)

b) preexistência de dois anos de exercício na respectiva entrância e integração do juiz de direito na primeira quinta parte da lista de antiguidade desta, salvo inexistindo quem, dentre os que disponham desses requisitos, aceite o lugar vago, caso em que concorrerão os integrantes da segunda quinta parte, em idêntico

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 64

procedimento, e assim sucessivamente. (revogada pela Emenda Constitucional nº 35, de 21.03.2006)

c) a promoção por merecimento, atendido o disposto na alínea anterior, resultará de lista tríplice organizada pelo Tribunal de Justiça, composta pelos nomes mais votados dentre os que tenham obtido maioria de votos dos membros do órgão, e se procederá, para alcançá-la, a até três votações, examinados, em primeiro lugar, os remanescentes de lista anterior; (revogada pela Emenda Constitucional nº 35, de 21.03.2006)

d) adotar-se-ão, como critério de aferição do merecimento, a presteza e a segurança no exercício da jurisdição, a frequência e o aproveitamento em cursos de aperfeiçoamento reconhecidos, e a regularidade e atualização dos serviços judiciais pelos quais seja o juiz de direito responsável; (revogada pela Emenda Constitucional nº 35, de 21.03.2006)

e) obrigatoriedade da promoção do juiz de direito que figurar, por três vezes consecutivas, ou cinco alternadamente, em listas tríplices de merecimento; (revogada pela Emenda Constitucional nº 35, de 21.03.2006)

f) nenhum juiz de direito poderá ser promovido ou removido enquanto existir processo paralisado, pendente de despacho, decisão ou sentença de sua competência, conforme se correição promovida pela Corregedoria de Justiça. (revogada pela Emenda Constitucional nº 35, de 21.03.2006)

III - o acesso ao Tribunal de Justiça, em vaga destinada a magistrado, se fará por antiguidade e merecimento, alternadamente, apurados na última entrância;

IV - a instituição de cursos oficiais de preparação e aperfeiçoamento de magistrados e comprovação de obtenção, neles, de nível satisfatório de frequência e aproveitamento como requisitos para ingresso e promoção na carreita;

IV - previsão de cursos oficiais de preparação, aperfeiçoamento e promoção de magistrados, constituindo etapa obrigatória do processo de vitaliciamento a participação em curso oficial ou reconhecido por escola nacional de formação e aperfeiçoamento de magistrados; (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

V - aposentadoria com vencimentos integrais, compulsória por invalidez ou aos setenta anos de idade, e facultativa aos trinta anos de serviço, após cinco anos de efetivo exercício na judicatura;

V - os subsídios dos Desembargadores do Tribunal de Justiça e dos demais magistrados serão fixados com observância do disposto no inciso V do art. 93 da Constituição Federal; (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

V-A - a aposentadoria dos magistrados e a pensão de seus dependentes observarão o disposto no art. 40 da Constituição Federal; (incluído pela Emenda Constitucional nº 35, de 21.03.2006)

VI - o juiz de direito titular residirá na respectiva comarca;

VI - o juiz titular residirá na respectiva comarca, salvo autorização do Tribunal de Justiça; (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

VII - a criação ou restauração e a instalação de comarca ou vara se darão conforme dispuserem a Lei de Organização e Divisão Judiciárias e o Regimento Interno do Tribunal de Justiça, importando a previsão das respectivas estruturas administrativas, judiciárias, notarial e de registro, definidas naquela lei;

VIII - o ato de remoção, disponibilidade e aposentadoria de magistrado, por interesse público, fundar-se-á em decisão por voto de dois terços do Tribunal de Justiça, assegurada ampla defesa, com os meios e recursos a ela inerentes;

VIII - o ato de remoção, disponibilidade e aposentadoria do magistrado, por interesse público, fundar-se-á em decisão por voto da maioria absoluta do Tribunal de Justiça ou do Conselho Nacional de Justiça, assegurada ampla defesa; (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 65

VIII-A - a remoção a pedido ou a permuta de magistrados de comarca de igual entrância atenderá, no que couber, ao disposto nas alíneas a, b, c e e, do inciso II, do art. 93 da Constituição Federal; (incluído pela Emenda Constitucional nº 35, de 21.03.2006)

IX - todos os julgamentos dos órgãos do Poder Judiciário serão públicos, e fundamentadas todas as suas decisões, sob pena de nulidade, podendo a lei, por exigência do interesse público, limitar a presença, em determinados atos, às próprias partes e as seus advogados, ou somente a estes;

IX - todos os julgamentos dos órgãos do Poder Judiciário serão públicos, e fundamentadas todas as decisões, sob pena de nulidade, podendo a lei limitar a presença, em determinados atos, às próprias partes e a seus advogados, ou somente a estes, em casos nos quais a preservação do direito à intimidade do interessado no sigilo não prejudique o interesse público à informação; (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

X - as decisões administrativas do Tribunal de Justiça serão sempre motivadas e, as disciplinares, tomadas pelo voto da maioria absoluta de seus membros, ressalvado o disposto no inciso VIII deste artigo.

X - as decisões administrativas do Tribunal de Justiça serão motivadas e em sessão pública, sendo as disciplinares tomadas pelo voto da maioria absoluta de seus membros; (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

XI - a atividade jurisdicional será ininterrupta, sendo vedado férias coletivas, funcionando, nos dias em que não houver expediente forense normal, juízes em plantão permanente; (incluído pela Emenda Constitucional nº 35, de 21.03.2006)

XII - o número de juízes na unidade jurisdicional será proporcional à efetiva demanda judicial e à respectiva população; (incluído pela Emenda Constitucional nº 35, de 21.03.2006)

XIII - os servidores receberão delegação para a prática de atos de administração e atos de mero expediente sem caráter decisório; (incluído pela Emenda Constitucional nº 35, de 21.03.2006)

XIV - a distribuição de processos será imediata, em todos os graus de jurisdição. (incluído pela Emenda Constitucional nº 35, de 21.03.2006)

**Art. 127.** Haverá, no Tribunal de Justiça, o Conselho da Magistratura, com a composição e a competência que lhe derem a Lei de Organização e Divisão Judiciárias e o Regimento Interno do Tribunal.

**Art. 128.** Um quinto do Tribunal de Justiça será composto de membros do Ministério Público com mais de dez anos de carreira e de advogados de notório saber jurídico e de reputação ilibada, com mais de dez anos de efetiva atividade profissional, indicados em listas sêxtuplas, pelos órgãos de representação das respectivas classes.

**Parágrafo único.** Recebidas as indicações, na hipótese deste artigo, o Tribunal de Justiça formará lista tríplice, em sessão secreta, enviando-a ao Governador do Estado, que, nos cinco dias subsequentes, escolherá e nomeará um de seus integrantes.

**Parágrafo único.** Recebidas as indicações, o Tribunal de Justiça formará lista tríplice, enviando-a ao Poder Executivo, que, nos vinte dias subsequentes, escolherá um de seus integrantes para nomeação. (redação dada pela

Emenda Constitucional nº 35, de 21.03.2006)

**Art. 129.** Os magistrados gozam das seguintes garantias:

I - vitaliciedade adquirida;

I - vitaliciedade, que, no primeiro grau, só será adquirida após dois anos de exercício, dependendo a perda do cargo, nesse período, de deliberação do

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 66

Tribunal de Justiça, e, nos demais casos, de sentença judicial transitada em julgado; (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

a) pelos desembargadores, a partir da posse; (revogada pela Emenda Constitucional nº 35, de 21.03.2006)

b) pelos juízes de direito, após dois anos de efetivo exercício do cargo. (revogada pela Emenda Constitucional nº 35, de 21.03.2006)

II - inamovibilidade, salvo nas hipóteses de remoção compulsória, por interesse público, ou de movimentação voluntária de juiz de uma para outra vara da mesma comarca, ou de uma para outra comarca da mesma entrância, se o interesse da prestação jurisdicional assim o recomendar;

II - inamovibilidade, salvo por motivo de interesse público, na forma do artigo 93, VIII, da Constituição Federal; (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

III - irredutibilidade de vencimentos, nos termos da Constituição Federal.

III - irredutibilidade de subsídio, ressalvado o disposto nos artigos 37, X e XI, 39, § 4º, 150, II, 153, III, e 153, § 2º, I da Constituição Federal. (redação dada pela

Emenda Constitucional nº 35, de 21.03.2006)

**§ 1º** O magistrado vitalício somente perderá o cargo em decorrência de sentença judicial transitada em julgado. (revogado pela Emenda Constitucional nº 35, de 21.03.2006)

**§ 2º** O Tribunal de Justiça poderá, pelo voto de dois terços de seus membros, assegurada ampla defesa, com os meios e recursos a ela inerentes, por ato ou omissão verificados durante o biênio de estágio probatório, decidir pela exoneração do juiz:

I - manifestamente negligente no cumprimento dos deveres do cargo:

II - de procedimento incompatível com a dignidade, a honra e o decoro de suas funções;

III - de insuficiente capacidade de trabalho ou cujo proceder funcional seja incompatível com o bom desempenho das atividades do Poder Judiciário.

**§ 3º** Dar-se-á exoneração, com automático afastamento do magistrado de suas funções, ainda que o ato respectivo seja publicado após o biênio.

**§ 4º** Em caso de extinção da comarca, ou mudança de sede do juízo, será facultado ao magistrado requerer remoção para outra comarca de igual entrância, ou obter a disponibilidade com vencimentos integrais, até seu aproveitamento na judicatura, por decisão do Tribunal de Justiça. (revogado pela Emenda Constitucional nº 35, de 21.03.2006)

**Art. 130.** Os vencimentos dos magistrados serão fixados com diferença não superior a dez por cento de uma para outra das categorias da carreira, devendo os dos Desembargadores manter isonomia com os dos Deputados Estaduais. (revogado pela Emenda Constitucional nº 35, de 21.03.2006)

**§ 1º** Os vencimentos dos membros do Tribunal de Justiça do Estado manterão sempre a equivalência resultante do art. 37, XI, da Constituição Federal. (revogado pela Emenda Constitucional nº 35, de 21.03.2006)

**§ 2º** Alterada a remuneração dos membros e servidores dos demais Poderes, o Tribunal de Justiça promoverá, mediante resolução, o reajustamento dos vencimentos de seus magistrados e servidores, nos mesmos índices, observados e dispostos neste artigo. (revogado pela Emenda Constitucional nº 35, de 21.03.2006)

**§ 3º** os magistrados se sujeitam aos impostos gerais inclusive ao de renda, aos extraordinários e aos descontos fixados em lei, observada a isonomia com os membros dos demais Poderes. (revogado pela Emenda Constitucional nº 35, de 21.03.2006)

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 67

**§ 4º** Os proventos dos magistrados na inatividade serão pagos na mesma data e revistos segundo os mesmos índices dos vencimentos dos magistrados em atividade. (revogado pela Emenda Constitucional nº 35, de 21.03.2006)

**Art. 131.** Aos magistrados é vedado:

I - exercer, ainda que em disponibilidade, outro cargo ou função, salvo uma de magistério;

II - receber, a qualquer título ou pretexto, custas ou participação em processo;

III - dedicar-se a atividade político-partidária.

IV - receber, a qualquer título ou pretexto, auxílios ou contribuições de pessoas físicas, entidades públicas ou privadas, ressalvadas as exceções previstas em lei; (incluído pela Emenda Constitucional nº 35, de 21.03.2006)

V - exercer a advocacia no juízo ou tribunal do qual se afastou, antes de decorridos três anos do afastamento do cargo por aposentadoria ou exoneração. (incluído pela Emenda Constitucional nº 35, de 21.03.2006)

##### SEÇÃO II Do Tribunal de Justiça

**Art. 132.** O Tribunal de Justiça, com sede na Capital e jurisdição em todo o território do Estado, compõe-se de sete desembargadores.

**Art. 132.** O Tribunal de Justiça, com sede na Capital e jurisdição em todo o Território do Estado, compõe-se de, no mínimo, sete desembargadores. (redação dada pela Emenda Constitucional nº 11, de 11.11.1998)

**Art. 132.** O Tribunal de Justiça, com sede na capital e jurisdição em todo território do Estado, compõe-se de, no mínimo, nove Desembargadores. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

**Art. 133.** Compete privativamente ao Tribunal de Justiça:

**Art. 133.** Compete privativamente ao Tribunal de Justiça, além das competências elencadas no inciso I do art. 96 da Constituição Federal: (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

I - propor ao Poder Legislativo, observados os parâmetros desta Constituição:

I - propor ao Poder Legislativo, observado o disposto no art. 169 da Constituição Federal: (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

a) a alteração do número de seus membros;

b) a criação, a extinção de cargos e a fixação de vencimentos dos servidores de seus serviços auxiliares e os dos juízes que lhe forem vinculados;

b) a criação e a extinção de cargos e a remuneração dos seus serviços auxiliares e dos juízos que lhes forem vinculados, bem como a fixação do subsídio de seus membros e dos juízes; (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

c) a criação e a extinção de tribunais inferiores;

d) a criação da Justiça Militar estadual, na forma do art. 125, §3º, da Constituição Federal;

e) a regulamentação da Justiça de Paz e a eleição dos respectivos juízes;

e) a criação da Justiça de Paz e a eleição dos respectivos juízes; (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

f) a criação do Juizado de Pequenas Causas;

f) a criação dos juizados especiais; (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

g) a revisão da organização e da divisão judiciárias, bienalmente; CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 68

g) a alteração da organização e da divisão judiciárias; (redação dada pela

Emenda Constitucional nº 35, de 21.03.2006)

h) a criação de novas varas e respectivos cargos.

II - processar e julgar, originariamente:

a) o Vice-Governador e os Secretários de Estado, nos crimes comuns e de responsabilidade, exceto, em relação a estes, quando forem os atos conexos com delito imputado ao Governador do Estado, os Prefeitos Municipais, os juízes de direito estaduais e os membros do Ministério Público estadual, com exceção do Procurador- Geral da Justiça, nos crimes de responsabilidade, ressalvada a competência da Justiça Eleitoral;

a) o Vice-Governador, os Secretários de Estado, ressalvado o disposto no art. 95, XI, a, os Juízes Estaduais e os membros do Ministério Público, ressalvado o disposto no art. 95, XI, b, nos crimes comuns e de responsabilidade, e os Prefeitos nos crimes comuns, ressalvada a competência da Justiça Eleitoral; (redação dada pela

Emenda Constitucional nº 35, de 21.03.2006)

b) nos crimes comuns, o Procurador-Geral do Estado e os Deputados Estaduais;

c) o mandado de segurança contra atos do Governador do Estado, da Mesa e do Presidente da Assembleia Legislativa, do próprio Tribunal ou de seus órgãos diretivos e colegiados, dos Secretários de Estado e do Tribunal de Contas do Estado, inclusive de seus respectivos Presidentes, e do Procurador-Geral do Estado;

c) o mandado de segurança contra atos do Governador, Mesa e da Presidência da Assembleia, do próprio Tribunal ou de algum de seus membros, dos Secretários de Estado, do Presidente ou dos Conselheiros do Tribunal de Contas, do Procurador Geral de Justiça, dos Prefeitos Municipais e do Presidente da Câmara Municipal da Capital; (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

d) o habeas-corpus, quando o coator ou paciente for autoridade que goze de foro especial junto ao próprio Tribunal de Justiça, em razão de prerrogativa da função, ou sujeita à sua jurisdição, ou se trate de ação penal de sua competência originária, ressalvada a competência da Justiça Eleitoral;

e) o "habeas-data" contra atos de autoridades diretamente submetidas à sua jurisdição;

e) o habeas-data contra atos das autoridades referidas na alínea “c”; (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

f) o mandado de injunção, quando a elaboração da norma regulamentadora for atribuição do Governador do Estado, de Secretário de Estado, da Assembleia Legislativa, do Tribunal de Contas do Estado ou do próprio Tribunal de Justiça e seus órgãos diretivos;

g) a ação rescisória de seus julgados e a revisão criminal nos processos de sua competência;

h) a reclamação para preservação de sua competência e garantia de autoridade de suas decisões;

i) a execução de acórdãos nas causas de sua competência originária, facultada a delegação de atribuições para a prática de atos processuais, não decisórios;

j) os conflitos de competência entre juízes de direito do Estado;

l) os conflitos de atribuições entre autoridades judiciais e administrativas estaduais, quando forem suscitantes ou suscitados o Governador do Estado e o Procurador-Geral de Justiça.

m) a ação direta de inconstitucionalidade de leis ou atos normativos estaduais ou municipais que afrontem a Constituição Estadual, e de leis ou atos

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 69

normativos municipais em choque com a Constituição Federal, observado o disposto no art. 97 desta;

m) a ação direta de inconstitucionalidade e a ação declaratória de constitucionalidade de leis ou atos normativos estaduais ou municipais em face da Constituição Estadual e de leis ou atos normativos municipais em face da Constituição Federal, observado o disposto no art. 97 desta última; (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

n) o julgamento da exceção da verdade, nos processos de crimes contra a honra em que o querelante fizer jus a foro especial, por prerrogativa de função, junto ao próprio Tribunal de Justiça;

o) a suspeição oposta a desembargadores e ao Procurador Geral de Justiça;

p) a perda do posto e da patente de oficiais e da graduação das praças, na forma do art. 125, § 4º, da Constituição Federal;

q) os incidentes de uniformização de jurisprudência.

III - julgar, em grau de recurso, na forma que dispuserem a legislação e seu regimento interno, pelo seu plenário ou outros órgãos que o componham, as causas decididas em primeiro grau de jurisdição, e as decisões e sentenças sujeitas a remessa ou reexame necessário, em duplo grau de jurisdição, observado o âmbito de sua competência, e as decisões dos presidentes de suas Secções ou Câmaras;

IV - promover representação para garantia do livre exercício do Poder Judiciário estadual, quando este se achar coacto ou impedido, e para assegurar a observância de princípios consagrados nas Constituições Federal e Estadual, ou ainda para assegurar a execução de lei, ordem ou decisão judicial, requerendo a intervenção no Estado e requisitando-a para o Município, conforme o caso;

V - eleger seus órgãos diretivos e elaborar o respectivo regimento interno, com observância das normas de processo e das garantias constitucionais das partes, e dispondo sobre a competência e funcionamento dos respectivos órgãos jurisdicionais e administrativos;

VI - organizar suas secretarias, seus serviços auxiliares e os dos juízes que lhe forem vinculados, velando pelo exercício da atividade correcional respectiva;

VII - prover, por concurso público de provas, ou de provas e títulos, respeitado o disposto no art. 169, da Constituição Federal, os cargos necessários à administração da justiça, exceto os de confiança, assim definidos em lei, mediante ato de seu Presidente;

VIII - conceder licença, férias e outros afastamentos a seus membros e aos juízes e servidores que lhe forem imediatamente vinculados;

IX - prover os cargos de juiz de carreira da respectiva jurisdição;

X - expedir decisão normativa em matéria administrativa de economia interna do Poder Judiciário;

XI - encaminhar ao Poder Executivo a proposta orçamentária do Poder Judiciário e as propostas de abertura de créditos adicionais, dentro dos limites estipulados pela lei de diretrizes orçamentárias;

XII - aplicar sanções aos magistrados e decidir, para efeito da aposentadoria ou afastamento temporário sobre a incapacidade física ou mental;

XIII - homologar os concursos para o ingresso na magistratura estadual, indicando ao Presidente do Tribunal, para nomeação, os candidatos neles aprovados;

XIV - exercer as atribuições do § 1º, inciso I, alíneas a e b, e III, do art. 120 da Constituição Federal;

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 70

XV - receber do Ministério Público e da Ordem dos Advogados do Brasil, Secção do Amapá, lista sêxtupla para preenchimento de vagas no Tribunal de Justiça reservadas a seus integrantes e, com base nela, elaborar lista tríplice, enviando-a ao Governo do Estado, que escolherá um para nomeação;

XVI - indicar à nomeação, pelo Presidente do Tribunal, o juiz de direito que deva ser promovido por antiguidade e, em lista tríplice os que devem sê-lo por merecimento;

XVII - julgar processos de invalidez dos serventuários, para fins de aposentadoria, licença compulsória, reversão, afastamento e readmissão;

XVIII - conceder reversão, afastamento ou readmissão a magistrados e declarar o abandono ou a perda de cargos, por estes;

XIX - outras atribuições que lhe sejam conferidas pela legislação vigente ou venham a sê-lo por atos normativos do próprio Tribunal de Justiça.

**§ 1º** Para a eleição a que se refere o inciso V deste artigo, terão direito a voto todos os membros do Tribunal de Justiça.

**§ 2º** Compete ao Presidente do Tribunal de Justiça expedir ato de nomeação, promoção, remoção, disponibilidade, exoneração e aposentadoria de magistrado de carreira da respectiva jurisdição.

##### SEÇÃO III Dos Tribunais do Júri

**Art. 134.** O Tribunal do Júri, que terá competência para o julgamento dos crimes dolosos contra a vida, na forma da legislação processual penal, tem funcionamento na sede de cada comarca, com a composição que a lei determinar, assegurados o sigilo das votações, a plenitude de defesa e a soberania dos veredictos.

##### SEÇÃO IV Do Juiz de Direito, dos Juízes de Direito Auxiliares e dos Juízes de Direito Substitutos

**Art. 135.** Os juízes de direito, os juízes de direito auxiliares e os juízes de direitos substitutos exercerão jurisdição comum de primeiro grau e integração a carreira da magistratura, com a competência que a Lei de Organização e Divisão Judiciárias estabelecer.

**§ 1º** Compete ao juiz de direito julgar mandado de injunção quando a forma regulamentadora for atribuição do Prefeito, da Câmara Municipal ou de sua Mesa Diretora, ou ainda de autarquia ou fundação pública municipal.

**§ 2º** O Tribunal de Justiça poderá designar juízes de direito auxiliares e juízes de direito substitutos, para auxiliarem na comarca ou vara cujo número de processos tenha ultrapassado o limite que vier a ser fixado na lei de organização e divisão judiciárias.

**Art. 136.** O Tribunal de Justiça avaliará, periodicamente, as comarcas e o volume dos trabalhos forenses e proporá, se necessário, a reavaliação das entrâncias e a criação ou supressão de varas.

**Art. 137.** Para dirimir conflitos fundiários, o Tribunal de Justiça, através de seu Presidente, designará juiz de direito auxiliar, com competência exclusiva para questões agrárias.

**§ 1º** A designação prevista neste artigo só poderá ser revogada a pedido do juiz ou por deliberação da maioria absoluta dos membros do Tribunal. CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 71

**§ 2º** Sempre que necessário à eficiente prestação jurisdicional, o juiz far- se-á presente ao local do litígio.

**§ 3º** A Lei de Organização e Divisão Judiciárias definirá a competência do juiz referido neste artigo, ressalvada a competência privativa da Justiça Federal.

**Art. 137.** Para dirimir conflitos fundiários, o Tribunal de Justiça proporá a criação de varas especializadas, com competência exclusiva para questões agrárias. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

**Parágrafo único.** Sempre que necessário à eficiente prestação jurisdicional, o juiz far-se-á presente no local do litígio. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 72

##### SEÇÃO V Da Justiça Militar

**Art. 138.** A Justiça Militar é competente para o processo e julgamento dos integrantes das organizações militares estaduais nos crimes militares definidos em lei, sendo composta, em primeiro grau de jurisdição, pelo Conselho da Justiça Militar e, em segundo grau, pelo Tribunal de Justiça do Estado.

**Art. 138.** A Justiça Militar do Estado do Amapá é competente para processar e julgar os militares estaduais, nos crimes militares definidos em lei e as ações judiciais contra atos disciplinares militares, ressalvada a competência do júri quando a vítima for civil, cabendo ao Tribunal de Justiça decidir sobre a perda do posto e da patente dos oficiais e da graduação de praças. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

**Parágrafo único.** Enquanto não for criado o Conselho de Justiça Militar, o processo e julgamento dos crimes militares se farão: (revogado pela Emenda Constitucional nº 35, de 21.03.2006)

a) em primeiro grau, pelos juízes de direito das varas criminais; (revogada pela Emenda Constitucional nº 35, de 21.03.2006)

b) em segundo grau, pelo Tribunal de Justiça, ao qual caberá também decidir sobre a perda do posto e patente dos oficiais e da graduação das praças. (revogada pela Emenda Constitucional nº 35, de 21.03.2006)

**Art. 139.** A lei poderá criar, mediante proposta do Tribunal de Justiça, o Tribunal de Justiça Militar, quando cumprido o requisito previsto no art. 125, § 3a, da Constituição Federal.

**Art. 139.** Compete aos juízes de direito do juízo militar processar e julgar, singularmente, os crimes militares cometidos contra civis e as ações judiciais contra atos disciplinares militares, cabendo ao Conselho de Justiça, sob a presidência de juiz de direito, processar e julgar os demais crimes militares. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

##### SEÇÃO VI Dos Juizados Especiais

**Art. 140.** Os juizados especiais serão providos por juízes togados, ou togados e leigos, competentes para conciliação, o julgamento, e a execução de causas cíveis de menor complexidade e infrações penais de menor potencial ofensivo, mediante os procedimentos oral e sumaríssimo, permitidos, nas hipóteses previstas em lei, a transação e o julgamento de recurso por turmas de juízes de primeiro grau.

##### SEÇÃO VII Da Justiça de Paz

**Art. 141.** A Justiça de Paz compõe-se de cidadãos remunerados, eleitos pelo voto direto, universal e secreto, com mandato de quatro anos, e tem competência para, na forma da lei, celebrar casamentos, verificar, de ofício ou em face de impugnação apresentada, o processo de habilitação e exercer atribuições conciliatórias, sem caráter jurisdicional, além de outras previstas na legislação.

**§ 1º** A eleição do juiz de paz, observados o sistema majoritário e a coincidência com as eleições municipais, será disciplinada em lei de iniciativa do Tribunal de Justiça.

**§ 2º** Haverá em cada município em juiz de paz para cada Cartório de Registro Civil e Casamento.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 73

##### SEÇÃO VIII Do Controle da Constitucionalidade

**Art. 142.** São partes legítimas para propor, perante Tribunal de Justiça do Estado, ação direta inconstitucionalidade de lei ou ato normativo municipal, em da Constituição Federal, e de lei estadual ou municipal em desta Constituição:

**Art. 142.** Podem propor a ação direita de inconstitucionalidade e a ação declaratória de constitucionalidade de que trata a alínea m do inciso II do art. 133 desta Constituição: (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

I - o Governo do Estado;

II - a Mesa da Assembleia Legislativa;

III - o Procurador-Geral de Justiça;

IV - o Prefeito e a Mesa da Câmara do respectivo Município, em se tratando de lei ou ato normativo local;

V - o Conselho da Ordem dos Advogados do Brasil, Secção do Amapá;

VI - os partidos políticos com representação na Assembleia Legislativa ou em Câmara de Vereadores;

VII - entidades sindical ou de classes com base territorial no Estado.

**§ 1º** O Procurador-Geral de Justiça será ouvido, previamente, como fiscal da lei, em todas as ações diretas de inconstitucionalidade em que não seja parte.

**§ 2º** Declarada a inconstitucionalidade de lei em ação direta, a decisão terá eficácia de caráter geral, como suspensão automática de seus efeitos, independentemente de qualquer comunicação ao respectivo órgão legislativo.

**§ 3º** Declarada a inconstitucionalidade de lei, incidentalmente, em última instância, a decisão será comunicada à Assembleia Legislativa ou à Câmara Municipal, conforme o caso, para suspensão, no todo ou em parte, da norma impugnada.

**§ 4º** Declarada a inconstitucionalidade de ato normativo, em ação direta, ou incidentalmente, em última instância, a decisão será comunicada ao Poder competente para adoção das providências necessárias à prática do ato ou início do respectivo processo legislativo, conforme o caso, e, em se tratando de órgão administrativo, com a determinação para fazê-lo em trinta dias, sob pena de responsabilidade.

**§ 5º** Quando o Tribunal de Justiça apreciar a inconstitucionalidade, em tese, de norma legal ou ato normativo estadual, citará o Procurador-Geral do Estado, que defenderá, ou não, o ato ou texto impugnado, ou no caso de norma legal ou ato normativo municipal, o Prefeito Municipal, para a mesma finalidade.

**§ 6º** Somente pelo voto da maioria absoluta de seus membros poderá o Tribunal de Justiça declarar a inconstitucionalidade de lei ou ato normativo estadual ou municipal, incidentalmente ou como objeto de ação direta.

##### SEÇÃO IX Dos Serviços Notariais e de Registro

**Art. 143.** Os serviços notariais e de registro, no âmbito estadual, são exercidos em caráter privado, por delegação do Poder Público.

**§ 1º** Lei estadual, de iniciativa do Poder Judiciário, regulará as atividades, disciplinará a responsabilidade civil e criminal dos notários, dos oficiais de

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 74

registro e de seus prepostos, e definirá a fiscalização de seus atos pelo Poder Judiciário.

**§ 1º** Lei federal regulará as atividades, disciplinará a responsabilidade civil e criminal dos notários, dos oficiais de registro e de seus prepostos, e definirá a fiscalização de seus atos pelo Poder Judiciário. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

**§ 2º** As normas gerais para a fixação de custas e emolumentos relativos aos atos praticados pelos serviços notariais e de registro obedecerão ao que dispuser a lei federal, na forma do art. 236, § 2º, da Constituição Federal.

**§ 2º** A fixação de emolumentos relativos aos atos praticados pelos serviços notariais e de registro observará as normas gerais fixadas em lei federal. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

**§ 3º** O ingresso na atividade notarial e de registro depende de concurso público de provas e títulos, promovido pelo Tribunal de Justiça do Estado, não se permitindo que qualquer serventia fique vaga, por mais de seis meses, sem abertura de concurso com vistas a provimento ou remoção, ressalvados os direitos daqueles que estiverem no exercício na data da promulgação desta Constituição.

#### CAPÍTULO IV Das Funções Essenciais à Justiça

##### SEÇÃO I Do Ministério Público

**Art. 144.** O Ministério Público é instituição permanente, essencial à função jurisdicional do Estado, incumbindo-lhe a defesa da ordem jurídica, do regime democrático e dos interesses sociais e individuais indisponíveis.

**Parágrafo único.** São princípios institucionais do Ministério Público a unidade, a indivisibilidade e a independência funcionais.

**Art. 145.** Ao Ministério Público é assegurada autonomia financeira, funcional e administrativa, podendo propor ao Poder Legislativo a criação e extinção de seus cargos e serviços auxiliares, provendo-os por concurso público de provas e de provas e títulos, bem como a fixação de seus vencimentos; a lei disporá sobre sua organização e funcionamento.

**Art. 145.** Ao Ministério Público é assegurada autonomia funcional e administrativa, podendo, observado o disposto no artigo 169 da Constituição Federal, propor ao Poder Legislativo a criação e extinção de seus cargos e serviços auxiliares, provendo-os por concurso público de provas ou de provas e títulos, a política remuneratória e os planos de carreira; a lei disporá sobre sua organização e funcionamento. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

**§ 1º** As decisões do Ministério Público, fundadas em sua autonomia, obedecidas as formalidades legais, têm eficácia plena e executoriedade imediata, ressalvada a competência constitucional do Poder Judiciário e do Tribunal de Contas do Estado.

**§ 2º** O Ministério Público elaborará sua proposta orçamentária dentro dos limites estabelecidos na lei de diretrizes orçamentárias.

**§ 2º** O Ministério Público elaborará sua proposta orçamentária dentro dos limites estabelecidos na lei de diretrizes orçamentárias. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

**§ 3º** O recursos próprios, não originários do Tesouro Estadual, serão utilizados em programas vinculados às finalidades da instituição.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 75

**§ 3º** Se o Ministério Público não encaminhar a respectiva proposta orçamentária dentro do prazo estabelecido na lei de diretrizes orçamentárias, o Poder Executivo considerará, para fins de consolidação da proposta orçamentária anual, os valores aprovados na lei orçamentária vigente, ajustados de acordo com os limites estipulados na forma do § 2º. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

**§ 4º** Se a proposta orçamentária de que trata este artigo for encaminhada em desacordo com os limites estipulados na forma do § 2º, o Poder Executivo procederá aos ajustes necessários para fins de consolidação da proposta orçamentária anual. (incluído pela Emenda Constitucional nº 35, de 21.03.2006)

**§ 5º** Durante a execução orçamentária do exercício, não poderá haver a realização de despesas ou a assunção de obrigações que extrapolem os limites estabelecidos na lei de diretrizes orçamentárias, exceto se previamente autorizadas, mediante a abertura de créditos suplementares ou especiais. (incluído pela Emenda Constitucional nº 35, de 21.03.2006)

**§ 6º** Os recursos próprios, não originários do Tesouro Estadual, serão utilizados em programas vinculados às suas finalidades institucionais. (incluído pela

Emenda Constitucional nº 35, de 21.03.2006)

**Art. 146.** O Ministério Público do Estado tem como Chefe o Procurador- Geral de Justiça, nomeado pelo Governador do Estado, após a aprovação de seu nome pela maioria absoluta dos membros do Poder Legislativo, dentre os Procuradores de Justiça integrantes da carreira, indicados em lista tríplice, na forma prevista na lei respectiva, para mandato de dois anos, permitida uma recondução.

**Art. 146.** O Ministério Público do Estado tem como Chefe o Procurador Geral de Justiça, nomeado pelo Governador do Estado, dentre integrantes da carreira, indicados em lista tríplice, para mandato de dois anos, permitida a recondução. (redação dada pela Emenda Constitucional nº 21, de 12.12.2000)

**Art. 146.** O Ministério Público do Estado tem como Chefe o Procurador- Geral de Justiça, nomeado pelo Governador do Estado, dentre Procuradores ou Promotores de Justiça com mais de trinta e cinco anos de idade, que gozem de vitaliciedade, indicados em lista tríplice, para mandato de dois anos, permitida uma recondução. (redação dada pela Emenda Constitucional nº 40, de 04.03.2008)

**Art. 146.** O Ministério Público do Estado tem como Chefe o Procurador- Geral de Justiça, nomeado pelo Governador do Estado, dentre Procuradores com mais de trinta e cinco anos de idade, que gozem de vitaliciedade, indicados em lista tríplice, para mandato de dois anos, permitida uma recondução. (redação dada pela

Emenda Constitucional nº 48, de 13.10.2014) (Declarada inconstitucional, em controle concentrado, pelo Supremo Tribunal Federal, no julgamento da ADIN nº 5.171)

**Parágrafo único.** A eleição do Procurador-Geral de Justiça do Estado, para cada biênio subsequente, será realizada sempre no dia 15 (quinze) de janeiro (incluído pela Emenda Constitucional nº 48, de 13.10.2014) (Declarada inconstitucional, em controle concentrado, pelo Supremo Tribunal Federal, no julgamento da ADIN nº 5.171)

**Art. 147.** A destituição do Procurador-Geral de Justiça, em casos de abuso de poder ou de omissão grave no cumprimento de dever, poderá ocorrer por deliberação do Poder Legislativo ou por indicação de dois terços do Colégio de Procuradores de Justiça, dependendo, em ambos os casos, de aprovação da maioria absoluta dos membros da Assembleia Legislativa, na forma da lei complementar.

**Art. 148.** Lei complementar, cuja iniciativa é facultada ao Procurador- Geral de Justiça estabelecerá a organização, as atribuições e o Estatuto do Ministério Público, observadas, relativamente a seus membros:

I - as seguintes garantias:

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 76

a) vitaliciedade, após dois anos de exercício, não podendo perder o cargo senão por sentença judicial transitada em julgado;

b) inamovibilidade, salvo por motivo de interesse público, mediante decisão do órgão colegiado competente do Ministério Público, por voto de dois terços de seus membros, assegurada ampla defesa;

b) inamovibilidade, salvo por motivo de interesse público, mediante decisão do órgão colegiado competente do Ministério Público, por voto da maioria absoluta de seus membros, assegurada ampla defesa; (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

c) irredutibilidade de vencimentos, observado quanto à remuneração o que dispõem os arts. 37, XI, 150, II, 153, III, e 153, § 2º, I, da Constituição Federal.

c) irredutibilidade de subsídio, fixado na forma do art. 39, § 4º, e ressalvado o disposto nos arts. 37, X e XI, 150, II, 153, III e 153, § 2º, I, todos da Constituição Federal. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

II - as seguintes vedações:

a) receber, a qualquer título e sob qualquer pretexto, honorários, percentagens ou cartas processuais;

b) exercer a advocacia;

c) participar de sociedade comercial, na forma da lei;

d) exercer, ainda que em disponibilidade, qualquer outra função pública, salvo uma de magistério;

e) exercer atividade político-partidária, ressalvadas as exceções previstas em lei.

e) exercer atividade político partidária; (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

f) receber, a qualquer título ou pretexto, auxílios ou contribuições de pessoas físicas, entidades públicas ou privadas, ressalvadas as exceções previstas em lei. (incluída pela Emenda Constitucional nº 35, de 21.03.2006)

**Parágrafo único.** Aplica-se aos membros do Ministério Público o disposto no art. 95, parágrafo único, V, da Constituição Federal. (incluído pela Emenda Constitucional nº 35, de 21.03.2006)

**Art. 149.** O ingresso na carreira do Ministério Público far-se-á mediante concurso público de provas e títulos, assegurada a participação da Ordem dos Advogados do Brasil em sua realização, exigindo-se do bacharel em direito, no mínimo, três anos de atividade jurídica e observando-se, nas nomeações, a ordem de classificação. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

**§ 1º** Lei complementar observará ainda, em relação a seus membros, os seguintes princípios: (revogado pela Emenda Constitucional nº 35, de 21.03.2006)

I - promoção de entrância a entrância, alternadamente, por antiguidade e merecimento, atendidas as seguintes normas: (revogado pela Emenda Constitucional nº 35, de 21.03.2006)

a) é obrigatória a promoção do membro do Ministério Público que figure por três vezes consecutivas ou cinco alternadas em lista de merecimento; (revogado pela Emenda Constitucional nº 35, de 21.03.2006)

b) a promoção por merecimento pressupõe dois anos de exercício na respectiva entrância e integrar o membro do Ministério Público a primeira quinta parte da lista de antiguidade desta, salvo se não houver com tais requisitos quem aceite o lugar vago. (revogado pela Emenda Constitucional nº 35, de 21.03.2006)

c) aferição do merecimento pelos critérios de presteza e segurança no exercício do cargo e, ainda, pela frequência e aproveitamento em cursos reconhecidos de aperfeiçoamento; (revogado pela Emenda Constitucional nº 35, de 21.03.2006)

d) na apuração da antiguidade, o Colégio de Procuradores de Justiça somente poderá recusar o promotor de justiça mais antigo, pelo voto de dois terços

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 77

de seus membros, conforme procedimento próprio, repetindo-se a votação até a indicação; (revogado pela Emenda Constitucional nº 35, de 21.03.2006)

II - o acesso à entrância superior far-se-á por antiguidade e merecimento, alternadamente, apurados na última entrância , observando-se as normas do inciso anterior; (revogado pela Emenda Constitucional nº 35, de 21.03.2006)

III - vencimentos fixados com diferença não superior a dez por cento de uma para outra das categorias de carreira, não podendo exceder os dos magistrados da mesma entrância; (revogado pela Emenda Constitucional nº 35, de 21.03.2006)

IV - o ato de remoção, disponibilidade e aposentadoria do membro do Ministério Público será decidido pelo voto de dois terços dos membros do órgão colegiado, assegurada ampla defesa. (revogado pela Emenda Constitucional nº 35, de 21.03.2006)

**§ 2º** Aplica-se ao Ministério Público estadual o disposto no art. 126, V, desta Constituição.

**§ 2º** Aplica-se ao Ministério Público, no que couber, o disposto no art. 93, da Constituição Federal. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

**§ 3º** Os cargos da carreira do Ministério Público, para todos os efeitos legais, são assemelhados aos da magistratura nos termos do art. 39, § Ia, da Constituição Federal.

**§ 3º** A distribuição dos processos no Ministério Público será imediata. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

**Art. 150.** São funções institucionais do Ministério Público:

I - promover, privativamente, a ação penal pública, na forma da lei;

II - zelar pelo efetivo respeito dos Poderes Públicos e os serviços de relevância pública aos direitos assegurados na Constituição Federal e nesta Constituição, e promover as medidas necessárias à sua garantia;

III - promover o inquérito civil e ação civil pública, para proteção do patrimônio público e social, do meio ambiente, do consumidor, do contribuinte, dos grupos socialmente discriminados e qualquer outro interesse difuso e coletivo;

IV - promover a ação de inconstitucionalidade ou representação para fins de intervenção do Estado, nos casos previstos nesta Constituição;

V - atuar, além das hipóteses do inciso anterior, em qualquer caso em que seja arguida por outrem, direta ou indiretamente, inconstitucionalidade de lei ou ato normativo;

VI - defender judicialmente os direitos e interesses das populações indígenas;

VII - expedir notificações nos procedimentos administrativos de sua competência, requisitando informações e documentos para instruí-los, na forma da lei complementar;

VIII - exercer o controle externo da atividade policial, na forma da lei complementar mencionada no inciso anterior;

IX - requisitar diligências investigatórias e a instauração de inquérito policial, indicados os fundamentos jurídicos de suas manifestações processuais;

X - exercer a fiscalização dos estabelecimentos prisionais e dos que abriguem idosos, menores, incapazes ou pessoas portadoras de deficiência;

XI - participação em organismos estatais de defesa do meio ambiente, do consumidor, da política penal e penitenciária e outros afetos a sua área de atuação;

XII - representar ao Tribunal de Contas do Estado, sobre irregularidade no processamento das contas públicas, bem como solicitar inspeções e auditorias financeiras em Prefeituras, Câmaras Municipais, órgãos de administração direta e indireta do Estado e dos Municípios, inclusive fundações e sociedades instituídas e mantidas pelo Poder Público;

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 78

XIII - exercer outras funções que lhe forem conferidas, desde que compatíveis com sua finalidade, sendo-lhe vedadas a representação judicial e a consultoria jurídica a entidades públicas.

**§ 1º** Além das funções previstas na Constituição Federal, nesta Constituição e nas leis, incumbe ainda, ao Ministério Público, nos termos da sua lei complementar:

a) instaurar procedimentos administrativos, para instruí-los, expedir notificações para colher depoimentos ou esclarecimentos, municipais e estaduais da administração direta ou indireta, como também promover inspeções e diligências investigatórias;

b) sugerir à autoridade competente a instauração de sindicância, acompanhá-la e produzir provas;

c) efetuar recomendações para melhoria dos serviços públicos e dos serviços de relevância pública;

d) sugerir ao Poder competente a edição de normas e a alteração da legislação em vigor;

e) requisitar serviços temporários de servidores públicos para realização de atividades específicas;

f) fiscalizar a aplicação de verbas públicas destinadas às instituições assistenciais;

g) receber petições, reclamações ou queixas de qualquer pessoa por desrespeito aos direitos assegurados nesta Constituição e na da República.

**§ 2º** A legitimação do Ministério Público para as ações civis previstas neste artigo não impede a de terceiros, nas mesmas hipóteses, segundo o disposto nesta Constituição e na lei.

**§ 3º** As funções do Ministério Público só podem ser exercidas por integrantes da carreira, que deverão residir na comarca da respectiva lotação.

**§ 3º** As funções do Ministério Público só podem ser exercidas por integrantes da carreira, que deverão residir na comarca da respectiva lotação, salvo autorização do chefe da instituição. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

**§ 4º** Para fins do inciso XIII deste artigo, o Ministério Público poderá ser dotado de órgão de atuação especializados em meio ambiente, direitos do consumidor, direitos dos grupos socialmente discriminados, sem prejuízo de outros que a lei criar. A esses órgãos poderão ser encaminhadas as denúncias de violação de direitos e descumprimento das leis que lhes são relativas, ficando a autoridade que receber a denúncia solidariamente responsável, em caso de omissão, nos termos da lei.

**§ 5º** Mediante lei será criada a ouvidoria do Ministério Público, competente para receber reclamações e denúncias de qualquer interessado contra membros ou órgãos do Ministério Público, inclusive contra seus serviços auxiliares, representando diretamente ao Conselho Nacional do Ministério Público. (incluído pela

Emenda Constitucional nº 35, de 21.03.2006)

**Art. 151.** Aos membros do Ministério Público junto ao Tribunal de Contas do Estado aplicam-se as disposições desta seção pertinentes a direitos, vedações e forma de investidura.

**Parágrafo único.** O Ministério Público junto ao Tribunal de Contas será exercido pelo Procurador-Geral da Justiça ou por procuradores de justiça por ele designados, com funções de procuradores de contas, na forma da lei complementar.

**Art. 151.** Para fiscalizar e superintender a atuação do Ministério Público, bem como zelar pelos princípios institucionais, haverá um Conselho Superior, CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 79

estruturado na forma de lei complementar. (redação dada pela Emenda Constitucional nº 8, de 06.11.1996)

**Art. 152.** Para fiscalizar e superintender a atuação do Ministério Público, bem como para zelar pelos princípios institucionais, haverá um Conselho Superior, estruturado na forma da lei complementar.

###### SUBSEÇÃO I Do Ministério Público Junto ao Tribunal de Contas (incluída pela Emenda Constitucional nº 8, de 06.11.1996)

**Art. 152.** O Ministério Público junto ao Tribunal de Contas do Estado, ao qual se aplicam os princípios institucionais da unidade, indivisibilidade e da independência funcional, tendo como Chefe o Procurador-Geral de Contas, compõem-se de Procuradores de Contas. (incluída pela Emenda Constitucional nº 8, de 06.11.1996)

**§ 1º** O Procurador Geral de Contas será nomeado pelo Governador do Estado, sob critério de livre escolha, dentre os integrantes do quadro. (incluído pela

Emenda Constitucional nº 8, de 06.11.1996)

**§ 1º** O Procurador-Geral de Contas será nomeado pelo Presidente da Assembleia Legislativa dentre os integrantes do quadro, após aprovação pelo Plenário do Tribunal, para mandato de dois anos. (redação dada pela Emenda Constitucional nº 20, 12.12.2000)

**§ 1º** O Procurador-Geral de Contas será nomeado pelo Presidente da Assembleia Legislativa por livre escolha, dentre os integrantes do quadro, para mandato de dois anos. (redação dada pela Emenda Constitucional nº 22, 18.01.2001)

**§ 1º** O Procurador Geral de Contas será nomeado pelo Presidente do Tribunal de Contas do Estado, dentre os integrantes da carreira, indicados em lista tríplice na forma da lei respectiva, para mandato de dois anos, permitida uma recondução. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

**§ 2º** Aos membros do Ministério Público junto ao Tribunal de Contas, aplicam-se as disposições desta Seção, no que se refere a direitos, vedações e formas de investidura. (incluído pela Emenda Constitucional nº 8, de 06.11.1996)

##### SEÇÃO II Da Procuradoria-Geral do Estado

**Art. 153.** A Procuradoria-Geral do Estado é instituição essencial à administração pública estadual que, diretamente ou através de órgão vinculado, representa o Estado judicial e extrajudicialmente, cabendo-lhe a defesa de seus direitos e interesses na área judicial e administrativa, as atividades de consultoria e assessoramento jurídico do Poder Executivo, bem como exercer outras funções que lhe forem conferidas por Lei.

**Art. 153.** A Procuradoria Geral do Estado do Amapá é instituição essencial à justiça e à administração pública estadual, que representa o Estado judicial e extrajudicialmente, cabendo-lhe, com exclusividade, a defesa dos direitos e interesses estaduais na área judicial e administrativa e as atividades de consultoria e assessoramento jurídico do Poder Executivo, bem como exercer outras funções que lhe forem conferidas por lei. (redação dada pela Emenda Constitucional nº 47, de 03.07.2012)

**§ 1º** A Procuradoria-Geral do Estado será chefiada pelo Procurador- Geral do Estado, com prerrogativas de Secretário de Estado, sendo o cargo provido em comissão, pelo Governador preferencialmente, dentre membros da carreira,

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 80

devendo o nomeado apresentar declaração pública de bens no ato da posse e quando for exonerado.

**§ 1º** São fundamentos da Procuradoria Geral do Estado do Amapá a autonomia institucional, a fiel observância aos princípios gerais da administração, a lealdade ao ente público que representa e a independência técnica de seus membros, sendo esta última regulada pelo poder normativo do Conselho Superior e será exercida de forma a manter a harmonia, coerência, eficiência e agilidade em atuação. (redação dada pela Emenda Constitucional nº 47, de 03.07.2012)

**§ 2º** Lei complementar disporá sobre a organização e o funcionamento da Procuradoria-Geral do Estado e sobre o Estatuto dos Procuradores do Estado, com observância do seguinte:

**§ 2º** A Procuradoria-Geral do Estado será chefiada pelo Procurador- Geral do Estado, com prerrogativas de Secretário de Estado, sendo o cargo provido em comissão, pelo Governador, dentre cidadãos maiores de 35 (trinta e cinco) anos, notável saber jurídico e reputação ilibada, preferencialmente dentre membros da carreira, devendo o nomeado apresentar declaração pública de bens no ato da posse e quando for exonerado. (redação dada pela Emenda Constitucional nº 47, de 03.07.2012)

**§ 2º** A Procuradoria-Geral do Estado será chefiada pelo Procurador- Geral do Estado, com prerrogativas de Secretário de Estado, sendo o cargo provido em comissão pelo Governador, dentre membros do último nível da carreira, com idade superior a trinta e cinco anos, devendo apresentar declaração pública de bens no ato da posse e quando for exonerado. (redação dada pela Emenda Constitucional nº 58, de 27.11.2018)

I - ingresso nos casos iniciais da carreira de procurador do Estado, através de concurso público de provas e títulos, realizado pela Procuradoria-Geral do Estado, assegurada a participação da Ordem do Advogados do Brasil, Secção do Amapá, na sua realização e observada a ordem de classificação;

I – ingresso nos cargos iniciais da carreira de procurador do Estado, através de concurso público de provas e títulos, realizado por comissão nomeada e presidida pelo Governador do Estado, assegurado a participação da Ordem dos Advogados do Brasil, Secção do Amapá e de membro do Ministério Público na sua realização e observada a ordem de classificação. (incluído pela Emenda Constitucional nº 25, de 03.10.2001)

II - isonomia de vencimentos em relação aos cargos do Ministério Público e dos Poderes Legislativo e Judiciário, nos termos do art. 135 da Constituição Federal.

II - estabilidade após 3 (três) anos de efetivo exercício, mediante avaliação de desempenho perante os órgãos próprios, após relatório circunstanciado da corregedoria. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

**§ 3º** Nos processos judiciais que versarem sobre atos praticados pelo Poder Legislativo, ou por sua administração, a representação do Estado caberá à Procuradoria Geral da Assembleia Legislativa, observado o que dispõe a parte final do caput do art. 115. (incluído pela Emenda Constitucional nº 24, de 15.08.2001)

**§ 3º** Ingresso na carreira de Procurador do Estado far-se-á mediante concurso público de provas e títulos, assegurada a participação em todas as etapas da Ordem dos Advogados do Brasil, seccional do Amapá, e de membro do Ministério Público, exigindo-se do bacharel em direito, no mínimo, três anos de atividade jurídica e observando-se, nas nomeações, a ordem de classificação. (redação dada pela Emenda Constitucional nº 47, de 03.07.2012)

**§ 4º** Sem prejuízo do disposto no § 1º deste artigo são privativos de procuradores estáveis os cargos em comissão de Subprocurador Geral e Procurador de Estado Corregedor. (incluído pela Emenda Constitucional nº 47, de 03.07.2012)

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 81

**§ 5º** O subsídio da última classe dos Procuradores do Estado do Amapá corresponderá a noventa inteiros e vinte e cinco centésimos por cento do subsídio mensal, fixado para os Ministros do Supremo Tribunal Federal, e os subsídios dos demais integrantes da carreira de Procurador de Estado serão fixados em lei e escalonados, não podendo a diferença entre uma e outra classe ser superior a dez por cento ou inferior a cinco por cento, observado, em qualquer caso, o disposto nos arts. 37, XI e 39, § 4º da Constituição Federal. (incluído pela Emenda Constitucional nº 47, de 03.07.2012) (a primeira parte do § 5º foi declarada inconstitucional, em controle concentrado, pelo Supremo Tribunal Federal, no julgamento da ADIN n. 4898).

**§ 6º** Nos processos judiciais que versarem sobre atos praticados pelo Poder Legislativo ou por sua Administração, a representação do Estado cabe à Procuradoria Geral da Assembleia Legislativa, observado, no que couber, o que dispõe a parte final do caput do art. 115. (incluído pela Emenda Constitucional nº 47, de 03.07.2012)

##### SEÇÃO III Da Defensoria Pública

**Art. 154.** A Defensoria Pública é instituição essencial à função jurisdicional do Estado, incumbindo-lhe a orientação jurídica integral e gratuita, a postulação e a defesa, em todos os graus e instâncias judiciais e extrajudiciais, dos direitos, interesses e garantias individuais e coletivos dos necessitados, na forma do

art. 134 da Constituição Federal.

**Art. 154.** A Defensoria Pública é instituição essencial à função jurisdicional do Estado, incumbindo-lhe a orientação jurídica e a defesa, em todos os graus, dos necessitados, na forma do art. 5º LXXIV da Constituição Federal. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

**§ 1º** A Defensoria Pública é integrada pelos defensores públicos do Estado e com quadro próprio de pessoal para seus serviços auxiliares, sob a direção do Defensor-Geral do Estado, com prerrogativas de Secretários do Estado, nomeado pelo Governador, devendo a escolha recair em membros integrantes da carreira.

**§ 2º** Os membros da Defensoria Pública terão os direitos a que se refere o § 1º do art. 159 desta Constituição.

**§ 3º** À Defensoria Pública são asseguradas autonomia funcional e administrativa e a iniciativa de sua proposta orçamentária dentro dos limites estabelecidos na lei de diretrizes orçamentárias e subordinação ao disposto no art. 99, § 2º da Constituição Federal. (incluído pela Emenda Constitucional nº 35, de 21.03.2006)

**Art. 155.** São princípios institucionais da Defensoria Pública a unidade, indivisibilidade e a independência funcionais.

**Art. 156.** Lei complementar organizará a Defensoria Pública do Estado, dispondo sobre sua competência, estrutura e funcionamento, bem assim a carreira de seus membros, observadas as normas previstas na legislação federal.

**Art. 156.** Lei complementar organizará a Defensoria Pública, observadas as normas gerais a que se refere o § 1º do art. 134 da Constituição Federal, assegurada aos seus integrantes a garantia da inamovibilidade e vedado o exercício da advocacia fora das atribuições institucionais. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

**Parágrafo único.** O ingresso nos cargos iniciais da carreira de defensor público dar-se-á através de concurso público de provas e títulos, realizado por comissão nomeada e presidida pelo Governador do Estado, assegurado a participação da Ordem dos Advogados do Brasil, Secção do Amapá e do Ministério

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 82

Público na sua realização e observada a ordem de classificação. (incluído pela Emenda Constitucional nº 25, de 03.10.2001)

**Art. 157.** Os serviços da Defensoria Pública estender-se-ão por todas as comarcas do Estado, de acordo com as necessidades e na forma prevista na lei complementar que dispuser sobre sua organização.

**Art. 158.** Os membros da carreira de que trata este artigo terão seus vencimentos e vantagens fixados e pagos segundo o disposto no art. 135 da Constituição Federal.

**Art. 158.** Os servidores integrantes das carreiras disciplinadas nesta

Seção e na anterior serão remunerados na forma do art. 47, § 4º. (redação dada pela

Emenda Constitucional nº 35, de 21.03.2006)

##### SEÇÃO IV Da Advocacia

**Art. 159.** O advogado é indispensável à administração da justiça e, nos termos da lei, inviolável por seus atos e manifestações no exercício da profissão.

**§ 1º** O Poder Judiciário reservará, em todos os fóruns e tribunais do Estado, salas privativas, condignas e permanentes, destinadas aos advogados.

**§ 2º** É dever das autoridades e dos servidores do Estado e dos Municípios, o respeito aos direitos e às prerrogativas dos advogados.

**§ 3º** O Poder Executivo manterá, no sistema prisional e nos distritos policiais, instalações destinadas ao contato privado do advogado com o cliente preso.

### TÍTULO VI Da Tributação, do Orçamento e das Finanças

#### CAPÍTULO I Dos Princípios Gerais

**Art. 160.** O sistema tributário obedecerá ao disposto na Constituição Federal, leis complementares, resoluções do Senado Federal, nesta Constituição e leis ordinárias.

**Art. 161.** A receita pública será constituída por tributos, preços e outros ingressos.

**Parágrafo único.** Os preços públicos serão fixados por ato do Poder Executivo, observadas as normas gerais de direito financeiro e o que dispuser esta Constituição e as leis atinentes à espécie.

**Art. 162.** Quaisquer benefícios e incentivos fiscais, inclusive inserções, anistia e remissão, só serão concedidos mediante lei específica estadual ou municipal.

#### CAPÍTULO II Da Tributação

##### SEÇÃO I Das Limitações do Poder de Tributar

**Art. 163.** Sem prejuízo de outras garantias asseguradas ao contribuinte, é vedado ao Estado e aos Municípios:

I - exigir ou aumentar tributo sem lei que o estabeleça; CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 83

II - instituir tratamento desigual entre contribuintes que se encontrem em situação equivalente, proibida qualquer distinção em razão de ocupação profissional ou função por eles exercida, independentemente da denominação jurídica dos rendimentos, títulos ou direitos;

III - cobrar tributos:

a) em relação a fatos geradores ocorridos antes do início da vigência da

lei que os houver instituído ou aumentado.

b) no mesmo exercício financeiro em que haja sido publicada a lei que os tenha instituído ou aumentado.

IV - utilizar tributo com efeito de confisco;

V - estabelecer limitações ao tráfego de pessoas ou bens, por meio de tributos interestaduais ou intermunicipais, ressalvada a cobrança de pedágio pela utilização de vias conservadas pelo Poder Público estadual ou municipal;

VI - instituir impostos sobre:

a) patrimônio, renda ou serviços da União, de outros Estados, do Distrito Federal e outros Municípios;

b) templos de qualquer culto;

c) patrimônio, renda ou serviço dos partidos políticos, inclusive suas fundações, das entidades sindicais dos trabalhadores, das instituições de educação e de assistência social, sem fins lucrativos, observados os requisitos fixados em lei;

d) livros, jornais, periódicos e o papel destinado a sua impressão.

**§ 1º** A vedação de alínea a do inciso VI é extensiva às autarquias e às fundações instituídas e mantidas pelo Poder Público, no que se refere ao patrimônio, à renda e aos serviços vinculados às suas finalidades ou delas decorrentes.

**§ 2º** As vedações de alínea a do inciso VI e do parágrafo anterior não se aplicam ao patrimônio, à renda e aos serviços relacionados com a exploração de atividades econômicas, regidas pelas normas aplicáveis a empreendimentos privados, ou em que haja contraprestação ou pagamento de preços ou tarifas pelo usuário, nem exoneram o promitente comprador da obrigação de pagar imposto relativamente ao bem imóvel.

**§ 3º** As vedações no inciso VI, alíneas b e c, compreendem somente o patrimônio, a renda e os serviços relacionados com as finalidades essenciais das entidades nelas mencionadas.

**§ 4º** Lei estadual determinará medidas para que os consumidores sejam esclarecidos acerca dos impostos que incidem sobre mercadorias e ou serviços.

**§ 5º** É vedado ao Estado e aos Municípios estabelecerem diferenças tributárias entre bens e serviços de qualquer natureza, em razão de sua procedência ou destino.

**Art. 164.** A lei que conceder ou autorizar a concessão de isenções tributárias, ou qualquer outro incentivo fiscal, disporá sobre os mecanismos de avaliação de seus efeitos, pela Assembleia Legislativa ou pela respectiva Câmara Municipal, durante o primeiro ano da legislatura posterior à concessão.

**Art. 165.** A revogação de isenção, incentivo ou benefício, exclusão, suspensão e extinção de crédito tributário, ainda que objeto de liberação dos Estados, do Distrito Federal e de Municípios, na forma do art. 155, § 2º, inciso XII, da Constituição Federal, dependerá sempre de prévia aprovação do Poder Legislativo estadual ou municipal, conforme o caso.

**Parágrafo único.** Para atender ao disposto no caput deste artigo, o Poder Executivo encaminhará, devidamente justificado, o instrumento de deliberação à Assembleia Legislativa, que deverá pronunciar-se no prazo máximo de trinta dias.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 84

##### SEÇÃO II Dos Tributos

**Art. 166.** O Estado e os Municípios poderão instituir e cobrar os seguintes tributos:

I - impostos;

II - taxas em razão do exercício do poder de polícia ou pela utilização, efetiva ou potencial, de serviços públicos específicos divisíveis, prestados ao contribuinte ou postos à sua disposição;

III - contribuições de melhorias, pela valorização de imóvel decorrente de obras públicas.

**§ 1º** Sempre que possível, os impostos terão caráter pessoal e serão graduados segundo a capacidade econômica do contribuinte, facultado à administração tributária, especialmente para conferir efetividade a esses objetos, identificar, respeitados os direitos individuais, e nos termos da lei, o patrimônio, os rendimentos, e as atividades econômicas do contribuinte.

**§ 2º** As taxas não poderão ter base de cálculo própria de impostos.

**§ 3º** O Estado e os Municípios poderão instituir contribuições, cobradas de seus servidores, para o custeio, em benefício destes, dos sistemas de previdência e assistência social.

##### SEÇÃO III Dos Impostos Pertencentes ao Estado

**Art. 167.** Compete ao Estado instituir e cobrar imposto sobre:

I - transmissão causa mortis e doação de quaisquer bens ou direitos;

II - operações relativas à circulação de mercadorias e sobre a prestação de serviços de transporte interestadual e intermunicipal e de comunicação, ainda que as operações e as prestações se iniciem no exterior;

III - propriedade de veículos automotores.

**§ 1º** Além dos impostos indicados neste artigo, o Estado poderá instituir adicional ao imposto de renda e proventos de qualquer natureza, incidente sobre lucros, ganhos e rendimentos de capital, até o limite de cinco por cento do imposto pago à União por pessoas físicas ou jurídicas domiciliadas em seu território.

**§ 2º** São isentas dos impostos estaduais e municipais as operações de transferência de imóveis desapropriados para fins de reforma agrária.

**Art. 168.** O imposto de que trata o inciso I do artigo anterior incidirá sobre a transmissão:

I - de bens imóveis situados no Estado do Amapá e dos direitos a eles relativos;

II - de bens móveis, de títulos e de créditos, cujo arrolamento ou inventário se processar em seu território ou, no caso de doação, se o doador tiver domicílio neste Estado.

**Parágrafo único.** Nos casos em que o doador tiver domicílio ou residência no exterior, ou em que o de cujus houver residido, sido domicílio ou tiver seu inventário processado no exterior, a competência para a instituição do imposto de transmissão obedecerá ao que dispuser a lei complementar federal.

**Art. 169.** O imposto de que trata o art. 167, II terá suas alíquotas máximas fixadas pelo Senado Federal, e atenderá ao seguinte:

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 85

I - será não cumulativo, compensando-se o que for devido em cada operação relativa à circulação de mercadorias ou à prestação de serviços com o montante cobrado nas anteriores pelo Estado, por outros Estados ou pelo Distrito Federal;

II - a isenção ou não incidência, salvo determinação em contrário da legislação:

a) não implicará crédito para compensação com o montante devido nas operações ou prestações seguintes;

b) acarretará a anulação do crédito relativo às operações anteriores.

III - poderá ser seletivo, em função da essencialidade das mercadorias e dos serviços;

IV - as alíquotas aplicáveis serão fixadas:

a) pelo Senado Federal, quanto às operações e prestações interestaduais e de exportação;

b) por lei estadual, respeitados os incisos V e VI deste artigo, quanto às operações internas, inclusive de importação.

V - serão observadas, nas operações internas, as alíquotas mínimas e máximas que vierem a ser fixadas pelo Senado Federal, nos termos da Constituição Federal;

VI - salvo deliberação em contrário dos Estados e do Distrito Federal, nos termos do art. 155, § 2º, VI, da Constituição Federal, as alíquotas internas, nas operações relativas à circulação de mercadorias e nas prestações de serviços, não poderão ser inferiores às previstas para as operações interestaduais;

VII - em relação às operações e prestações que destinem bens e serviços ao consumidor final localizado em outro Estado, adotar-se-á:

a) a alíquota interestadual, quando o destinatário for contribuinte do imposto;

b) a alíquota interna, quando o destinatário não for contribuinte dele.

VIII - na importação de mercadorias, bens e serviços de outros Estados para contribuintes deste Estado, é devido o imposto sobre a diferença entre as alíquotas interna e interestadual;

IX - incidirá também:

a) sobre a entrada de mercadoria importada do exterior, ainda quando se tratar de bem destinado a consumo ou ativo fixo do estabelecimento, assim como sobre serviço prestado no exterior, cabendo o imposto ao Estado, quando neles estiver situado o estabelecimento destinatário da mercadoria ou serviço;

b) sobre o valor total da operação, quando mercadorias forem fornecidas com serviços não compreendidos na competência tributária dos Municípios.

X - não incidirá:

a) sobre operações que destinem ao exterior produtos industrializados excluídos os semi-elaborados definidos em lei complementar federal;

b) sobre operações que destinem a outros Estados, o petróleo, inclusive lubrificantes, combustíveis líquidos e gasosos dele derivados, e energia elétrica;

c) sobre ouro, nas hipóteses definidas no art. 153, § 5º, da Constituição Federal.

XI - não compreenderá, em sua base de cálculo, o montante do imposto sobre produtos industrializados, quando a operação, realizada entre contribuintes e relativa a produto destinado à industrialização ou à comercialização configure fato gerador os dois impostos.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 86

##### SEÇÃO IV Dos Impostos Pertencentes aos Municípios

**Art. 170.** Compete aos Municípios instituir e cobrar impostos sobre:

I - propriedade predial e territorial urbana;

II - transmissão inter vivos, a qualquer título, por ato oneroso, de bens imóveis, por natureza ou acessão física, e de direitos reais sobre imóveis, exceto os de garantia, bem como cessão de direitos a sua aquisição;

III - vendas a varejo de combustíveis, líquidos e gasosos, exceto óleo diesel;

IV - serviços de qualquer natureza, não compreendidos no art. 155, inciso I, alínea b, da Constituição Federal, definidos em lei complementar.

##### SEÇÃO V Da Repartição das Receitas Tributárias

**Art. 171.** Pertencem ao Estado:

I - o produto da arrecadação do imposto da União sobre renda e proventos de qualquer natureza, incidente na fonte sobre rendimentos pagos, a qualquer título, por ele, suas autarquias e pelas fundações que instituir e mantiver;

II - vinte por cento do produto da arrecadação do imposto que a União instituir no exercício da competência que lhe é atribuída pelo art. 154, I, da Constituição Federal.

**Art. 172.** Pertencem aos Municípios:

I - o produto da arrecadação do imposto da União sobre a renda e proventos de qualquer natureza, incidente na fonte, sobre rendimentos pagos, a qualquer título, por eles, suas autarquias e pelas fundações que instituírem ou mantiverem;

II - cinquenta por cento do produto da arrecadação do imposto da União sobre a propriedade territorial rural, relativamente aos imóveis situados em cada um deles;

III - cinquenta por cento do produto da arrecadação do imposto estadual sobre a propriedade de veículos automotores licenciados no território de cada um deles;

IV - vinte e cinco por cento do produto da arrecadação do imposto estadual sobre as operações relativas à circulação de mercadorias e sobre prestação de serviços de transporte interestadual e intermunicipal e de comunicação;

V - as respectivas quotas do Fundo da Participação dos Municípios, referida no art. 159, I, b, da Constituição Federal;

VI - setenta por cento da arrecadação, conforme a origem do imposto a que se refere o art. 153, V da Constituição Federal, incidente sobre o ouro, quando definido em lei como ativo financeiro ou instrumento cambial.

**Parágrafo único.** As parcelas da receita pertencentes aos municípios, mencionadas no inciso IV deste artigo, serão creditadas conforme os seguintes critérios:

I - três quartos, no mínimo, na proporção do valor adicionado nas operações relativas à circulação de mercadorias e sobre prestação de serviços;

II - até um quarto, como dispuser lei estadual.

**Art. 173.** Os Poderes Executivos do Estado e dos municípios divulgarão, até o último dia do mês subsequente ao da arrecadação, os montantes de cada um

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 87

dos tributos arrecadados, os recursos recebidos, os valores de origem tributária entregues e a entregar e a expressão numérica de rateio, por Município.

#### CAPÍTULO III Do Orçamento

**Art. 174.** Os orçamentos anuais do Estado e dos Municípios obedecerão às disposições da Constituição Federal, às normas gerais de direito financeiro e às desta Constituição.

**Art. 175.** Leis de iniciativa do Poder Executivo estabelecerão:

I - o plano plurianual;

II - as diretrizes orçamentárias anuais;

III - os orçamentos anuais.

**§ 1º** A lei que instituir o plano plurianual estabelecerá de forma regionalizada, as diretrizes, objetivos e metas da administração pública estadual direta e indireta, para as despesas de capital e outras delas decorrentes e para as relativas aos programas de duração continuada.

**§ 1º** A lei que instituir o plano plurianual estabelecerá, de forma setorizada e regionalizada, as Diretrizes, objetivos e metas da administração pública estadual direta e indireta, para as despesas de capital e outras delas decorrentes e para as relativas aos programas de duração continuada. (redação dada pela Emenda Constitucional nº 14, de 20.12.1999)

**§ 2º** Nenhum investimento cuja execução ultrapasse um exercício financeiro poderá ser iniciado sem prévia inclusão no plano plurianual, ou sem lei que autorize sua inclusão, sob pena de crime de responsabilidade.

**§ 2º** O Projeto de Lei do Plano Plurianual, para vigência até o final do primeiro exercício financeiro do mandato do Governador do Estado, subsequente, será encaminhado até 04 (quatro) meses antes do encerramento do primeiro exercício financeiro e devolvido para sanção até o encerramento da Sessão Legislativa. (redação dada pela Emenda Constitucional nº 12, de 24.09.1999)

**§ 2º** O Plano Plurianual, cuja elaboração contará com a participação de entidades representativas da sociedade civil organizada e dos Municípios, será aprovado no primeiro ano de cada período de governo, submetido à apreciação da Assembleia Legislativa até o dia trinta e um de agosto, sob pena de crime de responsabilidade do Governador do Estado. (redação dada pela Emenda Constitucional nº 14, de 20.12.1999)

**§ 3º** A lei de diretrizes orçamentárias, de caráter anual, compreenderá:

I - as metas e prioridades da administração pública estadual direta e indireta;

II - as orientações para elaboração da lei orçamentária anual;

III - as disposições sobre as alterações na legislação tributária;

IV - as políticas de aplicações dos agentes financeiros oficiais de fomento, apresentando o plano de prioridade das aplicações financeiras e destacando os projetos de maior relevância;

V - os limites para a elaboração das propostas orçamentárias dos Poderes Legislativo e Judiciário e do Ministério Público.

**§ 3º** O não encaminhamento do Projeto de Lei do Plano Plurianual no prazo previsto no parágrafo anterior implicará em crime de responsabilidade do Governador do Estado. (redação dada pela Emenda Constitucional nº 12, de 24.09.1999)

**§ 3º** Nenhum investimento cuja execução ultrapasse um exercício financeiro poderá ser iniciado sem prévia inclusão no plano plurianual, ou sem lei que

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 88

autorize sua inclusão, sob pena de crime de responsabilidade. (redação dada pela Emenda Constitucional nº 14, de 20.12.1999)

**§ 4º** O Poder Executivo publicará, até trinta dias após o encerramento de cada bimestre, relatório resumido da execução orçamentária.

**§ 4º** A Lei de Diretrizes Orçamentária anual, compreenderá as metas e prioridades da administração pública estadual, direta e indireta, incluindo as despesas de capital para o exercício financeiro subsequente, orientará a elaboração da Lei Orçamentária anual, disporá sobre as alterações na legislação tributária, estabelecerá a política de aplicação das agências financeiras oficiais de fomento e estabelecerá os limites para a elaboração das propostas Orçamentárias dos Poderes Legislativo, Judiciário e do Ministério Público. (redação dada pela Emenda Constitucional nº 14, de 20.12.1999)

**§ 5º** Os planos e programas estaduais, regionais e setoriais previstos nesta Constituição serão elaborados em consonância com o plano plurianual, apreciado e aprovado pela Assembleia Legislativa.

**§ 5º** O Projeto de Lei das Diretrizes Orçamentárias será encaminhado à Assembleia Legislativa até 30 (trinta) de abril, para apreciação até 30 (trinta) de junho. (redação dada pela Emenda Constitucional nº 14, de 20.12.1999)

**§ 6º** A lei orçamentária anual compreenderá:

I - o orçamento fiscal, fixando as despesas referentes aos poderes estaduais, seus fundos, órgãos e entidades da administração direta e indireta, estimando as receitas do Estado, efetivas e potenciais, aqui incluídas as renúncias fiscais a qualquer título;

II - o orçamento da seguridade social, abrangendo todos os órgãos e entidades a ela vinculados, da administração direta ou indireta, bem como os fundos e fundações instituídos e mantidos pelo Poder Público;

III - os orçamentos de investimentos das empresas públicas e daquelas em que o Estado, direta e indiretamente, detenha a maioria do capital social com direito a voto.

**§ 6º** O Poder Executivo publicará até trinta dias após o encerramento de cada bimestre, relatório resumido da execução Orçamentária. (redação dada pela Emenda Constitucional nº 14, de 20.12.1999)

**§ 7º** Os orçamentos previstos no § 6º, I, II e III deste artigo deverão ser elaborados em consonância com as políticas de desenvolvimento urbano, rural e regional integrantes do plano plurianual.

**§ 7º** Os planos e programas estaduais, regionais e setoriais previstos nesta Constituição serão elaborados em consonância com o plano plurianual, apreciado e aprovado pela Assembleia Legislativa, que criará mecanismos de fiscalização adequada para sua fiel observância. (redação dada pela Emenda Constitucional nº 14, de 20.12.1999)

**§ 8º** O projeto de lei orçamentária será remetido à Assembleia Legislativa até o dia trinta de setembro, acompanhado de demonstrativo dos efeitos sobre as receitas e despesas públicas decorrentes da concessão de quaisquer benefícios de natureza financeira, tributária e creditícia, pela administração pública estadual, detalhados de forma regionalizada e identificados os objetivos de referidas concessões.

**§ 8º** A lei Orçamentária anual compreenderá: (redação dada pela Emenda Constitucional nº 14, de 20.12.1999)

I - O Orçamento fiscal, fixando as despesas referentes aos poderes estaduais, seus fundos, órgãos e entidades da administração direta e indireta,

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 89

estimando as receitas do Estado, efetivas e potenciais, incluídas as renúncias fiscais a qualquer título; (incluído pela Emenda Constitucional nº 14, de 20.12.1999)

II - O orçamento de seguridade social, abrangendo todos os órgãos e entidades a ela vinculados, da administração direta e indireta, bem como os fundos e fundações instituídos e mantidos pelo poder público; (incluído pela Emenda Constitucional nº 14, de 20.12.1999)

III - Os orçamentos de investimentos das empresas públicas e daquelas em que o Estado, direta ou indiretamente, detenha a maioria do capital social com direito a voto. (incluído pela Emenda Constitucional nº 14, de 20.12.1999)

IV - O percentual mínimo de 5% (cinco por cento), como contrapartida do Poder Executivo Estadual, aos valores referentes às Emendas Parlamentares Federais, na execução dos projetos destinados pela União aos Municípios do Estado do Amapá. (incluído pela Emenda Constitucional nº 46, de 03.07.2012)

**§ 9º** A lei orçamentária anual não conterá dispositivo estranho à previsão da receita e à fixação de despesa, não se incluindo na proibição a autorização para abertura de créditos suplementares e de operação de crédito, ainda que por antecipação da receita, nos termos da lei.

**§ 9º** Os orçamentos previstos no § 8º, I, II e III deste artigo deverão ser elaborados em consonância com as políticas de desenvolvimento urbano, rural e regional integrantes do plano plurianual. (redação dada pela Emenda Constitucional nº 14, de 20.12.1999)

**§ 10** O Projeto de Lei Orçamentária anual será remetido à Assembleia Legislativa até o dia trinta de setembro, acompanhado de demonstrativo dos efeitos sobre as receitas e despesas públicas decorrentes da concessão de quaisquer benefícios de natureza financeira, tributária e creditícia pela administração pública estadual, detalhados de forma regionalizada e identificados os objetivos de referidas concessões. (incluído pela Emenda Constitucional nº 14, de 20.12.1999)

**§ 11** A lei Orçamentária anual não conterá dispositivos estranhos à previsão da receita e à fixação da despesa, não se incluindo na proibição a autorização para abertura de créditos suplementares e de operações de créditos, ainda que por antecipação da receita, nos termos da lei. (incluído pela Emenda Constitucional nº 14, de 20.12.1999)

**§ 12** No primeiro ano de cada período de governo, o Projeto de Lei das Diretrizes Orçamentárias deverá ser encaminhado à Assembleia Legislativa, até 31 (trinta e um) de julho, para apreciação até 30 (trinta) de setembro, e o Projeto de Lei Orçamentária Anual será remetido até 31 (trinta e um) de outubro e apreciado até o encerramento da sessão legislativa. (incluído pela Emenda Constitucional nº 30, de 29.04.2003)

**§ 12** No primeiro ano de cada período de governo ou na hipótese de ocorrência de reconhecida calamidade pública, que justifique a impossibilidade de cumprimento dos prazos previstos nos §§ 5º e 10, o Projeto de Lei das Diretrizes Orçamentárias deverá ser encaminhado à Assembleia Legislativa, até 31 (trinta e um) de julho, para apreciação até 30 (trinta) de setembro, e o Projeto de Lei Orçamentária Anual será remetido até 31 (trinta e um) de outubro e apreciado até o encerramento da sessão legislativa. (redação dada pela Emenda Constitucional nº 62, de 30.04.2020)

**§ 13** A administração tem o dever de executar as programações orçamentárias, adotando os meios e as medidas necessários, com o propósito de garantir à sociedade. (incluído pela Emenda Constitucional nº 59, de 29.10.2019)

**Art. 176.** Os projetos de lei relativos do plano plurianual, às diretrizes orçamentárias, ao orçamento anual e aos créditos adicionais obedecerão ao que dispõe este capítulo e, naquilo em que for compatível, às regras do processo

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 90

legislativo, ordinário previsto nesta Constituição e no Regime Interno da Assembleia Legislativa.

**§ 1º** Caberá às comissões técnicas competentes da Assembleia Legislativa;

I - examinar e emitir parecer sobre os projetos referidos neste artigo e sobre as contas apresentadas anualmente pelo Governador do Estado;

II - examinar e emitir parecer sobre os planos e programas estaduais, regionais e setoriais previstos nesta Constituição e exercer o acompanhamento e a fiscalização orçamentária.

**§ 2º** As emendas serão apresentadas à comissão competente, que sobre elas emitirá parecer, e apreciadas em plenário, na forma regimental.

**§ 3º** As emendas ao projeto de lei do orçamento e aos projetos que o modifiquem somente podem ser aprovados caso:

I - sejam compatíveis com o plano plurianual e com a lei de diretrizes orçamentárias;

II - indiquem os recursos necessários, admitidos apenas os provenientes de anulação de despesa, excluídas as que incidem sobre:

a) dotação para pessoal e seus encargos;

b) serviço da dívida;

c) transferência constitucional para os Municípios.

III - sejam relacionados:

a) com a correção de erros ou omissões;

b) com os dispositivos do texto do projeto de lei.

**§ 4º** As emendas ao projeto de lei de diretrizes orçamentárias não poderão ser aprovadas quando incompatíveis com o plano plurianual.

**§ 5º** O Governador do Estado poderá enviar mensagem à Assembleia Legislativa para propor modificação nos projetos a que se refere este artigo, enquanto não tiver sido iniciada a votação, em plenário, da parte cuja alteração é proposta.

**§ 6º** Os recursos que, em decorrência de veto, emenda ou rejeição do projeto de lei orçamentária anual, ficarem sem despesas correspondentes poderão ser utilizados, conforme o caso, mediante créditos especiais ou suplementares, com prévia e específica autorização da Assembleia Legislativa.

**§ 7º** Sempre que solicitado pela Assembleia Legislativa, o Tribunal de Contas emitirá, no prazo por ela consignado, parecer prévio sobre a proposta orçamentária.

**§ 8º** As emendas individuais ao projeto de lei orçamentária serão aprovadas até o limite de 1,2% (um vírgula dois por cento) da receita corrente líquida prevista no projeto encaminhado pelo Poder Executivo, sendo que 25% (vinte e cinco por cento) do percentual definido serão destinados a ações e serviços públicos de saúde. (incluído pela Emenda Constitucional nº 59, de 29.10.2019)

**§ 9º** O percentual de que trata o § 8º será previsto e definido na redação do projeto de lei orçamentária encaminhado pelo Poder Executivo. (incluído pela Emenda Constitucional nº 59, de 29.10.2019)

**§ 10** A execução do montante destinado a ações e serviços públicos de saúde previstos no § 8º, inclusive custeio, será computada para fins do cumprimento do inciso II do § 2º do art. 198 da Constituição Federal, vedada a destinação para pagamento de pessoal ou encargos sociais. (incluído pela Emenda Constitucional nº 59, de 29.10.2019)

**§ 11** É obrigatória a execução orçamentária e financeira das programações a que se refere o § 8º deste artigo, em montante correspondente até o

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 91

limite de 1,2% (um vírgula dois por cento) da receita corrente líquida realizada no exercício anterior. (incluído pela Emenda Constitucional nº 59, de 29.10.2019)

**§ 11** É obrigatória a execução orçamentária e financeira das emendas previstas no § 8º deste artigo, até o limite definido na forma do § 9º, respeitado o fluxo de caixa do Tesouro Estadual. (redação dada pela Emenda Constitucional nº 60, de 19.12.2019)

**§ 12** As programações orçamentárias previstas no § 8º deste artigo não serão de execução obrigatória nos casos dos impedimentos de ordem técnica. (incluído pela Emenda Constitucional nº 59, de 29.10.2019)

**§ 13** Para fins de cumprimento do disposto nos §§ 8º, 11 e 12 deste artigo, os órgãos de execução deverão observar, nos termos da lei de diretrizes orçamentárias, cronograma para análise e verificação de eventuais impedimentos das programações e demais procedimentos necessários à viabilização da execução dos respectivos montantes. (incluído pela Emenda Constitucional nº 59, de 29.10.2019)

**§ 14** Quando a transferência obrigatória do Estado, para a execução da programação prevista nos §§ 8º, 10 e 11 deste artigo, for destinada a Municípios, independerá da adimplência destes e não integrará a base de cálculo da receita corrente líquida para fins de aplicação dos limites de despesa de pessoal de que trata o caput do art. 169 da Constituição Federal. (incluído pela Emenda Constitucional nº 59, de 29.10.2019) (Revogado pela Emenda Constitucional nº 60, de 19.12.2019)

**§ 15** Os restos a pagar provenientes das programações orçamentárias previstas nos §§ 8º, 10 e 11 deste artigo poderão ser considerados para fins de cumprimento da execução financeira realizada no exercício anterior para as programações das emendas individuais. (incluído pela Emenda Constitucional nº 59, de 29.10.2019) (Revogado pela Emenda Constitucional nº 60, de 19.12.2019)

**§ 16** Considera-se equitativa a execução das programações de caráter obrigatório que observe critérios objetivos e imparciais e que atenda de forma igualitária e impessoal às emendas apresentadas, independente de autoria. (incluído pela Emenda Constitucional nº 59, de 29.10.2019) (Revogado pela Emenda Constitucional nº 60, de 19.12.2019)

**§ 17** As programações de que tratam os §§ 8º, 11 e 12, quando versarem sobre o início de investimentos com duração de mais de um exercício financeiro ou cuja execução já tenha sido iniciada, deverão ser objeto de emenda pelo mesmo parlamentar, a cada exercício, até a conclusão da obra ou do empreendimento. (incluído pela Emenda Constitucional nº 59, de 29.10.2019) (Revogado pela Emenda Constitucional nº 60, de 19.12.2019)

**Art. 176-A** As emendas individuais de que trata o § 8º do art. 176, poderão alocar recursos aos Municípios por meio de: (incluído pela Emenda Constitucional n. 70, de 12.06.2024)

I - Transferência especial; e (incluído pela Emenda Constitucional n. 70, de 12.06.2024)

II - Transferência com finalidade específica. (incluído pela Emenda Constitucional n. 70, de 12.06.2024)

**§ 1°** Os recursos transferidos na forma do caput deste artigo não integrarão a receita dos Municípios para fins de repartição e para cálculo dos limites das despesas com pessoal, tampouco com o endividamento nos termos do art. 179, vedada, em qualquer caso, a aplicação dos recursos a que se refere o caput deste artigo no pagamento de: (incluído pela Emenda Constitucional n. 70, de 12.06.2024)

I - despesas com pessoal e encargos sociais relativos a ativos e inativos, e com pensionista; e (incluído pela Emenda Constitucional n. 70, de 12.06.2024)

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 92

II - encargos referentes ao serviço de dívida. (incluído pela Emenda Constitucional n. 70, de 12.06.2024)

**§ 2°** Na transferência especial a que se refere o caput deste artigo, os recursos: (incluído pela Emenda Constitucional n. 70, de 12.06.2024)

I - serão repassados diretamente ao ente federado beneficiado, independentemente de celebração de convênio ou de instrumento congênere; (incluído pela Emenda Constitucional n. 70, de 12.06.2024)

II - pertencerão ao ente federado no ato da efetiva transferência financeira; e (incluído pela Emenda Constitucional n. 70, de 12.06.2024)

III - serão aplicadas em programações finalísticas das áreas de competência do Poder Executivo do ente federado beneficiado, observado o § 4º deste artigo. (incluído pela Emenda Constitucional n. 70, de 12.06.2024)

**§ 3°** O ente federado beneficiado da transferência especial a que se refere o caput deste artigo poderá firmar contratos de cooperação técnica para fins de subsidiar o acompanhamento da execução orçamentária na aplicação dos recursos. (incluído pela Emenda Constitucional n. 70, de 12.06.2024)

**§ 4°** Pelo menos 70% (setenta por cento) das transferências especiais de que trata o inciso do caput deste artigo deverão ser aplicadas em despesas de capital, observada a restrição a que se refere o inciso II do § 1º deste artigo. (incluído pela Emenda Constitucional n. 70, de 12.06.2024)

**§ 5°** Na transferência com finalidade definida a que se refere o inciso II do caput deste artigo, os recursos serão: (incluído pela Emenda Constitucional n. 70, de 12.06.2024)

I - vinculados à programação estabelecida na emenda parlamentar; e (incluído pela Emenda Constitucional n. 70, de 12.06.2024)

II - aplicados nas áreas de competência constitucional dos Estados. (incluído pela Emenda Constitucional n. 70, de 12.06.2024)

**Art. 177.** É vedado:

I - o início de programas ou projetos não incluídos na lei orçamentária anual;

II - a realização de despesas ou a assunção de obrigações diretas que excedam os créditos orçamentários ou adicionais;

III - a realização de operações de créditos que excedam o montante das despesas de capital, exceto das autorizadas mediante créditos suplementares ou especiais com finalidade precisa, aprovados pelo Poder Legislativo, por maioria absoluta;

IV - a vinculação de receita de imposto a órgão, fundo ou a despesa, exceto para manutenção e desenvolvimento do ensino;

V - a abertura de crédito suplementar ou especial sem prévia autorização legislativa e sem indicação dos recursos correspondentes;

VI - a transposição, o remanejamento ou a transferência de recursos de uma categoria de programação para outra ou de um órgão para outro, sem prévia autorização da Assembleia Legislativa;

VII - a concessão ou utilização de crédito ilimitado;

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 93

VIII - a utilização, sem autorização da Assembleia Legislativa, de recursos do orçamento fiscal e da seguridade social, para suprir necessidades ou cobrir "déficit" de empresas, fundações e fundo;

IX - a instituição de fundos de qualquer natureza, sem prévia autorização da Assembleia Legislativa;

X - a subvenção ou auxílio do Poder Público às entidades de previdência privada com fins lucrativos.

**§ 1º** Os créditos especiais e extraordinários terão vigência no exercício financeiro em que, forem autorizados, salvo se o ato de autorização for promulgado nos últimos quatro meses do exercício, caso em que reabertos nos limites de seus saldos, serão incorporados aos orçamentos do exercício financeiro subsequente.

**§ 2º** A abertura de crédito extraordinário somente será admitida para atender a despesas imprevisíveis e urgentes como as decorrentes de guerra, comoção interna ou calamidade pública.

**Art. 178.** Os recursos correspondentes às dotações orçamentárias do Poder Legislativo, do Poder Judiciário e do Ministério Público, compreendidos os créditos suplementares e especiais, ser-lhe-ão entregues em duodécimos, até o dia vinte de cada mês, conforme a legislação pertinente.

**Parágrafo único.** Somente com autorização legislativa poderá haver antecipação de duodécimos aos Poderes do Estado, ao tribunal de Contas e ao Ministério Público. (incluído pela Emenda Constitucional nº 29, de 27.12. 2002)

**Art. 179.** A despesa com pessoal ativo e inativo do Estado não poderá exceder os limites estabelecidos em lei complementar federal.

**Parágrafo único.** A concessão de qualquer vantagem ou aumento de remuneração, a criação de cargos ou alteração de estrutura de carreiras, bem como a admissão de pessoal, a qualquer título, pelos órgãos e entidades da administração direta e indireta, inclusive fundações instituídas e mantidas pelo Poder Público, só poderão ser feitas:

I - se houver prévia dotação orçamentária suficiente para atender às projeções de despesa de pessoal e ao acréscimo dela decorrente;

II - se houver autorização específica na lei de diretrizes orçamentárias, ressalvadas as empresas públicas e as sociedades de economia mista.

**Art. 180.** A Assembleia Legislativa elaborará a proposta orçamentária do Poder Legislativo, cujo montante de recursos será de, no mínimo, três por cento da receita geral do Estado, incluídas as transferências da União.

**Art. 180.** A Assembleia Legislativa elaborará a Proposta Orçamentária Anual do Poder Legislativo, nela incluída a dotação do Tribunal de Contas, cujo montante de recursos obedecerão aos limites previstos na Lei de Diretrizes Orçamentárias – LDO, encaminhando-a para inclusão obrigatória no Projeto de Lei Orçamentária Anual até o dia 31 de agosto de cada ano. (redação dada pela Emenda Constitucional nº 12, de 24.09.1999)

**Parágrafo único.** As propostas Orçamentárias do Poder Judiciário e Ministério Público, para inclusão obrigatória no Projeto de Lei Orçamentária Anual, também deverão ser encaminhadas ao Poder Executivo até a data prevista no caput deste artigo. (incluído pela Emenda Constitucional nº 12, de 24.09.1999)

#### CAPÍTULO IV Das Finanças Públicas

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 94

**Art. 181.** Lei estadual disporá, segundo os princípios da lei complementar federal, sobre:

I - fiscalização financeira;

II - normas orçamentárias e de contabilidade pública;

III - crédito público.

**Art. 182.** A administração financeira do Estado, inclusive a arrecadação dos tributos, será exercida exclusivamente pelo Poder Executivo, através de seus órgãos da administração direta, estruturados em lei.

**Art. 183.** Lei complementar estadual, obedecidos aos princípios estabelecidos na Constituição Federal e na legislação federal deles decorrentes, disporá sobre:

I - dívida pública externa e interna, incluída a das autarquias, fundações e demais entidades controladas pelo Poder Público;

II - concessão de garantias pelas entidades públicas estaduais;

III - emissão e resgate de títulos da dívida pública estadual.

**Art. 184.** As disponibilidades de caixa do Estado, de suas autarquias, fundações, empresas públicas e sociedades de economia mista serão depositadas nos bancos oficiais instalados no Estado, ressalvados os casos previstos em lei.

**Art. 185.** É agente financeiro do Tesouro Estadual o Banco do Estado do Amapá.

**Art. 185.** É agente de crédito do Tesouro Estadual a Agência de Fomento do Estado do Amapá. (redação dada pela Emenda Constitucional nº 53, 24.08.de 2015)

### TÍTULO VII Da Ordem Econômica

#### CAPÍTULO I Dos Princípios Gerais

**Art. 186.** A organização da atividade econômica, fundada na valorização do trabalho humano e na livre iniciativa, tem por fim assegurar a todos existência digna, observados os princípios da Constituição Federal, cabendo ao Estado e aos Municípios, no âmbito de sua competência, garantir sua realização.

**§ 1º** É assegurado a todos o livre exercício de qualquer atividade econômica, independentemente de autorização dos órgãos públicos, salvo nos casos previstos em lei.

**§ 2º** A lei estimulará a livre iniciativa e a livre concorrência, reprimindo os abusos do poder econômico.

**§ 3º** A intervenção do Estado na economia deverá ser precedida de consulta às entidades de classes interessadas na atividade objeto da intervenção e observará as condições estabelecidas pelo art. 173 da Constituição Federal.

**§ 4º** Os interesses da iniciativa privada não podem se sobrepor aos do Poder Público e da coletividade.

**§ 5º** A lei estimulará a descentralização geográfica das atividades de produção e comercialização de bens e de prestação de serviços, visando ao desenvolvimento intra-regional equilibrado, mediante a simplificação de obrigações administrativas, tributárias e creditícias ou, ainda, pela redução ou eliminação destas. (incluído pela Emenda Constitucional nº 35, de 21.03.2006)

**Art. 187.** Como agente normativo o regulador das atividades econômicas, o Estado exercerá, na forma da lei, as funções da fiscalização, incentivo

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 95

e planejamento, sendo este determinante para o setor público e indicativo para o setor privado.

**Art. 188.** A lei definirá o sistema, as diretrizes e bases do planejamento e desenvolvimento estadual equilibrado, integrando-o ao planejamento nacional e a ele se incorporando e compatibilizando os planos regionais e municipais, atendendo:

I - ao desenvolvimento social e econômico;

II - ao desenvolvimento urbano e rural;

III - à ordenação territorial;

IV - à desconcentração espacial das atividades econômicas e o melhor aproveitamento de suas potencialidades locais e regionais;

V - à definição de prioridades regionais;

VI - apoio e estímulo ao cooperativismo e outras formas associativas;

VII - ao apoio e estímulo ao aproveitamento do potencial energético, promovendo-se obrigatoriamente a intensificação dos programas de eletrificação rural;

VIII - à preservação das reservas indígenas, extrativistas, biológicas, e outras unidades de conservação, tendo por base o equilíbrio ecológico;

IX - à manutenção do serviço de extensão rural, de extensão e fiscalização da pesca;

X - à cooperação com outros Estados e outros países, observadas as disposições da lei federal;

XI - ao tratamento jurídico diferenciado às microempresas e às empresas de pequeno porte, aos pescadores artesanais e aos produtores rurais que trabalham em regime de economia familiar, assim definidos em lei visando incentivá-los mediante:

a) a simplificação de suas obrigações administrativas, tributárias e financeiras;

a) a simplificação de suas obrigações administrativas, tributárias e creditícias; (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

b) o favorecimento no acesso ao crédito, com a criação de programas específicos e financiamento;

c) a redução escalonada ou eliminação de produtos através da lei ou convênio.

c) a redução ou eliminação das obrigações descritas na alínea a, por meio de lei. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

XII - tratamento jurídico diferenciado, na forma da lei, às empresas instaladas fora de áreas beneficiadas com incentivos fiscais conferidos pela União, mediante a adoção dos mesmos parâmetros estabelecidos no inciso anterior. (incluído pela Emenda Constitucional nº 35, de 21.03.2006)

**Parágrafo único.** A implementação da política de planejamento e desenvolvimento de que trata este artigo caberá a um órgão colegiado, com representação paritária do Governo do Estado e do setor privado. (incluído pela Emenda Constitucional nº 35, de 21.03.2006)

**Art. 189.** Ao Estado incumbe a prestação de serviços públicos de sua competência.

**§ 1º** A execução poderá ser delegada, precedida de licitação, nos regimes de concessão ou permissão.

**§ 2º** A delegação assegurará ao concessionário e permissionário as condições de prorrogação, caducidade, fiscalização e rescisão de contrato, garantidas:

I - a qualidade do serviço prestado aos usuários; CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 96

II - política tarifária socialmente justa que assegure aos usuários o direito de igualdade, o melhoramento e expansão dos serviços, a justa remuneração do capital empregado e o equilíbrio econômico-financeiro do contrato.

**§ 3º** É vedado, na delegação de qualquer serviço, o contrato de exclusividade, salvo nos casos previstos em lei.

**Art. 189-A.** Fica instituído o Fundo Estadual de Transporte e Habitação – FETHAB, cuja organização, formação e gerenciamento observarão o disposto em

lei complementar, destinado a financiar o planejamento, a execução, o acompanhamento e avaliação de obras e serviços de transporte e de habitação em todo o Estado do Amapá. (incluído pela Emenda Constitucional nº 35, de 21.03.2006)

**Art. 190.** As parcelas de recursos asseguradas, nos termos da lei federal, ao Estado, com participação no resultado da exploração de petróleo ou gás natural, de recursos hídricos para fins de geração de energia elétrica e de outros recursos minerais, no seu território, ou como compensação financeira, por essa exploração, serão aplicadas e distribuídas na forma da lei.

**Parágrafo único.** O Estado do Amapá criará programas de incentivo à geração de energia elétrica por fontes renováveis. (incluído pela Emenda Constitucional nº 35, de 21.03.2006)

**Art. 191.** O Estado e os Municípios promoverão e incentivarão o turismo como fator de desenvolvimento social e econômico.

**Art. 192.** O Estado, por meio de lei e ação integrada com a União, com os Municípios e com a sociedade, promoverá a defesa dos direitos sociais do consumidor, através da sua conscientização, de prevenção e responsabilização por danos a ele causados.

**Art. 193.** É vedada a concessão de incentivos e isenções fiscais às empresas que não atendam às normas de proteção ambiental, de saúde e de segurança do trabalho.

#### CAPÍTULO II Da Política Urbana

##### SEÇÃO I Do Desenvolvimento Urbano

**Art. 194.** A política de desenvolvimento urbano tem por objetivo ordenar e harmonizar o crescimento das cidades de maneira a atender à função social do solo urbano e ao bem-estar dos habitantes.

**Art. 194.** A política de desenvolvimento urbano, executada pelo Poder Público municipal, conforme diretrizes gerais fixadas em lei, tem por objetivo ordenar o pleno desenvolvimento das funções sociais da cidade e garantir o bem-estar de seus habitantes, observados os princípios fixados pela Constituição Federal, e ainda: (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

**Parágrafo único.** O exercício do direito de propriedade do solo urbano atenderá à sua função social, condicionada às exigências fundamentais de ordenação da cidade.

**§ 1º** O exercício do direito de propriedade do solo urbano atenderá à sua função social, condicionada às exigências fundamentais de ordenação da cidade. (incluído pela Emenda Constitucional nº 35, de 21.03.2006)

**§ 2º** A política urbana deve garantir aos idosos, às gestantes e às pessoas portadoras de necessidades especiais facilidade plena de acesso aos bens

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 97

e serviços de uso coletivo, públicos e privados, em especial nos meios de transporte. (incluído pela Emenda Constitucional nº 35, de 21.03.2006)

**§ 3º** As empresas de transporte coletivo rodoviário intermunicipal de passageiros devem reservar 04 (quatro) vagas em cada viagem a ser realizada, qualquer que seja o destino, aos idosos inseridos no inciso II do art. 223. (incluído pela

Emenda Constitucional nº 35, de 21.03.2006)

**Art. 195.** O plano diretor, instrumento básico da política de desenvolvimento econômico e social e de expansão urbana, aprovado pela Câmara Municipal, é obrigatório para os Municípios com mais de cinco mil habitantes.

**Art. 195.** O plano diretor, aprovado pela Câmara Municipal, obrigatório para cidades com mais de vinte mil habitantes, é o instrumento básico da política de desenvolvimento e de expansão urbana. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

**§ 1º** O plano diretor disporá sobre:

I - normas relativas ao desenvolvimento urbano;

II - políticas de orientação à formulação de planos setoriais;

III - critérios de parcelamento, uso e ocupação do solo e zoneamento, prevendo áreas destinadas a moradias populares com garantias de acesso aos locais de trabalho e lazer;

IV - proteção ambiental;

V - ordenação de usos, atividades e funções de interesse zonal.

**§ 2º** Os Municípios observarão, quando necessário, os parâmetros de interesse regional, fixados em lei estadual, prevalecendo, quando houver conflito, a norma de desenvolvimento mais restritiva, respeitadas as respectivas autonomias.

**Art. 196.** Compete ao Estado, em consonância com seus objetivos de desenvolvimento econômico, estabelecer mediante lei, diretrizes para localização e integração das atividades industriais, considerando os aspectos ambientais, locacionais, sociais e econômicos, atendendo ao melhor aproveitamento das condições naturais urbanas e de organização espacial.

**Art. 197.** Compete aos Municípios, de acordo com as respectivas diretrizes de desenvolvimento urbano, a criação e regularização das zonas industriais, obedecendo aos critérios estabelecidos em lei estadual e respeitadas as normas relacionadas ao uso e ocupação do solo e ao meio ambiente urbano.

**Art. 198.** A Lei Orgânica Municipal fixará o âmbito, conteúdo básico, periodicidade, obediência, condições de aprovação, controle e revisão do plano diretor, dispondo sobre a competência dos órgãos de planejamento e consulta a entidades representativas da sociedade civil.

##### SEÇÃO II Da Habitação

**Art. 199.** A política habitacional do Estado, integrada à da União e dos Municípios, tem como finalidade combater a carência habitacional e buscar soluções para esses problemas em conjunto com a sociedade, e será executada mediante:

I - oferta de lotes urbanizados dotados de infra-estrutura básica;

II - utilização prioritária da mão-de-obra local na execução dos projetos habitacionais;

III - promoção e execução de programas de construção de moradias populares;

IV - melhoria das condições da habitação e de saneamento básico nos conjuntos habitacionais;

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 98

V - garantias de serviços de infra-estrutura e de lazer para os conjuntos já construídos e a construir;

VI - atendimento prioritário às famílias carentes:

VII - criação de programas habitacionais pelo sistema de mutirão e autoconstrução;

VIII - garantia dos serviços de saúde, ensino fundamental, creches e pré- escolar, água tratada, energia elétrica e transporte coletivo regular.

**§ 1º** O Estado promoverá e financiará a construção de habitações populares, especialmente para a população de média e baixa renda, da área urbana, assegurando o pagamento pela equivalência salarial ou pela renda mensal dos trabalhadores autônomos.

**§ 1º** O estado promoverá e financiará a construção de habitações populares, especialmente para a população de média e baixa renda, da área urbana, assegurando o pagamento pela equivalência salarial ou pela renda mensal dos trabalhadores autônomos e das mulheres que comprovarem condição mantenedora financeira de suas famílias. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

**§ 2º** O financiamento de habitações populares na área rural obedecerá a critérios instituídos em lei, assegurada proporcionalidade de investimentos em relação à área urbana.

**§ 3º** É assegurado o acesso dos trabalhadores ao crédito e ao financiamento habitacionais, vedadas discriminação e preferência.

##### SEÇÃO III Do Saneamento

**Art. 200.** Os programas de saneamento básico do Estado, integrados aos da União e dos Municípios serão elaborados e executados, em consonância com as diretrizes globais do Poder Executivo e constarão dos planos plurianuais.

**Art. 201.** O sistema estadual de saúde tomará parte na formulação da política e na execução das ações de saneamento básico.

**Art. 202.** O Estado, em conjunto com os Municípios, instituirá programas de saneamento urbano e rural, com a finalidade de promover a defesa preventiva da saúde pública.

**Art. 203.** O Estado e os Municípios estabelecerão mediante lei, a política tarifária dos serviços de saneamento básico prestados à população.

**Art. 204.** A lei estabelecerá a política das ações e obras de saneamento básico no Estado, respeitados os seguintes princípios:

I - garantia de abastecimento domiciliar prioritário de água tratada;

II - criação e desenvolvimento de mecanismos institucionais e financeiros destinados a assegurar os benefícios do saneamento à totalidade da população;

III - coleta, tratamento e destinação total dos esgotos sanitários, resíduos sólidos e industriais;

IV - proteção dos mananciais potáveis.

#### CAPÍTULO III Da Política Agrária, Fundiária, Agrícola e Extrativista Vegetal

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 99

**Art. 205.** As políticas agrária, fundiária, agrícola e extrativista vegetal serão planejadas e executadas, na forma da lei, com a participação paritária e efetiva dos produtores e trabalhadores rurais, objetivando o desenvolvimento rural nos seus aspectos econômicos e sociais com a racionalização do uso e preservação dos recursos naturais e ambientais, cabendo ao Estado:

I - a orientação, assistência técnica e extensão rural;

II - a geração contínua e evolutiva de tecnologia de produção;

III - a inspeção e fiscalização da produção, comercialização e utilização de insumos agropecuários;

IV - o zoneamento agroecológico;

IV - o Zoneamento Econômico Ecológico; (redação dada pela Emenda Constitucional nº 57, de 19.12.2017)

V - o estabelecimento de mecanismo de apoio:

a) a programas que atendam às áreas da agropecuária e do extrativismo vegetal autossustentável no Estado;

b) ao sistema de seguro agrícola;

c) a complementação dos serviços voltados para a comercialização agrícola e extrativista vegetal, armazenagem, transporte e abastecimento;

d) a organização dos produtores em cooperativas, associações profissionais e demais formas associativas;

e) a agroindustrialização de forma regionalizada e, preferencialmente, no meio rural ou em pequenas comunidades;

f) à comercialização sob forma coletiva.

VI - à instituição de um sistema de planejamento agrícola integrado;

VII - o investimento em benefícios sociais para rurícolas e comunidades rurais;

VIII - a irrigação, drenagem, eletrificação e telefonia rural e malha viária;

IX - a manutenção de controle estatístico de produção com estimativas de safras;

X - o incentivo a pesquisas agroflorestais de acordo com a estrutura ambiental e cultural do Estado.

**§ 1º** O Estado e os Municípios estimularão o cooperativismo e outras formas de associativismo econômico, através de linha de crédito específico e facilitado.

**§ 2º** A lei agrícola dará tratamento diferenciado e privilegiado ao micro e pequeno produtor.

**Art. 206.** A concessão, uso, permuta, destinação e venda a pessoa física ou jurídica será limitada a dois mil e quinhentos hectares de áreas contíguas, sendo respeitadas as seguintes normas, além de outras previstas em lei.

**Art. 206.** A alienação ou a concessão, a qualquer título, de terras públicas, a pessoa física ou jurídica, ainda que por interposta pessoa, obedecerá ao seguinte, sem prejuízo do disposto em lei: (redação dada pela Emenda Constitucional nº 42, de 30.06.2009)

a) até cem hectares, mediante aprovação do órgão fundiário;

a) até 4 módulos fiscais, mediante aprovação do órgão fundiário; (redação dada pela Emenda Constitucional nº 42, de 30.06.2009)

a) até 15 módulos fiscais, mediante aprovação do órgão fundiário; (redação dada pela Emenda Constitucional nº 43, de 30.11.2009) (revogado pela Emenda Constitucional nº 57, de 19.12.2017)

b) acima de cem até quinhentos hectares, mediante estudo de um plano de exploração econômica, através do órgão responsável;

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 100

b) acima de 4 e até 15 módulos fiscais, mediante aprovação de um plano de exploração econômica pelo órgão fundiário; (redação dada pela Emenda Constitucional nº 42, de 30.06.2009)

b) acima de 15 módulos fiscais e até dois mil e quinhentos hectares, além do disposto na alínea a, com prévia aprovação da Comissão Permanente de Política Agrária da Assembleia Legislativa. (redação dada pela Emenda Constitucional nº 43, de 30.11.2009) (revogado pela Emenda Constitucional nº 57, de 19.12.2017)

c) acima de quinhentos até dois mil e quinhentos hectares, além do disposto no item anterior, com a prévia aprovação da Assembleia Legislativa.

c) acima de 15 módulos fiscais e até dois mil e quinhentos hectares, além do disposto na alínea b, com prévia aprovação da Comissão Permanente de Política Agrária da Assembleia Legislativa. (redação dada pela Emenda Constitucional nº 42, de 30.06.2009) (revogado pela Emenda Constitucional nº 57, de 19.12.2017)

**§ 1º** As áreas já instaladas, superiores a quinhentos hectares, deverão apresentar projeto de utilização da área, com demonstração do respectivo retorno social, a ser apreciado pela Assembleia Legislativa, para devida aprovação ou cancelamento.

**§ 1º** As áreas já instaladas, superiores a 15 módulos fiscais, deverão apresentar projeto de utilização da área, com demonstração do respectivo retorno social, a ser apreciado pela Comissão Permanente de Política Agrária da Assembleia Legislativa, para a devida aprovação ou cancelamento. (redação dada pela Emenda Constitucional nº 42, de 30.06.2009)

**§ 1º** As áreas superiores a dois mil e quinhentos aplica-se, no que couber, o disposto na Constituição Federal. (redação dada pela Emenda Constitucional nº 43, de 30.11.2009)

**§ 2º** As áreas superiores ao disposto na alínea “c” do caput deste artigo deverão obedecer o que rege a lei federal.

**§ 2º** Às áreas superiores a dois mil e quinhentos hectares aplica-se, no que couber, o disposto na Constituição Federal. (redação dada pela Emenda Constitucional nº 42, de 30.06.2009)

**§ 2º** Excetuam-se do disposto no caput deste artigo as alienações ou as concessões de terras públicas para fins de reforma agrária. (redação dada pela Emenda Constitucional nº 43, de 30.11.2009)

**§ 3º** Excetuam-se do disposto no caput deste artigo as alienações ou as concessões de terras públicas para fins de reforma agrária. (incluído pela Emenda Constitucional nº 42, de 30.06.2009) (revogado pela Emenda Constitucional nº 57, de 19.12.2017)

**Art. 207.** Observada a lei federal, o Estado promoverá a implantação da reforma agrária.

**Art. 208.** A regularização de ocupações e destinações de terras públicas e devolutas serão compatibilizadas com as políticas agrária e de preservação ambiental, através de títulos de domínio ou de concessão de uso, segundo forma de critérios definidos em lei complementar estadual.

**§ 1º** Os órgãos do Estado devem ser colocados, em caráter complementar, a serviço dos assentamentos, no sentido de torná-los produtivos.

**§ 2º** A política de assentamento rural, desenvolvida pelo Estado, estimulará o cooperativismo e demais formas associativas.

**§ 3º** O Estado assegurará aos detentores de posse de terras públicas, por eles tornadas produtivas com o seu trabalho e o de sua família, a preferência para a aquisição da área, de até cem hectares, mediante concessão de título de domínio, desde que:

**§ 3º** O Estado assegurará aos detentores de posse de terras públicas, por eles tornadas produtivas como o seu trabalho e o de sua família, a preferência para a aquisição de

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 101

área, até o limite constitucional, mediante concessão de título de domínio, desde que: (redação dada pela Emenda Constitucional nº 42, de 30.06.2009)

I - não sejam proprietários de outra área rural, superior a um módulo rural mínimo;

I - não sejam proprietários de outra área rural superior ao menor módulo fiscal definido para o Estado do Amapá; (redação dada pela Emenda Constitucional nº 43, de 30.11.2009)

II - tenham na agricultura sua atividade principal;

III - detenham posse mansa e pacífica;

IV - tenham morada habitual e cultura afetiva. (incluído pela Emenda Constitucional nº 57, de 19.12.2017)

**§ 4º** Fica assegurada aos beneficiários e suas organizações representativas a participação na organização e no acompanhamento dos assentamentos.

**§ 5º** A concessão de títulos de domínio ou de uso de terras públicas e devolutas deverá considerar a manutenção de áreas de preservação e as restrições de uso do solo, nos termos da lei.

**§ 6º** Os lotes destinados a assentamentos nunca serão inferiores ao módulo rural mínimo definido por lei, ficando vedada a concessão de títulos de domínio ou de uso de mais de um lote à mesma unidade familiar.

**§ 6º** Os lotes destinados a assentamentos nunca serão inferiores ao módulo fiscal definido para o município onde se localizar o projeto de assentamento, ficando vedada a concessão de títulos de domínio ou de uso de mais de um lote à mesma unidade familiar. (redação dada pela Emenda Constitucional nº 43, de 30.11.2009)

**§ 7º** As terras devolutas do Estado, observado o disposto nesta Constituição, serão prioritariamente destinadas ao assentamento de trabalhadores rurais.

**Art. 209.** Caberá ao Estado, em benefício dos projetos de assentamento:

I - criar programas especiais de créditos, assistência técnica e extensão rural;

II - executar obras de infraestrutura física e social;

III - estabelecer programas de fornecimento de insumo básico e de serviços de mecanização agrícola;

IV - criar mecanismo de apoio à comercialização da produção;

V - desenvolver o diagnóstico de acompanhamento sócio-econômico dos assentamentos, bem como seus levantamentos físicos;

VI - assegurar para que todos os projetos de assentamento de colonos sejam previamente dotados da infraestrutura mínima necessária.

**Art. 210.** O Estado, adotando medidas cabíveis:

I - disciplinará, por lei, tudo o que se referir a produtos destinados a uso agrícola que ofereça risco à vida, à fauna, à flora e ao meio ambiente;

II - inspecionará, classificará e estabelecerá padrões de qualidade e sanidade para comercialização de produtos agropecuários e subprodutos de origem animal e vegetal;

III - adotará medidas de defesa sanitária animal e vegetal e serviços de erradicação e prevenção de doenças e pragas que afetem o setor agrossilvopastoril;

IV - manterá serviço de assistência técnica e extensão rural, assegurando orientação prioritária ao micro e pequeno produtor sobre a produção agrossilvopastoril, sua organização, comercialização e preservação de recursos naturais;

V - promoverá ações que visem à profissionalização no meio rural;

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 102

VI - promoverá e subsidiará financeiramente a pesquisa agroflorestal e pastoril, garantindo o avanço tecnológico compatibilizado com o desenvolvimento social e cultural do homem do campo, sem trazer prejuízo ao meio ambiente e priorizando a produção de alimentos.

**Art. 211.** Na aquisição de terras pelo Estado, destinadas à implantação de projetos de interesse social, o pagamento será efetuado em moeda corrente.

**Art. 212.** O Estado e os Municípios poderão criar centrais de abastecimento, com a finalidade de combater a elevação abusiva dos preços dos produtos alimentícios.

**Art. 213.** Compete, ainda, ao Estado:

I - promover a adequação da atividade agropecuária e extrativista vegetal de forma a preservar os recursos naturais renováveis, o meio ambiente e a conservação do solo;

II - fiscalizar e controlar o sistema de armazenamento, abastecimento de produtos agropecuários e a comercialização de insumos agrícolas;

III - promover a criação de pólos agroindustriais e agrominerais, através de linhas de créditos especiais;

IV - estimular a comercialização entre produtores e consumidores;

V - compatibilizar a política agrícola e extrativista com a situação sócio- econômica e cultural do meio rural amapaense;

VI - facilitar a aquisição de insumo agrícola, priorizando os micro e pequenos produtores rurais;

VII - adotar mecanismos que garantam a adequação da pesquisa às peculiaridades rurais do Estado;

VIII - Criar sistema estadual de cadastramento e georreferenciado das propriedades e ocupações rurais, com a indicação do uso do solo. (incluído pela Emenda Constitucional nº 57, de 19.12.2017)

**Art. 214.** Os órgãos públicos responsáveis pela pesquisa no Estado farão a indicação, obedecendo ao zoneamento agroecológico, das áreas potenciais para implantação de projetos de desenvolvimento agropecuário e florestal.

**Art. 214.** Os órgãos públicos responsáveis pelas políticas agrária, fundiária e florestal no Estado farão a indicação, obedecendo ao zoneamento agroecológico, das áreas potenciais para implantação de projetos de desenvolvimento agropecuário e florestal. (redação dada pela Emenda Constitucional nº 42, de 30.06.2009)

**Art. 215.** O Estado desenvolverá planos de valorização e aproveitamento de seus recursos fundiários, a fim de:

I - promover a efetiva exploração agrossilvopastoril nas terras que se encontrem ociosas, subaproveitadas ou aproveitadas inadequadamente;

II - criar oportunidade de trabalho e de progresso social e econômico para o trabalho rural;

III - melhorar as condições de vida e a fixação do homem na zona rural;

IV - implantar a justiça social.

**Art. 216.** É vedado ao Estado, sem prévia autorização do Poder Legislativo, resguardando o disposto na Constituição Federal:

**Parágrafo único.** Promover a legitimação ou/ alienação de terras públicas ou devolutas para fins de reflorestamento homogêneo.

**Art. 216.** É vedado ao Estado, sem prévia autorização do órgão competente da Assembleia Legislativa, resguardado o disposto na Constituição Federal: (redação dada pela Emenda Constitucional nº 42, de 30.06.2009)

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 103

I - promover a alienação ou concessão de terras públicas e devolutas, com áreas superiores a 15 módulos fiscais; observado o limite máximo de dois mil e quinhentos hectares; (redação dada pela Emenda Constitucional nº 42, de 30.06.2009)

II - promover a legitimação, alienação ou concessão de terras públicas e devolutas para fins de reflorestamento homogêneo e manejo florestal. (redação dada pela

Emenda Constitucional nº 42, de 30.06.2009)

**Art. 216.** É vedado ao Estado, sem prévia autorização do órgão competente da Assembleia Legislativa, resguardando o disposto na Constituição Federal, a alienação ou concessão de terras públicas e devolutas, com áreas superiores a quinze módulos fiscais, observado o limite máximo de dois mil e quinhentos hectares. (redação dada pela Emenda Constitucional nº 43, de 30.11.2009)

**Parágrafo único.** A vedação prevista no caput deste artigo refere-se, inclusive, à alienação ou concessão para fins de reflorestamento homogêneo ou de manejo floresta. (redação dada pela Emenda Constitucional nº 43, de 30.11.2009) (revogado pela

Emenda Constitucional nº 57, de 19.12.2017)

**Art. 217.** Os projetos técnicos de assentamento de trabalhadores rurais serão elaborados pela administração pública, juntamente com os beneficiários e as entidades representativas das classes envolvidas.

**§ 1º** O Estado outorgará títulos de concessão de direito real de uso aos beneficiários dos projetos de assentamento de trabalhador rural, nos quais constarão as seguintes condições:

I - exploração de terra, direta, pessoal, familiar, associativa, ou cooperativa, ou com os demais membros do assentamento, para o cultivo ou quaisquer outros de exploração que atendam ao planejamento da política agrária, sob pena de reversão ao outorgante;

II - domicílio e residência do beneficiário na área do assentamento;

III - indivisibilidade e intransferibilidade do direito, a qualquer título, sem autorização do outorgante;

IV - manutenção das áreas de preservação e conservação obrigatórias e a observância das restrições ao uso do imóvel, nos termos da lei.

**§ 2º** O título de concessão de direito real de uso será conferido a grupo de trabalhador rural, a homem ou mulher, ou a ambos, independentemente de estado civil, nos termos e condições previstos em lei.

**§ 2°** A concessão do direito real de uso ou título de domínio será conferido a grupo de trabalhador rural, a homem ou mulher, ou ambos, independentemente de estado civil, nos termos e condições previstos em lei. (redação dada pela Emenda Constitucional nº 57, de 19.12.2017)

**Art. 218.** O Estado, no limite de sua competência, poderá criar e manter reservas extrativistas em espaços territoriais considerados de interesse ecológico e social.

**§ 1º** São espaços territoriais de interesse ecológico e social as áreas que possuam características naturais ou exemplares da biota que possibilitem a sua exploração autossustentável sem prejuízo da conservação ambiental, na forma da lei estadual.

**§ 2º** A criação destas reservas dependerá de prévia demanda de populações extrativistas.

#### CAPÍTULO IV Da Política Pesqueira

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 104

**Art. 219.** O Estado elaborará política específica para o setor pesqueiro, tendo como fundamento e objetivo o desenvolvimento da pesca, dos pescadores, suas comunidades e da aquicultura.

**§ 1º** Na elaboração da política pesqueira, o Estado garantirá a efetiva participação dos pequenos piscicultores e pescadores artesanais ou profissionais, através de suas representações sindicais, cooperativas e organizações similares.

**§ 2º** Incumbe ao Estado criar mecanismos de proteção e preservação de áreas ocupadas pelas comunidades de pescadores, sua cultura e costumes, bem como as áreas de desova e do crescimento de espécies de peixes, crustáceos e quelônios.

**Art. 220.** É vedada e será reprimida na forma da lei, pelos órgãos públicos, com atribuições para fiscalizar e controlar as atividades pesqueiras, a pesca predatória sob qualquer de suas formas, tais como:

I - práticas que causem riscos às bacias hidrográficas e zonas costeiras do território do Estado;

II - emprego de técnicas e equipamentos que possam causar danos à capacidade de renovação dos recursos pesqueiros;

III - pesca industrial a menos de trinta milhas marítimas da costa estadual.

**Art. 221.** A assistência técnica e a extensão pesqueira compreenderão:

I - difusão de tecnologia adequada à conservação de recursos naturais e à melhoria de condições de vida do pequeno produtor pesqueiro e do pescador artesanal;

II - estímulo à associação e organização de pequenos produtores pesqueiros e dos pescadores artesanais ou profissionais;

III - integração da pesquisa pesqueira com as reais necessidades do setor produtivo.

#### CAPÍTULO V Dos Transportes

**Art. 222.** O transporte coletivo de passageiros é um serviço público essencial, incluído entre as atribuições do Poder Público, responsável por seu planejamento e normatização, que pode operá-lo diretamente ou mediante concessão ou permissão, obrigando-se a fornecê-lo com tarifa justa e digna qualidade de serviço:

I - segurança, higiene e conforto do usuário;

II - preservação do meio ambiente e do patrimônio arquitetônico e paisagístico;

III - estabelecimento, através da lei, de critérios de fixação, tarifas, e a obrigatoriedade de publicação das planilhas de cálculo, no órgão oficial, a cada fixação ou reajuste.

**§ 1º** O Estado e os Municípios, em regime de cooperação, criarão câmaras de compensação tarifária relativas ao transporte rodoviário de passageiros, nos termos da lei.

**§ 2º** O Poder Público, mediante autorização, concessão ou permissão, poderá entregar a execução do serviço de transporte de sua competência a empresas privadas, legalmente estabelecias no Estado, após regular processo licitatório e aprovação do respectivo Poder Legislativo, na forma da lei.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 105

**§ 3º** O transporte coletivo municipal e intermunicipal de passageiros, quando operado mediante concessão, deverá ser explorado por mais de uma empresa, vedada qualquer exclusividade ou monopólio.

**§ 4º** A empresa que deixar de cumprir com as cláusulas contratuais relativas à prestação desses serviços ficará impedida de participar de outras licitações para o mesmo fim.

**§ 5º** Comprovada a inviabilidade econômica da linha a ser explorada, o Poder Público deverá assumir diretamente a execução desse serviço.

**Art. 223.** São isentos de pagamentos de tarifas nos transportes coletivos urbanos, rodoviários e aquaviários municipais e intermunicipais:

I - criança até seis anos de idade;

II - idosos à partir de sessenta e cinco anos;

II - idosos a partir de sessenta; (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

III - deficientes físicos com reconhecida dificuldade de locomoção;

III - pessoas portadoras de deficiência física, auditiva, visual, mental e múltipla, devidamente reconhecidos e cadastrados pelo órgão governamental competente, na forma da lei; (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

IV - carteiros e vigilantes em serviço e devidamente uniformizados;

IV - carteiros, vigilantes, policiais civis, policiais militares e bombeiro militar em serviço e devidamente uniformizados; (redação dada pela Emenda Constitucional nº 23, de 18.01.2001)

IV - carteiros, vigilantes, policiais civis, policiais penais, policiais militares e bombeiro militar em serviço e devidamente uniformizados; (redação dada pela Emenda Constitucional nº 61, de 04.03.2020)

V - doadores de sangue regulares devidamente cadastrados no órgão competente do Estado.

**Art. 224.** O Estado garantirá o direito à meia passagem ao estudante de qualquer nível, nos transportes coletivos urbanos, rodoviários e aquaviários, municipais e intermunicipais, mediante lei.

**Art. 225.** O Estado, na forma da lei, adotará medidas para a implantação de um sistema integrado de transporte, rodoviário e aquaviário, em âmbito municipal, estadual e interestadual.

**Art. 226.** O Estado e os Municípios terão como meta prioritária a abertura e conservação de estradas vicinais.

#### CAPÍTULO VI Dos Recursos Naturais

##### SEÇÃO I Disposições Gerais

**Art. 227.** O Estado definirá, mediante a lei, a política hídrica e minerária estadual, protegendo seus interesses e os da população, inclusive interrompendo atividades predatórias, resguardando a soberania nacional no que concerne à pesquisa, à exploração, lavra e uso dos recursos naturais renováveis e não renováveis, disciplinando a conservação e o aproveitamento racional dos recursos hidrominerais.

**Art. 228.** Lei estadual disciplinará a responsabilidade das empresas de grande porte que explorem recursos naturais em território estadual, com vistas ao financiamento de ações e serviços que visem a compensar e atender ao aumento

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 106

significativo da demanda de infraestrutura social, sanitária, urbana e educacional decorrente de sua implantação.

**Art. 229.** O Estado participará do resultado da exploração dos recursos naturais no seu território e respectiva plataforma continental, mar territorial ou zona econômica exclusiva, nos termos da lei, e fiscalizará a compensação financeira decorrente dessa exploração, estabelecendo normas para a utilização dos recursos assim auferidos, resguardando o princípio da compensação social, na forma lei.

**Art. 230.** O Estado organizará e manterá serviços de geologia, hidrologia, meteorologia, estatística e cartografia em consonância com a legislação federal, e de monitoramento das atividades direta e indiretamente vinculados à mineração, de modo a permitir o registro, acompanhamento e fiscalização das concessões de direitos de pesquisa e exploração dos recursos minerais e hídricos em seu território.

##### SEÇÃO II Dos Recursos Hídricos

**Art. 231.** O Estado instituirá, por lei, sistema integrado de gerenciamento dos recursos hídricos, congregando os órgãos estaduais, municipais e a sociedade civil, e assegurará meios financeiros e institucionais para:

I - utilização racional das águas superficiais e subterrâneas e sua destinação prioritária para abastecimento às populações;

II - fomento à atividade de pesquisa e de desenvolvimento e difusão tecnológica do setor hídrico;

III - proteção das águas contra ações que possam comprometer o seu uso atual e futuro;

IV - a internalização dos efeitos positivos gerados pela exportação dos recursos hídricos do Estado, de forma a estimular geração de oportunidades de investimento, de empregos diretos e indiretos e efeitos que importem ampliação econômica para atender o mercado local;

V - o desenvolvimento do transporte hidroviário e seu aproveitamento econômico.

**Art. 232.** O Poder Público, por meio de sistema estadual de gerenciamento de recursos hídricos, observará, dentre outros, os seguintes preceitos:

I - adoção de bacia hidrográfica como base de gerenciamento e de classificação dos recursos hídricos;

II - zoneamento das áreas inundáveis com restrições e edificações;

III - condicionamento à aprovação prévia, por órgãos estaduais de controle ambiental e de gestão de recursos hídricos, os atos de outorga a terceiros, pelos Municípios, de direitos que possam influir na qualidade ou quantidade de águas superficiais ou subterrâneas.

**Art. 233.** Na articulação com a união, quando da exploração dos serviços e instalações de energia elétrica, e o aproveitamento energético dos cursos de água em seu território, o Estado levará em conta os usos múltiplos e o controle das águas, a drenagem, a correta utilização das várzeas, a flora e fauna aquáticas e a preservação do meio ambiente.

**Art. 234.** Nos projetos de produção de energia elétrica, será observada a preservação do patrimônio ambiental, cultural e turístico do Estado.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 107

**Art. 235.** Nos projetos de produção de qualquer tipo de energia elétrica será obrigatória a extensão de suas linhas de transmissão para abastecer consumidores dos Municípios contíguos ao projeto ou através dos quais passem suas linhas de transmissão.

**Art. 236.** A irrigação deverá ser desenvolvida em harmonia com a política de recursos hídricos e com os programas de conservação do solo e da água.

**Art. 237.** Constarão obrigatoriamente das Leis Orgânicas municipais disposições relativas ao uso, à conservação, à proteção e ao controle dos recursos hídricos superficiais e subterrâneos, no sentido de:

I - serem obrigatórias a conservação e a proteção das águas e a inclusão, nos planos diretores municipais, de áreas de preservação daquelas utilizáveis para abastecimento da produção;

II - serem conservados os ecossistemas aquáticos.

**Art. 238.** O Estado e os Municípios estabelecerão programas conjuntos visando ao tratamento de dejetos urbanos e industriais e de resíduos sólidos, à proteção e à utilização racional da água, assim como ao controle das inundações e da erosão.

##### SEÇÃO III Dos Recursos Minerais

**Art. 239.** Compete ao Estado:

I - Elaborar e propor o planejamento estratégico do conhecimento geológico de seu território, executando programa permanente de levantamentos geológicos básicos, no atendimento de necessidades do desenvolvimento econômico e social, em conformidade com a política estadual do meio ambiente;

II - garantir, às instituições públicas, o direito de fiscalização nos processos de extração e comercialização de minérios extraídos pelas empresas mineradoras instaladas no Estado;

III - fomentar atividade de pesquisa e de desenvolvimento e difusão tecnológica do setor mineral, de forma a definir estratégias de exploração mineral que contemplam os vários segmentos produtivos, inclusive atividades garimpeiras;

IV - dar apoio de assistência técnica permanente, na organização, implantação e operação da atividade garimpeira, priorizando o pequeno produtor, buscando promover melhores condições de exploração e transformação dos bens minerais, com acesso às novas tecnologias do setor, garantida a preservação do meio ambiente e a promoção econômico-social dos garimpeiros;

V - fomentar as atividades de mineração, de interesse sócio-econômico e financeiro para o Estado, em particular de cooperativa de pequenos mineradores, assegurados suprimentos de recursos minerais necessários ao atendimento da agricultura, da indústria de transformação e da construção civil e do Estado, da maneira estável e harmônica com as demais formas de ocupação do solo e atendimento à legislação ambiental;

VI - controlar os pagamentos de royalties ao Estado, pagos pela exploração mineral;

VII - delimitar áreas propícias à exploração mineral;

VIII - controlar e fiscalizar a preservação do meio ambiente, a exploração de minérios, em especial no sentido de evitar sua evasão;

IX - proporcionar atendimento técnico das ampliações e aplicações do conhecimento geológico às necessidades das prefeituras municipais.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 108

**Art. 240.** Adotará ainda o Estado:

I - plano estratégico baseado no conhecimento geológico de seu território;

II - mecanismos de incentivos e fomento às atividades de garimpagem, quando realizadas em nível de cooperativas;

III - a internalização dos efeitos positivos gerados pela exploração dos recursos minerais no âmbito de seu território, de forma a fomentar a difusão tecnológica do setor mineral;

**Art. 241.** Será criado e disciplinado, através de lei, um conselho consultivo especial, para o acompanhamento, avaliação, controle e fiscalização de todas as atividades relacionadas à mineração, recursos hídricos e energéticos, que contará com a participação de representantes do Poder Legislativo, Executivo e entidades civis organizadas.

#### CAPÍTULO VII Da Indústria e Comércio

**Art. 242.** A indústria e o comércio no âmbito estadual obedecerão e atenderão aos princípios estabelecidos pela Constituição Federal e mais aos seguintes:

I - livre concorrência;

II - defesa do meio ambiente;

III - prioridade à mão-de-obra local, visando à busca da planificação e do pleno emprego.

**Art. 243.** É garantida a todos a comercialização e a industrialização de quaisquer mercadorias ou serviços lícitos, observado o que dispõe a Constituição Federal.

**Art. 244.** O Estado e os Municípios concederão especial proteção às microempresas e às empresas de pequeno porte, assim definidas em lei, que receberão tratamento jurídico diferenciado, visando o incentivo de sua criação, preservação e desenvolvimento, através da eliminação, redução ou simplificação, conforme o caso, de suas obrigações administrativas, tributárias, creditícias e previdenciárias, nos termos da lei.

**§ 1º** O Estado apoiará e incentivará, também, as empresas produtoras de bens e serviços instaladas, com sede e domicílio fiscal em seu território.

**§ 2º** O serviço de apoio e assistência técnica às microempresas e às de pequeno porte será executado pelo órgão a nível estadual, responsável pela política de apoio.

#### CAPÍTULO VIII Da Defesa do Consumidor

**Art. 245.** O Estado promoverá, de acordo com o disposto na Constituição Federal, ação sistemática de defesa do consumidor de modo a garantir-lhe a segurança, a saúde e a defesa de seus interesses.

**Art. 246.** A política econômica de consumo será planejada e executada pelo Poder Público, com a participação de empresários e trabalhadores de todos os setores da economia e, inclusive, da sociedade civil organizada.

**Art. 247.** A política econômica de consumo observará os seguintes princípios:

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 109

I - implementação do sistema estadual da defesa do consumidor;

II - incentivo às cooperativas e outras formas de associativismo de consumo;

III - criação de mecanismos que possibilitem ao consumidor o exercício do direito à informação, à escolha e à defesa de seus interesses, sua segurança e sua saúde;

IV - elaboração de estudos econômicos e sociais de mercados consumidores, estabelecendo sistema de planejamento, acompanhamento e orientação;

V - atendimento e orientação ao consumidor, com atribuições e funcionamento definidos em lei.

**Art. 248.** O Estado e os Municípios garantirão o padrão de qualidade dos produtos disponíveis ao consumo da população, mediante fiscalização rigorosa dos estabelecimentos comerciais e industriais.

**Art. 249.** Os comerciantes fornecerão, obrigatoriamente, nota fiscal discriminando os tributos incidentes sobre os produtos comercializados, observadas as disposições da lei federal.

#### CAPÍTULO IX Do Turismo

**Art. 250.** O Estado apoiará e incentivará o turismo como atividade econômica e como fator de desenvolvimento social e cultural.

**Art. 251.** O Estado, juntamente com a iniciativa privada, definirá através de lei, a política estadual de turismo, observadas as seguintes diretrizes e ações:

I - plano integrado e permanente de acordo com o princípio da regionalização, objetivando o pleno desenvolvimento do turismo;

II - estímulo ao turismo, mediante benefícios fiscais;

III - apoio a programa de divulgação e orientação do turismo regional e a implantação de projetos turísticos nos Municípios;

IV - promoção de eventos turísticos;

V - proteção do patrimônio turístico, ecológico e histórico-cultural;

VI - demarcação das áreas de especial interesse turístico;

VII - investimento na formação e aperfeiçoamento de mão-de-obra especializada em turismo.

### TÍTULO VIII Da Ordem Social

#### CAPÍTULO I Disposição Geral

**Art. 252.** A ordem social tem como base o primado do trabalho e como objetivo o bem-estar e a justiça social.

#### CAPÍTULO II Da Seguridade Social

##### SEÇÃO I Disposições Gerais

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 110

**Art. 253.** O Estado, em ação conjunta e integrada com a União, Município e a sociedade, assegurará os direitos relativos à saúde, alimentação, à educação, ao lazer, à profissionalização, à capacidade para o trabalho, à cultura e cuidará da proteção especial da família, da mulher, da criança, do adolescente, do idoso, do índio e do deficiente.

**§ 1º** As receitas do Estado e dos Municípios destinadas à seguridade social constarão dos respectivos orçamentos.

**§ 2º** Nenhuma prestação de benefício ou serviço de seguridade poderá ser criada, majorada ou estendida sem a correspondente fonte de custeio total.

**§ 3º** As contribuições sociais só poderão ser exigidas após decorridos noventa dias da data da publicação da lei que as houver instituído ou modificado, não se lhes aplicando o princípio da anualidade.

**§ 4º** A proposta de orçamento, no tocante à seguridade social, será elaborada de forma integrada pelos órgãos responsáveis pela saúde e previdência social, tendo em vista as metas e prioridades estabelecidas na lei de diretrizes orçamentárias, assegurada a cada área a gestão de seus recursos.

**Art. 253.** A seguridade social compreende um conjunto integrado de ações de iniciativa dos Poderes Públicos e da sociedade, destinadas a assegurar os direitos relativos à saúde, à previdência e à assistência social, competindo ao Poder Público, nos termos da lei, organizá-la com base nos objetivos estabelecidos no

parágrafo único do art. 194, da Constituição Federal. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

**Parágrafo único.** O financiamento da seguridade social no âmbito do Estado do Amapá se dará com observância, no que couber, do disposto no art. 195 e seus parágrafos da Constituição Federal. (incluído pela Emenda Constitucional nº 35, de 21.03.2006)

**Art. 254.** Cabe ao Estado garantir a coordenação e execução de uma política social que assegure:

I - a universalidade da cobertura e do atendimento;

II - a uniformidade e equivalência dos benefícios e serviços às populações urbanas e rurais;

III - a participação organizada da sociedade civil na definição e execução dos objetivos, permitindo que os segmentos interessados tenham participação nos programas sociais.

##### SEÇÃO II Da Saúde

**Art. 255.** A saúde é direito de todos e dever do Estado, garantido mediante políticas sociais e econômicas que visem à prevenção, redução e eliminação de doenças e de outros agravos e ao acesso universal e igualitário às ações e serviços de saúde para a sua promoção, proteção e recuperação.

**Parágrafo único.** Ao Estado, como integrante do sistema único de saúde, compete implementar ações destinadas a cumprir as atribuições referidas no

art. 200 da Constituição Federal.

**Parágrafo único.** Ao Estado, como integrante do sistema único de saúde, compete implementar ações destinadas a cumprir as atribuições referidas no

art. 200 da Constituição Federal assim como, nos termos da lei: (redação dada pela

Emenda Constitucional nº 35, de 21.03.2006)

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 111

I - controlar e fiscalizar, através de profissionais especializados, qualquer atividade e serviço que comporte risco à saúde, à segurança ou ao bem-estar físico e psíquico do indivíduo e da coletividade, bem como ao meio ambiente; (incluído pela

Emenda Constitucional nº 35, de 21.03.2006)

II - fomentar a pesquisa, o ensino, a produção científica e o aprimoramento tecnológico e de recursos humanos no desenvolvimento das áreas de saúde, prevenção de acidentes e meio ambiente; (incluído pela Emenda Constitucional nº 35, de 21.03.2006)

III - estimular a formação da consciência pública voltada à preservação da saúde e do meio ambiente; (incluído pela Emenda Constitucional nº 35, de 21.03.2006)

IV - promover e fiscalizar ações em benefício da saúde integral do trabalhador urbano e rural. (incluído pela Emenda Constitucional nº 35, de 21.03.2006)

**Art. 256.** As ações e serviços de saúde são de relevância pública, cabendo ao Poder Público dispor, nos termos da lei, sobre sua regulamentação, fiscalização e controle, devendo sua execução ser feita, preferencialmente, através de serviços oficiais e, supletivamente, através de serviços de terceiros, pessoas físicas ou jurídicas de direito privado.

**Parágrafo único.** A redução dos riscos decorrentes do trabalho pressupõe a adoção de medidas de iniciativa do empregador, nas esferas pública e privada, com participação do trabalhador e da sociedade, cabendo, em especial aos órgãos e entidades integrantes do sistema único de saúde, promover ações e serviços que visem à promoção e à proteção da saúde do trabalhador. (incluído pela Emenda Constitucional nº 35, de 21.03.2006)

**Art. 257.** O sistema único de saúde do Estado contará, sem prejuízo das funções do Poder Legislativo, com as seguintes instâncias colegiadas:

I - a Conferência Estadual de Saúde;

II - o Conselho Estadual de Saúde.

**§ 1º** A Conferência Estadual de Saúde reunir-se-á a cada quatro anos com a representação dos vários segmentos sociais, com o objetivo de avaliar a situação de saúde e propor as diretrizes para a formulação da política estadual de saúde, convocada pelo Poder Executivo ou, extraordinariamente, por este ou pelo Conselho Estadual de Saúde, sempre que necessário.

**§ 2º** O Conselho Estadual de Saúde, em caráter permanente e deliberativo, órgão colegiado composto por representantes do Poder Público, prestadores de serviços, profissionais de saúde e usuários, atua na formulação de estratégias e no controle da execução da política estadual de saúde, inclusive nos aspectos econômicos e financeiros, cujas decisões serão homologadas pelo Chefe do Poder Executivo estadual.

**§ 3º** A representação dos usuários no Conselho e Conferência Estadual de Saúde será paritária em relação ao conjunto dos demais segmentos.

**§ 4º** Lei Estadual estabelecerá a composição e atribuições do Conselho e da Conferência Estadual de Saúde.

**Art. 258.** Compete ao Estado e aos municípios o controle, avaliação e a gerência dos recursos a ele destinados, bem como a execução básica de vigilância sanitária, epidemiológica e endêmica no âmbito de seu território.

**Parágrafo único.** Aos residentes no Estado é assegurada a assistência farmacêutica básica, promovida pelo Poder Público.

**Art. 259.** As ações e serviços públicos de saúde integram uma rede regionalizada e hierarquizada e constituem um sistema estadual de saúde, que será organizado e regulamentado em lei estadual.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 112

**Art. 259.** As ações e serviços públicos de saúde integram uma rede regionalizada e hierarquizada e constituem um sistema único, organizado e regulamentado em lei estadual, de acordo com as seguintes diretrizes: (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

I - descentralização, com direção única em cada esfera de governo; (incluído pela Emenda Constitucional nº 35, de 21.03.2006)

II - atendimento integral, com prioridade para as atividades preventivas, sem prejuízo dos serviços assistenciais; (incluído pela Emenda Constitucional nº 35, de 21.03.2006)

III - participação da comunidade. (incluído pela Emenda Constitucional nº 35, de 21.03.2006)

**§ 1º** Fica assegurado a todos o atendimento médico emergencial, nos estabelecimentos de saúde públicos ou privados.

**§ 2º** Fica proibido o uso de atestado de esterilidade e de teste de gravidez como condição para admissão ou continuidade no trabalho.

**§ 2º** Fica proibida a exigência de atestado de esterilidade, de teste de gravidez, e de qualquer outra que possua a mesma natureza destas, como condição para admissão ou continuidade no trabalho. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

**§ 3º** Os gestores locais do sistema único de saúde poderão admitir enfermeiros, técnicos de enfermagem, auxiliares de enfermagem, agentes comunitários de saúde, agentes de combate às endemias e atendente de consultório dentário por meio de processo seletivo público, de acordo com a natureza e complexidade de suas atribuições e requisitos específicos para sua atuação. (incluído pela Emenda Constitucional nº 36, de 08.08.2006)

**§ 4º** Aplica-se aos agentes comunitários de saúde e agentes de combate às endemias o disposto na Lei Federal nº. 10.507, de 10 de junho de 2002, e Lei Estadual disporá sobre o regimento jurídico e a regulamentação das atividades de agente comunitário de saúde e agente de combate às endemias. (incluído pela Emenda Constitucional nº 36, de 08.08.2006)

**§ 5º** Aplica-se a todos os profissionais enumerados no § 4º o disposto no

art. 49. (incluído pela Emenda Constitucional nº 36, de 08.08.2006)

**Art. 260.** A exploração dos serviços de assistência à saúde é livre à iniciativa privada.

**§ 1º** As instituições privadas poderão participar, de forma complementar, do sistema estadual de saúde, segundo diretrizes deste, mediante contrato de direito público ou convênio, tendo preferência as entidades filantrópicas e as sem fins lucrativos.

**§ 2º** São vedados quaisquer incentivos fiscais e a destinação de recursos públicos para auxílio ou subvenção a instituições privadas com fins lucrativos.

**Art. 261.** O Estado incentivará e auxiliará os órgãos públicos e entidades filantrópicas de estudos e pesquisas científicas nas áreas de saúde, constituídas na forma de lei, respeitando a sua autonomia e independência de atuação científica.

**Art. 262.** As entidades de classes atuarão em conjunto com o Poder Público no controle do ambiente de trabalho, visando à proteção da saúde do trabalhador.

**Art. 263.** O Estado elaborará o Plano Estadual de Saúde de duração plurianual, visando à articulação e desenvolvimento da saúde em diversos níveis e a integração das ações do Poder Público federal e municipal.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 113

**Parágrafo único.** Mediante lei será instituído o Código Sanitário Estadual, o qual normatizará o processo de fiscalização, acompanhamento e promoção da saúde no Estado. (incluído pela Emenda Constitucional nº 35, de 21.03.2006)

**Art. 264.** Compete ao Estado fiscalizar e inspecionar alimentos, inclusive o controle de seu teor nutricional, e bem como bebidas e águas destinadas ao consumo humano.

**Art. 265.** O Estado dotará os serviços de saúde de meios adequados ao atendimento da saúde da mulher, do deficiente físico ou mental, do idoso, da criança e do adolescente.

**Parágrafo único.** A rede pública de saúde prestará atendimento médico para prática de aborto, nos casos previstos em lei federal, bem como para realização de cirurgia reparadora em vítimas de mutilação decorrente de câncer de mama e de violência. (incluído pela Emenda Constitucional nº 35, de 21.03.2006)

**Art. 266.** Os recursos destinados à saúde pelo Estado e Municípios serão definidos em suas respectivas leis orçamentárias.

**Art. 266.** Os recursos destinados à saúde pelo Estado e Municípios serão definidos em suas respectivas leis orçamentárias, anualmente, e aplicarão anualmente em ações e serviços públicos de saúde, no mínimo, 15% (quinze por cento) da arrecadação dos impostos a que se refere o art. 156 e dos recursos de que tratam o art. 158 e a alínea “b” do inciso I do caput e o § 3º do art. 159, todos da Constituição Federal. (redação dada pela Emenda Constitucional nº 52, de 24.08.2015)

**§ 1º** Para fins de apuração da aplicação dos recursos mínimos estabelecidos, considerar-se-ão como despesas com ações e serviços públicos de saúde no Estado aquelas voltadas para a promoção, proteção e recuperação da saúde que atendam, simultaneamente, aos princípios estatuídos no art. 7o da Lei no 8.080, de 19 de setembro de 1990, e às seguintes diretrizes: (incluído pela Emenda Constitucional nº 52, de 24.08.2015)

I - sejam destinadas às ações e serviços públicos de saúde de acesso universal, igualitário e gratuito; (incluído pela Emenda Constitucional nº 52, de 24.08.2015)

II - estejam em conformidade com objetivos e metas explicitados nos Planos de Saúde do Estado; e (incluído pela Emenda Constitucional nº 52, de 24.08.2015)

III - sejam de responsabilidade específica do setor da saúde, não se aplicando a despesas relacionadas a outras políticas públicas que atuam sobre determinantes sociais e econômicos, ainda que incidentes sobre as condições de saúde da população. (incluído pela Emenda Constitucional nº 52, de 24.08.2015)

**§ 2º** Além de atender aos critérios estabelecidos no caput, as despesas com ações e serviços públicos de saúde realizadas pelo Estado, e pelos Municípios deverão ser financiadas com recursos movimentados por meio dos respectivos fundos Estaduais e Municipais de saúde. (incluído pela Emenda Constitucional nº 52, de 24.08.2015)

I - vigilância em saúde, incluindo a epidemiológica e a sanitária; (incluído pela Emenda Constitucional nº 52, de 24.08.2015)

II - atenção integral e universal à saúde em todos os níveis de complexidade, incluindo assistência terapêutica e recuperação de deficiências nutricionais; (incluído pela Emenda Constitucional nº 52, de 24.08.2015)

III - capacitação do pessoal de saúde do Sistema Único de Saúde (SUS); (incluído pela Emenda Constitucional nº 52, de 24.08.2015)

IV - desenvolvimento científico e tecnológico e controle de qualidade promovidos por instituições do SUS; (incluído pela Emenda Constitucional nº 52, de 24.08.2015)

V - produção, aquisição e distribuição de insumos específicos dos serviços de saúde do SUS, tais como: imunobiológicos, sangue e hemoderivados,

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 114

medicamentos e equipamentos médico-odontológicos; (incluído pela Emenda Constitucional nº 52, de 24.08.2015)

VI - saneamento básico de domicílios ou de pequenas comunidades, desde que seja aprovado pelo Conselho de Saúde do ente da Federação financiador da ação e esteja de acordo com as diretrizes das demais determinações previstas nesta Constituição; (incluído pela Emenda Constitucional nº 52, de 24.08.2015)

VII - saneamento básico dos distritos sanitários especiais indígenas e de comunidades remanescentes de quilombos; (incluído pela Emenda Constitucional nº 52, de 24.08.2015)

VIII - manejo ambiental vinculado diretamente ao controle de vetores de doenças; (incluído pela Emenda Constitucional nº 52, de 24.08.2015)

IX - investimento na rede física do SUS, incluindo a execução de obras de recuperação, reforma, ampliação e construção de estabelecimentos públicos de saúde; (incluído pela Emenda Constitucional nº 52, de 24.08.2015)

X - remuneração do pessoal ativo da área de saúde em atividade nas ações de que trata este artigo, incluindo os encargos sociais; (incluído pela Emenda Constitucional nº 52, de 24.08.2015)

XI - ações de apoio administrativo realizadas pelas instituições públicas do SUS e imprescindíveis à execução das ações e serviços públicos de saúde; e (incluído pela Emenda Constitucional nº 52, de 24.08.2015)

XII - gestão do sistema público de saúde e operação de unidades prestadoras de serviços públicos de saúde. (incluído pela Emenda Constitucional nº 52, de 24.08.2015)

**§ 3º** Não constituirão despesas com ações e serviços públicos de saúde, para fins de apuração dos percentuais mínimos de que trata o caput do artigo, aquelas decorrentes de: (incluído pela Emenda Constitucional nº 52, de 24.08.2015)

I - pagamento de aposentadorias e pensões, inclusive dos servidores da saúde; (incluído pela Emenda Constitucional nº 52, de 24.08.2015)

II - pessoal ativo da área de saúde quando em atividade alheia à referida área; (incluído pela Emenda Constitucional nº 52, de 24.08.2015)

III - assistência à saúde que não atenda ao princípio de acesso universal; (incluído pela Emenda Constitucional nº 52, de 24.08.2015)

IV - merenda escolar e outros programas de alimentação, ainda que executados em unidades do SUS, ressalvando-se o disposto no inciso II do art. 3o; (incluído pela Emenda Constitucional nº 52, de 24.08.2015)

V - saneamento básico, inclusive quanto às ações financiadas e mantidas com recursos provenientes de taxas, tarifas ou preços públicos instituídos para essa finalidade; (incluído pela Emenda Constitucional nº 52, de 24.08.2015)

VI - limpeza urbana e remoção de resíduos; (incluído pela Emenda Constitucional nº 52, de 24.08.2015)

VII - preservação e correção do meio ambiente, realizadas pelos órgãos de meio ambiente dos entes da Federação ou por entidades não governamentais; (incluído pela Emenda Constitucional nº 52, de 24.08.2015)

VIII - ações de assistência social; (incluído pela Emenda Constitucional nº 52, de 24.08.2015)

IX - obras de infraestrutura, ainda que realizadas para beneficiar direta ou indiretamente a rede de saúde; e (incluído pela Emenda Constitucional nº 52, de 24.08.2015)

X - ações e serviços públicos de saúde custeados com recursos distintos dos especificados na base de cálculo definida no caput do artigo ou vinculados a fundos específicos distintos daqueles da saúde”. (incluído pela Emenda Constitucional nº 52, de 24.08.2015)

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 115

**Art. 267.** A lei disporá sobre as condições e os requisitos que facilitem a remoção de órgãos, tecidos e substâncias humanas para fins de transplantes, pesquisas e tratamento, incluindo processamento e transfusão de sangue e hemoderivados, vedado qualquer tipo de comercialização.

**Art. 268.** O Estado viabilizará a implantação da política estadual de alimentação e nutrição, bem como o sistema de vigilância alimentar e nutricional, com o objetivo de controlar o estado nutricional da população.

**Parágrafo único.** A política prevista no caput deste artigo deverá ser observada na elaboração da lei que instituir a política relacionada aos setores produtivos do Estado.

##### SEÇÃO III Da Previdência Social

**Art. 269.** A previdência social será prestada pelo Estado e pelos Municípios aos seus servidores, família e dependentes, diretamente ou através de institutos de previdência, ou, ainda, mediante convênios e acordos, compreendendo, dentre outros, os seguintes benefícios, na forma da lei:

I - cobertura de eventos de doença, invalidez, morte, incluindo os resultados de acidentes do trabalho, velhice e reclusão;

II - ajuda à manutenção de dependente dos segurados de baixa renda;

III - proteção à maternidade, especialmente à gestante;

IV - pensão por morte do segurado, homem ou mulher, ao cônjuge ou companheiro e dependentes, obedecidas as disposições desta Constituição;

V - aposentadoria compulsória por invalidez permanente ou por tempo de serviço, aos setenta anos de idade;

VI - licença para tratamento de saúde, por motivo de doença em pessoa da família ou, ainda, por motivo de gestação.

**§ 1º** Todos os salários de contribuição considerados no cálculo de benefícios serão corrigidos monetariamente.

**§ 2º** A gratificação natalina dos aposentados e pensionistas terá por base o valor dos proventos do mês de dezembro de cada ano.

**§ 3º** Nenhum benefício que substitua o salário de contribuição ou o rendimento do trabalhador segurado terá valor mensal inferior ao salário mínimo.

**§ 4º** É vedada subvenção ou auxílio do Poder Público às entidades de previdência privada com fins lucrativos.

**§ 5º** Ao beneficiário de pensão decorrente da morte de servidor em serviço, no cumprimento do dever, ou em decorrência dele, são assegurados proventos equivalentes aos que faria jus o de cujus, se vivo fosse.

**Art. 269.** A previdência social será prestada pelo Estado e pelos Municípios aos servidores e seus dependentes, diretamente ou através de institutos de previdência, seja pelo regime próprio seja pelo regime geral, e atenderá, nos termos da lei, a: (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

I - cobertura dos eventos de doença, invalidez, morte e idade avançada; (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

II - proteção à maternidade, especialmente à gestante; (redação dada pela

Emenda Constitucional nº 35, de 21.03.2006)

III - salário-família e auxílio-reclusão para os dependentes dos segurados de baixa renda; (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

IV - pensão por morte do segurado, homem ou mulher, ao cônjuge ou companheiro e dependente, observado o disposto no § 1º. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 116

**§ 1º** Nenhum benefício que substitua o salário de contribuição ou o rendimento do trabalho do segurado terá valor mensal inferior ao salário mínimo. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

**§ 2º** Todos os salários de contribuição considerados para o cálculo de benefício serão devidamente atualizados, na forma da lei. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

**§ 3º** É assegurado o reajustamento dos benefícios para preservar-lhes, em caráter permanente, o valor real, conforme critérios definidos em lei. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

**§ 4º** É vedada a filiação ao regime geral de previdência social, na qualidade de segurado facultativo, de pessoa que participe do regime próprio de previdência. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

**§ 5º** A gratificação natalina dos aposentados e pensionistas terá por base o valor dos proventos do mês de dezembro de cada ano. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

**§ 6º** Para efeito de aposentadoria, é assegurada a contagem recíproca do tempo de contribuição na administração pública e na atividade privada, rural e urbana, hipótese em que os diversos regimes de previdência social se compensarão financeiramente, segundo critérios estabelecidos em lei. (incluído pela Emenda Constitucional nº 35, de 21.03.2006)

**Art. 270.** Aos Prefeitos e Vereadores é facultado o direito de serem contribuintes e segurados do Instituto de Previdência Social do Estado.

**Art. 270.** O regime de previdência complementar de que trata o art. 60, organizado de forma autônoma em relação ao regime próprio de previdência social, será facultativo, baseado na constituição de reservas que garantam o benefício contratado, e regulado por lei complementar. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

**§ 1º** A lei complementar de que trata este artigo assegurará ao participante de planos de benefícios de entidades de previdência privada o pleno acesso às informações relativas à gestão de seus respectivos planos. (incluído pela

Emenda Constitucional nº 35, de 21.03.2006)

**§ 2º** Observar-se-á quanto às contribuições, aos benefícios e às condições contratuais, bem como quanto ao aporte de recursos para as entidades de previdência privada, o disposto nos §§ 2º e 3º do art. 202 da Constituição Federal. (incluído pela Emenda Constitucional nº 35, de 21.03.2006)

**Art. 271.** Os servidores municipais poderão integrar o sistema previdenciário do Estado, quando no Município não existir sistema próprio de previdência.

**Art. 271.** Quando no Município não existir regime próprio de previdência, seus servidores ficarão vinculados ao regime geral de previdência social. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

##### SEÇÃO IV Da Assistência Social

**Art. 272.** O Estado e os Municípios, diretamente ou através do auxílio a entidades privadas de caráter assistencial, regularmente constituídas e sem fins lucrativos, prestarão assistência a quem dela necessitar, através de benefícios de prestação continuada, serviços sociais específicos e auxílios eventuais para acesso à renda mínima e atendimento às necessidades básicas do cidadão.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 117

**Parágrafo único.** Os auxílios às entidades referidas no caput deste artigo somente serão concedidos após o parecer favorável pelo órgão técnico do Poder Executivo.

**Art. 273.** A assistência social será prestada com os seguintes objetivos:

I - proteção à família, à natalidade, à infância, à adolescência e à velhice;

II - amparo às crianças, aos adolescentes e aos idosos carentes;

III - habilitação, reabilitação e amparo aos portadores de deficiência física e mental, bem como sua integração na sociedade;

IV - garantia de um salário mínimo de benefício mensal à pessoa portadora de invalidez para o trabalho e do idoso que comprove não possuir meios de prover a própria manutenção ou tê-la provida por sua família;

V - promoção da integração e ingresso ao mercado de trabalho dos assistidos;

VI - garantia de gratuidade no transportes coletivos urbanos aos portadores de perda total da acuidade visual;

VI - garantia de gratuidade nos transportes coletivos, urbanos e intermunicipais, aos portadores de perda total da acuidade visual, bem assim às pessoas incapacitadas de se locomoverem por si só, seja por deficiência física ou psicológica; (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

VII - acompanhamento e orientação aos superdotados e paranormais;

VIII - proteção, orientação e amparo ao migrante, facilitando sua adaptação;

IX - gratuidade dos serviços funerais aos comprovadamente carentes.

**Art. 274.** A população, alvo da assistência social, será todo o cidadão em situação de incapacidade ou impedimento, permanente ou temporário por motivos sociais, pessoais ou de calamidade pública, de prover a si e sua família ou ser por ela provido.

**Art. 275.** A assistência social, na esfera estadual, será implementada com recursos do Estado e de outras fontes, observando-se os seguintes princípios:

I - a descentralização administrativa, segundo a política de regionalização com a participação de entidades beneficentes e de assistência social;

II - a participação da população na elaboração, execução e controle das ações de assistência, através de entidades representativas;

III - prioridade no atendimento às necessidades sociais básicas do cidadão acima da rentabilidade econômica;

IV - universalização dos direitos sociais tornando a população alvo da assistência social alcançável pelas políticas sociais;

V - promoção e emancipação, do destinatário, objetivando sua independência da assistência social;

VI - o repasse da assistência social como um direito de cidadania, vedando-se qualquer comprovação vexatória de necessidade, bem como de relação clientelista e paternalista.

**Art. 276.** O Estado e os Municípios atuarão de forma integrada, compatibilizando programas e recursos, buscando evitar a duplicidade de atendimento.

**Art. 277.** O Estado é responsável pelos serviços de abrangência estadual ou regional, ou por programas, projetos ou atividades, que por seu custo, especialização ou grau de complexidade, não possam ser executados pelo Município.

**Art. 278.** Ao Estado incumbe criar órgãos e manter estabelecimentos especializados, com o objetivo de estudar os problemas relacionados com o menor

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 118

abandonado e carecedor de cuidados especiais, a fim de que lhe seja proporcionada a necessária proteção.

**Parágrafo único.** O Poder Público criará programas de atendimento e recuperação do menor infrator, com sua integração ao convívio social, sendo assegurada sua reabilitação por pessoas especializadas, em locais adequados.

#### CAPÍTULO III Da Educação

**Art. 279.** A educação, direito de todos e dever do Estado e da família, promovida e incentivada com a colaboração da sociedade, visa o pleno desenvolvimento da pessoa e a formação do cidadão; aprimoramento da democracia e dos direitos humanos; o respeito aos valores e ao primado do trabalho a afirmação do pluralismo cultural; a convivência solidária e serviço de uma sociedade justa, fraterna, livre e soberana.

**Parágrafo único.** O Poder Público estimulará o desenvolvimento de propostas educativas diferenciadas, com base em experiências pedagógicas, através de programas especiais, como também a capacitação e habilitação de recursos humanos para a educação.

**Art. 280.** As instituições educacionais de qualquer natureza ministrarão o ensino com base nos princípios estabelecidos na Constituição Federal e mais os seguintes:

I - direito de acesso e permanência na escola a qualquer pessoa, vedadas distinções baseadas na origem, raça, sexo, idade, religião, preferência política ou classe social;

II - pluralismo de idéias e de concepções filosóficas, políticas, estéticas, religiosas e pedagógicas, que conduzam o educando à formação de uma postura social própria;

III - valorização dos profissionais da educação, como garantia, na forma da lei, de plano de carreira para o magistério público, com vencimentos, no mínimo, em isonomia com as demais categorias funcionais para as quais se exija idêntica escolaridade, com ingresso exclusivamente por concurso público de provas e títulos, realizado periodicamente, sob o regime jurídico único adotado pelo Estado para seus servidores civis e com base no Estatuto do Magistério;

IV - liberdade de pensar, aprender, ensinar, pesquisar e divulgar o pensamento, a arte, o saber e o conhecimento;

V - reinvestimento em educação, no âmbito do Estado, do percentual que for estabelecido em lei, dos lucros auferidos pelas instituições privadas de ensino estabelecido no Amapá;

VI - gratuidade de ensino em estabelecimentos mantidos pelo Poder Público, vedada a cobrança de taxas ou contribuições, de qualquer natureza, ainda que facultativa;

VII - garantia de padrão de qualidade em todo o sistema de ensino a ser fixado em lei;

VIII - manutenção, no âmbito do Estado, em originais ou duplicatas arquivadas, por qualquer meio, em seus órgãos de consulta, dos resultados de pesquisa, bases de dados e acervos científicos, bibliográficos e tecnológicos colecionados no exercício de atividade educacional, revertendo em favor do Estado o material acumulado na hipótese de fechamento, extinção ou transferência da instituição de ensino aqui estabelecida;

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 119

IX - direito de organização autônoma dos diversos segmentos da comunidade escolar;

X - preservação dos valores educacionais regionais e locais.

**Art. 281.** O Estado e os Municípios prestarão assistência médica, odontológica e social ao educando pertencente à rede pública estadual e municipal, atendidos, prioritariamente, os estudantes da pré-escola e do ensino fundamental.

**Art. 282.** O Poder Público organizará o sistema estadual de ensino, abrangendo todos os níveis e modalidades, incluindo a especial, estabelecendo normas gerais de funcionamento para as escolas públicas estaduais e municipais, bem como para as particulares.

**§ 1º** Os Municípios organizarão seus sistemas de ensino de acordo com suas peculiaridades, observados os princípios estabelecidos nesta Constituição e na Constituição Federal.

**§ 2º** As escolas particulares estarão sujeitas a fiscalização, controle e avaliação, na forma da lei.

**§ 3º** Será prioritário o atendimento à escolaridade obrigatória.

**§ 4º** Será responsabilidade progressiva do Município o atendimento em creches, pré-escolares e ensino fundamental.

**§ 5º** Serão desenvolvidos pelo Estado programas suplementares de material didático-escolar, transporte, alimentação e assistência à saúde, financiados com recursos provenientes de contribuições sociais e outros previstos na lei orçamentária anual.

**§ 6º** Os programas previstos no parágrafo anterior serão desenvolvidos por profissionais habilitados, de nível médio e de nível superior das respectivas áreas.

**§ 7º** O Estado e os Municípios desenvolverão esforços para a atualização, capacitação e qualificação docente, visando à melhoria da qualidade do ensino e a gradual extinção do quadro de professores leigos.

**Art. 283.** É dever do Estado garantir:

I - o ensino fundamental, que será obrigatório e gratuito para todos e para os que a ele não tiverem acesso na idade própria, vedadas exigências que gerem despesas incompatíveis com a renda familiar do educando;

II - progressiva extensão de obrigatoriedade e gratuidade ao ensino médio;

III - atendimento educacional especializado ao portador de necessidades especiais e aos que revelarem vocação excepcional em qualquer ramo do conhecimento, preferencialmente na rede regular de ensino, com garantia de recursos humanos capacitados e material e equipamentos públicos adequados;

IV - apoiar, com recursos humanos, financeiros e materiais, as entidades especializadas, públicas e privadas, sem fins lucrativos para o atendimento ao portador de necessidades especiais;

V - o acesso a níveis mais elevados do ensino, da pesquisa e da criação artística, segundo a capacidade de cada um;

VI - a expansão da oferta de ensino noturno regular e de ensino supletivo, adequados às condições do educando;

VII - condições físicas adequadas para o funcionamento das escolas;

VIII - criação de sistema integrado de bibliotecas, para difusão de informações científicas e culturais;

IX - supervisão e orientação educacional nas escolas públicas, em todos os níveis e modalidades de ensino, exercidas por profissional habilitado;

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 120

X - profissionais da educação em número suficiente para atender à demanda escolar;

XI - a promoção, em toda a rede estadual de ensino fundamental, de exames preventivos de deficiência visual;

XII - prevenção dos aspectos humanísticos e profissionalizantes no ensino médio;

XIII - participação da comunidade, no processo educacional, na forma da lei;

XIV - a implantação do sistema Braille, como atendimento educacional especializado ao portador de deficiência visual;

XV - promoção da expansão da rede de estabelecimentos oficiais que oferecerão cursos gratuitos de ensino técnico-industrial, agrícola e comercial, observadas as peculiaridades regionais e as características dos grupos sociais;

XVI - oferecimento da infraestrutura necessária aos professores e profissionais da área de educação em escolas do interior;

XVII - expansão e manutenção da rede de estabelecimentos oficiais de ensino, com a dotação de infraestrutura física e equipamentos adequados para o atendimento ao menor carente ou infrator, bem como às pessoas portadoras de deficiência;

XVIII - com a colaboração técnica e financeira do Município, gratuidade nos transportes coletivos urbanos aos estudantes dos estabelecimentos de ensino situados nas sedes municipais, na forma estabelecida em lei complementar. (incluído pela Emenda Constitucional nº 32, de 23.03.2004)

**§ 1º** O acesso ao ensino obrigatório e gratuito é direito público subjetivo.

**§ 2º** O não oferecimento do ensino obrigatório pelo Poder Público ou sua oferta irregular importa responsabilidade da autoridade competente.

**§ 3º** Compete ao Poder Público recensear os educandos do ensino fundamental, fazer-lhes a chamada anual e zelar, junto aos pais ou responsáveis, pela sua frequência à escola.

**§ 4º** O ensino noturno será estruturado de maneira a salvaguardar as experiências práticas dos alunos e a assegurar-lhes condições escolares compatíveis com a situação do aluno trabalhador.

**§ 5º** O ensino religioso, de matrícula facultativa, constituirá disciplina dos horários normais das escolas públicas de ensino fundamental.

**§ 5º** O ensino religioso, de matrícula facultativa, é parte integrante da formação básica do cidadão e constitui disciplina dos horários normais das escolas públicas de ensino fundamental e médio, assegurado o respeito à diversidade cultural e religiosa do Amapá, vedadas quaisquer formas de proselitismo. (redação dada pela

Emenda Constitucional nº 35, de 21.03.2006)

**§ 6º** O ensino é livre à iniciativa privada, verificadas as seguintes condições:

I - observância das diretrizes e bases da educação nacional e da legislação concorrente a nível estadual;

II - comprovação da capacidade financeira e pedagógica;

III - autorização de funcionamento, mediante a supervisão e avaliação do Poder Público, obedecendo a critérios definidos na forma da lei.

**Art. 284.** A lei estabelecerá o plano estadual de educação plurianual e ajustamento anuais, de forma integrada, articulada e harmônica com o plano nacional de educação e com os planos municipais de educação e de acordo com a política estadual de educação, devendo conter, obrigatoriamente:

I - o programa de expansão da rede pública de ensino; CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 121

II - o programa de responsabilização progressiva do Município pelo ensino fundamental previsto para o período e a correspondente expansão do ensino médio;

III - medidas destinadas ao estabelecimento de modelo de ensino rural, que considerem a realidade estadual específica;

IV - medidas concernentes à valorização e capacitação técnica e profissional dos trabalhadores em educação;

V - medidas destinadas à erradicação do analfabetismo;

VI - melhoria da qualidade de ensino;

VII - formação para o trabalho;

VIII - universalização do atendimento escolar;

IX - promoção humanística, científica e tecnológica.

**§ 1º** Os planos de educação serão encaminhados para apreciação da Assembleia Legislativa, até o dia trinta e um de agosto do ano imediatamente anterior ao do início de sua execução.

**§ 2º** A não apresentação do plano estadual de educação, ou a não deliberação sobre ele, pela Assembleia Legislativa, importa responsabilidade da autoridade competente.

**§ 3º** O Estado publicará, anualmente, relatório da execução financeira da despesa em educação, por fonte de recursos e o remeterá à Assembleia Legislativa e ao Conselho Estadual de Educação, até trinta dias após o encerramento de cada semestre, discriminados os gastos mensais, em especial, os de reformas, manutenção e conservação das escolas, bem como as respectivas fontes.

**Art. 285.** O ensino será organizado em sistema estadual, constituído pelas instituições públicas ou privadas existentes no Estado, que prestem serviços continuados de instrução para a população, pelos órgãos colegiados, normativos, técnicos ou fiscalizadores e pelos órgãos do Poder Executivo encarregados de executar as políticas educacionais.

**§ 1º** Constitui base do sistema estadual hierarquizado e descentralizado de educação a rede pública regular de ensino custeada pelo Estado do Amapá e seus Municípios, para a qual reverterão todas as prioridades de ação em âmbito municipal e estadual.

**§ 2º** São órgãos normativos e fiscalizadores do sistema estadual de educação, nos termos da lei:

I - o Conselho Estadual de Educação, órgão consultivo, deliberativo e normativo da política estadual de educação, terá composição, estrutura administrativa, funcionamento e atribuições definidos em lei estadual;

II - os Conselhos Escolares, com gestão democrática, são órgãos de aconselhamento, fiscalização e avaliação do sistema de ensino, no nível de cada estabelecimento escolar público.

II - Os Conselhos Escolares, com gestão democrática, são órgãos de aconselhamento, fiscalização deliberação e avaliação do sistema de ensino, no nível de cada estabelecimento escolar público, na forma da lei. (redação dada pela Emenda Constitucional nº 4, de 1995)

**Art. 286.** Respeitado o conteúdo mínimo do ensino fundamental estabelecido pela União, o Estado lhe fixará conteúdo complementar, com o objetivo de assegurar a formação política e cultural regional.

**Parágrafo único.** No que se refere ao conteúdo complementar ou diversificado, é facultado ao Estado:

I - inserir, no currículo escolar, as matérias de:

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 122

a) História do Amapá;

b) Cultura do Amapá;

c) Educação Ambiental;

d) Estudos Amazônicos;

e) Técnica Agropecuária e Pesqueira.

II - promover os programas de:

a) Educação do Consumidor;

b) Educação Sexual;

c) Primeiros Socorros;

d) Noções de Estudos Constitucionais;

e) Educação para o Trânsito;

f) Educação para Prevenção contra o uso de Drogas;

g) Moral e ética; (incluída pela Emenda Constitucional nº 31, de 07.05.2003)

h) Direitos humanos. (incluída pela Emenda Constitucional nº 31, de 07.05.2003)

i) Noções básicas da Lei Maria da Penha. (incluída pela Emenda Constitucional nº 63, de 31.08.2021)

**Art. 287.** O ensino superior será desenvolvido com base na indissociabilidade entre ensino, pesquisa e extensão, tendo como objetivos gerais, a produção, difusão do conhecimento e a formação de recursos humanos para o mercado de trabalho.

**Art. 288.** A lei disciplinará as formas de apoio à manutenção e ao desenvolvimento do ensino que as empresas privadas deverão prestar, sempre que se beneficiarem:

**Art. 288.** A lei disciplinará as formas de apoio à manutenção e ao desenvolvimento do ensino que Pessoas Jurídicas de Direito Privado deverão prestar, sempre que se beneficiarem: (NR). (redação dada pela Emenda Constitucional n. 65, de 30.08.2022)

I - de programas estaduais de incentivos financeiros e fiscais;

II - de pesquisas e tecnologias por elas geradas com financiamento do Poder Público estadual.

**Art. 289.** O Estado e os Municípios aplicarão anualmente vinte e cinco por cento, no mínimo, da receita resultante de impostos, compreendida a proveniente de transferência, na manutenção e desenvolvimento do ensino público.

**Parágrafo único.** É vedado ao Estado auxiliar com recursos financeiros e humanos o Município que deixe de comprovar a aplicação do mínimo exigido da receita municipal na manutenção e desenvolvimento do ensino.

**Art. 289.** O Estado e os Municípios aplicarão, respectivamente, vinte e oito por cento e vinte e cinco por cento, no mínimo, da receita resultante de impostos, compreendida a proveniente de transferência, na manutenção e desenvolvimento do ensino público. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

**§ 1º** O Estado aplicará, do total da receita destinada ao ensino público, nunca menos de um e meio por cento em programas estaduais de erradicação do analfabetismo, com prioridade de atendimento às populações da zona rural. (incluído pela Emenda Constitucional nº 35, de 21.03.2006)

**§ 2º** A parcela da arrecadação de impostos transferida pelos Estados aos Municípios não é considerada, para efeito do cálculo previsto neste artigo, receita do governo que a transferir. (incluído pela Emenda Constitucional nº 35, de 21.03.2006)

**Art. 290.** O Estado garantirá a educação não diferenciada para o sexo masculino e feminino, eliminando do seu conteúdo práticas discriminatórias no material didático.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 123

**Art. 291.** O sistema de ensino do Estado poderá adotar calendário escolar adequado, diferenciado de acordo com as necessidades, peculiaridades e possibilidades de cada localidade ou comunidade onde a escola esteja sediada.

**§ 1º** O Estado e os Municípios apoiarão com recursos humanos, financeiros e materiais as Escolas Famílias, entidades de ensino privadas, sem fins lucrativos, criadas para dar atendimento e formação profissionalizante aos jovens agricultores. (incluído pela Emenda Constitucional nº 35, de 21.03.2006)

**§ 2º** Os alunos formados pelas Escolas Famílias terão prioridade, na forma da lei, na contratação, pelo Estado e pelos Municípios, para o serviço de assistência às comunidades agrícolas. (incluído pela Emenda Constitucional nº 35, de 21.03.2006)

#### CAPÍTULO IV Da Cultura

**Art. 292.** O Estado garantirá a todos o pleno exercício dos direitos culturais e o acesso às fontes de cultura nacional, estadual e municipal, protegendo, apoiando e incentivando a valorização e difusão das manifestações culturais, através:

I - da liberdade de criação, produção intelectual e artística, e do acesso a todas as fontes e formas de expressão cultural;

II - do incentivo à formação cultural e ao desenvolvimento da criatividade;

III - da proteção às expressões culturais populares e de grupos participantes do processo cultural;

IV - do acesso e da preservação do patrimônio cultural;

V - da concessão de incentivos fiscais às entidades que assumirem o patrocínio de atividades culturais;

VI - de legislação de proteção ao patrimônio cultural.

**Parágrafo único.** O Conselho Estadual de Cultura, incumbido de regulamentar, acompanhar e orientar a política cultural do Estado, bem como deliberar sobre ela, terá sua atribuição e composição definidas por lei.

**Art. 293.** Será assegurada a participação da sociedade civil, na forma da lei, na formulação da política estadual de cultura.

**Art. 294.** Os prédios, monumentos e bens públicos de interesse histórico-cultural, tombados na forma da lei, não poderão ser vendidos nem doados.

**Parágrafo único.** A cessão somente ocorrerá mediante autorização do órgão responsável pela política da conservação do patrimônio cultural.

**Art. 295.** Constituem o patrimônio cultural do Estado:

I - os bens materiais e imateriais tombados individualmente ou em conjunto, portadores de referências no que diz respeito à identidade, à ação ou à memória dos grupos que formam a sociedade;

II - as formas de expressão;

III - as criações artísticas, científicas e tecnológicas;

IV - as obras, objetos, documentos, edificações e demais espaços destinados a manifestações artístico-culturais;

V - os conjuntos urbanos e sítios de valor histórico, paisagístico, artístico, arqueológico, paleontológico, ecológico e científico.

#### CAPÍTULO V Da Ciência e da Tecnologia

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 124

**Art. 296.** O Estado promoverá e incentivará, por intermédio de uma política específica, o desenvolvimento científico e tecnológico, a pesquisa básica e aplicada, 0a autonomia e a capacitação tecnológica, e a ampla difusão dos conhecimentos, com a finalidade de melhorar a qualidade de vida da população, desenvolver o sistema produtivo, buscar solução dos problemas sociais e o progresso das ciências.

**§ 1º** A política estadual de ciência e tecnologia, considerando as peculiaridades regionais, adotará como princípios o respeito à vida e a saúde humana, o aproveitamento racional e não predatório dos recursos naturais, a preservação e a recuperação do meio ambiente, bem como o respeito aos valores culturais da população amapaense.

**§ 2º** A lei apoiará e estimulará as empresas que propiciem:

I - investimentos em pesquisas e criação de tecnologia adequada ao sistema produtivo regional;

II - investimento em formação e aperfeiçoamento de seus recursos humanos;

III - a pesquisa e a utilização de tecnologia;

IV - promoção e integração das pesquisas desenvolvidas no Estado, de modo a racionalizar a distribuição e a aplicação de recursos;

V - a permissão e o registro das atividades científicas no Estado, viabilizando o acompanhamento e a difusão sistemática, de modo que as pesquisas desenvolvidas com recursos ou administração do Estado tenham seus resultados divulgados, especialmente, à população que constitui objeto de investigação científica;

VI - a produção voltada para o mercado interno, em particular as dedicadas à produção de alimentos, com utilização de tecnologia indicada para a exploração dos recursos naturais e para a preservação do meio ambiente;

VII - a pesquisa tecnológica e o desenvolvimento experimental no âmbito da medicina preventiva e terapêutica publiquem e divulguem seus resultados e produzam equipamentos especializados destinados ao uso de portador de deficiência.

**§ 3º** As universidades e demais instituições de pesquisa sediadas no Estado devem participar do processo de formulação e acompanhamento da política científica e tecnológica.

**§ 3º** As universidades e demais instituições de pesquisa sediadas no Estado devem participar do processo de formulação e acompanhamento da política científica e tecnológica, competindo-lhes a criação de comitês de ética em pesquisa responsáveis pelo acompanhamento das ações desenvolvidas nesse campo. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

**§ 4º** É facultado ao Estado vincular parcela de sua receita orçamentária a entidades públicas de fomento ao ensino e à pesquisa científica e tecnológica.

**§ 5º** As instituições estrangeiras, com fins de pesquisa, só poderão se instalar em território amapaense com prévia autorização da Assembleia Legislativa.

**§ 6º** É defesa a saída do território do Estado, sem autorização prévia da Assembleia Legislativa, de produtos da fauna e da flora, bem como peças arqueológicas ou históricas do Amapá, para fins de pesquisa.

#### CAPÍTULO VI Do Desporto e do Lazer

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 125

**Art. 297.** O Estado apoiará e incentivará as práticas formais e não formais e as atividades de lazer, visando atender a todas as faixas etárias e classes sociais.

**Parágrafo único.** A lei disporá sobre a organização, composição e competência do Conselho Estadual de Desporto.

**Art. 298.** O Estado, utilizando a rede oficial de ensino em colaboração com entidades desportivas, garantirá, mediante lei, a promoção e o estímulo, a orientação e o apoio à difusão da educação e do desporto através de:

I - destinação de recursos públicos à promoção prioritária de desporto educacional e, em situações específicas, do desporto de alto rendimento;

II - tratamento diferenciado para o desporto amador e o profissional;

III - reserva obrigatória de áreas destinadas à praça e campos de esporte nos projetos de urbanização e de unidades escolares e no desenvolvimento de programas de construção de áreas para a prática de esporte comunitário;

IV - garantia de acesso à prática desportiva e ao lazer, mediante atendimento especializado, preferencialmente no âmbito escolar, a pessoas portadoras de deficiência;

V - construção e manutenção de espaços devidamente equipados para as práticas desportivas e o lazer.

#### CAPÍTULO VII Da Comunicação Social

**Art. 299.** A manifestação do pensamento, a criação, a expressão e a informação, sob qualquer forma, processo ou veículo, não sofrerão qualquer restrição, observado o disposto na Constituição Federal e nesta Constituição.

**§ 1º** É livre o acesso à informação jornalística, em qualquer veículo de comunicação social.

**§ 2º** É vedada toda e qualquer censura de natureza política, ideológica e artística.

**§ 3º** A publicação de veículo impresso de comunicação é independente de licença de autoridade.

**Art. 300.** Nenhuma lei ou ato do Poder Público poderá constituir embaraço à plena liberdade de informação jornalística em veículo de comunicação, observado o seguinte:

I - democratização do acesso às informações;

II - pluralismo e multiplicidade das fontes de informação;

III - visão pedagógica da comunicação dos órgãos e entidades públicas;

IV - liberdade e manifestação do pensamento;

V - o asseguramento do direito à resposta proporcional ao agravo, além de indenização por danos material, moral ou à imagem.

**Art. 301.** Na publicidade dos atos, programas, obras, serviços e campanhas por parte do Poder Público, não poderão constar nomes, símbolos ou imagens que caracterizem promoção pessoal.

**Art. 302.** A produção e a programação das emissoras de rádio e de televisão oficiais atenderão aos seguintes princípios:

I - preferência à finalidade educativa, artística, cultural e informativa;

II - erradicação do analfabetismo;

III - respeito aos valores éticos e sociais da pessoa e da família;

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 126

IV - educação rural, com vistas a difundir, aos produtores rurais, conhecimentos técnicos e científicos, além de informações gerais sobre financiamento, escoamento e armazenamento da produção agropecuária no Estado.

**Art. 303.** São vedadas as propagandas, as divulgações e as manifestações, sob qualquer forma, que atentem contra as minorias raciais, étnicas ou religiosas, bem assim a constituição e funcionamento de empresas ou organizações que visem ou exerçam aquelas práticas.

#### CAPÍTULO VIII Da Família, da Criança, do Adolescente, do Portador de Deficiência e do Idoso

**Art. 304.** Cabe ao Poder Público, bem como à família, assegurar a criança, ao adolescente, ao idoso, aos portadores de deficiências, com absoluta prioridade, o direito à vida, à saúde, à alimentação, à educação, ao lazer, à profissionalização, à dignidade, ao respeito, à liberdade e à convivência familiar e comunitária, além de colocá-los a salvo de toda forma de negligência, discriminação, exploração, violência, crueldade e agressão.

**§ 1º** O Estado, isoladamente ou em cooperação, manterá programas de assistência à família, com o objetivo de assegurar:

I - o livre exercício do planejamento familiar;

II - a orientação psicossocial às famílias de baixa renda;

III - a prevenção da violência no âmbito das relações familiares;

IV - o acolhimento, preferencialmente em casa especializada, de mulher, criança, adolescente e idoso, vítima de violência no âmbito da família ou fora dela;

V - extensão à mulher trabalhadora, mãe adotiva dos mesmos direitos concedidos à mãe biológica, na forma a ser regulamentada em lei.

**§ 2º** O Estado estimulará, mediante incentivos fiscais subsídios ações promocionais, nos termos da lei, o acolhimento ou guarda de criança ou adolescente órfão ou abandonado.

**§ 3º** O Estado destinará recursos à assistência materno-infantil.

**§ 4º** A prevenção da dependência de drogas e afins é dever do Estado, que prestará atendimento especializado à criança e ao adolescente, devolvendo ações que auxiliem na sua integração na comunidade, na forma da lei.

**§ 5º** A criança e o adolescente gozam de proteção especial, oportunidades e facilidades estabelecidas por lei ou por outros meios a fim de lhes facultar desenvolvimento físico, mental, moral, espiritual e social, de forma sadia, em condições de liberdade e dignidade.

**§ 6º** A criança e ao adolescente é garantida a prioridade receber proteção e socorro, em qualquer circunstância, e preferência no atendimento por órgão público de qualquer Poder.

**§ 7º** Os setores e áreas diretamente relacionados com a proteção à criança e ao adolescente serão aquinhoados de forma preferencial na aplicação de recursos públicos.

**§ 8º** Cabe ao Poder Público:

a) apoiar e estimular a criação das associações civis de defesa dos direitos da criança e do adolescente, para que funcionem como centros de estudos na busca permanente da garantia dos direitos dos mesmos, fiscalizando as ações programáticas a eles relativas;

b) priorizar e desenvolver programas especiais de atendimento à criança e ao adolescente em situação de risco pessoal e social;

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 127

c) priorizar o financiamento de programas institucionais destinados ao atendimento de crianças e adolescentes em meio aberto;

d) instituir sistemas de creches e pré-escolares, na forma da lei.

**§ 9º** Em caso de detenção de criança ou adolescente, a autoridade competente comunicará, imediatamente e urgentemente, a seus pais, pessoas ou entidades responsáveis, inclusive para atender ao disposto no art. 227, §3º, IV, V e VII, da Constituição Federal.

**§ 10** O Estado criará, mediante lei, o Centro Integrado de Atendimento à Infância e Adolescência – CEINFA, constituindo-se o mesmo em centro de referência para o atendimento de crianças e jovens dependentes químicos e portadores de deficiência mental ou qualquer outra necessidade especial. (incluído pela Emenda Constitucional nº 35, de 21.03.2006)

**Art. 305.** É garantida a toda e qualquer entidade ligada à defesa da criança e do adolescente, legalmente constituída, o livre acesso às instituições ou locais para onde os mesmos forem encaminhados pelos órgãos judiciários, de assistência social de segurança pública garantindo-se-lhes, igualmente, o livre acesso a dados, informações, inquéritos e processos a eles relativos.

**Art. 306.** O Estado assegurará condições de prevenção das deficiências físicas, sensorial e mental, com prioridade para a assistência pré-natal e à infância, e de integração social do portador de deficiência, em especial do adolescente, e a facilitação do acesso a bens e serviços coletivos, com eliminação de preconceitos e remoção de obstáculos arquitetônicos.

**Parágrafo único.** Para assegurar a implementação das medidas indicadas neste artigo, incumbe ao Poder Público.

I - estabelecer normas de construção e adaptação de logradouros e edifícios de uso público e de adaptação de veículos de transportes coletivos;

II - celebrar convênios com entidades profissionalizantes sem fins lucrativos, com vista à formação profissional e à preparação para o trabalho do deficiente;

III - instituição de escolas públicas para atendimento especializado aos deficientes físicos, mentais, sensoriais e superdotados;

IV - criar programas de assistência integral para deficiente mental não reabilitável e deficiente físico comprovadamente impossibilitado para o trabalho;

V - promover a formação dos policiais militares e demais servidores públicos responsáveis pela segurança do trânsito, para habilitação ao atendimento das necessidades do portador de deficiência;

VI - facilitar aos portadores de deficiência a aquisição de equipamentos que permitam a correção, a diminuição ou a superação de suas limitações.

**Art. 307.** O Estado e os Municípios reservarão vagas em seus respectivos quadros de pessoal para serem preenchidas por pessoas portadoras de deficiência.

**Art. 308.** O Estado promoverá condições que assegurem amparo à pessoa idosa no que diz respeito à sua dignidade e ao seu bem-estar.

**§ 1º** O amparo ao idoso será, quando possível, exercício no próprio lar.

**§ 2º** Para assegurar a integração do idoso na comunidade e na família, serão criados centros de amparo, de lazer e programas de preparação à aposentadoria, com a participação de instituições dedicadas a esta finalidade.

**Art. 309.** Lei estadual disporá sobre a criação, organização composição e competência do Conselho Estadual de Defesa da Criança e do Adolescente.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 128

#### CAPÍTULO IX Do Meio Ambiente

**Art. 310.** Todos têm direito ao meio ambiente ecologicamente equilibrado, bem de uso comum do povo e essencial à sadia qualidade de vida, impondo-se ao Poder Público e à Coletividade o dever de defendê-lo e preservá-lo para as presentes e futuras gerações.

**§ 1º** O Poder Executivo, através de seus órgãos executores das políticas ambientais, elaborará, anualmente, o relatório de qualidade ambiental do Estado do Amapá. (incluído pela Emenda Constitucional nº 38, de 05.06.2007)

**§ 2º** O relatório de qualidade ambiental refletirá quaisquer alterações naturais ou construídas ocorridas no período anterior, devendo ser apresentado até o fim do primeiro quadrimestre do ano subsequente. (incluído pela Emenda Constitucional nº 38, de 05.06.2007)

**Art. 311.** O Poder Público estadual realizará o zoneamento ecológico- econômico do Estado, de modo a compatibilizar o desenvolvimento com a preservação e a conservação do meio ambiente, bem como promoverá o levantamento e o monitoramento periódico da área geográfica estadual, de acordo com a tendência e desenvolvimento científico e tecnológico, de modo que o zoneamento ecológico-econômico esteja sempre atualizado, garantindo a conservação das amostras representativas dos ecossistemas.

**Art. 312.** A execução de obras, atividades industriais, processos produtivos e empreendimentos e a exploração de recursos naturais de qualquer espécie, quer pelo setor público, quer pelo setor privado, será admitida, se houver resguardo do meio ambiente ecologicamente equilibrado, ficando proibida a exploração desordenada e predatória das espécies frutíferas nativas do Estado.

**§ 1º** A liberação de licença ambiental, por órgão ou entidade governamental competente, integrante de sistema unificado para esse efeito, será feita com observância dos critérios fixados por lei, além de normas e padrões estabelecidos pelo Poder Público, e em conformidade com o planejamento e zoneamento ambientais.

**§ 2º** A licença ambiental, renovável na forma da lei, para execução e a exploração mencionada no caput deste artigo, quando potencialmente causadores de significativa degradação do meio ambiente, será sempre precedida da aprovação do estudo prévio de impacto ambiental e respectivo relatório, a que se dará prévia publicidade, garantida a realização de audiências públicas.

**§ 3º** O Poder Público estadual manterá um órgão da administração direta para execução da política do meio ambiente.

**Art. 313.** O Estado, mediante lei, criará um sistema de administração da qualidade ambiental, proteção e desenvolvimento do meio ambiente e uso adequado dos recursos naturais, para organizar, coordenar e integrar as ações de órgãos e entidades da administração pública direta e indireta, assegurada a participação da coletividade, com o fim de:

I - propor uma política estadual de proteção do meio ambiente;

II - promover a educação ambiental em todos os níveis de ensino e disseminar, na forma da lei, as informações necessárias à conscientização pública para a preservação do meio ambiente;

III - fiscalizar e zelar pela utilização racional e sustentada dos recursos naturais;

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 129

IV - assegurar a participação popular em todas as decisões relacionadas ao meio ambiente e o direito à informação sobre essa matéria;

V - proteger e restaurar a diversidade e a integridade do patrimônio genético, biológico, paisagístico, histórico e arquitetônico relativo ao meio ambiente;

VI - definir, implantar e administrar espaços territoriais e seus componentes representativos de todos os ecossistemas originais a serem protegidos, sendo a alteração e supressão, incluindo as já existentes, permitidas somente por lei;

VII - proteger e preservar a flora e a fauna, as espécies ameaçadas de extinção, as vulneráveis e raras, vedadas as práticas que submetem os animais à crueldade, por ação direta do homem sobre os mesmos;

VIII - estimular e promover o reflorestamento ecológico em áreas degradadas, objetivando especialmente a proteção de encostas e dos recursos hídricos, a consecução de índices mínimos de cobertura vegetal, o reflorestamento econômico em áreas ecologicamente adequadas, visando suprir a demanda de matéria-prima de origem florestal e a preservação das florestas nativas;

IX - assegurar, na forma da lei, o livre acesso às informações básicas sobre o meio ambiente;

X - prevenir e controlar a poluição, a erosão, assoreamento e outras formas de degradação ambiental;

XI - preservar os ecossistemas essenciais e promover o manejo ecológico de espécies;

XII - zelar pelas áreas de preservação dos corpos aquáticos, principalmente, as nascentes, inclusive os olhos d′água, cuja ocupação só se fará na forma da lei, mediante estudos de impactos ambientais.

**Art. 314.** A lei disporá sobre a organização, composição e competência do Conselho Estadual do Meio Ambiente.

**Art. 315.** As terras marginais dos cursos d′água são consideradas áreas de preservação permanente, proibido o seu desmatamento.

**Parágrafo único.** Cabe ao órgão estadual determinar a largura da faixa aos diferentes cursos d′água.

**Art. 316.** O Estado estimulará o plantio de culturas perenes como forma de reflorestamento através de isenção e crédito facilitado.

**Art. 317.** Aquele que explorar recursos naturais fica obrigado a recuperar o meio ambiente degradado, de acordo com a solução técnica exigida pelo órgão público competente.

**Art. 318.** As condutas e atividades lesivas ao meio ambiente sujeitarão os infratores a sanções administrativas, com aplicação de multas diárias e progressivas, na forma da lei e, nos casos de continuidade da infração ou reincidência, inclusive à redução do nível da atividade e a interdição, independentemente da obrigação de restaurar os danos causados.

**Art. 319.** A pesquisa, a experimentação, a produção, o armazenamento, a comercialização, o uso, o transporte, a importação, a exportação, o controle, a inspeção e a fiscalização de agrotóxicos, seus componentes e afins, no território amapaense, estão condicionados a prévio cadastramento dos mesmos nos órgãos estaduais responsáveis pelos setores da ciência e tecnologia, indústria e comércio, agricultura, transporte, saúde e meio ambiente, garantindo-se a obrigatoriedade da aplicação do receituário agronômico.

**Art. 320.** As indústrias poluentes só serão implantadas em áreas previamente delimitadas pelo Poder Público, respeitada a política de meio ambiente, e adotarão, obrigatoriamente, técnicas eficazes que evitem a contaminação ambiental.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 130

**Art. 321.** As pessoas físicas ou jurídicas, públicas ou privadas, que exercem atividades consideradas poluidoras ou potencialmente poluidores, serão obrigadas a promover a conservação ambiental, pela coleta, tratamento e disposição final dos resíduos por elas produzidos, cessando, com a entrega dos resíduos a eventuais adquirentes, quando tal for, devidamente, autorizado pelo órgão de controle ambiental imediatamente, a responsabilidade daquelas e iniciando-se, imediatamente, a destes.

**Art. 322.** As empresas públicas ou privadas que realizarem obras de usinas hidrelétricas, de formação de barragens ou outras quaisquer que determinem a submersão, exploração, consumo ou extinção de recursos naturais localizados em terras públicas ou devolutas, ainda que aforadas ou concedidas, ficarão obrigadas a indenizar o Estado na forma que a lei definir.

**Parágrafo único.** Ocorrendo necessidade de desapropriação, no caso das obras referidas neste artigo, o valor da indenização será pago pelas empresas interessadas nas obras.

**Art. 323.** São indisponíveis as terras devolutas, ou arrecadadas pelo Estado, necessárias às atividades de recreação pública e à instalação de parques e demais unidades de conservação, para proteção dos ecossistemas naturais.

**Art. 324.** Os Municípios poderão, mediante lei, instituir áreas de preservação ambiental, histórica ou paisagística.

**Art. 325.** É dever do Estado promover, através de seu órgão ambiental competente, a classificação dos seus principais cursos d′água.

**Art. 326.** A construção de centrais hidrelétricas dependerá de projeto técnico de impacto ambiental, com a participação do Conselho Estadual do Meio Ambiente e prévia aprovação da Assembleia Legislativa.

**Art. 327.** São proibidos, no território estadual:

I - a instalação de aterro sanitário, usina de reaproveitamento e depósito de lixo a menos de cinco quilômetros do perímetro urbano, de núcleos residenciais, do mar, das baías, dos lagos, dos rios e seus afluentes;

II - o lançamento de resíduos hospitalares, industriais e de esgotos residenciais, sem tratamento, diretamente em praias, rios, lagos e demais cursos d'água, devendo os expurgos e dejetos, após conveniente tratamento, sofrer controle e avaliação de órgãos técnicos governamentais, quanto aos teores de poluição;

III - a implantação e construção de indústrias que produzam resíduos poluentes, de qualquer natureza, em todo o litoral do Estado, compreendendo a faixa de terra que vai da preamar até cinco quilômetros para o interior.

**Art. 328.** São indisponíveis as terras na área territorial do Estado, para fins de construção de usinas nucleares, depósitos de materiais radioativos e lixos atômicos, na forma da lei. (declarado inconstitucional, em controle concentrado, pelo Supremo Tribunal Federal, no julgamento da ADI nº 6.902)

#### CAPÍTULO X Da Mulher

**Art. 329.** É dever do Estado:

I - garantir, perante a sociedade, a imagem social da mulher com dignidade como mãe, trabalhadora e cidadã, em plena igualdade de direitos e obrigações com o homem;

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 131

II - no cumprimento das funções essenciais à justiça, criar um centro de atendimento para assistência, apoio e orientação jurídica, no que tange às questões específicas de interesse da mulher;

III - criar condições para coibir qualquer forma de violência contra a mulher, em especial no lar e no trabalho;

IV - promover, anualmente, na primeira semana do mês de março, a Semana de Atendimento Integral à Saúde da Mulher; (incluído pela Emenda Constitucional nº 35, de 21.03.2006)

V - implantar a Ouvidoria da Mulher em âmbito estadual; (incluído pela

Emenda Constitucional nº 35, de 21.03.2006)

VI - estimular políticas de inclusão da mulher no mercado de trabalho. (incluído pela Emenda Constitucional nº 35, de 21.03.2006)

#### CAPÍTULO XI Dos Índios

**Art. 330.** O Estado e os Municípios promoverão e incentivarão a proteção aos índios e sua cultura, organização social, costumes, crenças, tradições, assim como reconhecerão seus direitos originários sobre as terras que tradicionalmente ocupam, outras que a União lhes reservar e aquelas de domínio próprio indígena.

**§ 1º** O Poder Público estabelecerá projetos especiais com vistas a respeitar e difundir a cultura indígena no patrimônio cultural do Estado.

**§ 2º** No atendimento às populações indígenas, as ações e serviços públicos, de qualquer natureza, devem integrar-se e adaptar-se às suas tradições, línguas e organização social.

**§ 3º** O Estado proporcionará às comunidades indígenas o ensino regular, na língua indígena original da comunidade e em português, devendo o órgão estadual da educação desenvolver programas de formação de professores indígenas bilíngues para o atendimento dessas comunidades.

**§ 4º** O Estado e os Municípios devem garantir a posse dos índios sobre as terras que tradicionalmente ocupam e o usufruto exclusivo deles sobre as riquezas do solo, dos rios e dos lagos nelas existentes.

**§ 5º** É vedada qualquer forma de deturpação externa da cultura indígena, violência às comunidades ou a seus membros, bem como sua utilização para fins de exploração.

**§ 6º** A participação da população indígena é essencial à formulação de conceitos políticos e na tomada de decisões sobre assuntos que lhe digam respeito, sendo instrumento básico desta participação as comunidades indígenas e suas organizações.

**§ 7º** O Ministério Público do Estado manterá promotor de justiça ou promotores de justiça especializados para a defesa dos direitos e interesses dos índios, suas comunidades e organizações existentes no território estadual.

**§ 8º** O aproveitamento dos recursos hídricos, incluídos os potenciais energéticos, a pesquisa e a lavra das riquezas minerais em terras indígenas só podem ser efetivadas com autorização do Congresso Nacional, ouvidas as comunidades afetadas, ficando-lhe assegurada participação nos resultados da lavra, na forma da lei.

**Art. 331.** A lei disporá sobre formas de proteção do meio ambiente nas áreas contíguas às reservas e às áreas tradicionalmente ocupadas por grupos indígenas, observado o disposto no art. 231 da Constituição Federal.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 132

**Art. 332.** O Estado promoverá a proteção da saúde indígena através de plano específico de saúde para essa área.

#### CAPÍTULO XII Dos Afro-Brasileiros (incluído pela Emenda Constitucional nº 35, de 21.03.2006)

**Art. 332-A.** Aos afro-brasileiros, assim definidos em lei, além dos direitos e garantias fundamentais consagrados pela Constituição Federal e por esta Constituição, é assegurado igualdade de oportunidade e tratamento em sua participação na vida econômica, social, política e cultural decorrente do desenvolvimento de políticas públicas no âmbito do Estado do Amapá, por meio de:

I - inclusão da dimensão racial nas políticas de desenvolvimento econômico e social;

II - adoção de medidas, programas e políticas de ação afirmativa;

III - modificação das estruturas institucionais do Estado para o adequado enfrentamento e superação das desigualdades decorrentes do preconceito e da discriminação racial;

IV - eliminação dos obstáculos históricos, socioculturais e institucionais que impedem a representação da diversidade racial nas esferas pública e privada;

V - estímulo e fortalecimento de iniciativas oriundas da sociedade civil direcionadas à promoção da igualdade de oportunidades e ao combate às desigualdades raciais, inclusive mediante a implementação de incentivos e critérios de condicionamento e prioridade no acesso aos recursos e contratos públicos;

VI - implementação de programas de ação afirmativa, destinados ao enfrentamento das desigualdades raciais em todos os níveis e setores das atividades pública e privada;

VII - criação do Conselho Estadual de Promoção da Igualdade Racial.

**Parágrafo único.** Os programas de ação afirmativa constituir-se-ão em imediatas iniciativas reparatórias, destinadas a promover a correção das distorções e desigualdades raciais decorrentes do processo de escravidão e das demais práticas discriminatórias adotadas durante todo o processo de formação social do Brasil e poderão utilizar-se da estipulação de cotas para consecução de seus objetivos.

#### CAPÍTULO XIII Dos Direitos Humanos (renumerado pela Emenda Constitucional nº 35, de 21.03.2006)

**Art. 333.** Os direitos humanos serão respeitados e exercitados de acordo com o art. 5º da Constituição Federal.

**Art. 334.** O Conselho Estadual dos Direitos Humanos terá a sua organização, composição e funcionamento regulados por lei, nele garantida a participação de representantes dos Poderes Legislativo, Executivo e Judiciário, do Ministério Público, do Conselho da Ordem dos Advogados do Brasil, Secção do Amapá, de associações representativas e entidades da sociedade civil organizada.

#### CAPÍTULO XIV Da Política Penitenciária (renumerado pela Emenda Constitucional nº 35, de 21.03.2006)

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 133

**Art. 335.** A política penitenciária do Estado tem como objetivo a reeducação e reintegração moral e social dos presos, devendo priorizar a manutenção das colônias penais agrícolas ou industriais com o objetivo de promover a escolarização ou profissionalização dos presos.

**§ 1º** A pena será cumprida em estabelecimentos distintos, de acordo com a natureza do delito, a idade e o sexo do apenado.

**§ 2º** Às presidiárias serão asseguradas condições para que possam permanecer com seus filhos durante o período de amamentação, devendo o estabelecimento prisional ter uma creche contígua, atendida por pessoal especializado, para menores até seis anos, garantido o acompanhamento da mãe.

**Art. 336.** A lei disporá sobre a organização, composição e competência do Conselho Estadual de Política Penitenciária.

**Art. 337.** Aos detidos, presos e condenados, ficam preservados todos os direitos não atingidos pela sentença ou pela lei, devendo ser alojados em estabelecimentos dotados de instalações salubres adequadas e que resguardem sua dignidade humana.

**Art. 338.** Será preservada a integridade física e moral dos presos, assegurando-se-lhes assistência médica, jurídica e espiritual, aprendizado profissionalizante, trabalho produtivo e remunerado, além de acesso aos dados relativos ao andamento dos processos de seu interesse e execução das respectivas penas.

#### CAPÍTULO XV Da Política de Justiça Social (incluído pela Emenda Constitucional n. 69, de 12.06.2024)

**Art. 338-A.** A política de justiça social tem como objetivo a diminuição da desigualdade social e econômica na sociedade, especialmente por meio da redução das taxas de pobreza e de desemprego no Estado. (incluído pela Emenda Constitucional n. 69, de 12.06.2024)

**Parágrafo único.** Para a apuração das taxas referidas no caput deste artigo, serão utilizadas preferencialmente estatísticas da Fundação Instituto Brasileiro de Geografia e Estatística (IBGE). (incluído pela Emenda Constitucional n. 69, de 12.06.2024)

**Art. 338-B.** Lei complementar disporá sobre a organização da política de justiça social, estabelecendo seus objetivos, metas e formas de avaliação periódica. (incluído pela Emenda Constitucional n. 69, de 12.06.2024)

**Parágrafo único.** São princípios norteadores à organização da política de justiça social: (incluído pela Emenda Constitucional n. 69, de 12.06.2024)

I - a geração de emprego e de renda; (incluído pela Emenda Constitucional n. 69, de 12.06.2024)

II - a emancipação econômica dos grupos minoritários; (incluído pela

Emenda Constitucional n. 69, de 12.06.2024)

III - a sustentabilidade fiscal do Estado; e (incluído pela Emenda Constitucional n. 69, de 12.06.2024)

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 134

IV - a tomada de decisão baseada em evidências. (incluído pela Emenda Constitucional n. 69, de 12.06.2024)

### TÍTULO IX Das Disposições Constitucionais Gerais

**Art. 339.** É vedada a alteração nominativa dos prédios públicos que contenham nomes de pessoas, fatos históricos ou geográficos, salvo para correção ou adequação aos termos da Lei.

**Art. 339.** É vedada a alteração nominativa de prédios públicos que contenham nomes de pessoas, fatos históricos ou geográficos, salvo com autorização legislativa. (Redação dada pela Emenda Constitucional nº 6, de 1996)

**Parágrafo único.** Esta proibição se estende à inscrição de símbolos ou nomes de autoridades ou administradores em placas indicadoras de obras.

**Art. 340.** Aos servidores da União que optarem pelo Governo do Estado do Amapá, ficam asseguradas as seguintes prerrogativas, a contar da data da opção:

I - a criação pelo governo estadual de quadro de pessoal específico, em extinção, para absorver os servidores optantes;

II - irredutibilidade de salários e níveis funcionais;

III - manutenção das vantagens fixas anexas à remuneração, adquiridas antes da opção.

**Art. 341.** O Estado promoverá a assistência a homens e mulheres internos e egressos do sistema penal, visando a sua reintegração na sociedade.

**Art. 342.** Os órgãos competentes publicarão, com a periodicidade necessária, os preços médios de mercado de material de consumo, bens e serviços, os quais servirão de base para as licitações da administração direta e indireta, inclusive fundações instituídas ou mantidas pelo Poder público.

**Art. 343.** O Estado criará crédito educativo por meio de suas entidades financeiras, para favorecer os estudantes de baixa renda, na forma da lei.

**Art. 344.** A Fortaleza de São José de Macapá, as Vilas de Mazagão Velho, Cunani e Curiaú são patrimônios históricos protegidos pelo Estado.

**Art. 345.** As empresas que abrirem vagas em seu quadro de pessoal a menores de 18 anos e aos portadores de deficiência, terão direito a incentivos fiscais especiais, a serem estabelecidos em lei.

**Art. 346.** O Estado assegurará, prioritariamente, apoio ao assentamento de produtores rurais próximo às áreas de várzeas, compatibilizando suas ações com a política agrícola estadual e com o Plano Nacional de Reforma Agrária, em consonância com a política de preservação do meio ambiente.

**Art. 347.** As áreas de terras estaduais cujo potencial econômico se caracterize pela exploração de riquezas extrativistas, em especial os açaizais, seringais e castanhais, não poderão ser desmembradas do patrimônio fundiário do Estado.

**Parágrafo único.** Nas áreas a que se refere o caput deste artigo, o Estado somente repassará o domínio útil, que poderá ser vitalício, hereditário e transferível, após autorização expressa do Poder Público.

**Art. 348.** Quando no exercício de mandato ou função, dos cargos de Governador, de Vice-Governador e de Deputado Estadual, seu titular ficar definitivamente impedido de exercê-lo, por falecimento, por doença grave ou permanente invalidez, é assegurado ao cônjuge, se houver, enquanto viver, ou aos filhos menores, uma pensão equivalente ao valor do subsídio, paga na mesma data e

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 135

revista segundo os mesmos índices daqueles que estiverem em atividade. (revogado pela Emenda Constitucional nº 35, de 21.03.2006)

**§ 1º** A pensão será devidamente atualizada, na mesma proporção e data, sempre que se modificar a remuneração dacrueles em atividade. (revogado pela

Emenda Constitucional nº 35, de 21.03.2006)

**§ 2º** Contraído novo matrimônio, a pensão será transferida automaticamente do cônjuge para os filhos menores até a maioridade. (revogado pela

Emenda Constitucional nº 35, de 21.03.2006)

**§ 3º** Ocorrendo o afastamento da função, por força de invalidez permanente, do cargo de Governador do Estado ou Deputado Estadual, o mesmo passa a receber as vantagens de que trata o caput do artigo. (revogado pela Emenda Constitucional nº 35, de 21.03.2006)

**Art. 349.** É dever do Estado conceder pensão especial correspondente ao salário mínimo à viúva e dependentes de motoristas profissionais que venham a falecer no exercício da profissão, vítima de assaltos. (revogado pela Emenda Constitucional nº 35, de 21.03.2006)

**Parágrafo único.** Se o falecido não tiver dependentes e for arrimo de família, a pensão será paga a seus ascendentes. (revogado pela Emenda Constitucional nº 35, de 21.03.2006)

**Art. 350.** Nos dez primeiros anos de criação de Municípios, serão observadas as seguintes normas básicas:

I - a Prefeitura terá no máximo quatro unidades administrativas;

II - as despesas orçamentárias com pessoal não poderão ultrapassar cinquenta por cento da receita do Município;

III - o orçamento da Câmara Municipal não poderá ultrapassar dez por cento da receita do Município.

**Art. 350.** Nos dez primeiros anos de criação de municípios, as despesas orçamentárias com pessoal não poderão ultrapassar cinquenta por cento da receita do município. (redação dada pela Emenda Constitucional nº 1, de 1994)

**Art. 351.** Lei Complementar estadual definirá os critérios e os valores para aposentadoria dos magistrados, dos conselheiros do Tribunal de Contas e dos membros do Ministério Público, observando-se o disposto na Constituição Federal, nesta Constituição e na legislação federal em vigor.

**Art. 352.** Em caso de morte de magistrado, de procurador de justiça e de conselheiro do Tribunal de Contas, ativo ou inativo, em pleno gozo da vitaliciedade, é assegurado o benefício de pensão, ao cônjuge se houver, enquanto viver, ou aos filhos menores, correspondente ao valor do subsídio, pago na mesma data e revisto segundo os mesmos índices dos que estiverem em atividade.

**Art. 352.** Aplicam-se, no que couber, aos servidores titulares de cargos efetivos do Estado do Amapá, incluídas suas autarquias e fundações, as normas atinentes ao regime previdenciário estabelecidas pelas Emendas à Constituição Federal nº. 20, de 15 de dezembro de 1998, n.º 41, de 19 de dezembro de 2003 e n.º 47, de 5 de julho de 2005. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

**Art. 353.** As empresas de médio e grande porte que operam no ramo do extrativismo mineral e vegetal, instaladas ou que vierem a se instalar no território do Estado, são obrigadas a desenvolver processo de industrialização no ramo de sua atuação, de acordo com as leis do meio ambiente.

**Art. 354.** Fica assegurada, ao doador voluntário de sangue, precedência de atendimento, em qualquer estabelecimento público ou privado do Estado, nos transportes coletivos urbanos, intermunicipais e interestaduais, e reforço alimentar no ato da doação do sangue.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 136

**Art. 355.** O dia 13 de Setembro, data magna do Amapá, é feriado em todo o território do Estado.

**Art. 356.** Cessada a investidura no cargo de Governador do Estado, quem o tiver exercido em caráter permanente, e por prazo não inferior a seis meses, fará jus, a título de representação, a um subsídio mensal e vitalício igual aos vencimentos do cargo de Desembargador do Tribunal de Justiça do Estado. (incluído pela Emenda Constitucional nº 3, de 30.11.1995) (revogado pela Emenda Constitucional nº 35, de 21.03.2006)

**§ 1º** Investido em cargo eletivo, o ex-governador não perceberá o beneficio enquanto durar o mandato. (incluído pela Emenda Constitucional nº 3, de 30.11.1995) (revogado pela Emenda Constitucional nº 35, de 21.03.2006)

**§ 2º** O benefício previsto neste artigo estende-se aos ex-governadores do extinto Território Federal do Amapá, observando-se os mesmos critérios quanto a titularidade e tempo de exercício no cargo”. (incluído pela Emenda Constitucional nº 3, de 30.11.1995) (revogado pela Emenda Constitucional nº 35, de 21.03.2006)

**Art. 357.** Os ex-integrantes da extinta Guarda Territorial do Amapá farão jus, quando carentes, ao recebimento de pensão especial vitalícia não inferior a dois salários mínimos, sendo a mesma inacumulável com quaisquer outros rendimentos recebidos dos cofres públicos, exceto os benefícios previdenciários, garantido o direito de opção. (incluído pela Emenda Constitucional nº 35, de 21.03.2006)

**§ 1º** O benefício estabelecido neste artigo é transferível aos dependentes reconhecidamente carentes. (incluído pela Emenda Constitucional nº 35, de 21.03.2006)

**§ 2º** A concessão do benefício far-se-á nos termos de lei a ser proposta pelo Poder Executivo. (incluído pela Emenda Constitucional nº 35, de 21.03.2006)

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 137

### TÍTULO X Ato das Disposições Constitucionais Transitórias

**Art. 1º** O Governador do Estado, o presidente do Tribunal de Justiça do Estado e os Deputados Estaduais prestarão compromisso de manter, defender e cumprir esta Constituição, no ato e na data de sua promulgação.

**Art. 2º** As Câmaras Municipais votarão sua Lei Orgânica respectiva até seis meses após a promulgação desta Constituição.

**Parágrafo único.** As Câmaras Municipais dos novos Municípios votarão sua Lei Orgânica respectiva até seis meses após sua instalação.

**Art. 3º** Vigorará no novo Município, enquanto não for promulgada sua

Lei Orgânica, se a Câmara de Vereadores assim o deliberar, a legislação do Município de origem.

**Art. 4º** No prazo de até noventa dias após a promulgação desta Constituição será realizada consulta plebiscitária, com vistas a posterior elevação a Município, nas localidades de:

I - Bailique, com desmembramento do Município de Macapá;

II - Porto Grande, com desmembramento do Município de Macapá;

III - Serra do Navio, com desmembramento do Município de Macapá;

IV - Pacuí, com desmembramento do Município de Macapá;

V - Itaubal, com desmembramento do Município de Macapá;

VI - Araguari, com desmembramento do Município de Macapá;

VII - Maracá, com desmembramento do Município de Mazagão;

VIII - Pracuúba, com desmembramento do Município de Amapá;

IX - Sucuriju, com desmembramento do Município de Amapá;

X - Lourenço, com desmembramento do Município de Calçoene;

XI - São Tiago, com desmembramento do Município de Mazagão;

XII - Cassiporé, com desmembramento do Município de Oiapoque;

XIII - Aporema, com desmembramento do Município de Tartarugalzinho;

XIV - Igarapé do Lago, com desmembramento dos Municípios de Macapá e Santana;

XV - Beiradinho, com desmembramento do Município de Laranjal do Jari;

XVI - Pedreira, com desmembramento do Município de Macapá;

XVII - Pedra Branca, com desmembramento do Município de Macapá;

XVIII - Ilha de Santana, com desmembramento do Município de Santana;

XIX - Fazendinha, com desmembramento do Município de Macapá;

XX - Jarilândia, com desmembramento do Município de Laranjal do Jari;

XXI - Cunani, com desmembramento dos Municípios de Calçoene e Oiapoque;

XXII - Filadélfia do Pacuí, com desmembramento de Macapá.

**§ 1º** Se o resultado do plebiscito for favorável, o Governo do Estado promoverá, dentro de sessenta dias após a consulta, a demarcação dos limites geográficos dos Municípios envolvidos.

**§ 2º** O Governador do Estado designará os Prefeitos pro tempore, até a instalação dos Municípios, que se dará com a posse dos Vereadores, Prefeitos e Vice- Prefeitos eleitos.

**§ 3º** O Estado prestará assistência técnica e financeira aos Municípios, em caráter excepcional, até que sejam contemplados com as transferências constitucionais.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 138

**Art. 5º** Será criada, no prazo de noventa dias da promulgação da Constituição, Comissão Especial de Estudos, formada por oito membros de ilibada reputação e notórios conhecimentos culturais e ecológicos, sendo quatro indicados pelo Poder Executivo, dois pelo Poder Legislativo e dois por entidades afins, visando à delimitação da área de preservação ecológica e cultural da comunidade de Curiaú.

**Art. 6º** O Estado, em cooperação com os Municípios, criará centrais de abastecimentos para armazenagem, conservação e comercialização dos produtos agrícolas, na forma da lei.

**Art. 7º** Fica criado o Conselho Estadual da Política Agrária, Fundiária, Agrícola e Extrativista Vegetal, constituído por representantes do Poder Público e da sociedade civil, através de entidades ligadas às questões agrária, fundiária, agrícola e extrativista vegetal do tipo sindical, associativa, profissional e financeira, paritariamente entre se, cabendo-lhe, entre outras atribuições da lei complementar respectiva:

I - propor a política de desenvolvimento estadual para o setor primário, através de planos, diretrizes e programas;

II - opinar sobre a proposta orçamentária do Estado para o setores agrário, fundiário, agrícola e extrativista vegetal;

III - criar mecanismo de acompanhamento, deliberação, fiscalização e normatização de ações e projetos no setor.

**Art. 8º** O Estado criará, na forma da lei, uma empresa de administração portuária.

**Art. 9º** O servidor público federal, estadual ou municipal que, na data da promulgação desta Constituição, estiver regularmente à disposição de órgão público, estadual ou municipal, que não aquele em que esteja investido, poderá optar, sem prejuízo de sua atividade, e assegurada a irredutibilidade salarial, por integrar o quadro de pessoal do órgão ou Poder ao qual se encontrava cedido.

**Parágrafo único.** O direito de opção de que trata o presente artigo, esgotar-se-á em cento e vinte dias da data da promulgação da Constituição.

**Art. 10.** O Estado promoverá incentivos fiscais e de assistência técnica à criação de áreas apropriadas a minifúndios, já instalados e a serem instalados, próximos aos centros urbanos, cuja finalidade seja a produção de hortifrutigranjeiros.

**Art. 11.** Fica o Estado incumbido de implantar delegacias especializadas de atendimento à mulher, em todos os Municípios.

**Art. 12.** Expirados os prazos fixados na Constituição Estadual para elaboração de leis complementares que sejam de iniciativa do Poder Legislativo, fica

a Mesa Diretora da Assembleia Legislativa responsável por apresentar, no prazo de trinta dias, os respectivos projetos de lei, que entrarão imediatamente na ordem do dia e deverão ser votados dentro de, no máximo, trinta dias.

**Art. 13.** A revisão desta Constituição será realizada imediatamente após concluída a revisão prevista no art. 3º do Ato das Disposições Constitucionais Transitórias da Constituição Federal.

**Art. 14.** A Assembleia Legislativa, através de comissão, com auxílio do Tribunal de Contas do Estado, revisará todas as doações, vendas e concessões de terras públicas do Estado, desde a data de sua instalação até à promulgação desta Constituição.

**Parágrafo único.** A comissão será constituída no prazo de cento e vinte dias, a partir da data da data da promulgação desta Constituição.

**Art. 15.** Será criada uma comissão, dentro de noventa dias após a promulgação desta Constituição, integrada por seis membros, indicados três pela CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 139

Assembleia Legislativa e três pelo Governador do Estado, para proceder, em favor do Estado, à incorporação dos bens imóveis do ex-Território Federal do Amapá, à transferência das terras públicas não devolutas, de acordo com o art. 5º do Decreto-

Lei nº. 2.375, de 24 de novembro de 1937, e à transferência, para o Estado, do acervo fundiário que se encontra no Estado do Pará.

**Art. 16.** O Estado do Amapá se empenhará e proporá, através de seus órgãos, as isenções seguintes:

I - do imposto sobre a operação relativa à circulação de mercadorias e sobre a prestação de serviços de transporte interestadual e intermunicipal e de comunicação incidente sobre os produtos componentes da cesta básica, bem como sobre os insumos e mercadorias adquiridos por pequenos produtores rurais, destinados a suas atividades produtivas, desde que voltadas para a produção da cesta básica;

II - do imposto sobre a propriedade de veículos automotores sobre veículo utilizado como táxi pelo proprietário, quando constitua a atividade única fonte de renda do beneficiário.

**Art. 17.** O Poder Executivo estadual deverá remeter à Assembleia Legislativa projeto de lei referente à política agrária, fundiária, agrícola e extrativista vegetal do Estado, no prazo máximo de seis meses, a partir da promulgação desta Constituição, observadas as disposições da lei federal.

**Art. 18.** O Estado adotará os mecanismos necessários para a instituição dos Conselhos de Escolas, compostos por membros da comunidade escolar, de acordo com o disposto em lei.

**Art. 19.** O Estado implantará, em todo o seu território, o sistema estadual de cadastro técnico rural, visando o planejamento e desenvolvimento das políticas agrícola, agrária e utilização e preservação dos recursos naturais.

**Art. 20.** O Estado criará nas terras devolutas de seu território as reservas de assentamento fundiário, que deverão ser destinadas exclusivamente aos pequenos agricultores, na forma da lei.

**Art. 21.** O Poder Executivo, até o final de cada exercício, procederá ao recenseamento escolar para o efeito de diagnóstico de toda situação, submetendo à apreciação da Assembleia Legislativa um plano que corrija falhas no sistema escolar do Estado.

**Art. 22.** O Poder Público estadual criará centros profissionalizantes para treinamento, habilitação e reabilitação de portadores de deficiência, priorizando os que não tenham condições de frequentar a rede regular de ensino.

**Art. 23.** O Estado promoverá o recadastramento de todas as propriedades rurais do Estado que não compreendam patrimônio da União.

**Art. 24.** Até que seja disciplinada por lei, de iniciativa do Tribunal de Justiça, e empossados os juízes de paz eleitos na conformidade desta Constituição, a Justiça de Paz estadual será regulada por ato normativo do Tribunal de Justiça.

**Art. 24.** A lei que instituir a justiça de paz manterá os atuais juízes de paz até a posse dos novos titulares, assegurando-lhes os direitos e atribuições conferidos a estes, e designará o dia para a eleição prevista no art. 141 desta Constituição. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

**Parágrafo único.** No prazo de 180 (cento e oitenta) dias, contados da data de publicação desta emenda, o Tribunal de Justiça do Estado fará apresentar o projeto de lei necessário à organização da Justiça de Paz. (incluído pela Emenda Constitucional nº 35, de 21.03.2006)

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 140

**Art. 25.** Lei estadual criará mecanismos que assegurem a efetiva implantação do ensino regular de segundo grau, no prazo máximo de dois anos, contados da promulgação desta Constituição, em todas as sedes municipais.

**Art. 26.** Ficam ratificados todos os atos de natureza normativa praticados pelo Governador do Estado, até a data da promulgação desta Constituição.

**§ 1º** A ratificação de que trata este artigo abrange todos os atos, contratos, convênios e ajustes praticados ou celebrados, com o objetivo de estruturar o funcionamento do Estado do Amapá.

**§ 2º** A ratificação se estende aos efeitos dos mencionados atos, contratos, convênios e ajustes.

**Art. 27.** O Estado criará estabelecimento do tipo ambulatorial, independente, que se destinará à coleta, controle e distribuição do leite humano, à população carente, cuja normatização dar-se-á por lei estadual.

**Art. 28.** Fica o Poder Executivo autorizado a construir, na Capital do Estado, a Praça da Bíblia, com o respectivo monumento, destinado as festividades religiosas.

**Art. 29.** Os assistentes jurídicos pertencentes ao quadro do extinto Território Federal do Amapá, sob a subordinação da Procuradoria-Geral e da Defensoria Pública do Estado, que optarem pelo quadro de servidores estaduais, serão denominados Procuradores ou Defensores Públicos do Estado, assegurado o direito de integrar os respectivos quadros de carreira. (Dispositivo declarado inconstitucional, em controle concentrado, pelo Supremo Tribunal Federal, no julgamento da ADIN nº 1267-3)

**Art. 30.** Até a promulgação da lei de que trata o art. 244 desta Constituição, poderão ser enquadrados no regime fiscal das microempresas aquelas cujo valor anual das entradas de mercadorias e serviços de transporte, utilizados na industrialização ou comercialização, não ultrapasse doze milhões de cruzeiros, corrigido pelo índice oficial adotado.

**Art. 31.** Enquanto não entrar em vigor a legislação tributária de competência estadual, prevista nesta Constituição, continuar-se-á utilizando a legislação tributária adotada á época da promulgação desta Constituição.

**Art. 32.** A área onde estava edificado o Forte de Santo Antônio de Macapá, antigo Forte Cumaú, no Município de Santana, às proximidades da foz do Igarapé da Fortaleza, passa a ser área de preservação histórico-cultural e de lazer.

**Art. 33.** Lei de iniciativa do Tribunal de Justiça, a ser elaborada e remetida à Assembleia Legislativa em noventa dias, contados da promulgação desta Constituição, e a ser promulgada em até sessenta dias após, disporá sobre normas para a criação e implantação de cartórios extrajudiciais, em todas as sedes municipais do Estado, inclusive na sua Capital.

**Parágrafo único.** O Tribunal de Justiça promoverá, no prazo de cento e oitenta dias após a publicação da lei mencionada no caput deste artigo, a instalação das serventias que vierem a ser criadas.

**Art. 34.** Nos dez primeiros anos da criação do Estado do Amapá, as despesas orçamentárias com pessoal ativo e inativo não poderão ultrapassar cinquenta por cento da receita do Estado.

**Art. 35.** Ao Procurador-Geral de Justiça, nomeado através do Decreto (P) nº. 21 de 01 de janeiro de 1991, aplica-se o disposto no art. 146 desta Constituição.

**Art. 36.** O Estado, através de lei específica, criará a Fundação Cultural do Amapá.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 141

**Art. 37.** Deverá o Banco do Estado do Amapá criar linha de crédito especial para pequenos e médios produtores, como para suas cooperativas, associações e respectivas entidades com autonomia jurídica, priorizando-se atendimento a áreas de assentamento, na forma da lei.

**Art. 38.** Ficam reconhecidas pelo Estado as Escolas Famílias existentes no interior do Amapá, sendo-lhes garantidos seus princípios e sua metodologia. (redação dada pela Emenda Constitucional nº 34, de 22.07.2005)

**Parágrafo único.** O Estado estimulará a criação de Escolas Famílias Agrícolas, garantindo-lhes apoio necessário para o pleno êxito de seu funcionamento.

**Parágrafo único.** O Estado estimulará a criação de Escolas Famílias, garantindo-lhes apoio necessário para o pleno êxito de seu funcionamento. (redação dada pela Emenda Constitucional nº 34, de 22.07.2005)

**Art. 39.** A lei disporá sobre a criação de loterias e outras formas promocionais de incrementar a arrecadação estadual.

**Art. 40.** Os veículos de comunicação social do Estado deverão atingir todos os seus Municípios.

**Art. 41.** O Estado criará, mediante lei a ser promulgada no prazo de doze meses da promulgação desta Constituição, os seguintes fundos:

I - Fundo de Desenvolvimento do Estado e dos Municípios;

II - Fundo de Desenvolvimento Rural.

**§ 1º** A lei que regulamentar os respectivos fundos definirá a fonte, o volume e a aplicação dos recursos.

**§ 2º** O fundo de que trata o inciso I deste artigo, será repassado mensalmente aos Municípios, na forma que a lei estabelecer, e somente poderá ser utilizado para investimento.

**§ 3º** Os recursos provenientes dos fundos referidos neste artigo e de tantos outros quanto possam vir a ser criados no âmbito do Estado, de natureza constitucional ou não, serão geridos e administrados pela Agência de Fomento do Amapá S/A, na forma da lei, através de linhas de crédito específicas, especialmente voltadas ao micro crédito e ao crédito para pequenos e médios empreendedores. (incluído pela Emenda Constitucional nº 35, de 21.03.2006)

**Art. 42.** O Estado criará centro de lazer e de amparo à velhice.

**Art. 43.** O Estado equipará e manterá financeiramente a Casa do Estudante Amapaense na Capital do Estado do Pará, em condições de abrigar e favorecer o estudo à discência universitária e nível médio.

**Art. 44.** Será garantido, mediante lei, a ser promulgada em até cento e oitenta dias após a promulgação desta Constituição, o aproveitamento compulsório, em todas as operações pesqueiras, da fauna acompanhante da pesca no Estado.

**Art. 45.** Enquanto não se dispuser, em normas próprias sobre a situação, obrigações, deveres, prerrogativas e regime de remuneração de pessoal militar do Corpo de Bombeiros Militar do Estado, aplicar-se-ão as disposições previstas em lei para a Polícia Militar do Estado do Amapá.

**Art. 46.** O Estado criará, na forma da lei, o Centro de Treinamento e Aperfeiçoamento de Recursos Humanos do Estado, com o objetivo de aprimorar os recursos humanos existentes no serviço público estadual e municipal.

**Parágrafo único.** A lei que criar o órgão referido no caput deste artigo definirá também os critérios de seu funcionamento, bem como a dotação orçamentária que irá gerir esse órgão.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 142

**Art. 47.** O Estado implantará, progressivamente, unidades equipadas do Corpo de Bombeiros e dos serviços periciais técnico-científicos nos Municípios, dando prioridade aos mais populosos, na forma da lei.

**Art. 48.** A partir da promulgação desta Constituição e no prazo de cento e cinquenta dias, uma comissão especial de cinco membros será formada, por representantes do Poder Judiciário, Ordem dos Advogados do Brasil - Secção do Amapá, Ministério Público, Pastoral Carcerária da Diocese de Macapá e Poder Legislativo, sob a coordenação deste, com o objetivo de proceder ao levantamento da população carcerária do Estado, visando definir a situação processual de cada interno, para as providências que se fizerem necessárias.

**Art. 49.** Através de lei ordinária o Poder Público criará a Tevê e Rádio Educativa do Amapá, cuja finalidade será promover a divulgação de programas regionais, como contribuição do Estado no aprimoramento cultural do povo.

**Art. 50.** Para justificar o princípio de religiosidade do povo amapaense, será impressa em página única na composição desta Constituição, antes da parte destinada ao sumário, a seguinte frase: “Feliz a Nação cujo Deus é o Senhor, e o povo que ele escolheu por herança”.

**Art. 51.** Fica estabelecido que a Bíblia Sagrada será colocada em todas as repartições públicas, inclusive nos estabelecimentos escolares, no vestíbulo do prédio, para uso de quem assim o desejar.

**Art. 52.** Os servidores públicos civis do Estado e dos Municípios, da administração direta, autárquica e das fundações públicas, em exercício na data da promulgação desta Constituição, há pelo menos cinco anos de exercício contínuo, e que não tenham sido admitidos na forma regulada pelo art. 37 da Constituição Federal, são considerados estáveis no serviço público. (revogado pela Emenda Constitucional nº 35, de 21.03.2006)

**Parágrafo único.** O disposto neste artigo não se aplica aos ocupantes de cargos, funções e empregos de confiança ou em comissão, nem aos que a lei declare de livre exoneração, cujo tempo de serviço não será computado para os fins do caput deste artigo, exceto se se tratar de servidor. (revogado pela Emenda Constitucional nº 35, de 21.03.2006)

**Art. 53.** O Poder Executivo mandará imprimir a presente Constituição para distribuí-la, ampla e gratuitamente, a todos os organismos públicos e interessados.

**Art. 54.** Nos dez primeiros anos da existência do Estado do Amapá, o Tribunal de Contas do Estado terá três conselheiros, dentre brasileiros de comprovada idoneidade e notório saber. (incluído pela Emenda Constitucional nº 5, de 1996)

**§ 1º** Na hipótese de vacância nos cargos referidos neste artigo, o provimento dos mesmos será feito: (incluído pela Emenda Constitucional nº 5, de 1996)

I - o primeiro pela Assembleia Legislativa; (incluído pela Emenda Constitucional nº 5, de 1996)

II - o segundo pela Assembleia Legislativa; (incluído pela Emenda Constitucional nº 5, de 1996)

III - o terceiro pelo Governador. (incluído pela Emenda Constitucional nº 5, de 1996)

**§ 2º** Após passar o Tribunal de Contas a ter sete Conselheiros, desde que fique garantida a distribuição proporcional prevista no §2º, I e II do artigo 113, as quatro vagas serão preenchidas pela Assembleia Legislativa, observados os

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 143

requisitos do § 1º do mencionado artigo. (incluído pela Emenda Constitucional nº 5, de 1996)

**Art. 55.** Lei Complementar disciplinará o disposto no Parágrafo único do

art. 79 desta Constituição, no prazo máximo de 60 (sessenta) dias, assegurando aos Delegados de Polícia de carreira, isonomia de vencimentos com as carreiras de Procuradores ou de Defensores Públicos do Estado. (incluído pela Emenda Constitucional nº 9, de 28.08.1997) (revogado pela Emenda Constitucional nº 35, de 21.03.2006)

**Art. 56.** A desativação de empresas industriais e comerciais com atividades no Estado do Amapá, implantadas por meio de contrato ou concessão do Poder Público, utilizando recursos do solo, subsolo e meio hídrico, e gozando de doações, isenções, incentivos ou subsídios de quaisquer espécies, observará: (incluído pela Emenda Constitucional nº 10, de 19.12.1997)

I - o acordo de negociação para desativação das empresas, qualquer que seja a natureza e que envolva o Estado do Amapá, será objeto de apreciação e deliberação da Assembleia Legislativa; (incluído pela Emenda Constitucional nº 10, de 19.12.1997)

II - para acompanhar os trabalhos de desativação das empresas, a Assembleia Legislativa designará uma Comissão Especial composta de cinco deputados estaduais; (incluído pela Emenda Constitucional nº 10, de 19.12.1997)

III - o Ministério Público designará dois representantes, a convite da Assembleia Legislativa, para acompanharem os trabalhos de desativação da empresa; (incluído pela Emenda Constitucional nº 10, de 19.12.1997)

IV - Os bens e benfeitorias que vierem a ser deixados pelos complexos operacionais das empresas desativadas serão destinados, preferencialmente, para os municípios que os sediarem, mediante plano de ação conjunto das prefeituras municipais envolvidas e com interveniência do governo do estado do Amapá. (incluído pela Emenda Constitucional nº 10, de 19.12.1997)

IV - Todos os bens móveis e imóveis que vierem a ser deixados pelos complexos operacionais das empresas desativadas serão destinados para os municípios que os sediarem. (redação dada pela Emenda Constitucional nº 13, de 29.09.1999)

**Parágrafo único.** A infraestrutura sócioeconômica localizada no município de Serra do navio, implantada pela ICOMI – Indústria e Comércio de Minérios S/A e a ser revertida ao Poder Público destinar-se-á, também, à instalação e desenvolvimento de atividades de entidades públicas de pesquisas científico- tecnológica e de extensão próprias do ensino superior. (incluído pela Emenda Constitucional nº 10, de 19.12.1997)

**§ 1º** Os bens que ocuparem espaço territorial de mais de um município serão destinados ao Estado do Amapá. (incluído pela Emenda Constitucional nº 13, de 29.09.1999)

**§ 2º** A infraestrutura sócio-econômica localizada no Município de Serra do Navio, implantada pela ICOMI – Indústria e Comércio de Minérios S/A, a ser revertida ao Poder Público, destinar-se-á, também, à instalação e desenvolvimento de atividades de entidades públicas de pesquisa científico-tecnológica e de extensão próprias do ensino superior. (anteriormente parágrafo único, transformado em § 2º pela Emenda Constitucional nº 13, de 1999)

**Art. 57.** O mandato da atual administração do Tribunal de Contas do Estado do Amapá se estenderá até a data estabelecida no § 8º do art. 113 da Constituição do Estado. (incluído pela Emenda Constitucional nº 19, de 22.11.2000) CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 144

**Art. 57.** Os vencimentos, a remuneração, as vantagens e os adicionais, bem como os proventos de aposentadoria que estejam sendo percebidos em desacordo com a Constituição serão imediatamente reduzidos aos limites dela decorrentes, não se admitindo, neste caso, invocação de direito adquirido ou percepção de excesso a qualquer título. (redação dada pela Emenda Constitucional nº 35, de 21.03.2006)

**§ 1º** É assegurado o exercício cumulativo de dois cargos ou empregos privativos de médico que estejam sendo exercidos por médico militar na administração pública direta ou indireta. (incluído pela Emenda Constitucional nº 35, de 21.03.2006)

**§ 2º** É assegurado o exercício cumulativo de dois cargos ou empregos privativos de profissionais de saúde que estejam sendo exercidos na administração pública direta ou indireta. (incluído pela Emenda Constitucional nº 35, de 21.03.2006)

**§ 3°** A incorporação dos direitos e vantagens fica limitada aos Oficiais que exerciam os cargos de Comandante Geral da Policia Militar, Comandante Geral do Corpo de Bombeiros Militar, Chefes de Gabinetes Militares dos Poderes e do Ministério Público Estadual até a data de 12 de abril de 2017, incluindo os que nesta data em exercício estavam, desde que os tenham exercido por um período mínimo de 18 meses ininterruptos ou alternados no ato da passagem para a inatividade, sendo vedadas novas incorporações a partir daquela data, ficando preservados, ainda, os direitos e vantagens dos Oficiais que já estavam transferidos à reserva naquela mesma data. (incluído pela Emenda Constitucional nº 71, de 17.06.2025)

**Art. 58.** O Poder Executivo adotará todas as providências necessárias à implantação da Universidade Estadual. (incluído pela Emenda Constitucional nº 35, de 21.03.2006)

**Art. 59.** No prazo de 60 (sessenta) dias, contados da data de publicação desta emenda, o Poder Executivo fará encaminhar à Assembleia Legislativa projeto de lei visando à regulamentação do § 10 do art. 304 desta Constituição. (incluído pela

Emenda Constitucional nº 35, de 21.03.2006)

**Art. 60.** A lei de que trata o § 3º do art. 41 deverá ser editada no prazo de 120 (cento e vinte) dias, contados da publicação desta emenda. (incluído pela

Emenda Constitucional nº 35, de 21.03.2006)

**Art. 61.** Fica facultado ao Estado, enquanto não for implantada a escola de governo responsável pelo atendimento do disposto no § 2º do art. 47, realizar a incumbência ali fixada mediante a celebração de contratos ou convênios com instituições de ensino superior. (incluído pela Emenda Constitucional nº 35, de 21.03.2006)

**Art. 62.** O Poder Executivo fará encaminhar à Assembleia Legislativa, no prazo máximo de 90 (noventa dias) contados da publicação desta Emenda, o projeto de lei a que se refere o § 2º do art. 357. (incluído pela Emenda Constitucional nº 35, de 21.03.2006)

**Art. 63.** O servidor público federal da categoria de Fiscal de Tributos e Auxiliar de Fiscal do Ex-território Federal do Amapá, citados na Lei nº 0982, de 03 de abril de 2006, que na data da promulgação desta Emenda estiver regularmente à disposição do Estado, poderá optar, sem prejuízo de suas atividades, por integrar o quadro pessoal da secretaria da Receita Estadual de que trata a Lei nº 0982/2006. (incluído pela Emenda Constitucional nº 44, de 21.12.2009)

**§ 1º** No enquadramento dos optantes será considerado o tempo de serviço e a irredutibilidade de vencimentos. (incluído pela Emenda Constitucional nº 44, de 21.12.2009)

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 145

**§ 2º** O direito de opção de que trata o presente artigo, esgotar-se-á em sessenta meses a contar da data da promulgação desta Emenda. (incluído pela

Emenda Constitucional nº 44, de 21.12.2009)

**§ 3º** A opção será regulamentada por decreto do Executivo Estadual. (incluído pela Emenda Constitucional nº 44, de 21.12.2009)

**Art. 64.** Até que seja criado o Quadro de Oficiais de Estado-Maior (ǪOEM) nas respectivas Corporações por meio de lei complementar, as regras previstas nos artigos 82 e 87 desta Constituição recairão sobre o Oficiais do último posto do Quadro de Oficiais Combatentes da Polícia Militar do Amapá e do Corpo de Bombeiros Militar do Amapá. (incluído pela Emenda Constitucional n. 68, de 11.04.2024)

**Art. 65.** Até que seja criado o Quadro de Oficiais Especialistas (QOE) nas respectivas Corporações por meio de lei complementar, permanecem vigentes as regras previstas nas legislações específicas a respeito dos quadros de Oficiais oriundos da carreira das praças. (incluído pela Emenda Constitucional n. 68, de 11.04.2024)

Macapá – AP, 20 de dezembro de 1991.

Deputado Nelson Salomão - Presidente Deputado Nilde Santiago - 1º Vice-Presidente Deputado Luis Barreto - 2º Vice-Presidente Deputado Félix Ramalho - Secretário Geral Deputado Dáqueo Ribeiro - 1º Secretário Deputado Adonias Trajano - 2º Secretário Deputado Aluízio Gomes Deputado Amiraldo Favacho Deputado Antônio Teles Deputado Fran Júnior Deputado Geraldo Rocha Deputado Hildo Fonseca Deputada Janete Capiberibe Deputado Jarbas Gato Deputado Jefri Hippolyte Deputado João Dias Deputado Júlio Miranda Deputado Manoel Brasil Deputado Maurício Júnior Deputado Regildo Salomão Deputado Ricardo Soares Deputado Sebastião Rocha Deputado Waldez Góes

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 146

EMENDAS CONSTITUCIONAIS

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 147

EMENDA À CONSTITUIÇÃO Nº 0001, DE 29 DE MARÇO DE 1994 Publicada no Diário Oficial do Estado nº 0808, de 13.04.94

Altera a redação do Art. 350 da Constituição do Estado do Amapá.

A Mesa Diretora da Assembleia Legislativa do Estado do Amapá, no uso de suas atribuições, tendo em vista o que dispõe o § 3º do art. 103, da Constituição do Estado, combinado com a alínea “c”, inciso I do Art. 15 do Regimento Interno, promulga a seguinte Emenda Constitucional:

**Art. 1º** O Artigo 350 da Constituição do Estado do Amapá passa a ter com a seguinte redação:

“Art. 350. Nos dez primeiros anos de criação de Municípios, as despesas orçamentárias com pessoal não poderão ultrapassar cinquenta por cento da receita do Município.”

**Art. 2º** Esta emenda à constituição entra em vigor na data de sua publicação, revogadas as disposições em contrário.

Macapá – AP, 29 de março de 1994.

A Mesa da Assembleia Legislativa: Júlio Miranda – Presidente; Fran Júnior - 1º Vice- Presidente; Amiraldo Favacho - 2º Vice-Presidente; João Dias - Secretário Geral; Luis Barreto - 1º Secretário; Félix Ramalho - 2º Secretário.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 148

EMENDA À CONSTITUIÇÃO Nº 0002, DE 30 DE NOVEMBRO DE 1995 Publicada no Diário Oficial do Estado nº 1216, de 14.12.95

Acrescenta o § 10 ao artigo 113 da Constituição do Estado do Amapá.

A Mesa Diretora da Assembleia Legislativa do Estado do Amapá faz saber que a Assembleia Legislativa do Estado do Amapá aprovou e ela promulga a seguinte Emenda à Constituição:

**Art. 1º** Fica acrescentado o § 10 ao artigo 113 da Constituição do Estado do Amapá, com a seguinte redação:

“§ 10 Cabendo a escolha de Conselheiro à Assembleia Legislativa, caso o chefe do Poder Executivo não efetive a nomeação do candidato indicado nas quarenta e oito horas que se seguirem ao recebimento da comunicação, o mesmo será investido automaticamente no cargo.”

**Art. 2º** Esta Emenda à Constituição entra em vigor na data de sua publicação, revogadas as disposições em contrário.

Macapá - AP, 30 de novembro de 1995.

A Mesa da Assembleia Legislativa: Júlio Miranda – Presidente; Amiraldo Favacho - 1º Vice-Presidente; Regildo Salomão - 2º Vice-Presidente; Antônio Teles - Secretário Geral; Manoel Brasil - 1º Secretário; Lucas Barreto - 2º Secretário.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 149

EMENDA À CONSTITUIÇÃO Nº 0003, DE 30 DE NOVEMBRO DE 1995 Publicada no Diário Oficial do Estado nº 1216, de 14.12.95

Acrescenta o artigo 356 e §§ 1º e 2º ao

### Título IX, Das Disposições Constitucionais Gerais da Constituição do Estado do Amapá.

A Mesa Diretora da Assembleia Legislativa do Estado do Amapá faz saber que a Assembleia Legislativa do Estado do Amapá aprovou e ela promulga a seguinte Emenda à Constituição:

**Art. 1º** Fica acrescentado o Artigo 356 e §§ 1º e 2º ao Título IX, Das Disposições Constitucionais Gerais do Estado do Amapá, com a seguinte redação:

“Art. 356. Cessada a investidura no cargo de Governador do Estado, quem o tiver exercido em caráter permanente, e por prazo não inferior a seis meses, fará jus, a título de representação, a um subsídio mensal e vitalício igual aos vencimentos do cargo de Desembargador do Tribunal de Justiça do Estado.

**§ 1º** Investido em cargo eletivo, o ex-governador não perceberá o beneficio enquanto durar o mandato.

**§ 2º** O benefício previsto neste artigo estende-se aos ex- governadores do extinto Território Federal do Amapá, observando-se os mesmos critérios quanto a titularidade e tempo de exercício no cargo”.

**Art. 2º** Esta Emenda à Constituição entra em vigor na data de sua publicação, revogadas as disposições em contrário.

Macapá - AP, 30 de novembro de 1995.

A Mesa da Assembleia Legislativa: Júlio Miranda – Presidente; Amiraldo Favacho - 1º Vice-Presidente; Regido Salomão - 2º Vice-Presidente; Antônio Teles - Secretário Geral; Manoel Brasil - 1º Secretário; Lucas Barreto - 2º Secretário.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 150

EMENDA CONSTITUCIONAL Nº 0004, DE 30 DE NOVEMBRO DE 1995 Publicada no Diário Oficial do Estado nº 1216, de 14.12.95

Modifica a redação do inciso II, do § 2º, do artigo 285 da Constituição do Estado do Amapá.

A Mesa Diretora da Assembleia Legislativa do Estado do Amapá faz saber que a Assembleia Legislativa do Estado do Amapá aprovou e ela promulga a seguinte Emenda à Constituição:

**Art. 1º** O inciso II, do § 2º, do Art. 285, da Constituição Estadual, passa a ter a seguinte redação:

“II – Os Conselhos Escolares, com gestão democrática, são órgãos de aconselhamento, fiscalização deliberação e avaliação do sistema de ensino, no nível de cada estabelecimento escolar público, na forma da lei.”

**Art. 2º** Esta Emenda Constitucional entra em vigor na data de sua publicação, revogadas as disposições em contrário.

Macapá - AP, 30 de novembro de 1995.

A Mesa da Assembleia Legislativa: Júlio Miranda – Presidente; Amiraldo Favacho - 1º Vice-Presidente; Regido Salomão - 2º Vice-Presidente; Antônio Teles - Secretário Geral; Manoel Brasil - 1º Secretário; Lucas Barreto - 2º Secretário.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 151

EMENDA À CONSTITUIÇÃO Nº 0005, DE 14 DE MARÇO DE 1996 Publicada no Diário Oficial do Estado nº 1218, de 21.03.96

Dá nova redação ao art. 113 e acrescenta o art. 54 ao Ato das Disposições Constitucionais Transitórias da Constituição do Estado do Amapá.

A Mesa Diretora da Assembleia Legislativa do Estado do Amapá faz saber que a Assembleia Legislativa do Estado do Amapá aprovou e ela promulga a seguinte Emenda à Constituição:

**Art. 1º** O artigo 113 da Constituição do Estado passa a vigorar com a seguinte redação:

“Art. 113. O Tribunal de Contas do Estado, órgão auxiliar do Poder Legislativo, integrado por sete Conselheiros, tem sede na capital do Estado, autonomia administrativa e financeira, quadro próprio de pessoal e jurisdição em todo o território estadual, exercendo, no que couber, as atribuições previstas no art. 133 desta Constituição.

**§ 1º** Os Conselheiros do Tribunal de Contas serão nomeados dentre brasileiros que satisfaçam os seguintes requisitos:

I - mais de trinta e cinco e menos de sessenta e cinco anos de idade;

II - idoneidade moral e reputação ilibada;

III - notórios conhecimentos jurídicos, contábeis, econômicos e financeiros ou de administração pública;

IV - mais de dez anos de exercício de função ou de efetiva atividade profissional que exija os conhecimentos mencionados no inciso anterior.

**§ 2º** Os Conselheiros do Tribunal de Contas do Estado serão escolhidos:

I - um terço pelo Governador do Estado, com aprovação da Assembleia Legislativa, sendo um alternadamente dentre auditores e membros do Ministério Público junto ao tribunal, indicados em lista tríplice pelo Tribunal, segundo os critérios de antiguidade e merecimento;

II - dois terços pela Assembleia Legislativa.

**§ 3º** Os Conselheiros do Tribunal de Contas terão as mesmas garantias, prerrogativas, impedimentos, vencimentos e vantagens dos Desembargadores do Tribunal de Justiça do Estado, e somente poderão aposentar-se com as vantagens do cargo quando o tiverem exercido efetivamente por mais de cinco anos.

**§ 4º** Os Conselheiros, nas suas faltas e impedimentos serão substituídos pelos auditores.

**§ 5º** O auditor, quando em substituição a Conselheiro, terá as mesmas garantias e impedimentos do titular e quando

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 152

no exercício das demais atribuições, as de Juiz de Direito da mais elevada entrância do Estado.

**§ 6º** Os auditores do Tribunal de Contas serão nomeados após concurso público de provas ou de provas e títulos, observada a classificação, cumpridos, ainda, os seguintes requisitos;

I - Título de curso superior em direito, Ciências Contábeis, Econômicas ou Administrativas;

II - Idoneidade moral e reputação ilibada;

**§ 7º** O auditor somente poderá aposentar-se com as vantagens do cargo, quando o tiver exercido efetivamente, no Tribunal de Contas, por mais de cinco anos”.

**Art. 2º** Fica acrescentado o seguinte artigo ao Ato das Disposições Constitucionais Transitórias da Constituição do Estado do Amapá, com a seguinte redação:

“Art. 54. Nos dez primeiros anos da existência do Estado do Amapá, o Tribunal de Contas do Estado terá três conselheiros, dentre brasileiros de comprovada idoneidade e notório saber.

**§ 1º** Na hipótese de vacância nos cargos referidos neste artigo, o provimento dos mesmos será feito:

I - o primeiro pela Assembleia Legislativa;

II - o segundo pela Assembleia Legislativa;

III - o terceiro pelo Governador.

**§ 2º** Após passar o Tribunal de Contas a ter sete Conselheiros, desde que fique garantida a distribuição proporcional prevista no § 2º, I e II do artigo 113, as quatro vagas serão preenchidas pela Assembleia Legislativa, observados os requisitos do § 1º do mencionado artigo”.

**Art. 3º** Esta Emenda à Constituição entra em vigor na data de sua publicação, revogando-se as disposições em contrário.

Macapá - AP, 14 de março de 1996.

A Mesa da Assembleia Legislativa: Júlio Miranda – Presidente; Amiraldo Favacho - 1º Vice-Presidente; Regido Salomão - 2º Vice-Presidente; Antônio Teles - Secretário Geral; Manoel Brasil - 1º Secretário; Lucas Barreto - 2º Secretário.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 153

EMENDA À CONSTITUIÇÃO Nº 0006, DE 28 DE MAIO DE 1996 Publicada no Diário Oficial do Estado nº 1328, de 31.05.96

Dá nova redação ao art. 339 da Constituição do Estado do Amapá.

A Mesa Diretora da Assembleia Legislativa do Estado do Amapá faz saber que a Assembleia Legislativa do Estado do Amapá aprovou e ela promulga a seguinte Emenda à Constituição:

**Art. 1º** O artigo 339 da Constituição do Estado do Amapá passa a vigorar com a seguinte redação:

“Art. 339. É vedada a alteração nominativa dos prédios públicos que contenham nomes de pessoas, fatos históricos ou geográficos, salvo com autorização legislativa”.

**Art. 2º** Esta Emenda à Constituição entra em vigor na data de sua publicação, revogando-se as disposições em contrário.

Macapá - AP, 20 de abril de 1996.

A Mesa da Assembleia Legislativa: Júlio Miranda – Presidente; Amiraldo Favacho - 1º Vice-Presidente; Regido Salomão - 2º Vice-Presidente; Antônio Teles - Secretário Geral; Manoel Brasil - 1º Secretário; Lucas Barreto - 2º Secretário.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 154

EMENDA À CONSTITUIÇÃO Nº 0007, DE 31 DE OUTUBRO DE 1996 Publicada no Diário Oficial do Estado nº 1437, de 06.11.96

Dá nova redação ao Inciso I do art. 95 e ao

**§ 3º** do art. 100 da Constituição do Estado do Amapá.

A Mesa Diretora da Assembleia Legislativa do Estado do Amapá faz saber que a Assembleia Legislativa do Estado do Amapá aprovou e ela promulga a seguinte Emenda à Constituição:

**Art. 1º** O Inciso I do art. 95 e o § 3º do art. 100 da Constituição do Estado do Amapá passam a vigorar com a seguinte redação:

“Art. 95. ...............................................................................

I - eleger os membros da Mesa Diretora, com mandato de dois anos, permitida a reeleição e constituir suas comissões.

**§ 3º** A Assembleia Legislativa reunir-se-á, em Sessão Preparatória, a partir de 1º de fevereiro, no primeiro ano de Legislatura, para a posse de seus membros e eleição da Mesa Diretora, para mandato de dois anos, permitida a reeleição”.

**Art. 2º** Esta Emenda à Constituição entra em vigor na data de sua publicação, revogando-se as disposições em contrário.

Macapá - AP, 31 de outubro de 1996.

A Mesa da Assembleia Legislativa: Júlio Miranda – Presidente; Amiraldo Favacho - 1º Vice-Presidente; Regido Salomão - 2º Vice-Presidente; Antônio Teles - Secretário Geral; Manoel Brasil - 1º Secretário; Lucas Barreto - 2º Secretário.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 155

EMENDA À CONSTITUIÇÃO Nº 0008, DE 06 DE NOVEMBRO DE 1996 Publicada no Diário Oficial do Estado nº 1437, de 06.11.96

Dá nova redação aos artigos 151 e 152 da Constituição do Estado do Amapá.

A Mesa Diretora da Assembleia Legislativa do Estado do Amapá faz saber que a Assembleia Legislativa do Estado do Amapá aprovou e ela promulga a seguinte Emenda à Constituição:

**Art. 1º** O Artigo 151 da Constituição do Estado do Amapá passa a vigorar com a seguinte redação:

“Art. 151. Para fiscalizar e superintender a atuação do Ministério público, bem como para zelar pelos princípios institucionais, haverá um Conselho Superior, estruturado na forma de Lei Complementar.”

**Art. 2º** O Artigo 152 da Constituição do Estado do Amapá passa a vigorar com a seguinte estrutura e redação:

“SUBSEÇÃO I Do Ministério Público Junto ao Tribunal de Contas

**Art. 152.** O Ministério Público junto ao Tribunal de Contas do Estado, ao qual se aplicam os princípios institucionais da unidade, da indivisibilidade e da independência funcional, tendo como chefe o Procurador Geral de Contas, compõe-se de Procuradores de Contas.

**§ 1º** O Procurador Geral de Contas será nomeado pelo Governador do Estado, sob critério de livre escolha, dentre os integrantes do quadro.

**§ 2º** Aos membros do Ministério Público junto ao Tribunal de Contas, aplicam-se as disposições desta Seção, no que se refere a direitos, vedações e formas de investidura.”

**Art. 3º** Esta emenda à Constituição entra em vigor na data de sua publicação, revogando-se as disposições em contrário.

Macapá - AP, 29 de março de 1994.

A Mesa da Assembleia Legislativa: Júlio Miranda – Presidente; Amiraldo Favacho - 1º Vice-Presidente; Regildo Salomão - 2º Vice-Presidente; Antônio Teles - Secretário Geral; Manoel Brasil - 1º Secretário; Lucas Barreto - 2º Secretário.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 156

EMENDA À CONSTITUIÇÃO Nº 0009, DE 28 DE AGOSTO DE 1997 Publicada no Diário Oficial do Estado nº 1643, de 09.09.97

Dá nova redação ao Parágrafo único do artigo 79 e acrescenta o art. 55 ao Ato das Disposições Constitucionais Transitórias da Constituição do Estado do Amapá.

A Mesa Diretora da Assembleia Legislativa do Estado do Amapá faz saber que a Assembleia Legislativa do Estado do Amapá aprovou e ela promulga a seguinte Emenda à Constituição:

**Art. 1º** O Parágrafo único do art. 79 da Constituição do Estado do Amapá passa a vigorar com a seguinte redação:

“Art. 79. ...............................................................................

**Parágrafo único.** Os vencimentos dos Delegados de Polícia Civil não serão inferiores aos percebidos pelas carreiras a que se refere o art. 135 da Constituição Federal, observada, para esse efeito, a correlação entre as respectivas classes e entrâncias e assegurada a revisão de remuneração, em igual percentual, sempre que forem revistos aqueles”

**Art. 2º** Fica acrescentado o artigo 55 ao Ato das Disposições Constitucionais Transitórias da Constituição do Estado do Amapá, com a seguinte redação:

“Art. 55. Lei Complementar disciplinará o disposto no

**Parágrafo único** do art. 79 desta Constituição, no prazo máximo de 60 (sessenta) dias, assegurando aos Delegados de Polícia de carreira, isonomia de vencimentos com as carreiras de Procuradores ou de Defensores Públicos do Estado”.

A Mesa da Assembleia Legislativa: Júlio Miranda – Presidente; Amiraldo Favacho - 1º Vice-Presidente; Regildo Salomão - 2º Vice-Presidente; Antônio Teles - Secretário Geral; Manoel Brasil - 1º Secretário; Lucas Barreto - 2º Secretário.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 157

EMENDA À CONSTITUIÇÃO Nº 0010, DE 19 DE DEZEMBRO DE 1997 Publicada no Diário Oficial do Estado nº 1718, de 31.12.97

Acrescenta o art. 56 ao ADCT da Constituição do Estado.

A Mesa Diretora da Assembleia Legislativa do Estado do Amapá faz saber que a Assembleia Legislativa do Estado do Amapá aprovou e ela promulga a seguinte Emenda à Constituição:

Artigo único. Fica acrescentado à Constituição do Amapá, com a seguinte redação:

“Art. 56. A desativação de empresas industriais e comerciais com atividades no Estado do Amapá, implantadas por meio de contrato ou concessão do Poder Público, utilizando recursos do solo, subsolo e meio hídrico, e gozando de doações, isenções, incentivos ou subsídios de quaisquer espécies, observará:

I - O acordo de negociação para a desativação das empresas, qualquer que seja a natureza e que envolva o Estado do Amapá, será objeto de apreciação e deliberação da Assembleia legislativa.

II - Para acompanhar os trabalhos de desativação das empresas, a Assembleia Legislativa designará uma Comissão especial composta de cinco (05) Deputados Estaduais.

III - O Ministério Público designará (02) dois representantes, a convite da Assembleia legislativa, para acompanharem os trabalhos de desativação da Empresa.

IV - Os bens e benfeitorias que vierem a ser deixados pelos complexos operacionais das empresas desativadas, serão destinados, preferencialmente, para os municípios que os sediarem, mediante plano de ação conjunto das prefeituras municipais envolvidas e com interveniência do governo do estado do Amapá.

**Parágrafo único.** A infraestrutura sócioeconômica localizada no município de Serra do navio, implantada pela ICOMI – Indústria e Comércio de Minérios S/A e a ser revertida ao Poder Público, destinar-se-á, também, à instalação e desenvolvimento de atividades de entidades públicas de pesquisas científico-tecnológica e de extensão próprias do ensino superior.”

Macapá - AP, 12 de dezembro de 1997.

A Mesa da Assembleia Legislativa: Júlio Miranda – Presidente; Amiraldo Favacho - 1º Vice-Presidente; Regildo Salomão - 2º Vice-Presidente; Antônio Teles - Secretário Geral; Manoel Brasil - 1º Secretário; Lucas Barreto - 2º Secretário.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 158

EMENDA À CONSTITUIÇÀO Nº 0011, DE 11 DE NOVEMBRO DE 1998 Publicada no Diário Oficial do Estado nº 1948, de 10.12.98

Altera a redação do art. 132 da Constituição do Estado do Amapá e dá outras providências.

A Mesa Diretora da Assembleia Legislativa do Estado do Amapá faz saber que a Assembleia Legislativa do Estado do Amapá aprovou e ela promulga a seguinte Emenda à Constituição:

**Art. 1º** O artigo 132 da Constituição do Estado do Amapá passa a vigorar com a seguinte redação.

“Art. 132. O Tribunal de Justiça, com sede na Capital e jurisdição em todo o Território do Estado, compõe-se de, no mínimo, sete desembargadores”.

**Art. 2º** Esta Emenda Constitucional entra em vigor na data de sua publicação.

Macapá - AP, 19 de novembro de 1998.

A Mesa da Assembleia Legislativa: Júlio Miranda – Presidente; Amiraldo Favacho - 1º Vice-Presidente; Regildo Salomão - 2º Vice-Presidente; Antônio Teles - Secretário Geral; Manoel Brasil - 1º Secretário; Lucas Barreto - 2º Secretário.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 159

EMENDA À CONSTITUIÇÃO Nº 0012, DE 24 DE SETEMBRO DE 1999 Publicada no Diário Oficial do Estado nº 2144, de 28.09.99

Altera a redação dos artigos 175 e 180 da Constituição do Estado do Amapá.

A Mesa Diretora da Assembleia Legislativa do Estado do Amapá faz saber que a Assembleia Legislativa do Estado do Amapá aprovou e ela promulga a seguinte Emenda à Constituição:

**Art. 1º** Os artigos 175 e 180 da Constituição do Estado do Amapá passam a vigorar com a seguinte redação.

“Art. 175. ......................................

**§ 1º** ..............................................

**§ 2º** O Projeto de Lei do Plano Plurianual, para vigência até o final do primeiro exercício financeiro do mandato do Governador do Estado, subsequente, será encaminhado até 04 (quatro) meses antes do encerramento do primeiro exercício financeiro e devolvido para sanção até o encerramento da Sessão Legislativa.

**§ 3º** O não encaminhamento do Projeto de Lei do Plano Plurianual no prazo previsto no parágrafo anterior implicará em crime de responsabilidade do Governador do Estado.

**Art. 180.** A Assembleia Legislativa elaborará a Proposta Orçamentária Anual do Poder Legislativo, nela incluída a dotação do Tribunal de Contas, cujo montante de recursos obedecerão aos limites previstos na Lei de Diretrizes Orçamentárias – LDO, encaminhando-a para inclusão obrigatória no Projeto de Lei Orçamentária Anual até o dia 31 de agosto de cada ano.

**Parágrafo único.** As propostas Orçamentárias do Poder Judiciário e Ministério Público, para inclusão obrigatória no Projeto de Lei Orçamentária Anual, também deverão ser encaminhadas ao Poder Executivo até a data prevista no caput deste artigo.”

**Art. 2º** Esta Emenda Constitucional entra em vigor na data de sua publicação.

Macapá - AP, 24 de setembro de 1999.

A Mesa da Assembleia Legislativa: Fran Júnior – Presidente; Alexandre Torrinha - 1º Vice-Presidente; Jorge Salomão - 2º Vice-Presidente; Alexandre Barcellos - Secretário Geral; Manoel Brasil - 1º Secretário; Hildo Fonseca - 2º Secretário.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 160

EMENDA À CONSTITUIÇÃO Nº 0013, DE 29 DE SETEMBRO DE 1999 Publicada no Diário Oficial do Estado nº 2148, de 04.10.99

Altera a redação do inciso IV, acrescenta o

**§1º** e transforma o Parágrafo Único em § 2º do Art. 56 das Disposições Constitucionais Transitórias da Constituição do Estado do Amapá.

A Mesa Diretora da Assembleia Legislativa do Estado do Amapá faz saber que a Assembleia Legislativa do Estado do Amapá aprovou e ela promulga a seguinte Emenda à Constituição:

**Art. 1º** Altera a redação do inciso IV, acrescenta o § 1 e transforma o

**Parágrafo único** em § 2º, das Disposições Constitucionais Transitórias da Constituição do Estado do Amapá, passando a vigorar com a seguinte redação:

“Art. 56. ........................................

IV - Todos os bens móveis e imóveis que vierem a ser deixados pelos complexos operacionais das empresas desativadas serão destinados para os municípios que os sediarem.

**§ 1º** Os bens que ocuparem espaços territoriais de mais de um município serão destinados ao Estado do Amapá.

**§ 2º** ............................................”

**Art. 2º** Esta Emenda Constitucional entra em vigor na data de sua publicação.

Macapá - AP, 29 de agosto de 1999.

A Mesa da Assembleia Legislativa: Fran Júnior – Presidente; Alexandre Torrinha - 1º Vice-Presidente; Jorge Salomão - 2º Vice-Presidente; Alexandre Barcellos - Secretário Geral; Manoel Brasil - 1º Secretário; Hildo Fonseca - 2º Secretário.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 161

EMENDA À CONSTITUIÇÃO Nº 0014, DE 20 DE DEZEMBRO DE 1999 Publicada no Diário Oficial do Estado nº 2201, de 24.12.99

Altera dispositivos da Constituição do Estado do Amapá.

A Mesa Diretora da Assembleia Legislativa do Estado do Amapá faz saber que a Assembleia Legislativa do Estado do Amapá aprovou e ela promulga a seguinte Emenda à Constituição:

**Art. 1º** Os dispositivos da Constituição do Estado do Amapá, a seguir mencionados, passam a vigorar com a seguinte redação:

“Art. 1º O Estado do Amapá integrante da República Federativa do Brasil, rege-se por esta Constituição e pelas leis que adotar, observado os princípios da Constituição Federal, nos limites de sua autonomia e no território de sua jurisdição. ........................................................

**Art. 2º** ..........................................

IV - respeito aos princípios da legalidade, impessoalidade, moralidade, publicidade e eficiência. ........................................................

**Art. 17.** ..........................................

V - organizar e prestar, diretamente ou sob regime de concessão ou permissão, os serviços públicos de interesse local, incluído o de transporte coletivo que tem caráter essencial, o de táxi convencional e o transporte alternativo de moto-taxi, que poderão ser explorados diretamente, por empresas públicas, sociedade de economia mista ou entidade de classe, submetidas ao regime jurídico das empresas privadas. ........................................................

XIV - conceder, com a colaboração técnica e financeira de entidades representativas do transporte coletivo, transporte gratuito a estudantes de estabelecimentos de ensino situado no Município, na forma da lei. ........................................................

**Art. 24.** Os recursos correspondentes às dotações previstas no orçamento anual, compreendidos os créditos suplementares e especiais, destinadas ao Poder Legislativo Municipal, ser-lhes-ão entregues até o dia vinte de cada mês, sob pena de crime de responsabilidade do Prefeito Municipal. ........................................................

**Art. 26.** Os subsídios do Prefeito, do Vice-Prefeito e dos Secretários Municipais serão fixados por lei de iniciativa da Câmara Municipal, observado o que dispõe os Arts. 42, XI, 47, § 4º, desta Constituição e os Arts. 150, II,153, II e 153,

§ 2º, I da constituição Federal.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 162

........................................................

**§ 1º** Os subsídios dos Vereadores serão fixados por lei de iniciativa da Câmara Municipal, nos limites estabelecidos pela Constituição Federal.

**§ 2º** A remuneração dos servidores municipais e os subsídios a que trata este artigo, somente poderão ser fixados ou alterados por Lei específica, observada iniciativa privativa em cada caso, assegurada revisão geral anual, sempre na mesma data e sem distinção de índices.

**Art. 27.** As Câmaras municipais terão o número de Vereadores proporcional à população do Município, observados os seguintes limites:

I - até dez mil habitantes, nove Vereadores;

II - de dez mil e um a vinte mil habitantes, onze Vereadores;

III - de vinte e um a trinta mil habitantes, treze Vereadores;

IV - de trinta mil e um a cem mil habitantes, quinze Vereadores;

V - de cinquenta mil e um a cem mil habitantes, dezessetes Vereadores;

VI - de cem mil e um a duzentos e cinquenta mil habitantes dezenove Vereadores;

VII - de duzentos e cinquenta mil e um a um milhão de habitantes, vinte e um Vereadores;

**Parágrafo único.** O aumento do número de vagas de que trata este artigo, não implicará em aumento dos percentuais constitucionais devido às Câmaras Municipais. ..........................................................

**Art. 31.** ..............................................

**§ 1º** Ocorrendo a vacância dos últimos dois anos do mandato do Prefeito, a eleição para ambos os cargos será feita trinta dias depois da última vaga, pela Câmara Municipal, na forma da lei.

**§ 2º** Em qualquer dos casos os substitutos deverão completar o período de seus antecessores. ..........................................................

**Art. 35.** A criação, a incorporação, a fusão e o desmembramento de Municípios far-se-á por Lei Estadual, dentro do período determinado por lei complementar federal, obedecendo aos seguintes requisitos:

I - consulta prévia, mediante plebiscito, às populações dos Municípios envolvidos, após divulgação dos estudos de viabilidade Municipal, apresentados e publicados na forma da lei. ..........................................................

**§ 8º** O Plebiscito para criação de Município poderá ser realizado por ocasião da realização de eleição municipal, na forma disciplinada pelo Tribunal Regional Eleitoral. ...........................................................

**Art. 42.** A administração pública direta e indireta de qualquer dos Poderes do Estado e dos Municípios,

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 163

obedecerá aos princípios da legalidade, impessoalidade, moralidade, publicidade e eficiência e, também o seguinte:

I - os cargos, empregos e funções públicas são acessíveis aos brasileiros que preencham os requisitos estabelecidos em Lei, assim como aos estrangeiros, na forma da Lei;

II - a investidura em cargo ou emprego público depende de aprovação prévia em concurso público de provas ou de provas e títulos, de acordo com a natureza e a complexidade do cargo ou emprego, na forma prevista em Lei, ressalvadas as nomeações para cargos em comissão declarado em Lei de livre nomeação e exoneração; .............................................................

V - as funções de confiança, exercidas exclusivamente por servidores ocupantes de cargo efetivo, e os cargos em comissão, a serem preenchidos por servidores de carreira nos casos, condições e percentuais mínimos previstos em Lei, destina-se apenas às atribuições de direção, chefia e assessoramento. .............................................................

VII - o direito de greve será exercido nos termos e nos limites definidos em Lei específica;

X - a remuneração dos servidores públicos estaduais e o subsídio de que trata o § 4º do Art. 47, somente poderão ser fixados ou alterados por lei específica, observada a iniciativa privativa em cada caso, assegurada revisão geral anual, sempre na mesma data e sem distinção de índices;

XI - a remuneração e o subsídio dos ocupantes de cargos, funções e empregos públicos da administração direta, autárquica e fundacional, dos membros de qualquer dos Poderes do Estado e dos Municípios, dos detentores de mandato eletivo e dos demais agentes políticos e os proventos, pensões ou outra espécie remuneratória, percebidos cumulativamente ou não, incluídas as vantagens pessoais ou de qualquer outra natureza, não poderão exceder o subsídio mensal, em espécie, dos Desembargadores do Tribunal de Justiça do Estado;

XII - é vedada a vinculação ou equiparação de quaisquer espécies remuneratórias para efeito de remuneração de pessoal do serviço público;

XIII - os acréscimos pecuniários percebidos por servidor público não serão computados nem acumulados para fim de concessão de acréscimos ulteriores;

XIV - o subsídio e os vencimentos dos ocupantes de cargos e empregos públicos são irredutíveis, ressalvado o disposto nos incisos XI e XIII deste artigo, no § 4º do art. 47 e nos arts. 150, II, 153, III e 153, § 2º, I, da Constituição Federal;

XV - é vedada a acumulação remunerada de cargos públicos, exceto, quando houver compatibilidade de

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 164

horários, observado em qualquer caso o disposto no inciso XI;

XVI - a proibição de acumular estende-se a empregos e funções e abrange autarquias, fundações, empresas públicas, sociedades de economia mista, suas subsidiárias, e sociedades controladas, direta ou indiretamente, pelo poder público; .......................................................

**§ 5º** O servidor aposentado, no exercício de mandato eletivo ou de cargo em comissão ou quando contratado para prestação de serviços públicos, poderá perceber a remuneração dessas atividades acumulada com os proventos da aposentadoria, respeitado o limite previsto no inciso XI, do art. 42. ........................................................

**§ 7º** A Lei disciplinará as formas de participação do usuário na administração pública direta e indireta, regulando especialmente:

I - as reclamações relativas à prestação dos serviços públicos em geral, assegurada a manutenção de serviço de atendimento ao usuário e a avaliação periódica, externa e interna, da qualidade dos serviços;

II - o acesso dos usuários a registros administrativos e à informação sobre atos do Governo, observado o disposto no art. 5º, X e XXXIII, da Constituição Federal;

III - a disciplina da representação contra o exercício negligente ou abusivo de cargo, emprego ou função na administração pública. ............................................................

**Art. 43.** As leis e os atos administrativos de efeitos externos, do Poder Executivo e do Poder Legislativo, serão obrigatórios e gratuitamente publicados no órgão oficial do Estado, para que produzam os seus efeitos regulares, podendo ser resumida a publicação dos atos normativos. ........................................................

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 165

##### SEÇÃO II Dos Servidores Públicos

**Art. 47.** O Estado e os Municípios instituirão conselho de política de administração e remuneração de pessoal, integrado por servidores designados pelos respectivos poderes.

**§ 1º** A fixação dos padrões de vencimentos e dos demais componentes do sistema remuneratório observará:

I - a natureza, o grau de responsabilidade e a complexidade dos cargos componentes de cada carreira;

II - os requisitos para investidura;

III - a peculiaridade dos cargos.

**§ 2º** O Estado manterá escolas de governo para a formação e o aperfeiçoamento dos servidores públicos, constituindo- se a participação nos cursos um dos requisitos para promoção na carreira, facultada, para isso, a celebração de convênios ou contratos entre os entes federados. ..........................................................

**§ 3º** Aplicam-se aos servidores ocupantes de cargos públicos o disposto no art. 7º, IV, VII, VIII, IX, XII, XIII, XV, XVI, XVII, XVIII, XIX, XX, XXII e XXX, da Constituição Federal, podendo a lei estabelecer requisitos diferenciados de admissão quando a natureza do cargo o exigir.

**§ 4º** O membro de Poder, o detentor de mandato eletivo, os Secretários Estaduais e Municipais serão remunerados exclusivamente por subsídio fixado em parcela única, vedado o acréscimo de qualquer gratificação, adicional, abono, prêmio, verba de representação ou outra espécie remuneratória, obedecido em qualquer caso, o disposto no

art. 42, X e XI.

**§ 5º** Lei do Estado e dos Municípios poderão estabelecer a relação entre a maior e a menor remuneração dos servidores públicos estaduais e municipais, obedecido em qualquer caso, o disposto no art. 42, XI.

**§ 6º** Os Poderes Executivo, Legislativo e Judiciário publicarão anualmente os valores do subsídio e da remuneração dos cargos e empregos públicos.

**§ 7º** Lei do Estado e do Município disciplinarão a aplicação de recursos orçamentários provenientes da economia com despesas correntes em cada órgão, autarquia e fundação, para aplicação no desenvolvimento de programas de qualidade e produtividade, treinamento e desenvolvimento, modernização, reaparelhamento e racionalização do serviço público, inclusive sob a forma de adicional ou prêmio de produtividade.

**§ 8º** A remuneração dos servidores públicos organizados em carreira poderá ser fixado nos termos do § 4º. ......................................................

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 166

**Art. 55.** Aplicam-se aos servidores estaduais, para efeito do regime de previdência e aposentadoria, o disposto no

art. 40 e seus parágrafos, da Constituição Federal. .......................................................

**Art. 61.** O benefício da pensão por morte será concedido, atendendo-se ao prescrito no § 7º, do art. 40 da Constituição Federal. ........................................................

**Art. 65.** Os servidores estaduais e municipais que ocupavam empregos transformados em cargos públicos por Lei Estadual ou Municipal, passaram automaticamente à condição de servidores públicos estatutários, na data da publicação das respectivas Leis, usufruindo, desde então, de todos os direitos e vantagens inerentes ao novo regime. ...........................................................

**Art. 67.** .............................................

**§ 9º** Aplica-se aos servidores a que se refere este artigo, o disposto no art. 40, §§ 7º e 8º, da Constituição Federal. ...........................................................

**Art. 94.** ............................................

XIII - Fixação dos subsídios dos membros do Poder Judiciário, do Ministério Público e dos servidores auxiliares, observado o que dispõe os Art. 42, XI e 47, 4º, desta Constituição e 150, II, 152,III e 153, § 2º, I, da Constituição Federal. ......................................................

**Art. 95.** .............................................

II - dispor, através de Resolução, sobre sua organização, funcionamento, polícia, criação, transformação ou extinção dos cargos, empregos e funções de seus serviços, e a iniciativa de lei para a fixação da respectiva remuneração, observados os parâmetros estabelecidos na lei de Diretrizes Orçamentárias. .......................................................

XII - fixar através de lei especifica, os subsídios:

a) do Governador, do Vice-Governador e dos Secretários de Estado, observado o que dispõe os Art. 42,XI e 47, 4º, desta Constituição, e 150, II,152,II, e 153, § 2º, I da Constituição Federal;

b) dos Deputados Estaduais, observado o que dispõe os art. 42, XI e 47, 4º desta Constituição, e os arts. 150, II, 152, II, e 153, § 2º, I, da Constituição Federal;

**Art. 102.** .........................................

**Parágrafo único.** Lei Complementar disporá sobre a elaboração, alteração e consolidação das leis. .......................................................

**Art. 111.** .......................................

**§ 2º** Prestará contas qualquer pessoa física ou jurídica, pública ou privada que utilize, arrecade, guarde, gerencie ou administre dinheiro, bens e valores públicos ou pelos

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 167

quais o Estado responda, ou que, em nome deste, assuma obrigações de natureza pecuniária.

**Art. 117.** A eleição do Governador e do Vice-Governador do Estado, para mandato de 4 (quatro anos) realizar-se-á no primeiro Domingo de outubro, em primeiro turno, e no último Domingo de outubro, em segundo turno, se houver, do ano anterior ao término do mandato de seus antecessores, e a posse ocorrerá em primeiro de janeiro do ano subsequente, observado, quanto aos mais, o disposto no art. 77, da Constituição Federal. .......................................................

**Art. 118.** O Governador e o Vice-Governador do Estado e quem os houver sucedido ou substituído no curso do mandato poderão ser reeleitos para um único período subsequente de quatro anos. ...........................................................

**§ 5º** Vagando os cargos de Governador e Vice- Governador, far-se-á eleição noventa dias de abertura a última vaga.

**§ 6º** Ocorrendo a vacância nos últimos dois anos do período governamental, a eleição para ambos os cargos será feita trinta dias depois da última vaga, pela Assembleia Legislativa, na forma da lei.

**§ 7º** Em qualquer dos casos, os substitutos deverão completar o período de seus antecessores. ...........................................................

**Art. 125.** Ao Poder Judiciário é assegurada autonomia administrativa e financeira, competindo-lhe, participar, por convocação obrigatória de seu Presidente, de reunião conjunta com os demais Poderes, para a determinação dos índices a serem incluídos na Lei de Diretrizes Orçamentárias, nos termos do art. 99, § 1º, da Constituição Federal, sendo que essa reunião deverá realizar-se até 30 (trinta dias) antes do prazo previsto no § 5º, do art. 175. .........................................................

**Art. 175.** .........................................

**§ 1º** A Lei que instituir o plano plurianual estabelecerá, de forma setorizada e regionalizada, as Diretrizes, objetivos e metas da administração pública estadual direta e indireta, para as despesas de capital e outras delas decorrentes e para as relativas aos programas de duração continuada.

**§ 2º** O plano plurianual, cuja elaboração contará com a participação de entidades representativas da sociedade civil organizada e dos Municípios, será aprovado no primeiro ano de cada período de governo, submetido à apreciação da Assembleia Legislativa até o dia trinta e um de agosto, sob pena de crime de responsabilidade do Governador do Estado.

**§ 3º** Nenhum investimento cuja execução ultrapasse um exercício financeiro poderá ser iniciado sem prévia inclusão

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 168

no plano plurianual, ou sem lei que autorize sua inclusão, sob pena de crime de responsabilidade.

**§ 4º** A Lei de Diretrizes Orçamentária anual compreenderá as metas e prioridades da administração pública estadual, direta e indireta, incluindo as despesas de capital para o exercício financeiro subsequente, orientará a elaboração da Lei Orçamentária anual, disporá sobre as alterações na legislação tributária, estabelecerá a política de aplicação das agências financeiras oficiais de fomento e estabelecerá os limites para a elaboração das propostas Orçamentárias dos Poderes Legislativo, Judiciário e do Ministério Público.

**§ 5º** O Projeto de Lei das Diretrizes Orçamentárias será encaminhado à Assembleia legislativa até 30 (trinta) de abril, para apreciação até 30 (trinta) de junho.

**§ 6º** O Poder Executivo publicará até trinta dias após o encerramento de cada bimestre, relatório resumido da execução Orçamentária.

**§ 7º** Os planos e programas estaduais, regionais e setoriais previstos nesta Constituição serão elaborados em consonância com o plano plurianual, apreciado e aprovado pela Assembleia Legislativa, que criará mecanismos de fiscalização adequada para sua fiel observância.

**§ 8º** A lei Orçamentária anual compreenderá:

I - O Orçamento fiscal, fixando as despesas referentes aos poderes estaduais, seus fundos, órgãos e entidades da administração direta e indireta, estimando as receitas do Estado, efetivas e potenciais, incluídas as renúncias fiscais a qualquer título.

II - O orçamento de seguridade social, abrangendo todos os órgãos e entidades a ela vinculados, da administração direta e indireta, bem como os fundos e fundações instituídos e mantidos pelo poder público.

III - Os orçamentos de investimentos das empresas públicas e daquelas em que o Estado, direta ou indiretamente, detenha a maioria do capital social com direito a voto.

**§ 9º** Os orçamentos previstos no § 8º, I, II e III deste artigo deverão ser elaborados em consonância com as políticas de desenvolvimento urbano, rural e regional integrantes do plano plurianual.

**§ 10** O Projeto de Lei Orçamentária anual será remetido à Assembleia Legislativa até o dia trinta de setembro, acompanhado de demonstrativo dos efeitos sobre as receitas e despesas públicas decorrentes da concessão de quaisquer benefícios de natureza financeira, tributária e creditícia pela administração pública estadual, detalhados de forma regionalizada e identificados os objetivos de referidas concessões.

**§ 11** A lei Orçamentária anual não conterá dispositivos estranhos à previsão da receita e à fixação da despesa,

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 169

não se incluindo na proibição a autorização para abertura de créditos suplementares e de operações de créditos, ainda que por antecipação da receita, nos termos da lei."

**Art. 2º** Esta Emenda Constitucional entra em vigor na data de sua promulgação.

Macapá - AP, 20 de dezembro de 1999.

A Mesa da Assembleia Legislativa: Fran Júnior – Presidente; Alexandre Torrinha - 1º Vice-Presidente; Jorge Salomão - 2º Vice-Presidente; Alexandre Barcellos - Secretário Geral; Manoel Brasil - 1º Secretário; Hildo Fonseca - 2º Secretário.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 170

EMENDA À CONSTITUIÇÃO Nº 0015, DE 24 DE MAIO DE 2000 Publicada no Diário Oficial do Estado nº 2308, de 31.05.00

Altera o inciso XIV do Art. 119 e acrescenta o inciso VI ao Art. 123 da Constituição do Estado do Amapá.

A Mesa Diretora da Assembleia Legislativa do Estado do Amapá faz saber que a Assembleia Legislativa do Estado do Amapá aprovou e ela promulga a seguinte Emenda à Constituição:

**Art. 1º** O inciso XIV do Art. 119 da Constituição do Estado do Amapá passa a ter a seguinte redação:

"Art. 119. .......................................

XIV - prestar, por escrito, as informações solicitadas pelos Poderes Legislativo e Judiciário, no prazo de trinta dias, salvo se outro for determinado por Lei Federal,”

**Art. 2º** Acrescentar o inciso VI ao Art. 123 da Constituição do Estado do Amapá com a seguinte redação:

“Art. 123. .......................................

VI - dar resposta, nos termos e prazos estabelecidos no inciso XXVI do Art. 95, às solicitações de serviços e obras impetradas pelos Poderes Legislativo e Judiciário.”

**Art. 3º** Esta Emenda Constitucional entra em vigor na data de sua promulgação.

Macapá - AP, 24 de maio de 2000.

A Mesa da Assembleia Legislativa: Fran Júnior – Presidente; Alexandre Torrinha - 1º Vice-Presidente; Jorge Salomão - 2º Vice-Presidente; Alexandre Barcellos - Secretário Geral; Manoel Brasil - 1º Secretário; Hildo Fonseca - 2º Secretário.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 171

EMENDA À CONSTITUIÇÃO Nº 0016, DE 20 DE JUNHO DE 2000 Publicada no Diário Oficial do Estado nº 2326, de 27.06.00

Dá nova redação ao § 7º do Art. 67 da Constituição do Estado do Amapá.

A Mesa Diretora da Assembleia Legislativa do Estado do Amapá faz saber que a Assembleia Legislativa do Estado do Amapá aprovou e ela promulga a seguinte Emenda à Constituição:

Artigo único. O § 7º do Art. 67 da Constituição do Estado do Amapá passa a vigorar com a seguinte redação:

"Art. 67. omissis ...

**§ 7º** Será transferido para a reserva remunerada o Comandante Geral da Polícia Militar e do Corpo de Bombeiro Militar, com todos os direitos e vantagens do cargo, na forma da Lei.”

Macapá - AP, 20 de junho de 2000.

A Mesa da Assembleia Legislativa: Fran Júnior – Presidente; Alexandre Torrinha - 1º Vice-Presidente; Jorge Salomão - 2º Vice-Presidente; Alexandre Barcellos - Secretário Geral; Manoel Brasil - 1º Secretário; Hildo Fonseca - 2º Secretário.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 172

EMENDA À CONSTITUIÇÃO Nº 0017, DE 03 DE JULHO DE 2000 Publicada no Diário Oficial do Estado n 2332, de 05.07.00

Modifica a redação do Art. 43 e acrescenta os §§ 1º e 2º ao mesmo artigo, da Constituição do Estado do Amapá.

A Mesa Diretora da Assembleia Legislativa do Estado do Amapá faz saber que a Assembleia Legislativa do Estado do Amapá aprovou e ela promulga a seguinte Emenda à Constituição:

Artigo único. O artigo 43 da Constituição do Estado passa a ter a seguinte redação com os parágrafos que se seguem:

“Art. 43. As leis, os atos normativos e administrativos dos Poderes Executivo, Legislativo, Judiciário e Ministério Público serão, obrigatória e gratuitamente, publicados no Diário Oficial do Estado, para que produzam seus regulares e legais efeitos.

**§ 1º** Os atos não normativos poderão ter reduzida sua publicação.

**§ 2º** Os Poderes Legislativo e Judiciário poderão instituir, mediante Resolução, o Diário Legislativo e o Diário do Judiciário, para publicação específica dos atos de sua competência, sem embargo da publicação obrigatória das leis e atos normativos referida no caput deste artigo.”

Macapá - AP, 03 de julho de 2000.

A Mesa da Assembleia Legislativa: Fran Júnior – Presidente; Alexandre Torrinha - 1º Vice-Presidente; Jorge Salomão - 2º Vice-Presidente; Alexandre Barcellos - Secretário Geral; Manoel Brasil - 1º Secretário; Hildo Fonseca - 2º Secretário.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 173

EMENDA À CONSTITUIÇÃO Nº 0018, DE 04 DE JULHO DE 2000 Publicada no Diário Oficial do Estado nº 2340, de 17.07.00

Dá nova redação ao art. 120 e seu

Parágrafo único, da Constituição do Estado do Amapá.

A Mesa Diretora da Assembleia Legislativa do Estado do Amapá faz saber que a Assembleia Legislativa do Estado do Amapá aprovou e ela promulga a seguinte Emenda à Constituição:

Artigo único. O artigo 120 e seu Parágrafo único, da Constituição do Estado do Amapá, passam a vigorar com a seguinte redação:

“Art. 120. São crimes de responsabilidade do Governador do Estado, os definidos no art. 85 da Constituição da República e os previstos na legislação federal.

**Parágrafo único.** As normas de processo e julgamento são as definidas na legislação federal e no Regimento Interno da Assembleia Legislativa.”

Macapá - AP, 04 de julho de 2000.

A Mesa da Assembleia Legislativa: Fran Júnior – Presidente; Alexandre Torrinha - 1º Vice-Presidente; Jorge Salomão - 2º Vice-Presidente; Alexandre Barcellos - Secretário Geral; Manoel Brasil - 1º Secretário; Hildo Fonseca - 2º Secretário.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 174

EMENDA À CONSTITUIÇÃO Nº 0019, DE 22 DE NOVEMBRO DE 2000 Publicada no Diário Oficial da Assembleia Legislativa do Estado nº 61, de 27.11.00 (Publicada no Diário Oficial da Assembleia Legislativa nº 71, de 12.12.00; Republicada no Diário Oficial da Assembleia Legislativa nº 77, de 20.12.00; Revogada pela Emenda à Constituição nº 0022, de 18 de janeiro de 2001) Autor: Mesa Diretora

Acrescenta o § 8º ao art. 113, com a redação dada pela Emenda à Constituição nº 0005, de 21 de março de 1996, e o art. 57 ao Ato das Disposições Constitucionais da Constituição do Estado do Amapá.

A Mesa Diretora da Assembleia Legislativa do Estado do Amapá faz saber que a Assembleia Legislativa do Estado do Amapá aprovou e ela promulga a seguinte Emenda à Constituição:

**Art. 1º** Fica acrescentado o § 8º ao art. 113, com a redação dada pela

Emenda à Constituição nº 0005, de 21 de março de 1996, da Constituição do Estado do Amapá, com a seguinte redação:

“Art. 113. ..............................................................

**§ 8º** O Tribunal de Contas do Estado do Amapá será administrado pelo Presidente e Vice-Presidente, com mandato de dois anos, eleitos pelos Conselheiros, a ter início em 1º de março, cuja escolha dar-se-á dez dias antes do início do mandato".

**Art. 2º** Fica acrescentado o art. 57 ao Ato das Disposições Constitucionais Transitórias da Constituição do Estado do Amapá, com a seguinte redação:

“Art. 57. O mandato da atual administração do Tribunal de Contas do Estado do Amapá se estenderá até a data estabelecida no § 8º do art. 113 da Constituição do Estado.”

Macapá - AP, 22 de novembro de 2000.

A Mesa da Assembleia Legislativa: Jorge Salomão - Presidente em exercício; Alexandre Barcellos - 2º Vice-Presidente; Hildo Fonseca - 1º Secretário; Roberto Góes - 2º Secretário; Edinho Duarte - 3º Secretário; Geraldo Rocha - 4º Secretário.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 175

EMENDA À CONSTITUIÇÃO Nº 0020, DE 12 DE DEZEMBRO DE 2000 (Publicada no Diário Oficial da Assembleia Legislativa nº 71, de 12.12.00; Republicada no Diário Oficial da Assembleia Legislativa nº 77, de 20.12.00; Revogada pela Emenda à Constituição nº 0022, de 18 de janeiro de 2001)

Acrescenta o § 5º com os incisos I e II, ao

art. 112, § 8º ao art. 113, modifica a redação do § 1º do art. 152, e revoga a

Emenda à Constituição nº 19, de 22/11/2000, da Constituição do Estado do Amapá.

A Mesa Diretora da Assembleia Legislativa do Estado do Amapá faz saber que a Assembleia Legislativa do Estado do Amapá aprovou e ela promulga a seguinte Emenda à Constituição:

**Art. 1º** Ficam acrescentados o § 5º com os incisos I e II, ao art. 112 da Constituição do Estado do Amapá, com a seguinte redação:

“Art. 112. .....................................................

**§ 5º** Compete, ainda, ao Tribunal de Contas:

I – eleger seus órgãos diretivos 30 (trinta) dias antes do término dos respectivos mandatos, assim o Presidente e o Vice-Presidente, que serão sempre de dois anos, contados do dia 1º de março logo seguinte ao mandato extinto. A Corregedoria será exercida pelo Vice-Presidente;

II – elaborar seu Regimento Interno, com observância às normas desta Constituição, às leis e às normas de processo e garantias das partes, onde deverão ficar dispostas as matérias atinentes à competência e funcionamento de seus órgãos administrativos, assim também a organização de sua secretária, câmaras e serviços internos."

**Art. 2º** Fica acrescentado o § 8º ao art. 113 da Constituição do Estado do Amapá, com a seguinte redação:

“§ 8º A fiscalização contábil, financeira, orçamentária, operacional e patrimonial do Tribunal de Contas do Estado será exercida pela Assembleia Legislativa, na forma definida no seu Regimento Interno.”

**Art. 3º** O § 1º do art. 152 da Constituição do Estado do Amapá passa a vigorar com a seguinte redação:

“§ 1º O Procurador-Geral de Contas será nomeado pelo Presidente da Assembleia Legislativa dentre os integrantes do quadro, após aprovação pelo Plenário do Tribunal, para mandato de dois anos.”

**Art. 4º** Fica revogada a Emenda à Constituição nº 19, de 22/11/2000.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 176

Macapá - AP, 12 de dezembro de 2000.

A Mesa da Assembleia Legislativa: Fran Júnior – Presidente; Jorge Salomão - 1º Vice-Presidente; Alexandre Barcellos - 2º Vice-Presidente; Hildo Fonseca - 1º Secretário; Roberto Góes - 2º Secretário; Edinho Duarte - 3º Secretário; Geraldo Rocha - 4º Secretário.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 177

EMENDA À CONSTITUIÇÃO Nº 0021, DE 12 DE DEZEMBRO DE 2000 Publicada no Diário Oficial do Estado nº 2469, de 25.01.01

Modifica a redação do Art. 146 da Constituição do Estado do Amapá.

A Mesa Diretora da Assembleia Legislativa do Estado do Amapá faz saber que a Assembleia Legislativa do Estado do Amapá aprovou e ela promulga a seguinte Emenda à Constituição:

Artigo único. O artigo 146 da Constituição do Estado passa a ter a seguinte redação:

“Art. 146. O Ministério Público do Estado tem como Chefe o Procurador Geral de Justiça, nomeado pelo Governador do Estado, dentre integrantes da carreira, indicados em lista tríplice, para mandato de dois anos, permitida a recondução.”

Macapá - AP, 12 de Dezembro de 2000.

A Mesa da Assembleia Legislativa: Fran Júnior – Presidente; Jorge Salomão - 1º Vice-Presidente; Alexandre Barcellos - 2º Vice-Presidente; Hildo Fonseca - 1º Secretário; Roberto Góes - 2º Secretário; Edinho Duarte - 3º Secretário; Geraldo Rocha - 4º Secretário.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 178

EMENDA CONSTITUCIONAL Nº 0022, DE 18 DE JANEIRO DE 2001 Publicada no Diário Oficial do Estado n 2465, de 19.01.01

Modifica o inciso IX do art. 94 e inciso II do

art. 109; Acrescenta o § 8º, com o inciso I, ao art. 113, modifica o § 1º do art. 152, e revoga a Emenda à Constituição n.º 0020, de 12/12/2000, da Constituição do estado do Amapá.

A Mesa Diretora da Assembleia Legislativa do Estado do Amapá faz saber que a Assembleia Legislativa do Estado do Amapá aprovou e ela promulga a seguinte Emenda à Constituição:

**Art. 1º** O inciso IX do artigo 94, da Constituição do Estado do Amapá, passa a vigorar com a seguinte redação:

“Art. 94. ..........................................................

IX - Organização administrativa e judiciária do Ministério Público, Procuradoria-Geral do Estado, e da Defensoria Pública.”

**Art. 2º** O Inciso II, do artigo 109 da Constituição do Estado do Amapá passa a vigorar com a seguinte redação:

“Art. 109. ..................................... ....................

II - Organização do Ministério Público, da Procuradoria- Geral do Estado, da Defensoria Pública e da Polícia Militar.”

**Art. 3º** Acrescenta o § 8, com o inciso I, ao artigo 113 da Constituição do Estado do Amapá com a seguinte redação:

“Art. 113. ........................................................

**§ 8º** Os Conselheiros elegerão o Presidente e o Vice- Presidente do Tribunal de Contas do Estado do Amapá, para mandato de dois anos, a ter início no dia 15 de março, cuja escolha dar-se-á até quinze dias antes do início do mandato.

I - No período compreendido entre o término do mandato da atual administração do Tribunal e o início da próxima, o Tribunal de Contas do Estado do Amapá, será dirigido pelo Conselheiro mais antigo no cargo.”

**Art. 4º** O § 1º do artigo 152 da Constituição do Estado do Amapá passa a vigorar com a seguinte redação:

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 179

“Art. 152. .......................................................

**§ 1º** O Procurador-Geral de Contas será nomeado pelo Presidente da Assembleia Legislativa por livre escolha, dentre os integrantes do quadro, para mandato de dois anos.”

**Art. 5º** Ficam invalidados todos os atos praticados que contrariem o estabelecido nesta Emenda Constitucional, especialmente os realizados com base no

**§ 10** do Art. 7º, da Lei Complementar n0 0010, de 20 de setembro de 1995, aplicados a presente transição.

**Art. 6º** Fica revogada a Emenda a Constituição nº 0020 de 12/12/2000.

Macapá - AP, 18 de Janeiro de 2001.

A Mesa da Assembleia Legislativa: Fran Júnior – Presidente; Jorge Salomão - 1º Vice-Presidente; Alexandre Barcellos - 2º Vice-Presidente; Hildo Fonseca - 1º Secretário; Roberto Góes - 2º Secretário; Edinho Duarte - 3º Secretário; Geraldo Rocha - 4º Secretário.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 180

EMENDA À CONSTITUIÇÃO Nº 0023, DE 18 DE JANEIRO DE 2001 Publicada no Diário Oficial do Estado nº 2470, de 26.01.01

Altera o inciso IV do artigo 223 da Constituição do Estado do Amapá.

A Mesa Diretora da Assembleia Legislativa do Estado do Amapá faz saber que a Assembleia Legislativa do Estado do Amapá aprovou e ela promulga a seguinte Emenda à Constituição:

Art. 1 O inciso IV do Art. 223 da Constituição do Estado do Amapá passa a ter a seguinte redação:

“Art. 223. ....................................

IV – Carteiros, Vigilantes, Policiais Civis, Policiais Militares e Bombeiro Militar em serviço e devidamente uniformizados;”

Art. 2 Esta Emenda Constitucional entre em vigor na data de sua publicação.

Macapá - AP, 18 de Janeiro de 2001.

A Mesa da Assembleia Legislativa: Fran Júnior – Presidente; Jorge Salomão - 1º Vice-Presidente; Alexandre Barcellos - 2º Vice-Presidente; Hildo Fonseca - 1º Secretário; Roberto Góes - 2º Secretário; Edinho Duarte - 3º Secretário; Geraldo Rocha - 4º Secretário.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 181

EMENDA À CONSTITUIÇÃO Nº 0024, DE 15 DE AGOSTO DE 2001 Publicada no Diário Oficial do Estado nº 2620, de 05.09.01

Acrescenta o § 3º ao artigo 153 da Constituição do Estado do Amapá.

A Mesa Diretora da Assembleia Legislativa do Estado do Amapá faz saber que a Assembleia Legislativa do Estado do Amapá aprovou e ela promulga a seguinte Emenda à Constituição:

**Art. 1º** Fica acrescentado o § 3º ao artigo 153 da Constituição do Estado do Amapá, com a seguinte redação:

“Art. 153. ... omissis ...

**§ 3º** Nos processos judiciais que versarem sobre atos praticados pelo Poder Legislativo, ou por sua administração, a representação do Estado caberá à Procuradoria Geral da Assembleia Legislativa, observado o que dispõe a parte final do caput do art. 115.”

**Art. 2º** Esta Emenda à Constituição entra em vigor na data de sua publicação.

Macapá - AP, 15 de agosto de 2001.

A Mesa da Assembleia Legislativa: Fran Júnior - Presidente; Eider Pena - 1º Vice- Presidente; Roberto Góes - 2º Vice-Presidente; Vital Andrade - 1º Secretário; Edinho Duarte - 2º Secretário; Jorge Salomão - 3º Secretário; Judith Medeiros - 4º Secretário.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 182

EMENDA À CONSTITUIÇÃO Nº 0025, DE 03 DE OUTUBRO DE 2001 Publicada no Diário Oficial do Estado nº 2639, de 04.10.01

Modifica o Inciso I, do § 2º, do art. 153 e acrescenta o parágrafo único ao art. 156, ambos da Constituição do Estado do Amapá.

A Mesa Diretora da Assembleia Legislativa do Estado do Amapá faz saber que a Assembleia Legislativa do Estado do Amapá aprovou e ela promulga a seguinte Emenda à Constituição:

**Art. 1º** O inciso I, do § 2º, do art. 153, da Constituição do Estado do Amapá, passa a ter a seguinte redação:

“Art. 153. .............................................................................

**§ 2º** ......................................................................................

I – ingresso nos cargos iniciais da carreira de procurador do Estado, através de concurso público de provas e títulos, realizado por comissão nomeada e presidida pelo Governador do Estado, assegurado a participação da Ordem dos Advogados do Brasil, Secção do Amapá e de membro do Ministério Público na sua realização e observada a ordem de classificação.”

**Art. 2º** Fica acrescentado o parágrafo único ao art. 156 da Constituição do Estado do Amapá que terá a seguinte redação:

“Art. 156. .............................................................................

**Parágrafo único.** O ingresso nos cargos iniciais da carreira de defensor público dar-se-á através de concurso público de provas e títulos, realizado por comissão nomeada e presidida pelo Governador do Estado, assegurado a participação da Ordem dos Advogados do Brasil, Secção do Amapá e do Ministério Público na sua realização e observada a ordem de classificação.”

**Art. 3º** Esta Emenda Constitucional entra em vigor na data de sua promulgação.

Macapá - AP, 03 de outubro de 2001.

A Mesa da Assembleia Legislativa: Fran Júnior - Presidente; Eider Pena - 1º Vice- Presidente; Roberto Góes - 2º Vice-Presidente; Vital Andrade - 1º Secretário; Edinho Duarte - 2º Secretário; Jorge Salomão - 3º Secretário; Judith Medeiros - 4º Secretário.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 183

EMENDA À CONSTITUIÇÃO Nº 0026, DE 27 DE FEVEREIRO DE 2002 Publicada no Diário Oficial do Estado nº 2738, de 06.03.02

Acrescenta o § 12 ao artigo 67 da Constituição do Estado do Amapá.

A Mesa Diretora da Assembleia Legislativa do Estado do Amapá faz saber que a Assembleia Legislativa do Estado do Amapá aprovou e ela promulga a seguinte Emenda à Constituição:

**Art. 1º** Fica acrescentado o § 12 ao artigo 67 da Constituição do Estado do Amapá, com a seguinte redação:

“Art. 67. ...............................................................................

**§ 12** A transferência para a reserva remunerada a pedido será concedida mediante requerimento do servidor militar que conte mais de 25 (vinte e cinco) anos de serviço, se mulher, assegurado à promoção ao posto ou graduação imediatamente superior ao seu, por ocasião da passagem à inatividade.”

**Art. 2º** Esta Emenda Constitucional entra em vigor na data de sua publicação.

Macapá - AP, 27 de fevereiro de 2002.

A Mesa da Assembleia Legislativa: Fran Júnior - Presidente; Eider Pena - 1º Vice- Presidente; Roberto Góes - 2º Vice-Presidente; Vital Andrade - 1º Secretário; Edinho Duarte - 2º Secretário; Jorge Salomão - 3º Secretário; Judith Medeiros - 4º Secretário.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 184

EMENDA CONSTITUCIONAL Nº 0027, DE 09 DE SETEMBRO DE 2002 Publicado no Diário Oficial do Estado nº 2877, de 26.09.02

Altera a redação do § 8º e transforma o seu inciso I no § 9º, do art. 113, da Constituição do Estado do Amapá.

A Mesa Diretora da Assembleia Legislativa do Estado do Amapá faz saber que a Assembleia Legislativa do Estado do Amapá aprovou e ela promulga a seguinte Emenda à Constituição:

Artigo único. O § 8º e seu inciso I, este transformado no § 9º, do art. 113, da Constituição do Estado do Amapá, passam a vigorar com a seguinte redação:

“Art. 113. .............................................................................

**§ 8º** Os conselheiros elegerão o Presidente, o 1º e o 2º Vice-Presidentes do Tribunal de Contas, para mandato de dois anos, vedada a reeleição.

**§ 9º** Considerar-se-á eleita a chapa que obtiver a maioria de votos.”

Macapá-AP, 09 de Setembro de 2002

A Mesa da Assembleia Legislativa: Fran Júnior - Presidente; Eider Pena - 1º Vice- Presidente; Roberto Góes - 2º Vice-Presidente; Vital Andrade - 1º Secretário; Edinho Duarte - 2º Secretário; Jorge Salomão - 3º Secretário; Judith Medeiros - 4º Secretário.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 185

EMENDA À CONSTITUIÇÃO Nº 0028, DE 30 DE DEZEMBRO DE 2003 Publicado no Diário Oficial do Estado nº 2941, de 23.05.05

Dá nova redação ao Inciso I do art. 95 e ao

**§ 3º** do art. 100 da Constituição do Estado do Amapá.

A Mesa Diretora da Assembleia Legislativa do Estado do Amapá faz saber que a Assembleia Legislativa do Estado do Amapá aprovou e ela promulga a seguinte Emenda à Constituição:

**Art. 1º** O Inciso I do art. 95 e o § 3º do art. 100 da Constituição do Estado do Amapá passam a vigorar com a seguinte redação:

“Art. 95. .....................................................................

I - eleger os membros da Mesa Diretora e constituir suas comissões”. “Art. 100. ......................................................................

**§ 3º** A Assembleia Legislativa reunir-se-á, em Sessão Preparatória, a partir de 1º de fevereiro, no primeiro ano de Legislatura, para a posse de seus membros e eleição da Mesa Diretora, para mandato de dois anos, vedada a recondução para o mesmo cargo na eleição imediatamente subsequente.”

**Art. 2º** Esta Emenda à Constituição entra em vigor na data de sua promulgação.

Macapá - AP, 27 de dezembro de 2002.

A Mesa da Assembleia Legislativa: Fran Júnior - Presidente; Eider Pena - 1º Vice- Presidente; Roberto Góes - 2º Vice-Presidente; Vital Andrade - 1º Secretário; Edinho Duarte - 2º Secretário; Jorge Salomão - 3º Secretário; Judith Medeiros - 4º Secretário.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 186

EMENDA CONSTITUCIONAL Nº 0029, DE 27 DE DEZEMBRO DE 2002 Publicado no Diário Oficial do Estado nº 2966, de 03.02.03

Acrescenta o Parágrafo único ao Artigo 178 da Constituição do Estado do Amapá.

A Mesa Diretora da Assembleia Legislativa do Estado do Amapá faz saber que a Assembleia Legislativa do Estado do Amapá aprovou e ela promulga a seguinte Emenda à Constituição:

**Art. 1º** O Art. 178 da Constituição Estadual passa a vigorar acrescido do seguinte parágrafo:

“Art. 178. .............................................................................

**Parágrafo único.** Somente com autorização legislativa poderá haver antecipação de duodécimos aos Poderes do Estado, ao Tribunal de Contas e ao Ministério Público.”

**Art. 2º** Esta Emenda Constitucional entra em vigor na data de sua publicação.

Macapá - AP, 27 de dezembro de 2002.

A Mesa da Assembleia Legislativa: Fran Júnior - Presidente; Eider Pena - 1º Vice- Presidente; Roberto Góes - 2º Vice-Presidente; Vital Andrade - 1º Secretário; Edinho Duarte - 2º Secretário; Jorge Salomão - 3º Secretário; Judith Medeiros - 4º Secretário.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 187

EMENDA À CONSTITUIÇÃO Nº 0030, DE 29 DE ABRIL DE 2003 Publicada no Diário Oficial do Estado nº 3021, de 30.04.03

Altera o § 2º do art. 100 e inclui o § 12 ao

art. 175 da Constituição do Estado do Amapá.

A Mesa Diretora da Assembleia Legislativa do Estado do Amapá faz saber que a Assembleia Legislativa do Estado do Amapá aprovou e ela promulga a seguinte Emenda à Constituição:

**Art. 1º** Fica alterado o § 2º do art. 100 e acrescido o § 12 ao art. 175 da Constituição do Estado do Amapá, que passam a vigorar com as seguintes redações:

“Art. 100. ...............................................

**§ 2º** A sessão legislativa não será interrompida sem a aprovação do projeto de Lei de Diretrizes orçamentárias, exceto no caso previsto no § 12 do art. 175”. ............................................................... “Art. 175. ...............................................

**§ 12** No primeiro ano de cada período de governo, o Projeto de Lei das Diretrizes Orçamentárias deverá ser encaminhado à Assembleia Legislativa, até 31 (trinta e um) de julho, para apreciação até 30 (trinta) de setembro, e o Projeto de Lei Orçamentária Anual será remetido até 31 (trinta e um) de outubro e apreciado até o encerramento da sessão legislativa”.

**Art. 2º** Esta Emenda à Constituição entra em vigor na data de sua promulgação.

Macapá - AP, 29 de abril de 2003.

A Mesa da Assembleia Legislativa: Lucas Barreto - Presidente; Francisca Favacho - 1º Vice-Presidente; Jaci Amanajás - 2º Vice-Presidente; Jorge Amanajás - 1º Secretário; Roberto Góes - 2º Secretário; Jorge Souza - 3º Secretário; Roseli Matos - 4ª Secretária.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 188

EMENDA À CONSTITUIÇÃO Nº 0031, DE 07 DE MAIO DE 2003 Publicada no Diário Oficial do Estado nº 3035, de 21.05.03

Altera o inciso I do art. 95, o § 3º do art. 100 e insere no artigo 286, § único, inciso II, da Constituição do Estado do Amapá, as alíneas “g” e “h” e dá outras providências.

A Mesa Diretora da Assembleia Legislativa do Estado do Amapá faz saber que a Assembleia Legislativa do Estado do Amapá aprovou e ela promulga a seguinte Emenda à Constituição:

**Art. 1º** O Inciso I do art. 95 e o § 3º do art. 100 da Constituição do Estado do Amapá passam a vigorar com a seguinte redação:

“Art. 95. .....................................................................

I - eleger os membros da Mesa Diretora, com mandato de dois anos, permitida a reeleição e constituir suas comissões”. “Art. 100. .....................................................................

**§ 3º** A Assembleia Legislativa reunir-se-á, em Sessão Preparatória, a partir de 1º de fevereiro, no primeiro ano de Legislatura, para a posse de seus membros e eleição da Mesa Diretora, para mandato de dois anos, permitida a reeleição.”

**Art. 2º** Fica acrescentado ao inciso II, § único, artigo 286 da Constituição do Estado do Amapá, as alíneas “g” e “h” com conteúdo de MORAL E ÉTICA e DIREITOS HUMANOS, passando o mesmo a vigorar com a seguinte redação:

“Art. 286. .......................................................

**Parágrafo único.** ..............................................

II – ................................................................

a) .....................................................................

b) .....................................................................

c) .....................................................................

d) .....................................................................

e) .....................................................................

f) .....................................................................

g) Moral e ética;

h) Direitos humanos.”

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 189

**Art. 3º** A presente Emenda entrará em vigor na data de sua publicação, revogando-se as disposições em contrário.

Macapá - AP, 07 de Maio de 2003.

A Mesa da Assembleia Legislativa: Lucas Barreto - Presidente; Francisca Favacho - 1º Vice-Presidente; Jaci Amanajás - 2º Vice-Presidente; Jorge Amanajás - 1º Secretário; Roberto Góes - 2º Secretário; Jorge Souza - 3º Secretário; Roseli Matos - 4ª Secretária.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 190

EMENDA CONSTITUCIONAL Nº 0032, DE 23 DE MARÇO DE 2004 Publicada no Diário Oficial do Estado nº 3244, de 25.03.2004

Acrescenta o inciso XIV a art. 17, e o inciso XVIII ao art. 283, da Constituição do Estado do Amapá.

A Mesa Diretora da Assembleia Legislativa do Estado do Amapá faz saber que a Assembleia Legislativa do Estado do Amapá aprovou e ela promulga a seguinte Emenda à Constituição:

**Art. 1º** O inciso XIV, do art. 17 da Constituição do Estado do Amapá, passa a vigorar com a seguinte redação:

“Art. 17. Competente aos municípios: ..................................................... “XIV - garantir, com a colaboração técnica e financeira do Estado, gratuidade nos transportes coletivos urbanos aos estudantes dos estabelecimentos de ensino situados nas sedes municipais, na forma estabelecida em lei complementar.”

Art. 2 É acrescido ao art. 283, da Constituição do Estado do Amapá, o seguinte inciso:

“Art. 283. É dever do Estado garantir: ...................................................... “XVIII - com a colaboração técnica e financeira do Município, gratuidade nos transportes coletivos urbanos aos estudantes dos estabelecimentos de ensino situados nas sedes municipais, na forma estabelecida em lei complementar.”

**Art. 3º** Esta Emenda Constitucional entra em vigor na data de sua publicação.

Macapá - AP, 23 de março de 2004.

A Mesa da Assembleia Legislativa: Lucas Barreto - Presidente; Francisca Favacho - 1º Vice-Presidente; Jaci Amanajás - 2º Vice-Presidente; Jorge Amanajás - 1º Secretário; Roberto Góes - 2º Secretário; Jorge Souza - 3º Secretário; Roseli Matos - 4ª Secretária.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 191

EMENDA CONSTITUCIONAL Nº 0033, DE 30 DE MARÇO DE 2005 Publicada no Diário Oficial do Estado nº 3494, de 30.03.2005

Altera o art. 90 da Constituição do Estado do Amapá.

A Mesa Diretora da Assembleia Legislativa do Estado do Amapá faz saber que a Assembleia Legislativa do Estado do Amapá aprovou e ela promulga a seguinte Emenda à Constituição:

**Art. 1º** O art. 90 da Constituição do Estado do Amapá passa a vigorar com a seguinte redação:

“Art. 90. O cargo de perito é privativo de médico, dentista, farmacêutico, químico, engenheiro, biólogo, enfermeiro e contador, dependendo o respectivo ingresso de provimento condicionado à habilitação por concurso público de provas ou de provas e títulos.”

**Art. 2º** Esta Emenda Constitucional entra em vigor na data de sua publicação.

Macapá - AP, 30 de março de 2005.

A Mesa da Assembleia Legislativa: Jorge Amanajás - Presidente; Francisca Favacho - 1º Vice-Presidente; Paulo José - 2º Vice-Presidente; Roberto Góes - 1º Secretário; Ubiranildo Macêdo - 2º Secretário; Jorge Souza - 3º Secretário; Raimunda Beirão - 4ª Secretária.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 192

EMENDA À CONSTITUIÇÃO N º 0034, DE 22 DE JULHO DE 2005 Publicada no Diário Oficial do Estado nº 3573, de 02.08.2005

Dá nova redação ao art. 38, do Ato das Disposições Constitucionais Transitórias da Constituição do Estado do Amapá.

A Mesa Diretora da Assembleia Legislativa do Estado do Amapá faz saber que a Assembleia Legislativa do Estado do Amapá aprovou e ela promulga a seguinte Emenda à Constituição:

**Art. 1º** O art. 38, da Constituição do Amapá, passa a vigorar com a seguinte redação:

“Art. 38. Ficam reconhecidas pelo Estado as Escolas Famílias existentes no Interior do Amapá, sendo-lhes garantidos seus princípios e sua metodologia.

**Parágrafo único.** O Estado estimulará a criação de Escolas Famílias, garantindo-lhes apoio necessário para o pleno êxito de seu funcionamento”.

**Art. 2º** Esta Emenda à Constituição entra em vigor na data de sua publicação.

Macapá - AP, 22 de julho de 2005.

A Mesa da Assembleia Legislativa: Jorge Amanajás - Presidente; Francisca Favacho - 1º Vice-Presidente; Paulo José - 2º Vice-Presidente; Roberto Góes - 1º Secretário; Ubiranildo Macêdo - 2º Secretário; Jorge Souza - 3º Secretário; Raimunda Beirão - 4ª Secretária.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 193

EMENDA À CONSTITUIÇÃO Nº 0035, DE 21 DE MARÇO DE 2006 Publicada no Diário Oficial do Estado nº 3741, de 07.04.2006 Republicada no Diário Oficial nº 3786, de 19.06.2006

Altera, acrescenta e revoga artigos da Constituição do Estado do Amapá e dá outras providências.

A Mesa Diretora da Assembleia Legislativa do Estado do Amapá faz saber que a Assembleia Legislativa do Estado do Amapá aprovou e ela promulga a seguinte Emenda à Constituição:

**Art. 1º** A Constituição do Estado do Amapá passa a vigorar com as seguintes alterações:

“TÍTULO II Direitos e Garantias Fundamentais

CAPÍTULO I Dos Direitos e Deveres Individuais e Coletivos ............................................................................................” “Art. 4º É mantida a integridade territorial do Estado do Amapá que só poderá ser alterada mediante aprovação de sua população, através de plebiscito, e pelo Congresso Nacional, por lei complementar.” “Art. 5º Todos são iguais perante a lei, sem distinção de qualquer natureza, nos termos do art. 5º da Constituição Federal. .............................................................................................

XVI - é livre o acesso de Ministros e de membros de confissão religiosa para a prestação de assistência espiritual nas entidades civis e militares de internação coletiva, respeitada a proporcionalidade confessional, vedadas todas as formas de proselitismo e atos que possam incomodar os outros internos.”

“CAPÍTULO II Dos Direitos Políticos e Sociais”

“Art. 5º-A A soberania popular, no âmbito do Estado do Amapá, será exercida pelo sufrágio universal e pelo voto direto e secreto, com valor igual para todos, e, nos termos da lei, mediante:

I - plebiscito;

II - referendo;

III - iniciativa popular.” “Art. 5º-B Através de plebiscito o eleitorado se manifestará, especificamente, sobre fato, medida, decisão política, programa ou obra pública e, pelo referendo, sobre emenda

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 194

à Constituição, sobre lei e sobre projetos de emenda à Constituição e de lei.

**§ 1º** Podem requerer plebiscito ou referendo:

I - um por cento do eleitorado estadual;

II - o Governador do Estado;

III - um terço, pelo menos, dos membros da Assembleia Legislativa;

**§ 2º** A realização de plebiscito ou referendo depende de aprovação da maioria absoluta dos membros da Assembleia Legislativa.

**§ 3º** A decisão do eleitorado, através de plebiscito ou referendo, será válida quando tomada por maioria de votos, desde que tenha votado, mais da metade do eleitorado estadual e, tratando-se de emenda à esta Constituição, quando tomada por maioria absoluta de votos, não computados os em branco e os nulos.

**§ 4º** Convocado o plebiscito ou referendo, o Presidente da Assembleia Legislativa dará ciência à Justiça Eleitoral, a qual caberá, nos limites de sua circunscrição, adotar as medidas necessárias a sua realização.” “Art. 5º-C A iniciativa popular será exercida na forma dos arts. 103, IV e 110 desta Constituição.

**Parágrafo único.** Os projetos de emenda à Constituição e de lei, apresentados mediante iniciativa popular, terão inscrição prioritária na Ordem do Dia da Assembleia Legislativa, no prazo de quarenta e cinco dias de seu recebimento, garantindo-se sua defesa em Plenário por qualquer dos cidadãos que o tiverem subscrito.” “Art. 5º-D São direitos sociais a educação, a saúde, o trabalho, a moradia, o lazer, a segurança, a previdência social, a proteção à maternidade e à infância, a assistência aos desamparados, na forma da Constituição Federal e desta Constituição.” “Art. 5º-E Fica assegurada a presença da sociedade civil, na forma da lei, por meio de suas entidades representativas, nos Conselhos Estaduais e demais órgãos de composição colegiada, de caráter deliberativo, consultivo, normativo e fiscalizador.

**Parágrafo único.** O orçamento do Estado alocará para cada Secretaria Estadual os recursos necessários para o custeio das atividades dos respectivos Conselhos. ............................................................................................” “Art. 9º ...............................................................................

**Parágrafo único.** A alienação, gratuita ou onerosa, e a concessão de bens imóveis do Estado do Amapá dependerá de prévia autorização da Assembleia Legislativa. ............................................................................................” “Art. 16. Os Municípios poderão instituir regime próprio de previdência para seus servidores, observados os princípios

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 195

e normas estabelecidos pela Constituição Federal e por esta Constituição.” “Art. 17. .............................................................................. .............................................................................................

XII - constituir guardas municipais destinadas à proteção de seus bens, serviços e instalações, conforme dispuser a lei, bem como a colaborar com o Estado no policiamento ostensivo e preventivo, de acordo com disposições legais e acordos estabelecidos, respeitadas as competências federal e estadual. ............................................................................................” “Art. 19. O total da despesa do Poder Legislativo Municipal, incluídos os subsídios dos Vereadores e excluídos os gastos com inativos, não poderá ultrapassar os percentuais previstos nos incisos I a IV do art. 29-A da Constituição Federal, relativos ao somatório da receita tributária e das transferências previstas no § 5º do art. 153 e nos arts. 158 e 159, efetivamente realizado no exercício anterior.

**Parágrafo único.** A Câmara Municipal não gastará mais de 70% (setenta por cento) de sua receita com folha de pagamento, incluído o gasto com o subsídio de seus Vereadores.” “Art. 20. ...............................................................................

**Parágrafo único.** Compete à Câmara Municipal processar e julgar originariamente o Prefeito nos crimes de responsabilidade.” “Art. 21. As contas da Mesa Diretora das Câmaras Municipais serão julgadas pelo Tribunal de Contas do Estado.” ............................................................................................. “Art. 25. ...............................................................................

**§ 1º** O controle externo, a cargo da Câmara Municipal, será exercido com o auxílio do Tribunal de Contas.” ............................................................................................. “Art. 26. Os subsídios do Prefeito, do Vice-Prefeito e dos Secretários Municipais serão fixados por lei de iniciativa da Câmara Municipal, observado o que dispõem os arts. 42, XI e 47, § 4º desta Constituição e os arts. 150, II, 153, III e 153, § 2º, I da Constituição Federal.

**§ 1º** O subsídio dos vereadores será fixado por lei de iniciativa das respectivas Câmaras Municipais, observado o que dispõe a Constituição Federal, os critérios estabelecidos na respectiva Lei Orgânica e os limites máximos fixados no inciso VI do art. 29 da Constituição Federal.

**§ 2º** A lei a que se referem o caput deste artigo e o § 1º deverá ser aprovada e publicada antes da data das eleições municipais.” “Art. 27. O número de Vereadores das Câmaras Municipais será fixado nas respectivas Leis Orgânicas

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 196

proporcionalmente à população do Município, observados os limites estabelecidos no inciso IV do art. 29 da Constituição Federal. ............................................................................................” “Art. 34. Constitui crime de responsabilidade do Prefeito Municipal:

I - efetuar repasse que supere os limites definidos no art. 29-A da Constituição Federal;

II - não enviar o repasse até o dia vinte de cada mês; ou

III - enviá-lo a menor em relação à proporção fixada na Lei Orçamentária.

**Parágrafo único.** Constitui crime de responsabilidade do Presidente da Câmara Municipal o desrespeito ao

parágrafo único do art. 19 desta Constituição.” ............................................................................................. “Art. 37. ............................................................................... .............................................................................................

III - não tiver sido aplicado o mínimo exigido da receita municipal na manutenção e desenvolvimento do ensino e nas ações e serviços públicos de saúde; …….....................................................................................” “Art. 42. ...................................................………................. .............................................................................................

X - a remuneração dos servidores públicos estaduais e o subsídio de que trata o § 4º do art. 47, somente poderão ser fixados ou alterados por lei específica, observada a iniciativa privativa em cada caso, assegurada revisão geral anual, sempre no dia 1º do mês de abril e sem distinção de índices.

XI - a remuneração e o subsídio dos ocupantes de cargos, funções e empregos públicos da administração direta, autárquica e fundacional, dos membros de qualquer dos Poderes do Estado e dos Municípios e os proventos, pensões ou outra espécie remuneratória, percebidos cumulativamente ou não, incluídas as vantagens pessoais ou de qualquer outra natureza, não poderão exceder o subsídio mensal, em espécie, dos Desembargadores do Tribunal de Justiça, limitado a noventa inteiros e vinte e cinco centésimos por cento do subsídio mensal, em espécie, dos Ministros do Supremo Tribunal Federal, ressalvada a exceção prevista no § 12 do art. 37 da Constituição Federal; .............................................................................................

XV - .....................................................................................

a) a de dois cargos de professor;

b) a de um cargo de professor com outro, técnico ou científico;

c) a de dois cargos ou empregos privativos de profissionais de saúde, com profissões regulamentadas;

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 197

............................................................................................. ........

XVIII - somente por lei específica poderá ser criada autarquia e autorizada a instituição de empresa pública, de sociedade de economia mista e de fundação, cabendo à lei complementar, neste último caso, definir as áreas de sua atuação; .............................................................................................

XXVIII - ao Estado é vedado celebrar contratos com empresas ou pessoas físicas que, comprovadamente, desrespeitem normas de segurança, de medicina do trabalho, de preservação do meio ambiente e, em especial, os direitos e garantias fundamentais estabelecidos na Constituição Federal.

XXIX - ressalvados os casos especificados na legislação, as obras, serviços, compras e alienações serão contratados mediante licitação pública que assegure igualdade de condições a todos os concorrentes, com cláusulas que estabeleçam obrigações de pagamento, mantidas as condições efetivas da proposta, nos termos da lei, o qual somente permitirá as exigências de qualificação técnica e econômica indispensáveis à garantia do cumprimento das obrigações. .............................................................................................

**§ 5º** É vedada a percepção simultânea de proventos de aposentadoria decorrentes do art. 40 ou dos arts. 42 e 142 da Constituição Federal com a remuneração de cargo, emprego ou função pública, ressalvados os cargos acumuláveis na forma da Constituição Federal, os cargos eletivos e os cargos em comissão declarados em lei de livre nomeação e exoneração.

**§ 6º** Não serão computadas, para efeito dos limites remuneratórios de que trata o inciso XI do caput deste artigo, as parcelas de caráter indenizatório previstas em lei. ............................................................................................” “Art. 47. .............................................................................. .............................................................................................

**§ 2º** O Estado manterá escolas de governo para formação e o aperfeiçoamento dos servidores públicos, constituindo- se a participação nos cursos um dos requisitos para promoção na carreira, facultada, para isso, a celebração de convênios ou contratos com os demais entes federados, ou entre o Estado e os Municípios com instituições de ensino superior que ofereçam cursos afins. ............................................................................................” “Art. 48. O Estado e os Municípios deverão dotar seus planos de cargos e salários objetivando o atendimento à demanda de técnicos de nível médio e superior, de acordo com as necessidades locais, vedado o desvio de função”.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 198

**Parágrafo único.** A Administração Pública implementará política de recursos humanos que atenda ao princípio da valorização do servidor público, investindo na sua capacitação, aprimoramento e atualização profissionais, subsidiando cursos de graduação de nível superior, especialização, mestrado e doutorado, visando prepará-lo para um desempenho qualificado de suas atribuições funcionais. ............................................................................................” “Art. 54. O tempo de contribuição federal, estadual ou municipal será contado para efeito de aposentadoria e o tempo de serviço correspondente para efeito de disponibilidade.” “Art. 55. Aplica-se aos servidores públicos estaduais, titulares de cargos de provimento efetivo, para efeito do regime de previdência e aposentadoria, o disposto no art. 40 e seus parágrafos, da Constituição Federal.” ............................................................................................. “Art. 60. O Estado e os Municípios, desde que instituam regime de previdência complementar para os seus respectivos servidores titulares de cargo efetivo, poderão fixar, para o valor das aposentadorias e pensões a serem concedidas pelo regime de que trata este artigo, o limite máximo estabelecido para os benefícios do regime geral de previdência social de que trata o artigo 201 da Constituição Federal.

**Parágrafo único.** O regime de previdência complementar de que trata este artigo será instituído por lei de iniciativa do Poder Executivo, observado o disposto no art. 202 e seus parágrafos da Constituição Federal, no que couber, por intermédio de entidades fechadas de previdência complementar, de natureza pública, que oferecerão aos respectivos participantes planos de benefícios somente na modalidade de contribuição definida.” ............................................................................................. “Art.75. ..…....………….........……......……………….....…… …......……………………..……………….........…………....…

**Parágrafo único.** A remuneração dos servidores policiais integrantes dos órgãos relacionados neste artigo será fixada na forma do § 4º do art. 47 desta Constituição.” “Art. 76. ...............................................................................

**§ 1º** É dever dos órgãos responsáveis pela segurança pública dar aos policiais civis e militares, formação, capacitação e treinamento especializados para o trato das questões relativas ao idoso, à criança e ao adolescente e a mulher. .............................................................................................

**§ 5º** O Poder Executivo promoverá a instalação, progressivamente, em todos os municípios do Estado, de

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 199

delegacias de polícia especializadas em assuntos relativos às pessoas relacionadas no § 1º deste artigo.” ............................................................................................. “Art. 79. À polícia civil, instituição permanente, com autonomia administrativa e financeira, orientada com base na hierarquia, disciplina e respeito aos direitos humanos, dirigida por delegado de polícia de carreira da classe especial, de livre nomeação e exoneração pelo Governador do Estado, incumbe, ressalvada a competência da União, exercer com exclusividade, as funções de polícia judiciária e a apuração de infrações penais, exceto as militares.

**§ 1º** O titular da polícia civil será nomeado pelo Governador do Estado dentre os delegados integrantes da classe especial da carreira.

**§ 2º** Os delegados de polícia de carreira, bacharéis em direito, aprovados em concurso público de provas ou de provas e títulos, serão remunerados na forma do § 9º do

art. 144 da Constituição Federal, aplicando-se-lhes as vedações referidas no inciso II do art. 148 desta Constituição.

**§ 3º** Os Delegados de Polícia do Estado integrarão a Carreira Jurídica do Poder Executivo do Amapá.” ............................................................................................. “Art. 90. O cargo de perito é privativo de pessoas portadoras de diploma de nível superior, obtido em curso devidamente reconhecido pelo Ministério da Educação e Cultura, dependendo o ingresso na carreira de aprovação em concurso público de provas e títulos.” ............................................................................................. “Art. 95. ............................................................................... .............................................................................................

XI - processar e julgar:

a) o Governador e o Vice-Governador do Estado nos crimes de responsabilidade, bem como os Secretários de Estado nos crimes da mesma natureza conexos com aqueles;

b) o Procurador Geral de Justiça e o Procurador-Geral do Estado nos crimes de responsabilidade. .............................................................................................

XVI - aprovar, por maioria absoluta e voto secreto, a destituição do Procurador-Geral de Justiça.

XVII - julgar, anualmente, as contas do Tribunal de Contas do Estado, aplicando-se, quando for o caso, o previsto no inciso VI deste artigo. .............................................................................................

XX - Aprovar convênios, acordos ou contratos com os Governos federal, estaduais ou municipais e com entidades de direito público ou privado, de que resultem para o Estado quaisquer encargos não estabelecidos na lei orçamentária;

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 200

XXI - apreciar, trimestralmente os relatórios das atividades do Tribunal de Contas do Estado. .............................................................................................

XXIV - aprovar, após arguição, pelo voto secreto da maioria de seus membros, os nomes dos presidentes de fundações públicas; .............................................................................................

XXX - avaliar periodicamente a funcionalidade do Sistema Tributário Estadual, em sua estrutura e seus componentes e o desempenho da administração tributária do Estado. ............................................................................................” “Art. 96. Os Deputados são invioláveis, civil e penalmente, por quaisquer de suas opiniões, palavras e votos.

**§ 1º** Os Deputados, desde a expedição do diploma, serão submetidos a julgamento perante o Tribunal de Justiça do Estado do Amapá.

**§ 2º** Desde a expedição do Diploma, os Deputados não poderão ser presos, salvo em flagrante de crime inafiançável. Nesse caso, os autos serão remetidos dentro de vinte e quatro horas à Assembleia Legislativa, para que, pelo voto da maioria de seus membros, resolva sobre a prisão.

**§ 3º** Recebida a denúncia contra Deputado, por crime ocorrido após a diplomação, o Tribunal de Justiça dará ciência à Assembleia Legislativa, que, por iniciativa de partido político nela representado e pelo voto da maioria de seus membros, poderá, até a decisão final, sustar o andamento da ação.

**§ 4º** O pedido de sustação será apreciado pela Assembleia Legislativa no prazo improrrogável de quarenta e cinco dias do seu recebimento pela Mesa Diretora.

**§ 5º** A sustação do processo suspende a prescrição enquanto durar o mandato.

**§ 6º** Os Deputados não serão obrigados a testemunhar sobre informações recebidas ou prestadas em razão do exercício do mandato, nem sobre as pessoas que lhes confiaram ou deles receberam informações.

**§ 7º** A incorporação às Forças Armadas de Deputados, embora militares e ainda que em tempo de guerra, dependerá de prévia licença da Assembleia Legislativa.

**§ 8º** As imunidades de Deputados subsistirão durante o estado de sítio, só podendo ser suspensas mediante o voto de dois terços dos membros da Assembleia Legislativa, nos casos de atos praticados fora do recinto da Assembleia, que sejam incompatíveis com a execução da medida”. ............................................................................................. “Art. 98. ............................................................................... .............................................................................................

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 201

III - que deixar de comparecer, em cada sessão legislativa, à terça parte das sessões ordinárias, salvo licença ou missão autorizada pela Assembleia; .............................................................................................

**§ 4º** A renúncia de parlamentar submetido a processo que vise ou possa levar à perda do mandato, nos termos deste artigo, terá seus efeitos suspensos até as deliberações finais de que tratam os §§ 2º e 3º.” ............................................................................................. “Art. 100. A Assembleia Legislativa reunir-se-á, anualmente, na Capital do Estado, de 02 de fevereiro a 17 de julho e de 1º de agosto a 22 de dezembro. .............................................................................................

**§ 4º** A convocação extraordinária da Assembleia Legislativa far-se-á: .............................................................................................

II – pelo seu Presidente, a requerimento da maioria de seus membros ou pelo Governador do Estado, em caso de urgência ou interesse público relevante, em todas as hipóteses deste inciso com a aprovação da maioria absoluta dos seus membros.

**§ 5º** Na sessão legislativa extraordinária, a Assembleia Legislativa somente deliberará sobre matéria para qual foi convocada, vedado o pagamento de parcela indenizatória, em razão da convocação.” ............................................................................................. “Art. 107. ............................................................................ .............................................................................................

**§ 8º** Se a lei não for promulgada dentro de quarenta e oito horas pelo Governador do Estado, nos casos dos §§ 4º e 7º, o Presidente da Assembleia Legislativa a promulgará, e, se este, não o fizer em igual prazo, caberá ao Vice- Presidente fazê-lo. ............................................................................................” “Art. 109. ............................................................................. .............................................................................................

**Parágrafo único.** As leis complementares serão aprovadas por maioria absoluta e terão numeração distinta da numeração das leis ordinárias.” “Art. 110. A iniciativa popular pode ser exercida pela apresentação à Assembleia Legislativa de projeto de lei, subscrito por, no mínimo, um por cento do eleitorado estadual, distribuído pelo menos por cinco Municípios, com um mínimo de dois por cento dos eleitores de cada um deles, e de proposta de emenda à Constituição na forma do inciso IV do art. 103. ............................................................................................” “Art. 112. O controle externo, a cargo da Assembleia Legislativa, será exercido com o auxílio do Tribunal de Contas do Estado, ao qual compete”:

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 202

.............................................................................................

II - apreciar as contas dos Prefeitos e julgar as contas da Mesa Diretora das Câmaras Municipais, dentro do exercício em que forem prestadas. .............................................................................................

V - realizar, por iniciativa própria, da Assembleia Legislativa, de Comissão técnica ou de inquérito, inspeções e auditorias de natureza contábil, financeira, orçamentária, operacional e patrimonial, nas unidades administrativas dos Poderes Legislativo, Executivo e Judiciário, e demais entidades referidas no inciso III; .............................................................................................

**§ 1º** No caso de contrato, o ato de sustação será adotado diretamente pela Assembleia Legislativa ou pelas Câmaras Municipais que solicitarão, de imediato, ao Poder Executivo as medidas cabíveis. ............................................................................................” “Art. 113. O Tribunal de Contas do Estado, órgão auxiliar do Poder Legislativo, integrado por sete Conselheiros, tem sede na capital do Estado, autonomia administrativa e financeira, quadro próprio de pessoal e jurisdição em todo o território estadual, exercendo, no que couber, as atribuições do art. 133 desta Constituição. .............................................................................................

**§ 2º** .....................................................................................

I - um terço pelo Governador do Estado, com aprovação da Assembleia Legislativa, sendo dois alternadamente dentre auditores e membros do Ministério Público junto ao Tribunal, indicados em lista tríplice pelo Tribunal, segundo os critérios de antiguidade e merecimento; .............................................................................................

**§ 3º** Os Conselheiros do Tribunal de Contas terão as mesmas garantias, prerrogativas, impedimentos, vencimentos e vantagens dos Desembargadores do Tribunal de Justiça do Estado, aplicando-se-lhes, quanto à aposentadoria e pensão, as normas constantes do art. 40 da Constituição Federal. .............................................................................................

**§ 8º** Os Conselheiros elegerão o Presidente e o 1º e 2º Vice-Presidentes do Tribunal de Contas para mandato de dois anos, permitida a reeleição. ............................................................................................” “Art. 114. .............................................................................

I - avaliar o cumprimento das metas previstas no plano plurianual, a execução dos programas de governo e dos orçamentos do Estado e dos Municípios;

II - comprovar a legalidade e avaliar os resultados, quanto à eficácia e eficiência, da gestão orçamentária, financeira e patrimonial nos órgãos e entidades das administrações

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 203

estadual e municipal, bem como da aplicação de recursos públicos por entidades de direito privado;

III - exercer o controle das operações de crédito, avais e garantias, bem como dos direitos e haveres do Estado e dos Municípios; .............................................................................................

**§ 1º** Os responsáveis pelo controle interno, ao tomarem conhecimento de qualquer irregularidade ou ilegalidade, dela darão ciência ao Tribunal de Contas da União, sob pena de responsabilidade solidária. ............................................................................................” “Art. 115. .............................................................................

**Parágrafo único.** Lei, de iniciativa da Assembleia Legislativa, disciplinará sua competência e o ingresso na classe inicial da carreira que para todos os fins integra a Advocacia Pública do Estado do Amapá, mediante concurso de provas ou de provas e títulos.” ............................................................................................. “Art. 117. ............................................................................ .............................................................................................

**§ 3º** Os subsídios do Governador e do Vice-Governador do Estado serão fixados por lei de iniciativa da Assembleia Legislativa, que deverá ser aprovada e publicada antes da data das eleições estaduais, observado o que dispõem os arts. 42, XI e 47, § 4º desta Constituição e os arts. 150, II, 153, III e 153, § 2º, I da Constituição Federal.” “Art. 118. .............................................................................

**§ 1º** O Governador e o Vice-Governador residirão na Capital do Estado e não poderão, sem prévia permissão da Assembleia Legislativa, ausentar-se do País ou do Estado por mais de quinze dias, sob pena de perda do cargo. .............................................................................................

**§ 3º** (Dispositivo declarado inconstitucional, em controle concentrado, pelo Supremo Tribunal Federal, no julgamento da ADIN n.º 887-). ............................................................................................” “Art. 119. ............................................................................. .............................................................................................

XXII – prover e extinguir os cargos públicos estaduais na forma da lei; .............................................................................................

XXV – dispor, mediante decreto, sobre:

a) organização e funcionamento da administração estadual, quando não implicar aumento de despesa nem criação ou extinção de órgãos públicos;

b) extinção de funções ou cargos públicos, quando vagos. ............................................................................................” “Art. 121. ............................................................................ .............................................................................................

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 204

**§ 4º** O Governador do Estado, na vigência de seu mandato, não pode ser responsabilizado por atos estranhos ao exercício de suas funções.” “Art. 122. .............................................................................

**Parágrafo único.** O subsídio dos Secretários de Estado será fixado na forma do disposto no § 3º do art. 117 desta Constituição.” “Art. 123. ............................................................................ .............................................................................................

VI – responder, no prazo fixado no inciso XXVI do art. 95 desta Constituição, aos pedidos de informações da Assembleia Legislativa.” ............................................................................................. “Art. 125. Ao Poder Judiciário é assegurada autonomia administrativa e financeira.

**§ 1º** O Tribunal de Justiça elaborará sua proposta orçamentária dentro dos limites estipulados conjuntamente com os demais Poderes na lei de diretrizes orçamentárias.

**§ 2º** O encaminhamento da proposta, aprovada pelo Tribunal, compete ao Presidente do Tribunal de Justiça.

**§ 3º** Se o Tribunal não encaminhar sua proposta orçamentária dentro do prazo estabelecido na lei de diretrizes orçamentárias, o Poder Executivo considerará, para fins de consolidação da proposta orçamentária anual, os valores aprovados na lei orçamentária vigente, ajustados de acordo com os limites estipulados na forma do § 1º deste artigo.

**§ 4º** Se a proposta orçamentária de que trata este artigo for encaminhada em desacordo com os limites estipulados na forma do § 1º, o Poder Executivo procederá aos ajustes necessários para fins de consolidação da proposta orçamentária anual.

**§ 5º** Durante a execução orçamentária do exercício, não poderá haver a realização de despesas ou a assunção de obrigações que extrapolem os limites estabelecidos na lei de diretrizes orçamentárias, exceto se previamente autorizadas, mediante a abertura de créditos suplementares ou especiais”. “Art. 125-A. À exceção dos créditos de natureza alimentícia, os pagamentos devidos pela Fazenda Estadual ou Municipal, em virtude de sentença judiciária, far-se-ão exclusivamente na ordem cronológica de apresentação dos precatórios e à conta dos créditos respectivos, proibida a designação de casos ou de pessoas nas dotações orçamentárias e nos créditos adicionais abertos para este fim.

**§ 1º** É obrigatória a inclusão, no orçamento das entidades de direito público, de verba necessária ao pagamento de seus débitos oriundos de sentenças transitadas em julgado, constantes de precatórios judiciários,

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 205

apresentados até 1º de julho, fazendo-se o pagamento até o final do exercício seguinte, quando terão seus valores atualizados monetariamente.

**§ 2º** Os débitos de natureza alimentícia compreendem aqueles decorrentes de salários, vencimentos, proventos, pensões e suas complementações, benefícios previdenciários e indenizações por morte ou invalidez, fundadas na responsabilidade civil, em virtude de sentença transitada em julgado.

**§ 3º** As dotações orçamentárias e os créditos abertos serão consignados diretamente ao Poder Judiciário, cabendo ao Presidente do Tribunal de Justiça determinar o pagamento segundo as possibilidades do depósito, e autorizar, a requerimento do credor, e exclusivamente para o caso de preterimento de seu direito de precedência, o sequestro da quantia necessária à satisfação do débito.

**§ 4º** O disposto no caput deste artigo, relativamente à expedição de precatórios, não se aplica aos pagamentos de obrigações definidas em lei como de pequeno valor que a Fazenda Estadual ou Municipal deva fazer em virtude de sentença judicial transitada em julgado.

**§ 5º** São vedados a expedição de precatório complementar ou suplementar de valor pago, bem como fracionamento, repartição ou quebra do valor da execução, a fim de que seu pagamento não se faça, em parte, na forma estabelecida no § 4º deste artigo e, em parte, mediante expedição de precatório.

**§ 6º** A lei poderá fixar valores distintos para o fim previsto no § 4º deste artigo, segundo as diferentes capacidades das entidades de direito público.

**§ 7º** O Presidente do Tribunal de Justiça incorrerá em crime de responsabilidade se, por ato comissivo ou omissivo, retardar ou tentar frustrar a liquidação regular de precatório.” “Art. 126. ............................................................................

I - ingresso na carreira, cujo cargo inicial será o de juiz substituto, mediante concurso público de provas e títulos, com a participação da Ordem dos Advogados do Brasil em todas as fases, exigindo-se do bacharel em direito, no mínimo, três anos de atividade jurídica e obedecendo-se, nas nomeações, à ordem de classificação;

II - promoção de entrância para entrância, alternadamente, por antiguidade e merecimento, atendidas as normas fixadas no inciso II do art. 93 da Constituição Federal. .............................................................................................

IV - previsão de cursos oficiais de preparação, aperfeiçoamento e promoção de magistrados, constituindo etapa obrigatória do processo de vitaliciamento a participação em curso oficial ou reconhecido por escola nacional de formação e aperfeiçoamento de magistrados;

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 206

V - os subsídios dos Desembargadores do Tribunal de Justiça e dos demais magistrados serão fixados com observância do disposto no inciso V do art. 93 da Constituição Federal;

V-A - a aposentadoria dos magistrados e a pensão de seus dependentes observarão o disposto no art. 40 da Constituição Federal;

VI - o juiz titular residirá na respectiva comarca, salvo autorização do Tribunal de Justiça; .............................................................................................

VIII - o ato de remoção, disponibilidade e aposentadoria do magistrado, por interesse público, fundar-se-á em decisão por voto da maioria absoluta do Tribunal de Justiça ou do Conselho Nacional de Justiça, assegurada ampla defesa;

VIII-A - a remoção a pedido ou a permuta de magistrados de comarca de igual entrância atenderá, no que couber, ao disposto nas alíneas a, b, c e e, do inciso II, do art. 93 da Constituição Federal;

IX - Todos os julgamentos dos órgãos do Poder Judiciário serão públicos, e fundamentadas todas as decisões, sob pena de nulidade, podendo a lei limitar a presença, em determinados atos, às próprias partes e a seus advogados, ou somente a estes, em casos nos quais a preservação do direito à intimidade do interessado no sigilo não prejudique o interesse público à informação;

X - as decisões administrativas do Tribunal de Justiça serão motivadas e em sessão pública, sendo as disciplinares tomadas pelo voto da maioria absoluta de seus membros;

XI - a atividade jurisdicional será ininterrupta, sendo vedado férias coletivas, funcionando, nos dias em que não houver expediente forense normal, juízes em plantão permanente;

XII - o número de juízes na unidade jurisdicional será proporcional à efetiva demanda judicial e à respectiva população;

XIII - os servidores receberão delegação para a prática de atos de administração e atos de mero expediente sem caráter decisório;

XIV - a distribuição de processos será imediata, em todos os graus de jurisdição. ............................................................................................” “Art. 128. .............................................................................

**Parágrafo único.** Recebidas as indicações, o Tribunal de Justiça formará lista tríplice, enviando-a ao Poder Executivo, que, nos vinte dias subsequentes, escolherá um de seus integrantes para nomeação.” “Art. 129. ............................................................................

I - vitaliciedade, que, no primeiro grau, só será adquirida após dois anos de exercício, dependendo a perda do cargo, nesse período, de deliberação do Tribunal de

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 207

Justiça, e, nos demais casos, de sentença judicial transitada em julgado;

II - inamovibilidade, salvo por motivo de interesse público, na forma do artigo 93, VIII, da Constituição Federal;

III - irredutibilidade de subsídio, ressalvado o disposto nos artigos 37, X e XI, 39, § 4º, 150, II, 153, III, e 153, § 2º, I da Constituição Federal. ............................................................................................” “Art. 131. ............................................................................. .............................................................................................

IV - receber, a qualquer título ou pretexto, auxílios ou contribuições de pessoas físicas, entidades públicas ou privadas, ressalvadas as exceções previstas em lei;

V - exercer a advocacia no juízo ou tribunal do qual se afastou, antes de decorridos três anos do afastamento do cargo por aposentadoria ou exoneração.” “Art. 132. O Tribunal de Justiça, com sede na capital e jurisdição em todo território do Estado, compõe-se de, no mínimo, nove Desembargadores.” “Art. 133. Compete privativamente ao Tribunal de Justiça, além das competências elencadas no inciso I do art. 96 da Constituição Federal:

I - propor ao Poder Legislativo, observado o disposto no art. 169 da Constituição Federal: .............................................................................................

b) a criação e a extinção de cargos e a remuneração dos seus serviços auxiliares e dos juízos que lhes forem vinculados, bem como a fixação do subsídio de seus membros e dos juízes; .............................................................................................

e) a criação da Justiça de Paz e a eleição dos respectivos juízes;

f) a criação dos juizados especiais;

g) a alteração da organização e da divisão judiciárias;

II - processar e julgar originariamente:

a) o Vice-Governador, os Secretários de Estado, ressalvado o disposto no art. 95, XI, a, os Juízes Estaduais e os membros do Ministério Público, ressalvado o disposto no art. 95, XI, b, nos crimes comuns e de responsabilidade, e os Prefeitos nos crimes comuns, ressalvada a competência da Justiça Eleitoral. .............................................................................................

c) o mandado de segurança contra atos do Governador, Mesa e da Presidência da Assembleia, do próprio Tribunal ou de algum de seus membros, dos Secretários de Estado, do Presidente ou dos Conselheiros do Tribunal de Contas, do Procurador Geral de Justiça, dos Prefeitos Municipais e do Presidente da Câmara Municipal da Capital; .............................................................................................

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 208

e) o habeas-data contra atos das autoridades referidas na alínea “c”; .............................................................................................

m) a ação direta de inconstitucionalidade e a ação declaratória de constitucionalidade de leis ou atos normativos estaduais ou municipais em face da Constituição Estadual e de leis ou atos normativos municipais em face da Constituição Federal, observado o disposto no art. 97 desta última. ............................................................................................” “Art. 137. Para dirimir conflitos fundiários, o Tribunal de Justiça proporá a criação de varas especializadas, com competência exclusiva para questões agrárias.

**Parágrafo único.** Sempre que necessário à eficiente prestação jurisdicional, o juiz far-se-á presente no local do litígio.” “Art. 138. A Justiça Militar do Estado do Amapá é competente para processar e julgar os militares estaduais, nos crimes militares definidos em lei e as ações judiciais contra atos disciplinares militares, ressalvada a competência do júri quando a vítima for civil, cabendo ao Tribunal de Justiça decidir sobre a perda do posto e da patente dos oficiais e da graduação de praças.” “Art. 139. Compete aos juízes de direito do juízo militar processar e julgar, singularmente, os crimes militares cometidos contra civis e as ações judiciais contra atos disciplinares militares, cabendo ao Conselho de Justiça, sob a presidência de juiz de direito, processar e julgar os demais crimes militares. ............................................................................................” “Art. 142. Podem propor a ação direita de inconstitucionalidade e a ação declaratória de constitucionalidade de que trata a alínea m do inciso II do

art. 133 desta Constituição: ............................................................................................. ............................................................................................” “Art. 143. .............................................................................

**§ 1º** Lei federal regulará as atividades, disciplinará a responsabilidade civil e criminal dos notários, dos oficiais de registro e de seus prepostos, e definirá a fiscalização de seus atos pelo Poder Judiciário.

**§ 2º** A fixação de emolumentos relativos aos atos praticados pelos serviços notariais e de registro observará as normas gerais fixadas em lei federal. ............................................................................................” “Art. 145. Ao Ministério Público é assegurada autonomia funcional e administrativa, podendo, observado o disposto no artigo 169 da Constituição Federal, propor ao Poder Legislativo a criação e extinção de seus cargos e serviços auxiliares, provendo-os por concurso público de provas ou

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 209

de provas e títulos, a política remuneratória e os planos de carreira; a lei disporá sobre sua organização e funcionamento. .............................................................................................

**§ 2º** O Ministério Público elaborará sua proposta orçamentária dentro dos limites estabelecidos na lei de diretrizes orçamentárias.

**§ 3º** Se o Ministério Público não encaminhar a respectiva proposta orçamentária dentro do prazo estabelecido na lei de diretrizes orçamentárias, o Poder Executivo considerará, para fins de consolidação da proposta orçamentária anual, os valores aprovados na lei orçamentária vigente, ajustados de acordo com os limites estipulados na forma do § 2º.

**§ 4º** Se a proposta orçamentária de que trata este artigo for encaminhada em desacordo com os limites estipulados na forma do § 2º, o Poder Executivo procederá aos ajustes necessários para fins de consolidação da proposta orçamentária anual.

**§ 5º** Durante a execução orçamentária do exercício, não poderá haver a realização de despesas ou a assunção de obrigações que extrapolem os limites estabelecidos na lei de diretrizes orçamentárias, exceto se previamente autorizadas, mediante a abertura de créditos suplementares ou especiais.

**§ 6º** Os recursos próprios, não originários do Tesouro Estadual, serão utilizados em programas vinculados às suas finalidades institucionais.” ............................................................................................. “Art. 148. .............................................................................

I - ......................................................................................... .............................................................................................

b) inamovibilidade, salvo por motivo de interesse público, mediante decisão do órgão colegiado competente do Ministério Público, por voto da maioria absoluta de seus membros, assegurada ampla defesa;

c) irredutibilidade de subsídio, fixado na forma do art. 39, § 4º, e ressalvado o disposto nos arts. 37, X e XI, 150, II, 153, III e 153, § 2º, I, todos da Constituição Federal.

II - ........................................................................................ .............................................................................................

e) exercer atividade político partidária;

f) receber, a qualquer título ou pretexto, auxílios ou contribuições de pessoas físicas, entidades públicas ou privadas, ressalvadas as exceções previstas em lei.

**Parágrafo único.** Aplica-se aos membros do Ministério Público o disposto no art. 95, parágrafo único, V, da Constituição Federal.” “Art. 149. O ingresso na carreira do Ministério Público far- se-á mediante concurso público de provas e títulos,

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 210

assegurada a participação da Ordem dos Advogados do Brasil em sua realização, exigindo-se do bacharel em direito, no mínimo, três anos de atividade jurídica e observando-se, nas nomeações, a ordem de classificação. .............................................................................................

**§ 2º** Aplica-se ao Ministério Público, no que couber, o disposto no art. 93, da Constituição Federal.

**§ 3º** A distribuição dos processos no Ministério Público será imediata.” “Art. 150. ............................................................................. .............................................................................................

**§ 3º** As funções do Ministério Público só podem ser exercidas por integrantes da carreira, que deverão residir na comarca da respectiva lotação, salvo autorização do chefe da instituição. .............................................................................................

**§ 5º** Mediante lei será criada a ouvidoria do Ministério Público, competente para receber reclamações e denúncias de qualquer interessado contra membros ou órgãos do Ministério Público, inclusive contra seus serviços auxiliares, representando diretamente ao Conselho Nacional do Ministério Público.” ............................................................................................. “Art. 152. ............................................................................

**§ 1º** O Procurador Geral de Contas será nomeado pelo Presidente do Tribunal de Contas do Estado, dentre os integrantes da carreira, indicados em lista tríplice na forma da lei respectiva, para mandato de dois anos, permitida uma recondução. ............................................................................................. ............................................................................................” “Art. 153. ............................................................................ .............................................................................................

**§ 2º** ...................................................................................... .............................................................................................

II – estabilidade após 3 (três) anos de efetivo exercício, mediante avaliação de desempenho perante os órgãos próprios, após relatório circunstanciado da corregedoria.” ............................................................................................. “Art. 154. A Defensoria Pública é instituição essencial à função jurisdicional do Estado, incumbindo-lhe a orientação jurídica e a defesa, em todos os graus, dos necessitados, na forma do art. 5º, LXXIV da Constituição Federal. .............................................................................................

**§ 3º** À Defensoria Pública são asseguradas autonomia funcional e administrativa e a iniciativa de sua proposta orçamentária dentro dos limites estabelecidos na lei de diretrizes orçamentárias e subordinação ao disposto no art. 99, § 2º da Constituição Federal.”

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 211

............................................................................................. “Art. 156. Lei complementar organizará a Defensoria Pública, observadas as normas gerais a que se refere o § 1º do art. 134 da Constituição Federal, assegurada aos seus integrantes a garantia da inamovibilidade e vedado o exercício da advocacia fora das atribuições institucionais. ............................................................................................” “Art. 158. Os servidores integrantes das carreiras disciplinadas nesta Seção e na anterior serão remunerados na forma do art. 47, § 4º.” ............................................................................................. “Art. 186. ............................................................................. .............................................................................................

**§ 5º** A lei estimulará a descentralização geográfica das atividades de produção e comercialização de bens e de prestação de serviços, visando ao desenvolvimento intra- regional equilibrado, mediante a simplificação de obrigações administrativas, tributárias e creditícias ou, ainda, pela redução ou eliminação destas. …...………..………..………..………..………..………..…….” “Art.188. ……………………..……………………………..... ……………….…………………………………………………

XI - ………......…….………………………………………….

a) a simplificação de suas obrigações administrativas, tributárias e creditícias;

b) .........................................................................................

c) a redução ou eliminação das obrigações descritas na alínea a, por meio de lei.

XII - tratamento jurídico diferenciado, na forma da lei, às empresas instaladas fora de áreas beneficiadas com incentivos fiscais conferidos pela União, mediante a adoção dos mesmos parâmetros estabelecidos no inciso anterior.

**Parágrafo único.** A implementação da política de planejamento e desenvolvimento de que trata este artigo caberá a um órgão colegiado, com representação paritária do Governo do Estado e do setor privado.” “Art. 189. ............................................................................. .............................................................................................

**Art. 189-A.** Fica instituído o Fundo Estadual de Transporte e Habitação – FETHAB, cuja organização, formação e gerenciamento observarão o disposto em lei complementar, destinado a financiar o planejamento, a execução, o acompanhamento e avaliação de obras e serviços de transporte e de habitação em todo o Estado do Amapá.” “Art. 190. .............................................................................

**Parágrafo único.** O Estado do Amapá criará programas de incentivo à geração de energia elétrica por fontes renováveis.”

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 212

............................................................................................. “Art. 194. A política de desenvolvimento urbano, executada pelo Poder Público municipal, conforme diretrizes gerais fixadas em lei, tem por objetivo ordenar o pleno desenvolvimento das funções sociais da cidade e garantir o bem-estar de seus habitantes, observados os princípios fixados pela Constituição Federal, e ainda:

**§ 1º** O exercício do direito de propriedade do solo urbano atenderá à sua função social, condicionada às exigências fundamentais de ordenação da cidade.

**§ 2º** A política urbana deve garantir aos idosos, às gestantes e às pessoas portadoras de necessidades especiais facilidade plena de acesso aos bens e serviços de uso coletivo, públicos e privados, em especial nos meios de transporte.

**§ 3º** As empresas de transporte coletivo rodoviário intermunicipal de passageiros devem reservar 04 (quatro) vagas em cada viagem a ser realizada, qualquer que seja o destino, aos idosos inseridos no inciso II do art. 223.” “Art. 195. O plano diretor, aprovado pela Câmara Municipal, obrigatório para cidades com mais de vinte mil habitantes, é o instrumento básico da política de desenvolvimento e de expansão urbana. ............................................................................................” “Art. 199. ............................................................................

**§ 1º** O estado promoverá e financiará a construção de habitações populares, especialmente para a população de média e baixa renda, da área urbana, assegurando o pagamento pela equivalência salarial ou pela renda mensal dos trabalhadores autônomos e das mulheres que comprovarem condição mantenedora financeira de suas famílias. ............................................................................................” “Art. 223. ............................................................................ .............................................................................................

II - idoso a partir de sessenta anos;

III - pessoas portadoras de deficiência física, auditiva, visual, mental e múltipla, devidamente reconhecidos e cadastrados pelo órgão governamental competente, na forma da lei; ............................................................................................” “Art. 253. A seguridade social compreende um conjunto integrado de ações de iniciativa dos Poderes Públicos e da sociedade, destinadas a assegurar os direitos relativos à saúde, à previdência e à assistência social, competindo ao Poder Público, nos termos da lei, organizá-la com base nos objetivos estabelecidos no parágrafo único do art. 194, da Constituição Federal.

**Parágrafo único.** O financiamento da seguridade social no âmbito do Estado do Amapá se dará com observância, no

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 213

que couber, do disposto no art. 195 e seus parágrafos da Constituição Federal.” “Art. 255. ……….................................................................

**Parágrafo único.** Ao Estado, como integrante do sistema único de saúde, compete implementar ações destinadas a cumprir as atribuições referidas no art. 200 da Constituição Federal assim como, nos termos da lei:

I - controlar e fiscalizar, através de profissionais especializados, qualquer atividade e serviço que comporte risco à saúde, à segurança ou ao bem-estar físico e psíquico do indivíduo e da coletividade, bem como ao meio ambiente;

II - fomentar a pesquisa, o ensino, a produção científica e o aprimoramento tecnológico e de recursos humanos no desenvolvimento das áreas de saúde, prevenção de acidentes e meio ambiente;

III - estimular a formação da consciência pública voltada à preservação da saúde e do meio ambiente;

IV - promover e fiscalizar ações em benefício da saúde integral do trabalhador urbano e rural.” “Art. 256. …..…………………………………………………...

**Parágrafo único.** A redução dos riscos decorrentes do trabalho pressupõe a adoção de medidas de iniciativa do empregador, nas esferas pública e privada, com participação do trabalhador e da sociedade, cabendo, em especial aos órgãos e entidades integrantes do sistema único de saúde, promover ações e serviços que visem à promoção e à proteção da saúde do trabalhador.” “Art. 259. As ações e serviços públicos de saúde integram uma rede regionalizada e hierarquizada e constituem um sistema único, organizado e regulamentado em lei estadual, de acordo com as seguintes diretrizes:

I - descentralização, com direção única em cada esfera de governo;

II - atendimento integral, com prioridade para as atividades preventivas, sem prejuízo dos serviços assistenciais;

III - participação da comunidade. ...…......................................................................................

**§ 2º** Fica proibida a exigência de atestado de esterilidade, de teste de gravidez, e de qualquer outra que possua a mesma natureza destas, como condição para admissão ou continuidade no trabalho.” “Art. 263. .............................................................................

**Parágrafo único.** Mediante lei será instituído o Código Sanitário Estadual, o qual normatizará o processo de fiscalização, acompanhamento e promoção da saúde no Estado.” “Art. 265. ............................................................................

**Parágrafo único.** A rede pública de saúde prestará atendimento médico para prática de aborto, nos casos

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 214

previstos em lei federal, bem como para realização de cirurgia reparadora em vítimas de mutilação decorrente de câncer de mama e de violência.” “Art. 269. A previdência social será prestada pelo Estado e pelos Municípios aos servidores e seus dependentes, diretamente ou através de institutos de previdência, seja pelo regime próprio seja pelo regime geral, e atenderá, nos termos da lei, a:

I - cobertura dos eventos de doença, invalidez, morte e idade avançada;

II - proteção à maternidade, especialmente à gestante;

III - salário-família e auxílio-reclusão para os dependentes dos segurados de baixa renda;

IV - pensão por morte do segurado, homem ou mulher, ao cônjuge ou companheiro e dependente, observado o disposto no § 1º.

**§ 1º** Nenhum benefício que substitua o salário de contribuição ou o rendimento do trabalho do segurado terá valor mensal inferior ao salário mínimo.

**§ 2º** Todos os salários de contribuição considerados para o cálculo de benefício serão devidamente atualizados, na forma da lei.

**§ 3º** É assegurado o reajustamento dos benefícios para preservar-lhes, em caráter permanente, o valor real, conforme critérios definidos em lei.

**§ 4º** É vedada a filiação ao regime geral de previdência social, na qualidade de segurado facultativo, de pessoa que participe do regime próprio de previdência.

**§ 5º** A gratificação natalina dos aposentados e pensionistas terá por base o valor dos proventos do mês de dezembro de cada ano.

**§ 6º** Para efeito de aposentadoria, é assegurada a contagem recíproca do tempo de contribuição na administração pública e na atividade privada, rural e urbana, hipótese em que os diversos regimes de previdência social se compensarão financeiramente, segundo critérios estabelecidos em lei.” “Art. 270. O regime de previdência complementar de que trata o art. 60, organizado de forma autônoma em relação ao regime próprio de previdência social, será facultativo, baseado na constituição de reservas que garantam o benefício contratado, e regulado por lei complementar.

**§ 1º** A lei complementar de que trata este artigo assegurará ao participante de planos de benefícios de entidades de previdência privada o pleno acesso às informações relativas à gestão de seus respectivos planos.

**§ 2º** Observar-se-á quanto às contribuições, aos benefícios e às condições contratuais, bem como quanto ao aporte de recursos para as entidades de previdência privada, o disposto nos §§ 2º e 3º do art. 202 da Constituição Federal.”

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 215

“Art. 271. Quando no Município não existir regime próprio de previdência, seus servidores ficarão vinculados ao regime geral de previdência social.” “Art. 273. ............................................................................. .............................................................................................

VI - garantia de gratuidade nos transportes coletivos, urbanos e intermunicipais, aos portadores de perda total da acuidade visual, bem assim às pessoas incapacitadas de se locomoverem por si só, seja por deficiência física ou psicológica. ............................................................................................” “Art. 283. ............................................................................ .............................................................................................

**§ 5º** O ensino religioso, de matrícula facultativa, é parte integrante da formação básica do cidadão e constitui disciplina dos horários normais das escolas públicas de ensino fundamental e médio, assegurado o respeito à diversidade cultural e religiosa do Amapá, vedadas quaisquer formas de proselitismo. ............................................................................................” “Art. 289. O Estado e os Municípios aplicarão, respectivamente, vinte e oito por cento e vinte e cinco por cento, no mínimo, da receita resultante de impostos, compreendida a proveniente de transferência, na manutenção e desenvolvimento do ensino público.

**§ 1º** O Estado aplicará, do total da receita destinada ao ensino público, nunca menos de um e meio por cento em programas estaduais de erradicação do analfabetismo, com prioridade de atendimento às populações da zona rural.

**§ 2º** A parcela da arrecadação de impostos transferida pelos Estados aos Municípios não é considerada, para efeito do cálculo previsto neste artigo, receita do governo que a transferir.” “Art. 291. ............................................................................ .............................................................................................

**§ 1º** O Estado e os Municípios apoiarão com recursos humanos, financeiros e materiais as Escolas Famílias, entidades de ensino privadas, sem fins lucrativos, criadas para dar atendimento e formação profissionalizante aos jovens agricultores.

**§ 2º** Os alunos formados pelas Escolas Famílias terão prioridade, na forma da lei, na contratação, pelo Estado e pelos Municípios, para o serviço de assistência às comunidades agrícolas.” “Art. 296. ............................................................................ .............................................................................................

**§ 3º** As universidades e demais instituições de pesquisa sediadas no Estado devem participar do processo de formulação e acompanhamento da política científica e

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 216

tecnológica, competindo-lhes a criação de comitês de ética em pesquisa responsáveis pelo acompanhamento das ações desenvolvidas nesse campo. ............................................................................................” “Art. 304. ............................................................................ .............................................................................................

**§ 10** O Estado criará, mediante lei, o Centro Integrado de Atendimento à Infância e Adolescência – CEINFA, constituindo-se o mesmo em centro de referência para o atendimento de crianças e jovens dependentes químicos e portadores de deficiência mental ou qualquer outra necessidade especial.” “Art. 329. ............................................................................ .............................................................................................

IV - promover, anualmente, na primeira semana do mês de março, a Semana de Atendimento Integral à Saúde da Mulher;

V - implantar a Ouvidoria da Mulher em âmbito estadual;

VI - estimular políticas de inclusão da mulher no mercado de trabalho.”

“TÍTULO VIII Da Ordem Social .................................

#### CAPÍTULO XII Dos Afro-Brasileiros”

“Art. 332-A. Aos afro-brasileiros, assim definidos em lei, além dos direitos e garantias fundamentais consagrados pela Constituição Federal e por esta Constituição, é assegurado igualdade de oportunidade e tratamento em sua participação na vida econômica, social, política e cultural decorrente do desenvolvimento de políticas públicas no âmbito do Estado do Amapá, por meio de:

I - inclusão da dimensão racial nas políticas de desenvolvimento econômico e social;

II - adoção de medidas, programas e políticas de ação afirmativa;

III - modificação das estruturas institucionais do Estado para o adequado enfrentamento e superação das desigualdades decorrentes do preconceito e da discriminação racial;

IV - eliminação dos obstáculos históricos, socioculturais e institucionais que impedem a representação da diversidade racial nas esferas pública e privada;

V - estímulo e fortalecimento de iniciativas oriundas da sociedade civil direcionadas à promoção da igualdade de oportunidades e ao combate às desigualdades raciais, inclusive mediante a implementação de incentivos e

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 217

critérios de condicionamento e prioridade no acesso aos recursos e contratos públicos;

VI - implementação de programas de ação afirmativa, destinados ao enfrentamento das desigualdades raciais em todos os níveis e setores das atividades pública e privada;

VII - criação do Conselho Estadual de Promoção da Igualdade Racial.

**Parágrafo único.** Os programas de ação afirmativa constituir-se-ão em imediatas iniciativas reparatórias, destinadas a promover a correção das distorções e desigualdades raciais decorrentes do processo de escravidão e das demais práticas discriminatórias adotadas durante todo o processo de formação social do Brasil e poderão utilizar-se da estipulação de cotas para consecução de seus objetivos.”

“CAPÍTULO XIII Dos Direitos Humanos”

“Art. 333. ............................................................................ ............................................................................................”

“CAPÍTULO XIV Da Política Penitenciária”

“Art. 335. ........................................................................... ............................................................................................” “Art. 352. Aplicam-se, no que couber, aos servidores titulares de cargos efetivos do Estado do Amapá, incluídas suas autarquias e fundações, as normas atinentes ao regime previdenciário estabelecidas pelas Emendas à Constituição Federal n.º 20, de 15 de dezembro de 1998, n.º 41, de 19 de dezembro de 2003 e n.º 47, de 5 de julho de 2005.” ............................................................................................. “Art. 357. Os ex-integrantes da extinta Guarda Territorial do Amapá farão jus, quando carentes, ao recebimento de pensão especial vitalícia não inferior a dois salários mínimos, sendo a mesma inacumulável com quaisquer outros rendimentos recebidos dos cofres públicos, exceto os benefícios previdenciários, garantido o direito de opção.

**§ 1º** O benefício estabelecido neste artigo é transferível aos dependentes reconhecidamente carentes.

**§ 2º** A concessão do benefício far-se-á nos termos de lei a ser proposta pelo Poder Executivo.”

“TÍTULO X Ato das Disposições Constitucionais Transitórias” .............................................................................................

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 218

“Art. 24. A lei que instituir a justiça de paz manterá os atuais juízes de paz até a posse dos novos titulares, assegurando-lhes os direitos e atribuições conferidos a estes, e designará o dia para a eleição prevista no art. 141 desta Constituição.

**Parágrafo único.** No prazo de 180 (cento e oitenta) dias, contados da data de publicação desta emenda, o Tribunal de Justiça do Estado fará apresentar o projeto de lei necessário à organização da Justiça de Paz.” “Art. 29. (Dispositivo declarado inconstitucional, em controle concentrado, pelo Supremo Tribunal Federal, no julgamento da ADIN n.º 1267-3).” ............................................................................................” “Art. 41. ….......……………………………………………… …………………..……………………….....…………………

**§ 3º** Os recursos provenientes dos fundos referidos neste artigo e de tantos outros quanto possam vir a ser criados no âmbito do Estado, de natureza constitucional ou não, serão geridos e administrados pela Agência de Fomento do Amapá S/A, na forma da lei, através de linhas de crédito específicas, especialmente voltadas ao microcrédito e ao crédito para pequenos e médios empreendedores.” ............................................................................................” “Art. 57. Os vencimentos, a remuneração, as vantagens e os adicionais, bem como os proventos de aposentadoria que estejam sendo percebidos em desacordo com a Constituição serão imediatamente reduzidos aos limites dela decorrentes, não se admitindo, neste caso, invocação de direito adquirido ou percepção de excesso a qualquer

título.

**§ 1º** É assegurado o exercício cumulativo de dois cargos ou empregos privativos de médico que estejam sendo exercidos por médico militar na administração pública direta ou indireta.

**§ 2º** É assegurado o exercício cumulativo de dois cargos ou empregos privativos de profissionais de saúde que estejam sendo exercidos na administração pública direta ou indireta.” “Art. 58. O Poder Executivo adotará todas as providências necessárias à implantação da Universidade Estadual.” “Art. 59. No prazo de 60 (sessenta) dias, contados da data de publicação desta emenda, o Poder Executivo fará encaminhar à Assembleia Legislativa projeto de lei visando à regulamentação do § 10 do art. 304 desta Constituição.” “Art. 60. A lei de que trata o § 3º do art. 41 deverá ser editada no prazo de 120 (cento e vinte) dias, contados da publicação desta emenda.” “Art. 61. Fica facultado ao Estado, enquanto não for implantada a escola de governo responsável pelo

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 219

atendimento do disposto no § 2º do art. 47, realizar a incumbência ali fixada mediante a celebração de contratos ou convênios com instituições de ensino superior. “Art. 62. O Poder Executivo fará encaminhar à Assembleia Legislativa, no prazo máximo de 90 (noventa dias) contados da publicação desta Emenda, o projeto de lei a que se refere o § 2º do art. 357.” ............................................................................................”

**Art. 2º** São revogados o art. 3º, o § 4º do art. 76, o parágrafo único do

art. 79, o inciso XIII do art. 112, as alíneas de a à f do inciso II do art. 126, as alíneas a e b do inciso I e os §§ 1º e 4º do art. 129, o art. 130 e seus §§ 1º ao 4º, o parágrafo único e as alíneas a e b do art. 138, o § 1º seus incisos de I a IV do art. 149, o art. 348 e seus §§ 1º ao 3º, o art. 349 e seu parágrafo único e o art. 356 e seus §§ 1º e 2º da Constituição do Estado do Amapá, bem assim o art. 52 e seu parágrafo único e o art. 55 do Ato das Disposições Constitucionais Transitórias desta mesma Constituição.

**Art. 3º** Esta Emenda Constitucional entra em vigor na data de sua publicação. Macapá-AP, 21 de março de 2006.

A Mesa da Assembleia Legislativa: Jorge Amanajás - Presidente; Francisca Favacho - 1º Vice-Presidente; Paulo José - 2º Vice-Presidente; Roberto Góes - 1º Secretário; Ubiranildo Macêdo - 2º Secretário; Jorge Souza - 3º Secretário; Raimunda Beirão - 4ª Secretária.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 220

EMENDA À CONSTITUIÇÃO Nº 0036, DE 08 DE AGOSTO DE 2006 Publicada no Diário Oficial do Estado nº 3865, de 09.10.06

Acrescenta os §§ 3º, 4º e 5º ao art. 259 da Constituição Estadual.

A Mesa Diretora da Assembleia Legislativa do Estado do Amapá faz saber que a Assembleia Legislativa do Estado do Amapá aprovou e ela promulga a seguinte Emenda à Constituição:

**Art. 1º** O art. 259 da Constituição Estadual passa a vigorar acrescido dos §§ 3º, 4º e 5º.

“Art. 259. ............................................................................. .............................................................................................

**§ 3º** Os gestores locais do sistema único de saúde poderão admitir enfermeiros, técnicos de enfermagem, auxiliares de enfermagem, agentes comunitários de saúde, agentes de combate às endemias e atendente de consultório dentário por meio de processo seletivo público, de acordo com a natureza e complexidade de suas atribuições e requisitos específicos para sua atuação.

**§ 4º** Aplica-se aos agentes comunitários de saúde e agentes de combate às endemias o disposto na Lei Federal nº. 10.507, de 10 de junho de 2002, e Lei Estadual disporá sobre o regimento jurídico e a regulamentação das atividades de agente comunitário de saúde e agente de combate às endemias.

**§ 5º** Aplica-se a todos os profissionais enumerados no § 4º o disposto no art. 49.”

**Art. 2º** Após a promulgação da presente Emenda Constitucional, os enfermeiros, técnicos de enfermagem, auxiliares de enfermagem, agentes comunitários de saúde, agentes de combate às endemias e atendentes de consultório dentário somente poderão ser contratados diretamente pelos Municípios na forma do

**§ 3º** do art. 259 da Constituição Estadual, observado o limite de gastos estabelecido na Lei Complementar de que trata o art. 169 da Constituição Federal.

**§ 1º** Aplica-se aos profissionais da saúde, no que couber, o disposto no inciso XVI, alínea c, do art. 37 da Constituição Federal.

**§ 2º** Os agentes comunitários de saúde e agentes de combate às endemias, que na data da promulgação da Emenda à Constituição Federal nº. 51 e, os enfermeiros, técnicos de enfermagem, auxiliares de enfermagem e atendentes de consultório dentário, que na data da promulgação dessa emenda, que a qualquer

título, desempenharem as atividades no Programa de Agentes Comunitário de Saúde ou Agente de Combate às Endemias e no Programa Saúde da Família, na forma da Lei, ficam dispensados de se submeterem ao processo seletivo público a que se refere o § 3º do art. 259 da Constituição Estadual, desde que tenham sido contratados a partir de anterior processo de Seleção Pública efetuado por órgãos ou entes da administração direta ou indireta do Estado, Distrito Federal ou Município ou por outras

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 221

instituições com efetiva supervisão e autorização da administração direta dos entes da federação.

**Art. 3º** Ficam o Estado e os Municípios obrigados a aplicarem como contrapartida na formação dos vencimentos dos agentes comunitários de saúde, agentes de combate às endemias e atendentes de consultórios dentários, os percentuais mínimos de 50% (cinquenta por cento) sobre o repasse da União para o fim referido.

**Art. 4º** Esta Emenda Constitucional entra em vigor na data de sua publicação.

Macapá - AP, 08 de agosto de 2006.

A Mesa da Assembleia Legislativa: Jorge Amanajás - Presidente; Francisca Favacho - 1º Vice-Presidente; Paulo José - 2º Vice-Presidente; Roberto Góes - 1º Secretário; Ubiranildo Macêdo - 2º Secretário; Jorge Souza - 3º Secretário; Raimunda Beirão - 4ª Secretária.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 222

EMENDA À CONSTITUIÇÃO Nº 0037, DE 04 DE JUNHO DE 2007 Publicada no Diário Oficial do Estado nº 4025, de 13.06.2007

Dá nova redação ao art. 113 da Constituição do Estado do Amapá.

A Mesa Diretora da Assembleia Legislativa do Estado do Amapá faz saber que a Assembleia Legislativa do Estado do Amapá aprovou e ela promulga a seguinte Emenda à Constituição:

**Art. 1º** O art. 113 da Constituição do Estado do Amapá passa a vigorar com a seguinte redação:

“Art. 113. O Tribunal de Contas do Estado, integrado por sete Conselheiros, tem sede na capital do Estado, autonomia funcional, administrativa e financeira, quadro próprio de pessoal e jurisdição em todo o território estadual, exercendo, no que couber, as atribuições do art. 96 da Constituição Federal.”

**Art. 2º** Esta Emenda Constitucional entra em vigor na data de sua publicação.

Macapá – AP, 04 de junho de 2007.

A Mesa da Assembleia Legislativa: Jorge Amanajás - Presidente; Francisca Favacho - 1º Vice-Presidente; Ricardo Soares - 2º Vice-Presidente; Roberto Góes - 1º Secretário; Jorge Salomão - 2º Secretário; Mira Rocha - 3ª Secretária; Meire Serrão - 4ª Secretária.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 223

EMENDA À CONSTITUIÇÃO Nº 0038, de 05 de junho de 2007 Publicada no Diário Oficial do Estado nº 4027, de 15.05.07

Acrescenta parágrafos ao artigo 310 da Constituição do Estado.

A Mesa Diretora da Assembleia Legislativa do Estado do Amapá faz saber que a Assembleia Legislativa do Estado do Amapá aprovou e ela promulga a seguinte Emenda à Constituição:

**Art. 1º** O art. 310 da Constituição do Estado do Amapá passa a vigorar com a seguinte redação:

“Art. 310. Todos têm direito ao meio ambiente ecologicamente equilibrado, bem de uso comum do povo e essencial à sadia qualidade de vida, impondo-se ao Poder Público e à Coletividade o dever de defendê-lo e preservá- lo para as presentes e futuras gerações.

**§ 1º** O Poder Executivo, através de seus órgãos executores das políticas ambientais, elaborará, anualmente, o relatório de qualidade ambiental do Estado do Amapá.

**§ 2º** O relatório de qualidade ambiental refletirá quaisquer alterações naturais ou construídas ocorridas no período anterior, devendo ser apresentado até o fim do primeiro quadrimestre do ano subsequente.”

**Art. 2º** Esta Emenda à Constituição entra em vigor na data de sua publicação.

Macapá – AP, 05 de junho de 2007.

A Mesa da Assembleia Legislativa: Jorge Amanajás - Presidente; Francisca Favacho - 1º Vice-Presidente; Ricardo Soares - 2º Vice-Presidente; Roberto Góes - 1º Secretário; Jorge Salomão - 2º Secretário; Mira Rocha - 3ª Secretária; Meire Serrão - 4ª Secretária.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 224

EMENDA À CONSTITUIÇÃO Nº 0039, DE 11 DE SETEMBRO DE 2007 Publicada no Diário Oficial do Estado nº 4092, de 18.09.07

Altera a redação ao Art. 92, caput e § 2º, da Constituição do Estado do Amapá.

A Mesa Diretora da Assembleia Legislativa do Estado do Amapá faz saber que a Assembleia Legislativa do Estado do Amapá aprovou e ela promulga a seguinte Emenda à Constituição:

**Art. 1º** O Artigo 92, caput, da Constituição do Estado do Amapá, passa a vigorar com a seguinte redação:

“Art. 92. A Assembleia Legislativa funcionará em sessões públicas, presentes pelos menos um quarto de seus membros”.

**Art. 2º** Esta Emenda à Constituição entra em vigor na data de sua publicação.

Macapá – AP, 11 de setembro de 2007.

A Mesa da Assembleia Legislativa: Jorge Amanajás - Presidente; Francisca Favacho - 1º Vice-Presidente; Ricardo Soares - 2º Vice-Presidente; Roberto Góes - 1º Secretário; Jorge Salomão - 2º Secretário; Mira Rocha - 3ª Secretária; Meire Serrão - 4ª Secretária.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 225

EMENDA À CONSTITUIÇÃO Nº 0040, DE 04 DE MARÇO DE 2008 Publicada no Diário Oficial do Estado nº 4214, de 25.03.08

Altera o art. 146 da Constituição do Estado do Amapá.

A Mesa Diretora da Assembleia Legislativa do Estado do Amapá faz saber que a Assembleia Legislativa do Estado do Amapá aprovou e ela promulga a seguinte Emenda à Constituição:

**Art. 1º** Fica alterado o art. 146 da Constituição do Estado do Amapá, que passa a vigorar com a seguinte redação:

“Art. 146. O Ministério Público do Estado tem como Chefe o Procurador-Geral de Justiça, nomeado pelo Governador do Estado, dentre Procuradores ou Promotores de Justiça com mais de trinta e cinco anos de idade, que gozem de vitaliciedade, indicados em lista tríplice, para mandato de dois anos, permitida uma recondução”.

**Art. 2º** Esta Emenda à Constituição entra em vigor na data de sua publicação.

Macapá - AP, 04 de março de 2008.

A Mesa da Assembleia Legislativa: Jorge Amanajás - Presidente; Francisca Favacho - 1º Vice-Presidente; Ricardo Soares - 2º Vice-Presidente; Roberto Góes - 1º Secretário; Jorge Salomão - 2º Secretário; Mira Rocha - 3ª Secretária; Meire Serrão - 4ª Secretária.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 226

EMENDA À CONSTITUIÇÃO Nº 0041, DE 27 DE MAIO DE 2008 Publicada no Diário Oficial do Estado nº 4262, de 04.06.2008

Altera a redação do art. 100 da Constituição Estadual, que trata das reuniões da Assembleia Legislativa do Estado do Amapá.

A Mesa Diretora da Assembleia Legislativa do Estado do Amapá faz saber que a Assembleia Legislativa do Estado do Amapá aprovou e ela promulga a seguinte Emenda à Constituição:

**Art. 1º** O caput do art. 100 da Constituição do Estado do Amapá, passa a vigorar com a seguinte redação:

“Art. 100. A Assembleia Legislativa reunir-se-á, anualmente, na capital do Estado, de 02 de fevereiro a 30 de junho e de 1º de agosto a 22 de dezembro”.

**Art. 2º.** Esta Emenda à Constituição entra em vigor na data de sua publicação.

Macapá – AP, 27 de maio de 2008.

A Mesa da Assembleia Legislativa: Jorge Amanajás - Presidente; Francisca Favacho - 1º Vice-Presidente; Ricardo Soares - 2º Vice-Presidente; Roberto Góes - 1º Secretário; Jorge Salomão - 2º Secretário; Mira Rocha - 3ª Secretária; Meire Serrão - 4ª Secretária.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 227

EMENDA À CONSTITUIÇÃO Nº 0042, DE 30 DE JUNHO DE 2009 Publicada no Diário Oficial do Estado nº 4557, de 11.08.09

Altera os arts. 206, 208, 214 e 216 da Constituição do Estado do Amapá.

A Mesa Diretora da Assembleia Legislativa do Estado do Amapá faz saber que a Assembleia Legislativa do Estado do Amapá aprovou e ela promulga a seguinte Emenda à Constituição:

**Art. 1º** Os arts. 206, 208, 214 e 216 da Constituição do Estado do Amapá passam a vigorar com a seguinte redação:

“Art. 206. A alienação ou a concessão, a qualquer título, de terras públicas, a pessoa física ou jurídica, ainda que por interposta pessoa, obedecerá ao seguinte, sem prejuízo do disposto em lei:

a) até 4 módulos fiscais, mediante aprovação do órgão fundiário;

b) acima de 4 e até 15 módulos fiscais, mediante aprovação de um plano de exploração econômica pelo órgão fundiário;

c) acima de 15 módulos fiscais e até dois mil e quinhentos hectares, além do disposto na alínea b, com prévia aprovação da Comissão Permanente de Política Agrária da Assembleia Legislativa.

**§ 1º** As áreas já instaladas, superiores a 15 módulos fiscais, deverão apresentar projeto de utilização da área, com demonstração do respectivo retorno social, a ser apreciado pela Comissão Permanente de Política Agrária da Assembleia Legislativa, para a devida aprovação ou cancelamento.

**§ 2º** Às áreas superiores a dois mil e quinhentos hectares aplica-se, no que couber, o disposto na Constituição Federal.

**§ 3º** Excetuam-se do disposto no caput deste artigo as alienações ou as concessões de terras públicas para fins de reforma agrária.”

“Art. 208. ............................................................................. .............................................................................................

**§ 3º** O Estado assegurará aos detentores de posse de terras públicas, por eles tornadas produtivas como o seu trabalho e o de sua família, a preferência para a aquisição de área, até o limite constitucional, mediante concessão de

título de domínio, desde que: ............................................................................................”

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 228

“Art. 214. Os órgão públicos responsáveis pelas políticas agrária, fundiária e florestal no Estado farão a indicação, obedecendo ao zoneamento agroecológico, das áreas potenciais para implantação de projetos de desenvolvimento agropecuário e florestal.”

“Art. 216. É vedado ao Estado, sem prévia autorização do órgão competente da Assembleia Legislativa, resguardado o disposto na Constituição Federal:

I - promover a alienação ou concessão de terras públicas e devolutas, com áreas superiores a 15 módulos fiscais; observado o limite máximo de dois mil e quinhentos hectares;

II - promover a legitimação, alienação ou concessão de terras públicas e devolutas para fins de reflorestamento homogêneo e manejo florestal.”

**Art. 2º** Esta Emenda Constitucional entra em vigor na data de sua publicação.

Macapá - AP, 30 de junho de 2009.

A Mesa da Assembleia Legislativa: Jorge Amanajás – Presidente; Dalto Martins - 1º Vice-Presidente; Ricardo Soares - 2º Vice-Presidente; Eider Pena - 1º Secretário; Jorge Salomão - 2º Secretário; Mira Rocha - 3ª Secretária; Meire Serrão - 4ª Secretária.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 229

EMENDA À CONSTITUIÇÃO Nº 0043, DE 30 DE NOVEMBRO DE 2009 Publicada no Diário Oficial do Estado nº 4628, de 25.11.09

Altera a redação dada aos arts. 206, 208 e 216 da Constituição do Estado do Amapá pela Emenda Constitucional nº 0042, de 30 de junho de 2009, e dá outras providências.

A Mesa Diretora da Assembleia Legislativa do Estado do Amapá faz saber que a Assembleia Legislativa do Estado do Amapá aprovou e ela promulga a seguinte Emenda à Constituição:

**Art. 1º** As alíneas “a” e “b”, os §§ 1º e 2º, do art. 206, o inciso I do § 3º e o § 6º do art. 208 e o art. 216 da Constituição do Estado do Amapá passam a ter a seguinte redação:

“Art. 206. ............................................................................. .............................................................................................

a) até 15 módulos fiscais, mediante aprovação do órgão fundiário;

b) acima de 15 módulos fiscais e até dois mil e quinhentos hectares, além do disposto na alínea a, com prévia aprovação da Comissão Permanente de Política Agrária da Assembleia Legislativa.

**§ 1º** As áreas superiores a dois mil e quinhentos aplica-se, no que couber, o disposto na Constituição Federal.

**§ 2º** Excetuam-se do disposto no caput deste artigo as alienações ou as concessões de terras públicas para fins de reforma agrária. .............................................................................................

**Art. 208.** .............................................................................. .............................................................................................

§ 3º....................................................................................... ............................................................................................. I . Não sejam proprietários de outra área rural superior ao menor módulo fiscal definido para o Estado do Amapá; .............................................................................................

**§ 6º** Os lotes destinados a assentamentos nunca serão inferiores ao módulo fiscal definido para o município onde se localizar o projeto de assentamento, ficando vedada a concessão de títulos de domínio ou de uso de mais de um lote à mesma unidade familiar. .............................................................................................

**Art. 216.** É vedado ao Estado, sem prévia autorização do órgão competente da Assembleia Legislativa, resguardando o disposto na Constituição Federal, a alienação ou concessão de terras públicas e devolutas, com área superiores a quinze módulos fiscais, observado o limite máximo de dois mil e quinhentos hectares.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 230

**Parágrafo único.** A vedação prevista no caput deste artigo refere-se, inclusive, à alienação ou concessão para fins de reflorestamento homogêneo ou de manejo florestal”.

**Art. 2º** Esta Emenda Constitucional entra em vigor na data de sua publicação.

Macapá - AP, 16 de novembro de 2009.

A Mesa da Assembleia Legislativa: Jorge Amanajás - Presidente; Dalto Martins - 1º Vice-Presidente; Ricardo Soares - 2º Vice-Presidente; Eider Pena - 1º Secretário; Jorge Salomão - 2º Secretário; Mira Rocha - 3ª Secretária; Meire Serrão - 4ª Secretária.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 231

EMENDA À CONSTITUIÇÃO Nº 0044, DE 21 DE DEZEMBRO DE 2009 Publicada no Diário Oficial do Estado nº 4659, de 13.01.2010

Acrescenta o art. 63 ao ato das Disposições Transitórias da Constituição do Estado do Amapá.

A Mesa Diretora da Assembleia Legislativa do Estado do Amapá faz saber que a Assembleia Legislativa do Estado do Amapá aprovou e ela promulga a seguinte Emenda à Constituição:

**Art. 1º** Fica acrescentado o artigo 63 ao Ato das Disposições Transitórias com a seguinte redação:

“Art. 63. O servidor público federal da categoria de Fiscal de Tributos e Auxiliar de Fiscal do Ex-território Federal do Amapá, citados na Lei nº 0982, de 03 de abril de 2006, que na data da promulgação desta Emenda estiver regulamente à disposição do Estado, poderá optar, sem prejuízo de suas atividades, por integrar o quadro pessoal da secretaria da Receita Estadual de que trata a Lei nº 0982/2006.

**§ 1º** No enquadramento dos optantes será considerado o tempo de serviço e a irredutibilidade de vencimentos.

**§ 2º** O direito de opção de que trata o presente artigo, esgotar - se – à em sessenta meses a contar da data da promulgação desta Emenda.

**§ 3º** A opção será regulamentada por decreto do Executivo Estadual”.

**Art. 2º** A presente Emenda entrará em vigor na data de sua publicação.

Macapá - AP, 21 de dezembro de 2009.

A Mesa da Assembleia Legislativa: Jorge Amanajás - Presidente; Dalto Martins - 1º Vice-Presidente; Ricardo Soares - 2º Vice-Presidente; Eider Pena - 1º Secretário; Jorge Salomão - 2º Secretário; Mira Rocha - 3ª Secretária; Meire Serrão - 4ª Secretária.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 232

EMENDA A CONSTITUIÇÃO Nº 0045, DE 27 DE JUNHO 2012 Publicada no Diário Oficial do Estado nº 5259, de 03.07.2012

Acrescenta o Inciso XXVIII ao Art. 119 da Constituição do Estado do Amapá.

A MESA DIRETORA DA ASSEMBLEIA LEGISLATIVA DO ESTADO DO AMAPÁ faz saber que a Assembleia Legislativa do Estado do Amapá aprovou e ela promulga a seguinte Emenda Constitucional:

**Art. 1º** Fica acrescentado o Inciso XXVIII ao Art. 119 da Constituição do Estado do Amapá, com a seguinte redação:

“Art. 119. .............................................................................

XXVIII - O prazo para expedir decreto regulamentador de lei, aprovada ou promulgada, para sua fiel execução não poderá ser superior a 120 (cento e vinte) dias, contados a partir da sua publicação, sendo que o não cumprimento do prazo estipulado acarretará em crime de responsabilidade".

**Art. 2º** Esta Emenda à Constituição Estadual entra em vigor na data de sua publicação.

Macapá - AP, 27 de junho de 2012.

Deputado JÚNIOR FAVACHO Presidente em exercício

Deputada ROSELI MATOS 2º Vice-Presidente

Deputado CHARLES MARQUES 2º Secretário

Deputado KEKA CANTUÁRIA 3º Secretário

Deputada SANDRA OHANA 4º Secretária

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 233

EMENDA A CONSTITUIÇÃO Nº 0046, DE 03 DE JULHO 2012 Publicada no Diário Oficial do Estado nº 5261, de 05/07/2012

Acrescenta o inciso IV no § 8º do Artigo 175 da Constituição do Estado do Amapá.

A MESA DIRETORA DA ASSEMBLEIA LEGISLATIVA DO ESTADO DO AMAPÁ, nos termos do art. 103, § 3º da Constituição do Estado do Amapá, promulga a seguinte emenda ao texto da Constituição Estadual:

**Art. 1º** Acrescenta o inciso IV no § 8º do artigo 175 da Constituição Estadual, que passa a vigorar com a seguinte redação:

“Art. 175 ............................................................................. .............................................................................................

**§ 8°** A lei Orçamentária anual compreenderá:

I - ......................................................................................... ............................................................................................. “IV - O percentual mínimo de 5% (cinco por cento), como contrapartida do Poder Executivo Estadual, aos valores referentes às Emendas Parlamentares Federais, na execução dos projetos destinados pela União aos Municípios do Estado do Amapá.”

**Art. 2º** Esta Emenda à Constituição Estadual entra em vigor na data de sua publicação.

Macapá - AP, 03 de julho de 2012.

Deputado JÚNIOR FAVACHO Presidente em exercício

Deputada ROSELI MATOS 2º Vice-Presidente

Deputado CHARLES MARQUES 2º Secretário

Deputado KEKA CANTUÁRIA 3º Secretário

Deputada SANDRA OHANA 4º Secretária

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 234

EMENDA A CONSTITUIÇÃO Nº 0047, DE 03 DE JULHO 2012 Publicada no Diário Oficial do Estado nº 5261, de 05/07/2012

Dá nova Redação ao Artigo 153 da Constituição do Estado do Amapá.

A MESA DIRETORA DA ASSEMBLEIA LEGISLATIVA DO ESTADO DO AMAPÁ, nos termos do art. 103, § 3º da Constituição do Estado do Amapá, promulga a seguinte emenda ao texto da Constituição Estadual:

**Art. 1º** O artigo 153 da Constituição do Estado passa a vigorar com a seguinte redação:

“Art. 153. A Procuradoria Geral do Estado do Amapá é instituição essencial à justiça e à administração pública estadual, que representa o Estado judicial e extrajudicialmente, cabendo-lhe, com exclusividade, a defesa dos direitos e interesses estaduais na área judicial e administrativa e as atividades de consultoria e assessoramento jurídico do Poder Executivo, bem como exercer outras funções que lhe forem conferidas por lei.

**§ 1º** São fundamentos da Procuradoria Geral do Estado do Amapá a autonomia institucional, a fiel observância aos princípios gerais da administração, a lealdade ao ente público que representa e a independência técnica de seus membros, sendo esta última regulada pelo poder normativo do Conselho Superior e será exercida de forma a manter a harmonia, coerência, eficiência e agilidade em atuação.

**§ 2º** A Procuradoria-Geral do Estado será chefiada pelo Procurador-Geral do Estado, com prerrogativas de Secretário de Estado, sendo o cargo provido em comissão, pelo Governador, dentre cidadãos maiores de 35 (trinta e cinco) anos, notável saber jurídico e reputação ilibada, preferencialmente dentre membros da carreira, devendo o nomeado apresentar declaração pública de bens no ato da posse e quando for exonerado.

**§ 3º** Ingresso na carreira de Procurador do Estado far-se-á mediante concurso público de provas e títulos, assegurada a participação em todas as etapas da Ordem dos Advogados do Brasil, seccional do Amapá, e de membro do Ministério Público, exigindo-se do bacharel em direito, no mínimo, três anos de atividade jurídica e observando- se, nas nomeações, a ordem de classificação.

**§ 4º** Sem prejuízo do disposto no § 1º deste artigo são privativos de procuradores estáveis os cargos em comissão de Subprocurador Geral e Procurador de Estado Corregedor.

**§ 5º** O subsídio da última classe dos Procuradores do Estado do Amapá corresponderá a noventa inteiros e vinte e cinco centésimos por cento do subsídio mensal, fixado

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 235

para os Ministros do Supremo Tribunal Federal, e os subsídios dos demais integrantes da carreira de Procurador de Estado serão fixados em lei e escalonados, não podendo a diferença entre uma e outra classe ser superior a dez por cento ou inferior a cinco por cento, observado, em qualquer caso, o disposto nos arts. 37, XI e 39, § 4º da Constituição Federal.

**§ 6º** Nos processos judiciais que versarem sobre atos praticados pelo Poder Legislativo ou por sua Administração, a representação do Estado cabe à Procuradoria Geral da Assembleia Legislativa, observado, no que couber, o que dispõe a parte final do caput do art. 115”.

**Art. 2º** Esta Emenda à Constituição Estadual entra em vigor na data de sua publicação.

Macapá - AP, 03 de julho de 2012.

Deputado JÚNIOR FAVACHO Presidente em exercício

Deputada ROSELI MATOS 2º Vice-Presidente

Deputado CHARLES MARQUES 2º Secretário

Deputado KEKA CANTUÁRIA 3º Secretário

Deputada SANDRA OHANA 4º Secretária

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 236

EMENDA À CONSTITUIÇÃO Nº 0048, DE 13 DE OUTUBRO DE 2014 Publicada no Diário Oficial nº 5817, de 13.10.2014 (Declarada inconstitucional, em controle concentrado, pelo Supremo Tribunal Federal, no julgamento da ADIN nº 5.171).

Altera artigo da Constituição do Estado do Amapá, no Capítulo IV, Seção I, na forma que especifica.

A MESA DIRETORA DA ASSEMBLEIA LEGISLATIVA DO ESTADO DO AMAPÁ, nos termos do art. 103, § 3º da Constituição do Estado do Amapá, promulga a seguinte emenda ao texto da Constituição Estadual:

**Art. 1º** Altera e acrescenta dispositivo ao art. 146 do Capítulo IV, Seção I da Constituição do Estado do Amapá, que passa a vigorar com a seguinte redação: “Art. 146. O Ministério Público do Estado tem como Chefe o Procurador-Geral de Justiça, nomeado pelo Governador do Estado, dentre Procuradores com mais de trinta e cinco anos de idade, que gozem de vitaliciedade, indicados em lista tríplice, para mandato de dois anos, permitida uma recondução.

**Parágrafo único.** A eleição do Procurador-Geral de Justiça do Estado, para cada biênio subsequente, será realizada sempre no dia 15 (quinze) de janeiro”.

**Art. 2º** Esta Emenda Constitucional entra em vigor na data de sua publicação.

Macapá-AP, 13 de outubro de 2014.

Deputado MOISÉS SOUZA Presidente

Deputado JÚNIOR FAVACHO Presidente em exercício

Deputada ROSELI MATOS 2ª Vice-Presidente

Deputado EDINHO DUARTE 1º Secretário

Deputado CHARLES MARQUES 2º Secretário

Deputado KEKA CANTUÁRIA 3º Secretário

Deputada SANDRA OHANA 4ª Secretária

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 237

EMENDA À CONSTITUIÇÃO Nº 0049, DE 22 DE DEZEMBRO DE 2014 Publicada no Diário Oficial nº 5869, de 31.12.2014

Altera o §7º e §12 do art. 67 da Constituição do Estado do Amapá.

A MESA DIRETORA DA ASSEMBLEIA LEGISLATIVA DO ESTADO DO AMAPÁ, nos termos do art. 103, § 3º da Constituição do Estado do Amapá, promulga a seguinte emenda ao texto da Constituição Estadual:

**Art. 1º** A Constituição do Estado passa a vigorar com a seguinte redação ao § 7º e § 12 do art. 67:

“Art. 67. ............................................................................... [...]

**§ 7º** Serão transferidos para reserva remunerada o Comandante Geral da Polícia Militar, o Comandante Geral do Corpo de Bombeiros Militar, os Chefes dos Gabinetes Militares dos Poderes e do Ministério Público Estadual, que possuam o tempo de serviço para inatividade, com todos os direitos e vantagens pecuniárias do cargo e que tenham exercido os respectivos cargos pelo período mínimo de 18 meses, ininterruptos ou alternados, preservados os direitos e vantagens concedidos aos Oficiais já transferidos para a reserva remunerada. ............................................................................................. [...]

**§ 12** A transferência para a reserva remunerada a pedido será concedida mediante requerimento do servidor militar estadual que conte mais de 25 (vinte e cinco) anos de serviço, assegurada a promoção ao posto ou graduação imediatamente superior ao seu, por ocasião da passagem à inatividade.

**Art. 2º** Esta Emenda Constitucional entra em vigor na data de sua publicação. Macapá-AP, 22 de dezembro de 2014.

Deputado MOISES SOUZA Presidente

Deputado JÚNIOR FAVACHO Deputada ROSELI MATOS Presidente em exercício 2º Vice-Presidente

Deputado EDINHO DUARTE Deputado CHARLES MARQUES 1º Secretário 2º Secretário

Deputado KEKA CANTUÁRIA Deputada SANDRA OHANA 3º Secretário 4º Secretária

\*Republicação, no DOE nº 5899, de 31.12.2014, por haver sido publicado com incorreções.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 238

EMENDA À CONSTITUIÇÃO Nº 0050, DE 30 DE DEZEMBRO DE 2014 Publicada no Diário Oficial do Estado nº 5915, de 11.03.2005

Altera o art. 75 e 76 da Constituição do Estado do Amapá, para acrescentar o inciso V no art. 75 e o parágrafo 6º no art. 76.

A MESA DA ASSEMBLEIA LEGISLATIVA DO ESTADO DO AMAPÁ, nos termos do § 3º, do Art. 104, da Constituição do Estado, promulga a seguinte

Emenda ao texto da Constituição do Estado:

**Art. 1º** Acrescentem-se ao art. 75 o inciso V com a seguinte redação:

“Art. 75. A segurança pública, dever do Estado, direito e responsabilidade de todos, é exercida para a preservação da ordem pública e incolumidade das pessoas e do patrimônio, através dos seguintes órgãos, subordinados ao Governador do Estado:

I - Polícia Civil;

II - Polícia Militar;

III - Corpo de Bombeiros Militar;

IV - Polícia Técnico-Científica;

V - Superintendência de Administração Penitenciária do Estado do Amapá - SUAP. .............................................................................................

**Art. 2º** Acrescenta-se ao art. 76 o § 6º com a seguinte redação:.

“Art. 76. A Lei disciplinará a organização e funcionamento dos órgãos responsáveis pela segurança pública, de maneira a garantir a eficiência de suas atividades definindo suas competências, estruturando suas carreiras e fixando direitos, deveres, vantagens e regime de trabalho de seus integrantes.

**§ 1º** ......................................................................................

**§ 2º** ......................................................................................

**§ 3º** ......................................................................................

**§ 4º** ......................................................................................

**§ 5º** ......................................................................................

**§ 6º** A Superintendência de Administração Penitenciária do Estado do Amapá – SUAP, órgão permanente, assegurada a autonomia administrativa, atividade exclusiva do Estado essencial à função jurisdicional dirigida por agente, por educador de execução penal, de carreira, conforme requisitos a que se refere o art. 75 da Lei nº 7.210, de 11 de julho de 1984, destina-se, além das atribuições definidas em lei, a custódia dos apenados pela Justiça do Estado do Amapá, à segurança interna e externa das unidades penais, à escolta penal, a recaptura de foragidos

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 239

das unidades penais, ao serviço de inteligência penal, à intervenção em conflitos das unidades penais, à fiscalização do cumprimento das penas alternativas e condicionais, à ressocialização do apenado e às medidas de reinserção social ao egresso”.

**Art. 3º** O Governo do Estado terá o prazo de um ano para adequar a legislação aos termos desta Emenda Constitucional.

**Art. 4º** Esta Emenda Constitucional entra em vigor na data de sua publicação.

Macapá - AP, 30 de dezembro de 2014.

Deputado MOISÉS SOUZA Presidente

Deputado JÚNIOR FAVACHO 1º Vice-Presidente

Deputada ROSELI MATOS 2º Vice-Presidente

Deputado EDINHO DUARTE 1º Secretário

Deputado CHARLES MARQUES 2º Secretário

Deputado KEKA CANTUÁRIA 3º Secretário

Deputada SANDRA OHANA 4º Secretária

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 240

EMENDA À CONSTITUIÇÃO Nº 0051, DE 31 DE DEZEMBRO DE 2014 Publicada no Diário Oficial do Estado nº 5915, de 11.03.2015

Acrescenta os §§ 1º e 2º, ao art. 49, da Constituição Estadual.

A MESA DIRETORA DA ASSEMBLEIA LEGISLATIVA DO ESTADO DO AMAPÁ, nos termos do art. 103, § 3º da Constituição do Estado do Amapá, promulga a seguinte emenda ao texto da Constituição Estadual:

**Art. 1º** O art. 49 da Constituição do Estado do Amapá é acrescido dos seguintes parágrafos:

“Art. 49. ...............................................................................

**§ 1º** A Administração Pública Estadual tem o prazo de cinco anos para anular o Ato Administrativo gerador de efeitos favoráveis para os destinatários, salvo comprovada má-fé.

**§ 2º** No caso de efeitos patrimoniais contínuos, o prazo de decadência contar-se-á da percepção do primeiro pagamento”.

**Art. 2º** Esta Emenda à Constituição Estadual entra em vigor na data de sua publicação.

Macapá-AP, 31 de dezembro de 2014.

Deputado MOISES SOUZA Presidente

Deputado JÚNIOR FAVACHO 1º Vice - Presidente

Deputada ROSELI MATOS 2ª Vice-Presidente

Deputado EDINHO DUARTE 1º Secretário

Deputado CHARLES MARQUES 2º Secretário

Deputado KEKA CANTUÁRIA 3º Secretário

Deputada SANDRA OHANA 4ª Secretária

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 241

EMENDA À CONSTITUIÇÃO Nº 0052 DE 24 DE AGOSTO DE 2015

Dá nova redação ao art. 266, da Constituição do Estado do Amapá, e dá outras providências.

A MESA DIRETORA DA ASSEMBLEIA LEGISLATIVA DO ESTADO DO AMAPÁ,

Faz saber que a Assembleia Legislativa do Estado do Amapá, nos termos do § 3º, do art. 103, da Constituição Estadual, promulga a seguinte Emenda ao texto Constitucional:

**Art. 1º** O Art. 266, da Constituição do Estado do Amapá passa a ter a seguinte redação: ..........................................

“Art. 266. Os recursos destinados à saúde pelo Estado e Municípios serão definidos em suas respectivas leis orçamentárias, anualmente, e aplicarão anualmente em ações e serviços públicos de saúde, no mínimo, 15% (quinze por cento) da arrecadação dos impostos a que se refere o art. 156 e dos recursos de que tratam o art. 158 e a alínea “b” do inciso I do caput e o § 3º do art. 159, todos da Constituição Federal”.

**§ 1º** Para fins de apuração da aplicação dos recursos mínimos estabelecidos, considerar-se-ão como despesas com ações e serviços públicos de saúde no Estado aquelas voltadas para a promoção, proteção e recuperação da saúde que atendam, simultaneamente, aos princípios estatuídos no art. 7o da Lei no 8.080, de 19 de setembro de 1990, e às seguintes diretrizes:

I - sejam destinadas às ações e serviços públicos de saúde de acesso universal, igualitário e gratuito;

II - estejam em conformidade com objetivos e metas explicitados nos Planos de Saúde do Estado; e

III - sejam de responsabilidade específica do setor da saúde, não se aplicando a despesas relacionadas a outras políticas públicas que atuam sobre determinantes sociais e econômicos, ainda que incidentes sobre as condições de saúde da população.

**§ 2º** Além de atender aos critérios estabelecidos no caput, as despesas com ações e serviços públicos de saúde realizadas pelo Estado, e pelos Municípios deverão ser financiadas com recursos movimentados por meio dos respectivos fundos Estaduais e Municipais de saúde.

I - vigilância em saúde, incluindo a epidemiológica e a sanitária;

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 242

II - atenção integral e universal à saúde em todos os níveis de complexidade, incluindo assistência terapêutica e recuperação de deficiências nutricionais;

III - capacitação do pessoal de saúde do Sistema Único de Saúde (SUS);

IV - desenvolvimento científico e tecnológico e controle de qualidade promovidos por instituições do SUS;

V - produção, aquisição e distribuição de insumos específicos dos serviços de saúde do SUS, tais como: imunobiológicos, sangue e hemoderivados, medicamentos e equipamentos médico-odontológicos;

VI - saneamento básico de domicílios ou de pequenas comunidades, desde que seja aprovado pelo Conselho de Saúde do ente da Federação financiador da ação e esteja de acordo com as diretrizes das demais determinações previstas nesta Constituição;

VII - saneamento básico dos distritos sanitários especiais indígenas e de comunidades remanescentes de quilombos;

VIII - manejo ambiental vinculado diretamente ao controle de vetores de doenças;

IX - investimento na rede física do SUS, incluindo a execução de obras de recuperação, reforma, ampliação e construção de estabelecimentos públicos de saúde;

X - remuneração do pessoal ativo da área de saúde em atividade nas ações de que trata este artigo, incluindo os encargos sociais;

XI - ações de apoio administrativo realizadas pelas instituições públicas do SUS e imprescindíveis à execução das ações e serviços públicos de saúde; e

XII - gestão do sistema público de saúde e operação de unidades prestadoras de serviços públicos de saúde.

**§ 3º** Não constituirão despesas com ações e serviços públicos de saúde, para fins de apuração dos percentuais mínimos de que trata o caput do artigo, aquelas decorrentes de:

I - pagamento de aposentadorias e pensões, inclusive dos servidores da saúde;

II - pessoal ativo da área de saúde quando em atividade alheia à referida área;

III - assistência à saúde que não atenda ao princípio de acesso universal;

IV - merenda escolar e outros programas de alimentação, ainda que executados em unidades do SUS, ressalvando- se o disposto no inciso II do art. 3o;

V - saneamento básico, inclusive quanto às ações financiadas e mantidas com recursos provenientes de taxas, tarifas ou preços públicos instituídos para essa finalidade;

VI - limpeza urbana e remoção de resíduos;

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 243

VII - preservação e correção do meio ambiente, realizadas pelos órgãos de meio ambiente dos entes da Federação ou por entidades não governamentais;

VIII - ações de assistência social;

IX - obras de infraestrutura, ainda que realizadas para beneficiar direta ou indiretamente a rede de saúde; e

X - ações e serviços públicos de saúde custeados com recursos distintos dos especificados na base de cálculo definida no caput do artigo ou vinculados a fundos específicos distintos daqueles da saúde”.

**Art. 2º** Esta Emenda à Constituição entra em vigor na data da sua publicação.

Macapá - AP, 24 de agosto de 2015.

MESA DIRETORA DA ASSEMBLEIA LEGISLATIVA DO ESTADO DO AMAPÁ

Deputado MOISÉS SOUZA Presidente

Deputado KAKÁ BARBOSA 1º Vice-Presidente

Deputada ROSELI MATOS 2ª Vice-Presidente

Deputada LUCIANA GURGEL 1º Secretária

Deputada EDNA AUZIER 2º Secretária

Deputado AUGUSTO AGUIAR 3º Secretário

Deputado PASTOR OLIVEIRA 4º Secretário

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 244

EMENDA À CONSTITUIÇÃO Nº 0053, DE 24 DE AGOSTO DE 2015

Altera os artigos 95 e 185 da Constituição Estadual.

A MESA DA ASSEMBLEIA LEGISLATIVA DO ESTADO DO AMAPÁ, nos termos do § 3º, do Art. 104, da Constituição do Estado, promulga a seguinte

Emenda ao texto da Constituição do Estado:

**Art. 1º** Os Incisos II e XXIV do Art. 95 da Constituição do Estado passam a vigorar com a seguinte redação:

"Art. 95. ...............................................................

II – Dispor através de Lei, sobre sua organização, funcionamento, polícia, criação, transformação ou extinção dos cargos, empregos e funções de seus serviços, e a iniciativa de

lei para a fixação da respectiva remuneração, observados os parâmetros estabelecidos na Lei de Diretrizes Orçamentárias. ................................................................................

XXIV – aprovar, após arguição, pela maioria de seus membros, os nomes dos Procuradores Gerais de Justiça, dos presidentes de fundações estaduais, agências de fomento, sociedades de economia mista e empresas públicas. ..........................................................................................”

**Art. 2º** O Art. 185 da Constituição Estadual passa a ter a seguinte redação: “Art. 185. É agente de crédito do Tesouro Estadual a Agência de Fomento do Estado do Amapá.”

**Art. 3º** Esta Emenda Constitucional entra em vigor na data de sua publicação.

Macapá - AP, 24 de agosto de 2015.

MESA DIRETORA DA ASSEMBLEIA LEGISLATIVA DO ESTADO DO AMAPÁ

Deputado MOISÉS SOUZA Presidente

Deputado KAKÁ BARBOSA Deputada ROSELI MATOS 1º Vice-Presidente 2ª Vice-Presidente

Deputada LUCIANA GURGEL Deputada EDNA AUZIER 1º Secretária 2º Secretária

Deputado AUGUSTO AGUIAR Deputado PASTOR OLIVEIRA 3º Secretário 4º Secretário

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 245

EMENDA À CONSTITUIÇÃO Nº 0054, DE 12 DE ABRIL DE 2017

Revoga o § 7º e acrescenta o § 13 ao

art. 67 da Constituição do Estado do Amapá.

A MESA DIRETORA DA ASSEMBLEIA LEGISLATIVA DO ESTADO DO AMAPÁ, Faz saber que a Assembleia Legislativa do Estado do Amapá, nos termos do art. 103, § 3º da Constituição do Estado do Amapá, promulga a seguinte Emenda ao texto Constitucional:

**Art. 1º** Fica acrescentado o § 13 ao art. 67 da Constituição do Estado do Amapá, com a seguinte redação:

“§ 13 Ficam assegurados aos militares da ativa que se encontrem nomeados até a data de promulgação desta

Emenda ou que tenham exercido mediante nomeação os cargos de Comandante Geral da Polícia Militar, Comandante Geral do Corpo de Bombeiros Militar, Chefes de Gabinetes Militares dos Poderes e do Ministério Público Estadual, os direitos e vantagens pecuniárias, no ato da passagem à inatividade, desde que completem o requisito mínimo de 18 meses ininterruptos ou alternados, sendo preservados os direitos e vantagens concedidos aos Oficiais já transferidos para a reserva remunerada.”

**Art. 2o** Esta Emenda Constitucional entra em vigor na data de sua promulgação, revogado o § 7º do art. 67 da Constituição do Estado do Amapá.

Macapá - AP, 12 de abril de 2017.

MESA DIRETORA DA ASSEMBLEIA LEGISLATIVA DO ESTADO DO AMAPÁ

Deputado KAKÁ BARBOSA Presidente

Deputada ROSELI MATOS Deputado MAX DA AABB 1ª Vice-Presidente 2º Vice-Presidente

Deputada EDNA AUZIER Deputado BISPO OLIVEIRA 1ª Secretária 2º Secretário

Deputada MIRA ROCHA Deputada RAIMUNDA BEIRÃO 3ª Secretária 4ª Secretária

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 246

EMENDA À CONSTITUIÇÃO Nº 0055, DE 03 DE MAIO DE 2017

Insere o artigo 65-A no texto da Constituição do Estado do Amapá.

A MESA DIRETORA DA ASSEMBLEIA LEGISLATIVA DO ESTADO DO AMAPÁ, nos termos do art.103, § 3º da Constituição do Estado do Amapá, promulga a seguinte Emenda ao texto da Constituição Estadual.

**Art. 1º** Fica inserido no texto da Constituição do Estado do Amapá o artigo 65-A, cuja redação é a seguinte:

“Artigo 65-A. No caso de extinção, fusão, incorporação ou transferência de propriedade para iniciativa privada ou para a União Federal, de empresa pública ou sociedade de economia mista, que tenha sido constituída à época do extinto Território Federal do Amapá e que tenha passado a integrar o patrimônio do Estado do Amapá, por força do artigo 14, § 2º do ADCT da Constituição Federal, de 05 de outubro de 1988 e do disposto no artigo 16, da Lei Complementar nº 41 de 22 de dezembro 1981, o empregado que tenha ingressado mediante prévio concurso público no quadro de pessoal de qualquer das pessoas jurídicas elencadas, poderá, mediante opção ser aproveitado no quadro de pessoal da administração pública estadual, nos termos da Lei.”

**Art. 2o** Fica autorizado o Poder Executivo a regulamentar os procedimentos administrativos para tornar efetiva esta Emenda Constitucional.

**Art. 3o** Esta Emenda Constitucional entra em vigor na data de sua publicação.

Macapá - AP, 03 de maio de 2017.

MESA DIRETORA DA ASSEMBLEIA LEGISLATIVA DO ESTADO DO AMAPÁ

Deputado KAKÁ BARBOSA Presidente

Deputada ROSELI MATOS Deputado MAX DA AABB 1ª Vice-Presidente 2º Vice-Presidente

Deputada EDNA AUZIER Deputado BISPO OLIVEIRA 1ª Secretária 2º Secretário

Deputada MIRA ROCHA Deputada RAIMUNDA BEIRÃO 3ª Secretária 4ª Secretária

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 247

EMENDA À CONSTITUIÇÃO Nº 0056, DE 03 DE MAIO DE 2017

Altera a redação do § 2º do art. 98 da Constituição do Estado do Amapá.

A MESA DIRETORA DA ASSEMBLEIA LEGISLATIVA DO ESTADO DO AMAPÁ, nos termos do art. 103, § 3º da Constituição do Estado do Amapá, promulga a seguinte Emenda ao texto da Constituição Estadual.

**Art. 1º** O § 2º do art., 98 da Constituição do Estado do Amapá passa a vigorar com a seguinte redação.

“Art. 98. .............................................................................. ............................................................................................. .............................................................................................

**§ 2º** Nos casos dos incisos I, II e VI, a perda de mandato será decidida pela Assembleia Legislativa por maioria absoluta, mediante provocação da Mesa ou de partido politico representado na Assembleia assegurada ampla defesa. .............................................................................................

**Art. 2o** Esta Emenda Constitucional entra em vigor na data de sua publicação.

Macapá - AP, 03 de maio de 2017.

MESA DIRETORA DA ASSEMBLEIA LEGISLATIVA DO ESTADO DO AMAPÁ

Deputado KAKÁ BARBOSA Presidente

Deputada ROSELI MATOS Deputado MAX DA AABB 1ª Vice-Presidente 2º Vice-Presidente

Deputada EDNA AUZIER Deputado BISPO OLIVEIRA 1ª Secretária 2º Secretário

Deputada MIRA ROCHA Deputada RAIMUNDA BEIRÃO 3ª Secretária 4ª Secretária

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 248

Referente à Proposta de Emenda Constitucional nº 0002/17-GEA

EMENDA À CONSTITUIÇÃO Nº 0057, DE 19 DE DEZEMBRO DE 2017 Publicada no Diário Oficial do Estado nº 6585, de 20.12.2017 Autor: Poder Executivo

Altera a Constituição do Estado do Amapá para inserir modificações no Título VII

#### Capítulo III, relativas á Política Agrária, Fundiária, Agrícola e Extrativista Vegetal.

A MESA DIRETORA DA ASSEMBLEIA LEGISLATIVA DO ESTADO DO AMAPÁ, nos termos do art. 103, § 3º da Constituição do Estado do Amapá, promulga a seguinte Emenda ao texto da Constituição Estadual.

**Art. 1º** O inciso IV do artigo 205 da Constituição do Estado do Amapá passa a vigorar com a seguinte redação:

“Art. 205......................................................... ...

IV – o Zoneamento Econômico Ecológico;”

**Art. 2º** O artigo 206 da Constituição do Estado do Amapá passa a vigorar com a seguinte redação:

“Art. 206. .....................................................

a) Revogado.

b) Revogado.

c) Revogado.

**§ 1°** Às áreas superiores a dois mil e quinhentos aplica-se, no que couber, o disposto na Constituição Federal.

**§ 2°** Excetuam-se do disposto no caput deste artigo as alienações ou as concessões de terras públicas para fins de reforma agrária.

**§ 3°** Revogado.”

**Art. 3°** O art. 208 da Constituição do Estado do Amapá é acrescido do seguinte inciso:

“Art. 208. ......................................................

IV – tenham morada habitual e cultura afetiva.”

**Art. 4°** O art. 213 da Constituição do Estado do Amapá é acrescido do seguinte inciso:

“Art. 213. .....................................................

VIII – Criar sistema estadual de cadastramento e georreferenciado das propriedades e ocupações rurais, com a indicação do uso do solo.”

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 249

**Art. 5°** O artigo 216 da Constituição do Estado do Amapá passa a vigorar com a seguinte redação:

“Art. 216. ....................................................

**Parágrafo único.** Revogado.”

**Art. 6°** O artigo 217 da Constituição do Estado do Amapá passa a vigorar com a seguinte redação:

“Art. 217. ...................................................

**§ 2°** A concessão do direito real de uso ou título de domínio será conferido a grupo de trabalhador rural, a homem ou mulher, ou ambos, independentemente de estado civil, nos termos e condições previstos em lei.”

**Art. 7o** Esta Emenda Constitucional entra em vigor na data de sua publicação.

Macapá – AP, 19 de dezembro de 2017.

Deputado KAKÁ BARBOSA Presidente

Deputada ROSELI MATOS Deputado MAX DA AABB 1ª Vice-Presidente 2º Vice-Presidente

Deputada EDNA AUZIER Deputado OLIVEIRA SANTOS 1ª Secretária 2º Secretário

Deputada RAIMUNDA BEIRÃO 4ª Secretária

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 250

Referente à Proposta de Emenda Constitucional nº 0001/18-GEA

EMENDA À CONSTITUIÇÃO Nº 0058, DE 27 DE NOVEMBRO DE 2018 Publicada no Diário Oficial do Estado nº 6810, de 29.11.2018 Autor: Poder Executivo

Altera o § 2º, do artigo 153, da Constituição do Estado do Amapá, para fixar critério de escolha do Procurador Geral do Estado.

A MESA DIRETORA DA ASSEMBLEIA LEGISLATIVA DO ESTADO DO AMAPÁ, nos termos do art. 103, § 3º da Constituição do Estado do Amapá, promulga a seguinte Emenda ao texto da Constituição Estadual.

**Art. 1º** O §2º, do artigo 153, da Constituição do Estado do Amapá, passa a vigorar com a seguinte alteração:

“Art. 153. ............................................................................. (....)

**§ 2º** A Procuradoria-Geral do Estado será chefiada pelo Procurador-Geral do Estado, com prerrogativas de Secretário de Estado, sendo o cargo provido em comissão pelo Governador, dentre membros do último nível da carreira, com idade superior a trinta e cinco anos, devendo apresentar declaração pública de bens no ato da posse e quando for exonerado.”

**Art. 2º** Esta Emenda Constitucional entra em vigor na data de sua publicação.

Macapá - AP, 27 de novembro de 2018.

Deputado KAKÁ BARBOSA Presidente

Deputada ROSELI MATOS Deputado MAX DA AABB 1ª Vice-Presidente 2º Vice-Presidente

Deputada EDNA AUZIER Deputado OLIVEIRA SANTOS 1ª Secretária 2º Secretário

Deputada RAIMUNDA BEIRÃO 3ª Secretária

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 251

Referente à Proposta de Emenda Constitucional nº 0001/19-ALAP

EMENDA À CONSTITUIÇÃO Nº 0059, DE 29 DE OUTUBRO DE 2019 Publicada no Diário Oficial do Estado nº 7035, de 01.11.2019 Autor: Poder Legislativo

Altera os arts. 175 e 176 da Constituição Estadual, para tornar obrigatória a execução da programação orçamentária proveniente de emendas de parlamentares.

A MESA DIRETORA DA ASSEMBLEIA LEGISLATIVA DO ESTADO DO AMAPÁ faz saber que a Assembleia Legislativa do Estado do Amapá aprovou e ela, nos termos do § 3º, do art. 103 da Constituição Estadual, promulga a seguinte

Emenda ao Texto Constitucional:

**Art. 1º** Os arts. 175 e 176 da Constituição Estadual passam a vigorar com as seguintes alterações:

"Art. 175. ............................................................................ .............................................................................................

**§ 13** A administração tem o dever de executar as programações orçamentárias, adotando os meios e as medidas necessários, com o propósito de garantir à sociedade”. "Art. 176. ............................................................................. .............................................................................................

**§ 8º** As emendas individuais ao projeto de lei orçamentária serão aprovadas até o limite de 1,2% (um vírgula dois por cento) da receita corrente líquida prevista no projeto encaminhado pelo Poder Executivo, sendo que 25% (vinte e cinco por cento) do percentual definido serão destinados a ações e serviços públicos de saúde.

**§ 9º** O percentual de que trata o § 8º será previsto e definido na redação do projeto de lei orçamentária encaminhado pelo Poder Executivo.

**§ 10** A execução do montante destinado a ações e serviços públicos de saúde previstos no § 8º, inclusive custeio, será computada para fins do cumprimento do inciso II do § 2º do

art. 198 da Constituição Federal, vedada a destinação para pagamento de pessoal ou encargos sociais.

**§ 11** É obrigatória a execução orçamentária e financeira das programações a que se refere o § 8º deste artigo, em montante correspondente até o limite de 1,2% (um vírgula dois por cento) da receita corrente líquida realizada no exercício anterior.

**§ 12** As programações orçamentárias previstas no § 8º deste artigo não serão de execução obrigatória nos casos dos impedimentos de ordem técnica.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 252

**§ 13** Para fins de cumprimento do disposto nos §§ 8º, 11 e 12 deste artigo, os órgãos de execução deverão observar, nos termos da lei de diretrizes orçamentárias, cronograma para análise e verificação de eventuais impedimentos das programações e demais procedimentos necessários à viabilização da execução dos respectivos montantes.

**§ 14** Quando a transferência obrigatória do Estado, para a execução da programação prevista nos §§ 8º, 10 e 11 deste artigo, for destinada a Municípios, independerá da adimplência destes e não integrará a base de cálculo da receita corrente líquida para fins de aplicação dos limites de despesa de pessoal de que trata o caput do art. 169 da Constituição Federal.

**§ 15** Os restos a pagar provenientes das programações orçamentárias previstas nos §§ 8º, 10 e 11 deste artigo poderão ser considerados para fins de cumprimento da execução financeira realizada no exercício anterior para as programações das emendas individuais.

**§ 16** Considera-se equitativa a execução das programações de caráter obrigatório que observe critérios objetivos e imparciais e que atenda de forma igualitária e impessoal às emendas apresentadas, independente de autoria.

**§ 17** As programações de que tratam os §§ 8º, 11 e 12, quando versarem sobre o início de investimentos com duração de mais de um exercício financeiro ou cuja execução já tenha sido iniciada, deverão ser objeto de

emenda pelo mesmo parlamentar, a cada exercício, até a conclusão da obra ou do empreendimento.

**Art. 2º** Esta Emenda Constitucional entra em vigor na data de sua publicação e produzirá efeitos a partir da execução orçamentária do exercício de 2020.

Macapá, em 29 de outubro de 2019.

Deputado KAKÁ BARBOSA Presidente Deputada TELMA GURGEL Deputado MAX DA AABB 1ª Vice-Presidente 2º Vice-Presidente Deputada EDNA AUZIER Deputado OLIVEIRA SANTOS 1ª Secretária 2º Secretário Deputado JORY OEIRAS Deputado JAIME PEREZ 3ºSecretário 4º Secretário

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 253

Referente à Proposta de Emenda Constitucional nº 0001/19-GEA

EMENDA À CONSTITUIÇÃO Nº 0060, DE 19 DE DEZEMBRO DE 2019 Publicada no Diário Oficial do Estado nº 7069, de 23.12.2019 Autor: Poder Executivo

Altera o artigo 176 da Constituição Estadual, para tornar obrigatória a execução da programação orçamentária proveniente de emendas de parlamentares.

A MESA DIRETORA DA ASSEMBLEIA LEGISLATIVA DO ESTADO DO AMAPÁ faz saber que a Assembleia Legislativa do Estado do Amapá aprovou e ela, nos termos do § 3º, do art. 103 da Constituição Estadual, promulga a seguinte

Emenda ao Texto Constitucional:

**Art. 1º** O artigo 176, da Constituição Estadual passa vigorar com as seguintes alterações:

“Art. 176. .................................................................... (...)

**§ 8º** As emendas individuais ao projeto de lei orçamentária serão aprovadas até o limite de 1,2% (um vírgula dois por cento) da receita corrente líquida prevista no projeto encaminhado pelo Poder Executivo, sendo que 25% (vinte e cinco por cento) do percentual definido serão destinados a ações e serviços públicos de saúde.

**§ 9º** O percentual de que trata o § 8º será definido no projeto de lei orçamentária encaminhado pelo Poder Executivo.

**§ 10** A execução do montante destinado a ações e serviços públicos de saúde previstos no § 8º, inclusive custeio, será computada para fins do cumprimento do inciso II do § 2º do

art. 198 da Constituição Federal, vedada a destinação para pagamento de pessoal ou encargos sociais.

**§ 11** É obrigatória a execução orçamentária e financeira das emendas previstas no § 8º deste artigo, até o limite definido na forma do §9º, respeitado o fluxo de caixa do Tesouro Estadual.

**§ 12** As programações orçamentárias previstas no § 8º deste artigo não serão de execução obrigatória nos casos dos impedimentos de ordem técnica.

**§ 13** Para fins de cumprimento do disposto nos §§ 8º, 11 e 12 deste artigo, os órgãos de execução deverão observar, nos termos da lei de diretrizes orçamentárias, cronograma para análise e verificação de eventuais impedimentos das programações e demais procedimentos necessários à viabilização da execução dos respectivos montantes.

**§ 14** Revogado.

**§ 15** Revogado.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 254

**§ 16** Revogado.

**§ 17** Revogado.”

**Art. 2º** Esta Emenda Constitucional entra em vigor na data de sua publicação e produzirá efeitos a partir da execução orçamentária do exercício de 2021.

Macapá, em 19 de dezembro de 2019.

Deputado KAKÁ BARBOSA Presidente

Deputada TELMA GURGEL Deputado MAX DA AABB 1ª Vice-Presidente 2º Vice-Presidente

Deputada EDNA AUZIER Deputado OLIVEIRA SANTOS 1ª Secretária 2º Secretário

Deputado JORY OEIRAS Deputado JAIME PEREZ 3ºSecretário 4º Secretário

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 255

Referente à Proposta de Emenda Constitucional nº 0004/19-AL

EMENDA À CONSTITUIÇÃO Nº 0061, DE 4 DE MARÇO DE 2020 Publicada no Diário Oficial Eletrônico da Assembleia Legislativa nº 0981, de 05.03.2020 Autor: Deputado Jory Oeiras

Altera dispositivos da Constituição do Estado do Amapá na forma que especifica.

A MESA DIRETORA DA ASSEMBLEIA LEGISLATIVA DO ESTADO DO AMAPÁ faz saber que a Assembleia Legislativa do Estado do Amapá aprovou e ela, nos termos do § 3º, do art. 103 da Constituição Estadual, promulga a seguinte

Emenda ao Texto Constitucional:

**Art. 1º** O incido IX do art. 5º da Constituição do Estado passa a vigorar com a seguinte redação:

**Art. 5º** ..................................................................................

IX – qualquer cidadão poderá apresentar queixa à autoridade policial civil, penal ou militar que promover atos que atentem contra a integridade física ou moral das pessoas, sendo obrigatória a apuração dos fatos e das responsabilidades decorrentes, no prazo de sessenta dias, a partir da data da denúncia; .............................................................................................

**Art. 2º** O inciso XVI do art. 12 da Constituição do Estado passa a vigorar com a seguinte redação:

**Art. 12.** ................................................................................

XVI – organização, garantias, direitos e deveres da polícia civil e da polícia penal; .............................................................................................

**Art. 3º** O inciso V do art. 75 da Constituição do Estado passa a vigorar com a seguinte redação:

**Art. 75.** ................................................................................ (...)

V – Polícia Penal.

**Art. 4º** O art. 76 da Constituição do Estado passa a vigorar com a seguinte redação:

**Art. 76.** ................................................................................

**§ 1º** É dever dos órgãos responsáveis pela segurança pública dar aos policiais civis, penais e militares, formação, capacitação e treinamento especializados para o trato das questões relativas ao idoso, à criança, ao adolescente e à mulher. .............................................................................................

**§ 6º** revogado.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 256

**Art. 5º** O art. 77 da Constituição do Estado passa a vigorar com a seguinte redação:

**Art. 77.** O policial civil, penal ou militar denunciado por crime de abuso de autoridade será imediatamente afastado de seu cargo ou função, até a sentença transitada em julgado.

**Art. 6º** O preenchimento do quadro de servidores da Polícia Penal será feito, exclusivamente, por meio de concurso público e por meio da transformação dos cargos isolados, dos cargos de carreira dos atuais agentes penitenciários e dos cargos públicos equivalentes.

**Art. 7º** Acrescenta-se o Capítulo VI e o artigo 90-A com a seguinte redação:

#### CAPÍTULO VI Da Polícia Penal

**Art. 90-A.** À Polícia Penal, instituição permanente, com autonomia administrativa e financeira, estruturada em carreira única, dirigida por Policial Penal, essencial à segurança pública e à execução penal, incumbe à segurança dos estabelecimentos penais.

**Art. 8º** O inciso IV do art. 223 da Constituição do Estado passa a vigorar com a seguinte redação:

**Art. 223.** .............................................................................. (...)

IV – carteiros, vigilantes, policiais civis, policiais penais, policiais militares e bombeiros militares em serviço e devidamente uniformizados;

**Art. 9º** Lei Orgânica e estatuto disciplinarão a organização, o funcionamento, os direitos, deveres, vantagens e regime de trabalho da Polícia Penal e de seus integrantes.

**Art. 10.** O Governo do Estado terá o prazo de cento e oitenta dias para adequar a legislação aos termos desta Emenda Constitucional.

**Art. 11.** Esta Emenda Constitucional entra em vigor na data de sua publicação.

Macapá, em 4 de março de 2020.

Deputado KAKÁ BARBOSA Presidente

Deputada TELMA GURGEL Deputado MAX DA AABB 1ª Vice-Presidente 2º Vice-Presidente Deputada EDNA AUZIER Deputado OLIVEIRA SANTOS 1ª Secretária 2º Secretário Deputado JORY OEIRAS Deputado JAIME PEREZ 3º Secretário 4º Secretário

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 257

Referente à Proposta de Emenda Constitucional nº 0001/20-GEA

EMENDA À CONSTITUIÇÃO Nº 0062, DE 30 DE ABRIL DE 2020 Publicada no Diário Oficial Eletrônico da Assembleia Legislativa nº 1006, de 30.04.2020 Autor: Poder Executivo

Altera a redação do § 12 do art. 175 da Constituição do Estado do Amapá para permitir a dilação do prazo para remessa da LDO e da LOA pelo Poder executivo ao Poder Legislativo na ocorrência de reconhecida calamidade pública.

A MESA DIRETORA DA ASSEMBLEIA LEGISLATIVA DO ESTADO DO AMAPÁ faz saber que a Assembleia Legislativa do Estado do Amapá aprovou e ela, nos termos do § 3º, do art. 103 da Constituição Estadual, promulga a seguinte

Emenda ao Texto Constitucional:

**Art. 1º** O § 12 ao art. 175 da Constituição do Estado do Amapá passa a vigorar com a seguinte redação:

**Art. 175.** ...............................................

**§ 12** No primeiro ano de cada período de governo ou na hipótese de ocorrência de reconhecida calamidade pública, que justifique a impossibilidade de cumprimento dos prazos previstos nos §§ 5º e 10, o Projeto de Lei das Diretrizes Orçamentárias deverá ser encaminhado à Assembleia Legislativa até 31 (trinta e um) de julho, para apreciação até 30 (trinta) de setembro, e o Projeto de Lei Orçamentária Anual será remetido até 31 (trinta e um) de outubro e apreciado até o encerramento da sessão legislativa. .

**Art. 2º** Esta Emenda à Constituição entra em vigor na data de sua promulgação.

Macapá, 30 de abril de 2020.

Deputado KAKÁ BARBOSA Presidente

Deputada TELMA GURGEL Deputado MAX DA AABB 1ª Vice-Presidente 2º Vice-Presidente

Deputada EDNA AUZIER Deputado OLIVEIRA SANTOS 1ª Secretária 2º Secretário

Deputado JORY OEIRAS Deputado JAIME PEREZ 3º Secretário 4º Secretário

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 258

Referente à Proposta de Emeda à Constituição nº 0002/19-AL

EMENDA À CONSTITUIÇÃO Nº 0063, DE 31 DE AGOSTO DE 2020 Publicada no Diário Oficial do Estado nº 7214, de 29.09.2021 Autora: Deputada Cristina Almeida

Altera e insere no art. 286, parágrafo único, inciso II, da Constituição do Estado do Amapá, a alínea "i" e dá outras providências.

A MESA DIRETORA DA ASSEMBLEIA LEGISLATIVA DO ESTADO DO AMAPÁ faz saber que a Assembleia Legislativa do Estado do Amapá aprovou e ela, nos termos do § 3º, do art. 103 da Constituição Estadual, promulga a seguinte

Emenda ao Texto Constitucional:

**Art. 1º** Fica acrescentado ao inciso II, § único, Art. 286 da Constituição do Estado do Amapá a alínea “i” com conteúdo de NOÇÕES BÁSICAS DA LEI MARIA DA PENHA, passando o mesmo a vigorar com a seguinte redação: "Art. 286 - ..............................................

Parágrafo único: ....................................

II - ..........................................................

a) ...........................................................

b) ...........................................................

c) ...........................................................

d) ...........................................................

e) ...........................................................

f) ............................................................

g) ...........................................................

i) Noções básicas da Lei Maria da Penha."

**Art. 2º** Esta Emenda Constitucional entra em vigor na data de sua publicação.

Macapá, em 31 de agosto de 2021.

Deputado KAKÁ BARBOSA Presidente

Deputada TELMA GURGEL Deputado MAX DA AABB 1ª Vice-Presidente 2º Vice-Presidente

Deputada EDNA AUZIER Deputado PASTOR OLIVEIRA 1ª Secretária 2º Secretário

Deputado JORY OEIRAS Deputado JAIME PEREZ 3º Secretário 4º Secretário

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 259

Referente à Proposta de Emeda à Constituição nº 0001/22-GEA

EMENDA À CONSTITUIÇÃO Nº 0064, DE 31 DE MARÇO DE 2022 Publicada no Diário Oficial do Estado nº 7641, de 04.04.2022 Autora: Deputada Cristina Almeida

Revoga o § 11 do art. 67 da Constituição Estadual para garantir o princípio da isonomia e eficiência no ingresso dos quadros de oficiais das carreiras militares do Estado do Amapá.

A MESA DIRETORA DA ASSEMBLEIA LEGISLATIVA DO ESTADO DO AMAPÁ faz saber que a Assembleia Legislativa do Estado do Amapá aprovou e ela, nos termos do § 3º, do art. 103 da Constituição Estadual, promulga a seguinte

Emenda ao Texto Constitucional:

**Art. 1º** Fica revogado o § 11 do art. 67 da Constituição do Estado do Amapá.

**Art. 2º** Esta Emenda Constitucional entra em vigor na data de sua publicação.

Macapá, 31 de março de 2022.

Deputado KAKÁ BARBOSA Presidente

Deputada TELMA GURGEL Deputado MAX DA AABB 1ª Vice-Presidente 2º Vice-Presidente

Deputada EDNA AUZIER Deputado PASTOR OLIVEIRA 1ª Secretária 2º Secretário

Deputado JORY OEIRAS Deputado JAIME PEREZ 3º Secretário 4º Secretário

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 260

Referente à Proposta de Emeda à Constituição nº 0002/22-AL

EMENDA CONSTITUCIONAL Nº 0065, DE 30 DE AGOSTO DE 2022 Publicada no Diário Oficial do Estado nº 7743, de 31.08.2022

Autor: Deputado Charly Jhone Altera a redação dos artigos 5º-E e 288, da Constituição Estadual e dá outras providências.

A MESA DIRETORA DA ASSEMBLEIA LEGISLATIVA DO ESTADO DO AMAPÁ faz saber que a Assembleia Legislativa do Estado do Amapá aprovou e ela, nos termos do § 3º, do art. 103 da Constituição Estadual, promulga a seguinte

Emenda ao Texto Constitucional:

**Art. 1º** O art. 5º-E e o art. 288 da Constituição do Estado do Amapá passam a vigorar com as seguintes alterações: "Art. 5º-E. (...).

**§ 1º** O orçamento do Estado alocará para cada Secretaria Estadual os recursos necessários para o custeio das atividades dos respectivos conselhos.

**§ 2º** O disposto no parágrafo anterior não se aplica:

I - Ao Conselho Estadual de Educação que, na forma da lei, será entidade autônoma e se constituirá em uma unidade orçamentária e de despesa, vinculada diretamente ao Governador.

II - Aos conselhos vinculados à Secretaria de Estado da Educação que, na forma da lei, poderão se constituir, individualmente, em unidades orçamentárias e de despesas. .......

**Art. 288.** A lei disciplinará as formas de apoio à manutenção e ao desenvolvimento do ensino que Pessoas Jurídicas de Direito Privado deverão prestar, sempre que se beneficiarem: (NR)." Art. Esta Emenda Constitucional entra em vigor na data de sua publicação. Macapá, 31 de agosto de 2022. Deputado KAKÁ BARBOSA Presidente Deputada TELMA GURGEL Deputado MAX DA AABB 1ª Vice-Presidente 2º Vice-Presidente Deputada EDNA AUZIER Deputado PASTOR OLIVEIRA 1ª Secretária 2º Secretário Deputado JORY OEIRAS Deputado JAIME PEREZ 3º Secretário 4º Secretário

Referente à Proposta de Emeda à Constituição nº 0003/22-AL

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 261

EMENDA CONSTITUCIONAL Nº 0066, DE 20 DE DEZEMBRO DE 2022 Publicada no Diário Oficial do Estado nº 7815, de 21.12.2022 Autor: Deputado R.Nelson Vieira e outros deputados

Altera o artigo 68 da Constituição do Estado do Amapá, e acrescenta os §§ 1º e 2º neste dispositivo, a fim de inserir no texto constitucional os demais Quadros de Oficiais da Polícia Militar e do Corpo de Bombeiros Militar do Estado do Amapá.

A MESA DIRETORA DA ASSEMBLEIA LEGISLATIVA DO ESTADO DO AMAPÁ, nos termos do § 3º do art. 103 da Constituição do Estado do Amapá, promulga a seguinte Emenda ao texto da Constituição do Estado do Amapá:

**Art. 1º** O art. 68 da Constituição do Estado do Amapá, que trata do Quadro de Oficiais da Polícia Militar do Amapá – PMAP e do Corpo de Bombeiros Militar do Amapá – CBMAP, a passa a vigorar com a seguinte redação:

**Art. 68.** Os Quadros de Oficiais da Polícia Militar do Amapá – PMAP e do Corpo de Bombeiros Militar do Amapá – CBMAP deverão ser formados pelos seguintes Quadros: Quadro de Oficiais Combatentes (QOC), Quadro de Oficiais da Administração (QOA), Quadro de Oficiais de Saúde (QOS), Quadro de Oficiais Complementares (QOC), Quadro de Oficiais Músicos (QOM) e Quadro Especial de Oficiais (QEO).

**§ 1º** Os integrantes dos Quadros Oficiais Combatentes, de Saúde, Complementares, Oficiais da Administração e de Músicos poderão alcançar até o posto de Coronel; e os do Quadro Especial de Oficiais até o posto de Major, com acesso privativo e exclusivo aos referidos Quadros de Oficiais aos brasileiros natos que preencham os requisitos e tenham concluído os cursos de formação previstos no Estatuto dos Militares do Estado do Amapá.

**§ 2º** Não poderá haver distinção de idade para o ingresso nos Quadros de Praças e Oficiais da Polícia Militar e Corpo de Bombeiros Militar do Estado do Amapá.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 262

**Art. 2º** Esta Emenda Constitucional entra em vigor na data de sua publicação.

Macapá, 20 de dezembro de 2022.

Deputado KAKÁ BARBOSA Presidente

Deputada TELMA GURGEL Deputado MAX DA AABB 1ª Vice-Presidente 2º Vice-Presidente

Deputada EDNA AUZIER Deputado PASTOR OLIVEIRA 1ª Secretária 2º Secretário

Deputado JORY OEIRAS Deputado JAIME PEREZ 3º Secretário 4º Secretário

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 263

Referente à Proposta de Emeda à Constituição nº 0005/2023-AL

EMENDA CONSTITUCIONAL Nº 0067, DE 25 DE OUTUBRO DE 2023 Publicada no Diário Oficial do Estado nº 1629, de 06/11/2023 Autor: Deputados R.Nelson Vieira e Fabrício Furlan

Acrescenta os §§ 9º, 10 e 11 do Art. 47 da Constituição do Estado do Amapá.

A MESA DIRETORA DA ASSEMBLEIA LEGISLATIVA DO ESTADO DO AMAPÁ, nos termos do §3º do art. 103 da Constituição do Estado do Amapá, promulga a seguinte Emenda ao texto da Constituição do Estado do Amapá.

**Art. 1º** Acrescenta os §§ 9º, 10 e 11 ao artigo 47 da Constituição do Estado do Amapá, que terá a seguinte redação:

**Art. 47.** .............................................................................................

**§ 9º** É garantida a liberação do servidor público para exercício de mandato eletivo em diretoria de entidade sindical representativa da categoria de servidores públicos, de âmbito estadual, com ônus para o órgão de origem, sem prejuízo da remuneração integral, com todos seus benefícios, inclusive verbas indenizatórias, sendo-lhe assegurados todos os direitos, vantagens e progressão ou ascensão funcional do cargo como se em exercício efetivamente estivesse;

**§ 10** Em qualquer caso que exija o afastamento para o exercício de mandato eletivo, o tempo de serviço será contado para todos os efeitos legais, exceto para promoção por merecimento;

**§ 11** A garantia prevista no §9º deste artigo será exercida no mínimo por 2 (dois) representantes do sindicato, sendo acrescida de mais um representante por cada 1000 (mil) servidores em atividade, não podendo ultrapassar a 6 (seis) membros, devidamente indicados pela entidade.

**Art. 2º** Esta Emenda Constitucional entra em vigor na data de sua publicação. Macapá, 25 de outubro de 2023.

Deputada ALLINY SERRÃO Presidente

Deputado JAIME PEREZ Deputado FABRÍCIO FURLAN 1º Vice-Presidente 2º Vice-Presidente

Deputada EDNA AUZIER Deputado JESUS PONTES 1ª Secretária 2º Secretário

Deputado Dr. VICTOR Deputada LILIANE ABREU 3º Secretário 4ª Secretária

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 264

Referente à Proposta de Emenda à Constituição n. 0001/2024/GEA

EMENDA CONSTITUCIONAL Nº 0068, DE 11 DE ABRIL DE 2024 Publicada no Diário Oficial da ALAP nº 1719, de 25/04/2024, e no DOE nº 8153, de 26/04/2024 Autor: Poder Executivo

Dá nova redação aos artigos 68, 82, 87, e acrescenta os artigos 64 e 65 no Ato das Disposições Constitucionais Transitórias da Constituição do Estado do Amapá.

A MESA DIRETORA DA ASSEMBLEIA LEGISLATIVA DO ESTADO DO AMAPÁ, nos termos do §3º do art. 103 da Constituição do Estado do Amapá, promulga a seguinte Emenda ao texto da Constituição do Estado do Amapá.

**Art. 1º** O artigo 68 da Constituição do Estado do Amapá, que trata dos Quadros de Oficiais Polícia Militar do Amapá e do Corpo de Bombeiros Militar do Amapá, passa a vigorar com a seguinte redação:

“Art. 68. Os requisitos do acesso aos Quadros de Oficiais da Polícia Militar e do Corpo de Bombeiros Militar serão definidos em lei complementar, sendo privativo a brasileiros, aprovados em concurso público, possuidores de graduação de nível superior e que tenham concluído, com aproveitamento, o curso de formação de oficiais ou o respectivo curso de habilitação, realizado em estabelecimento de ensino próprio ou de polícia militar ou de corpo de bombeiros militar de outra unidade federada ou de Territórios

**Parágrafo único.** O Quadro de Oficiais Especialistas (QOE), integrado por Oficiais oriundos da carreira das praças será constituído pelos oficiais possuidores do respectivo curso de habilitação, nos termos da legislação específica, admitida a promoção até o posto de Tenente-coronel;”

**Art. 2º** O artigo 82 da Constituição do Estado do Amapá, que trata do Comando da Polícia Militar do Amapá, passa a vigorar com a seguinte redação:

“Art. 82. A Polícia Militar, órgão permanente e regular, força auxiliar e reserva do Exército, é dirigida por Comandante-Geral, nomeado pelo Governador do Estado, dentre os oficiais da ativa do Quadro de Oficiais de Estado-Maior (ǪOEM) pertencente ao último posto da corporação.”

**Art. 3º** O artigo 87, da Constituição do Estado do Amapá, que trata do Comando do Corpo de Bombeiros Militar, passa a vigorar com a seguinte redação:

“Art. 87. O Comandante-Geral do Corpo de Bombeiros Militar será nomeado pelo Governador do Estado, escolhido dentre os oficiais da ativa do Quadro de Oficiais de Estado-Maior (ǪOEM) pertencente ao último posto da corporação.”

**Art. 4º** A Constituição do Estado do Amapá, no Ato das Disposições Constitucionais Transitórias, fica acrescida dos seguintes artigos: CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 265

“Art. 64. Até que seja criado o Quadro de Oficiais de Estado-Maior (ǪOEM) nas respectivas Corporações por meio de lei complementar, as regras previstas nos artigos 82 e 87 desta Constituição recairão sobre o Oficiais do último posto do Quadro de Oficiais Combatentes da Polícia Militar do Amapá e do Corpo de Bombeiros Militar do Amapá.

**Art. 65.** Até que seja criado o Quadro de Oficiais Especialistas (QOE) nas respectivas Corporações por meio de lei complementar, permanecem vigentes as regras previstas nas legislações específicas a respeito dos quadros de Oficiais oriundos da carreira das praças.”

**Art. 5º** Ficam revogados os parágrafos 1º e 2º, do artigo 68, desta Constituição.

**Art. 6º** Esta Emenda Constitucional entra em vigor na data de sua promulgação.

Macapá, 11 de abril de 2024

Dep. ALLINY SERRÃO Presidente

Dep. JAIME PEREZ Dep. FABRÍCIO FURLAN 1º Vice-Presidente 2º Vice-Presidente

Dep. EDNA AUZIER Dep. JESUS PONTES 1ª Secretária 2º Secretário

Dep. DR. VICTOR Dep. LILIANE ABREU 3º Secretário 4ª Secretária

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 266

Referente à Proposta de Emenda à Constituição n. 0001/2024/AL

EMENDA CONSTITUCIONAL Nº 0069, DE 12 DE JUNHO DE 2024 Publicada no Diário Oficial da ALAP nº 1752, de 25/06/2024, e no DOE nº 8191, de 25/06/2024 Autor: Deputado Rodolfo Vale

Acrescenta o inciso X no art. 2º e os arts. 338- A e 338-B na Constituição do Estado do Amapá, e dá outras providências.

A MESA DIRETORA DA ASSEMBLEIA LEGISLATIVA DO ESTADO DO AMAPÁ, nos termos do §3º do art. 103 da Constituição do Estado do Amapá, promulga a seguinte Emenda ao texto da Constituição do Estado do Amapá:

**Art. 1º** A Constituição do Estado do Amapá passa a vigorar acrescida dos seguintes dispositivos:

“Art. 2º.....................................................................................................

X - erradicar a pobreza e reduzir as desigualdades sociais e regionais.

.....................................................................................................

### TÍTULO VIII Da Ordem Social

....................................................................................................

#### CAPÍTULO XV Da Política de Justiça Social

**Art. 338-A.** A política de justiça social tem como objetivo a diminuição da desigualdade social e econômica na sociedade, especialmente por meio da redução das taxas de pobreza e de desemprego no Estado.

**Parágrafo único.** Para a apuração das taxas referidas no caput deste artigo, serão utilizadas preferencialmente estatísticas da Fundação Instituto Brasileiro de Geografia e Estatística (IBGE).

**Art. 338-B.** Lei complementar disporá sobre a organização da política de justiça social, estabelecendo seus objetivos, metas e formas de avaliação periódica.

**Parágrafo único.** São princípios norteadores à organização da política de justiça social:

I - a geração de emprego e de renda;

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 267

II - a emancipação econômica dos grupos minoritários;

III - a sustentabilidade fiscal do Estado; e

IV - a tomada de decisão baseada em evidências.”

**Art. 2º** Esta Emenda Constitucional entra em vigor na data de sua promulgação.

Macapá, 12 de junho de 2024.

Dep. ALLINY SERRÃO Presidente

Dep. JAIME PEREZ Dep. FABRÍCIO FURLAN 1º Vice-Presidente 2º Vice-Presidente

Dep. EDNA AUZIER Dep. JESUS PONTES 1ª Secretária 2º Secretário

Dep. DR. VICTOR Dep. LILIANE ABREU 3º Secretário 4ª Secretária

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 268

Referente à Proposta de Emenda à Constituição n. 0004/2023/AL

EMENDA CONSTITUCIONAL Nº 0070, DE 12 DE JUNHO DE 2024 Publicada no Diário Oficial da ALAP nº 1752, de 25/06/2024, e no DOE nº 8191, de 25/06/2024 Autor: Deputado Júnior Favacho

Acrescenta o art. 176-A à Constituição do Estado para autorizar a transferência de recursos estaduais aos municípios mediante emendas ao projeto de lei orçamentária anual.

A MESA DIRETORA DA ASSEMBLEIA LEGISLATIVA DO ESTADO DO AMAPÁ, nos termos do §3º do art. 103 da Constituição do Estado do Amapá, promulga a seguinte Emenda ao texto da Constituição do Estado do Amapá.

**Art. 1°** A Constituição do Estado do Amapá passa a vigorar acrescida do seguinte art. 176- A: "Art. 176-A As emendas individuais de que trata o § 8º do art. 176, poderão alocar recursos aos Municípios por meio de:

I - Transferência especial; e

II - Transferência com finalidade específica.

**§ 1°** Os recursos transferidos na forma do caput deste artigo não integrarão a receita dos Municípios para fins de repartição e para cálculo dos limites das despesas com pessoal, tampouco com o endividamento nos termos do art. 179, vedada, em qualquer caso, a aplicação dos recursos a que se refere o caput deste artigo no pagamento de:

I - despesas com pessoal e encargos sociais relativos a ativos e inativos, e com pensionista; e

II - encargos referentes ao serviço de dívida.

**§ 2°** Na transferência especial a que se refere o caput deste artigo, os recursos:

I - serão repassados diretamente ao ente federado beneficiado, independentemente de celebração de convênio ou de instrumento congênere;

II - pertencerão ao ente federado no ato da efetiva transferência financeira; e

III - serão aplicadas em programações finalísticas das áreas de competência do Poder Executivo do ente federado beneficiado, observado o § 4º deste artigo.

**§ 3°** O ente federado beneficiado da transferência especial a que se refere o caput deste artigo poderá firmar contratos de cooperação técnica para fins de subsidiar o acompanhamento da execução orçamentária na aplicação dos recursos.

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 269

**§ 4°** Pelo menos 70% (setenta por cento) das transferências especiais de que trata o inciso do caput deste artigo deverão ser aplicadas em despesas de capital, observada a restrição a que se refere o inciso II do § 1º deste artigo.

**§ 5°** Na transferência com finalidade definida a que se refere o inciso II do caput deste artigo, os recursos serão:

I - vinculados à programação estabelecida na emenda parlamentar; e

II - aplicados nas áreas de competência constitucional dos Estados.

...................................................................................................... .”

**Art. 2°** No primeiro semestre do exercício financeiro subsequente ao da publicação desta Emenda Constitucional, fica assegurada a transferência financeira em montante mínimo equivalente a 60% (sessenta por cento) dos recursos de que trata o inciso I do caput do art. 176-A da Constituição Estadual.

**Art. 3º** Esta Emenda Constitucional entra em vigor na data de sua publicação.

Macapá, 12 de junho de 2024.

Deputada ALLINY SERRÃO Presidente

Deputado JAIME PEREZ Deputado FABRÍCIO FURLAN 1º Vice-Presidente 2º Vice-Presidente

Deputada EDNA AUZIER Deputado JESUS PONTES 1ª Secretária 2º Secretário

Deputado Dr. VICTOR Deputada LILIANE ABREU 3º Secretário 4ª Secretária

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 270

Referente à Proposta de Emenda à Constituição n. 0002/2025/GEA

EMENDA CONSTITUCIONAL Nº 0071, DE 17 DE JUNHO DE 2025 Publicada no Diário Oficial da ALAP nº 1906, de 17/06/2025, e no DOE nº 8432, de 17/06/2025 Autor: Poder Executivo

Insere um § 3º no art. 57 do Ato das Disposições Constitucionais Transitórias e revoga expressamente a Emenda Constitucional n° 054/2017.

A MESA DIRETORA DA ASSEMBLEIA LEGISLATIVA DO ESTADO DO AMAPÁ, nos termos do §3º do art. 103 da Constituição do Estado do Amapá, promulga a seguinte Emenda ao texto da Constituição do Estado do Amapá.

**Art. 1º** Fica inserido um § 3° no art. 57 do Ato das Disposições Constitucionais Transitórias da Constituição do Estado do Amapá, com a seguinte redação: “Art. 57..........................................................................................

**§ 3°** A incorporação dos direitos e vantagens fica limitada aos Oficiais que exerciam os cargos de Comandante Geral da Policia Militar, Comandante Geral do Corpo de Bombeiros Militar, Chefes de Gabinetes Militares dos Poderes e do Ministério Público Estadual até a data de 12 de abril de 2017, incluindo os que nesta data em exercício estavam, desde que os tenham exercido por um período mínimo de 18 meses ininterruptos ou alternados no ato da passagem para a inatividade, sendo vedadas novas incorporações a partir daquela data, ficando preservados, ainda, os direitos e vantagens dos Oficiais que já estavam transferidos à reserva naquela mesma data.”

**Art. 2º** Esta Emenda Constitucional entra em vigor na data de sua publicação, revogada a Emenda Constitucional n° 054/2017 da Constituição do Estado do Amapá.

Macapá, 17 de junho de 2025.

Deputada ALLINY SERRÃO Presidente

Deputado JAIME PEREZ Deputado FABRÍCIO FURLAN 1º Vice-Presidente 2º Vice-Presidente

Deputada EDNA AUZIER Deputado JESUS PONTES 1ª Secretária 2º Secretário

Deputado Dr. VICTOR Deputada LILIANE ABREU 3º Secretário 4ª Secretária

CONSTITUIÇÃO DO ESTADO DO AMAPÁ CONSOLIDADA Página 271
