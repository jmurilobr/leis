from pathlib import Path
import json,hashlib,sys,tempfile,shutil,subprocess,datetime,gzip
root=Path.cwd();base=Path('estaduais/TO/_fonte/auditorias/to45-visibilidade-complementar-20261028-001');mp='scripts/estados/manifestos/to45-overlay-visibilidade-complementar-20261028-001.json';hp=str(base/'hashes.json');maps=json.loads(Path(hp).read_text());SHA=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();qa=root/'scripts/bin/qa-20261027/python';bootstrap='''import sys,pathlib,json,os,unittest
repo=pathlib.Path(sys.argv[1]).resolve();qa=pathlib.Path(sys.argv[2]).resolve();ex=pathlib.Path.cwd().resolve();sys.path[:0]=[str(ex/'scripts/estados/snapshots/to_visibilidade_20261028_001'),str(qa)];blocked=[]
def hook(event,args):
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  p=pathlib.Path(os.fsdecode(args[0])).resolve()
  if p.is_relative_to(repo) and not p.is_relative_to(ex) and not p.is_relative_to(qa):blocked.append(str(p));raise RuntimeError('fora da exportação')
sys.addaudithook(hook)
from reexecutar_overlay_visibilidade import replay
from test_visibilidade_pdf_to import Visibilidade
r=replay(sys.argv[3],sys.argv[4]);t=unittest.TextTestRunner().run(unittest.defaultTestLoader.loadTestsFromTestCase(Visibilidade));print(json.dumps(dict(replay=r,testes=t.testsRun,falhas=len(t.failures),erros=len(t.errors),bloqueios=blocked)))
if not t.wasSuccessful() or blocked:raise SystemExit(1)
'''
with tempfile.TemporaryDirectory(prefix='to45-complemento-') as temp:
 ex=Path(temp)
 for p in list(maps)+[hp]:
  if p in maps and SHA(p)!=maps[p]:raise ValueError(p)
  d=ex/p;d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,d)
 r=subprocess.run([sys.executable,'-I','-B','-c',bootstrap,str(root),str(qa),mp,hp],cwd=ex,capture_output=True,text=True);(base/'testes-exportacao.txt').write_text(r.stderr)
 if r.returncode:raise RuntimeError(r.stderr+'\n'+r.stdout)
 proof=json.loads(r.stdout.strip().splitlines()[-1]);assert proof['testes']==6
receipt=base/'recibo-exportacao.json';receipt.write_text(json.dumps(dict(preparado_em=datetime.datetime.now().astimezone().isoformat(),entrada=mp,sha256_entrada=SHA(mp),mapa=hp,sha256_mapa=SHA(hp),resultado=proof,Python='-I -B',exportacao_somente_mapa=True,QA_externo='scripts/bin/qa-20261027/python',alterados=0,sem_Git_escrita=True),ensure_ascii=False,indent=2)+'\n');raw=Path(__file__).read_bytes();z=base/(hashlib.sha256(raw).hexdigest()+'.validar-exportacao.py.gz');z.write_bytes(gzip.compress(raw,mtime=0));files=set(maps)|{hp,str(base/'paths.txt'),str(receipt),str(base/'testes-exportacao.txt'),str(z)};delivery=base/'entrega';delivery.mkdir(exist_ok=False);final={p:SHA(p) for p in sorted(files)};(delivery/'hashes.json').write_text(json.dumps(final,ensure_ascii=False,indent=2)+'\n');(delivery/'paths.txt').write_text('\n'.join(final)+'\n');print(dict(resultado=proof,mapa=SHA(delivery/'hashes.json'),recibo=SHA(receipt),arquivos=len(final)))
