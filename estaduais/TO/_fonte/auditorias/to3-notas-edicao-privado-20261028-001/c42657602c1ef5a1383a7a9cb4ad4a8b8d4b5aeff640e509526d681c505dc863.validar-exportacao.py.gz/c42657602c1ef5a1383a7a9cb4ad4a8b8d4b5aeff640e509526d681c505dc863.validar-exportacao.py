from pathlib import Path
import sys,json,hashlib,tempfile,shutil,subprocess,gzip,datetime
root=Path.cwd();base=Path('estaduais/TO/_fonte/auditorias/to3-notas-edicao-privado-20261028-001');mp='scripts/estados/manifestos/to3-notas-edicao-overlay-privado-20261028-001.json';hp=str(base/'final/hashes.json');maps=json.loads(Path(hp).read_text());SHA=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();script='''import sys,pathlib,json,unittest,os
repo=pathlib.Path(sys.argv[1]).resolve();ex=pathlib.Path.cwd().resolve();sys.path.insert(0,str(ex/'scripts/estados/snapshots/to_metadados_edicao_20261028_001'));blocked=[]
def hook(event,args):
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  p=pathlib.Path(os.fsdecode(args[0])).resolve()
  if p.is_relative_to(repo) and not p.is_relative_to(ex):blocked.append(str(p));raise RuntimeError('fora da exportação')
sys.addaudithook(hook)
from aplicar_metadados_edicao import verify,rewrite,read,SHA
from test_aplicar_metadados_edicao import Overlay
m=json.loads(pathlib.Path(sys.argv[2]).read_text());maps=json.loads(pathlib.Path(sys.argv[3]).read_text())
for p,s in maps.items():
 if SHA(pathlib.Path(p).read_bytes())!=s:raise ValueError('SHA divergente')
for r in m['documentos']:
 old=pathlib.Path(r['preimagem']).read_bytes();new=pathlib.Path(r['privado']).read_bytes();verify(old,new,r['metadados_propostos'])
 if rewrite(old,r['metadados_propostos'])!=new or SHA(read(new)[1])!=r['sha256_corpo_H1']:raise ValueError('body/proposta diverge')
t=unittest.TextTestRunner().run(unittest.defaultTestLoader.loadTestsFromTestCase(Overlay));print(json.dumps(dict(total=len(m['documentos']),corpos_H1_byte_identicos=len(m['documentos']),testes=t.testsRun,falhas=len(t.failures),erros=len(t.errors),bloqueios=blocked)))
if not t.wasSuccessful() or blocked:raise SystemExit(1)
'''
with tempfile.TemporaryDirectory(prefix='to3-notas-export-') as temp:
 ex=Path(temp)
 for p in list(maps)+[hp]:
  if p in maps and SHA(p)!=maps[p]:raise ValueError(p)
  d=ex/p;d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,d)
 r=subprocess.run([sys.executable,'-I','-B','-c',script,str(root),mp,hp],cwd=ex,capture_output=True,text=True);(base/'testes-exportacao.txt').write_text(r.stderr)
 if r.returncode:raise RuntimeError(r.stderr+'\n'+r.stdout)
 proof=json.loads(r.stdout.strip().splitlines()[-1])
receipt=base/'recibo-final.json';receipt.write_text(json.dumps(dict(preparado_em=datetime.datetime.now().astimezone().isoformat(),manifesto=mp,sha256_manifesto=SHA(mp),mapa_entrada=hp,sha256_mapa_entrada=SHA(hp),resultado=proof,exportacao_somente_mapa=True,Python='-I -B',dependencias_externas='somente biblioteca padrão Python',dry_run=json.loads(Path('estaduais/TO/_fonte/auditorias/to3-notas-edicao-dry-run-20261028-001/resultado.json').read_text()),sem_apply=True,sem_Git_escrita=True,novas_normas=0,comando='python3 -B scripts/estados/snapshots/to_metadados_edicao_20261028_001/aplicar_metadados_edicao.py --manifesto '+mp+' --hashes '+hp+' --grupo 45|178|186|todos --controle CONTROLE_PRIVADO_NOVO (dry-run; --apply --confirmar-root ROOT exclusivo coordenador)'),ensure_ascii=False,indent=2)+'\n');files=set(maps)|{str(receipt),str(base/'testes-exportacao.txt'),hp,str(base/'final/paths.txt')}
control=Path('estaduais/TO/_fonte/auditorias/to3-notas-edicao-dry-run-20261028-001');files|={str(p) for p in control.rglob('*') if p.is_file()};raw=Path(__file__).read_bytes();z=base/(hashlib.sha256(raw).hexdigest()+'.validar-exportacao.py.gz');z.write_bytes(gzip.compress(raw,mtime=0));files.add(str(z));delivery=base/'entrega';delivery.mkdir(exist_ok=False);out={p:SHA(p) for p in sorted(files)};(delivery/'hashes.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');(delivery/'paths.txt').write_text('\n'.join(out)+'\n');print(dict(resultado=proof,mapa=SHA(delivery/'hashes.json'),recibo=SHA(receipt),arquivos=len(out)))
