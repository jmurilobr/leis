from pathlib import Path
import json,hashlib,subprocess,sys,tempfile,shutil,datetime,gzip
root=Path.cwd();base=Path('estaduais/TO/_fonte/auditorias/to178-privado-20261028-001');mp='scripts/estados/manifestos/to178-proposta-privada-20261028-001.json';hp=str(base/'final/hashes.json');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();maps=json.loads(Path(hp).read_text());out=base/'provas-portabilidade';out.mkdir(exist_ok=False);qa=str(root/'scripts/bin/qa-20261027/python');profile='scripts/estados/snapshots/to_pdf_simples_20261028_002';runner='scripts/estados/snapshots/to_promocao_20261028_001';py=sys.executable
bootstrap='''import sys,pathlib,json,unittest,importlib,os
export=pathlib.Path.cwd().resolve();repo=pathlib.Path(sys.argv[1]).resolve();qa=pathlib.Path(sys.argv[2]).resolve();profile=sys.argv[3];runner=sys.argv[4];mp=sys.argv[5];hp=sys.argv[6]
sys.path[:0]=[str(export/profile),str(export/runner),str(qa)]
blocked=[]
def hook(event,args):
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  p=pathlib.Path(os.fsdecode(args[0])).resolve()
  if p.is_relative_to(repo) and not p.is_relative_to(export) and not p.is_relative_to(qa):
   blocked.append(str(p));raise RuntimeError('leitura fora da exportação: '+str(p))
sys.addaudithook(hook)
from reexecutar_to_pdf import replay
result=replay(mp,hp)
modules=[importlib.import_module(p.stem) for folder in [profile,runner] for p in sorted(pathlib.Path(folder).glob('test_*.py'))]
suite=unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromModule(m) for m in modules)
r=unittest.TextTestRunner(verbosity=1).run(suite)
print(json.dumps(dict(replay=result,testes=r.testsRun,falhas=len(r.failures),erros=len(r.errors),bloqueios_fora_exportacao=blocked)))
if not r.wasSuccessful() or blocked:raise SystemExit(1)
'''
with tempfile.TemporaryDirectory(prefix='to178-export-') as temp:
 export=Path(temp)
 for p,want in maps.items():
  if sha(p)!=want:raise ValueError(p)
  dest=export/p;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest)
 for p in [hp,str(base/'final/paths.txt')]:
  dest=export/p;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest)
 r=subprocess.run([py,'-I','-B','-c',bootstrap,str(root),qa,profile,runner,mp,hp],cwd=export,capture_output=True,text=True);(out/'testes.txt').write_text(r.stderr);(out/'saida.txt').write_text(r.stdout)
 if r.returncode:raise RuntimeError(r.stderr+'\n'+r.stdout)
 result=json.loads(r.stdout.strip().splitlines()[-1]);(out/'prova-isolamento.json').write_text(json.dumps(dict(**result,exportacao_somente_mapa=True,QA_externo='scripts/bin/qa-20261027/python',Python='-I -B'),ensure_ascii=False,indent=2)+'\n')
checks=[]
for p in [p for p in maps if p.endswith('.py') or '/candidatos/' in p]:
 r=subprocess.run(['git','diff','--no-index','--check','/dev/null',p],capture_output=True,text=True)
 if r.stdout or r.stderr or r.returncode not in [0,1]:checks.append(dict(path=p,retorno=r.returncode,stdout=r.stdout,stderr=r.stderr))
(base/'final/diff-check.json').write_text(json.dumps(dict(arquivos=sum(p.endswith('.py') or '/candidatos/' in p for p in maps),diagnosticos=checks),ensure_ascii=False,indent=2)+'\n')
if checks:raise RuntimeError('diff check falhou')
print(json.dumps(result))
