from pathlib import Path
import json,gzip,subprocess
m=json.load(open('scripts/estados/manifestos/to178-proposta-privada-20261028-001.json'));base=Path('estaduais/TO/_fonte/auditorias/to178-privado-20261028-001/inspecao');base.mkdir(exist_ok=False);selected=[]
for year in ['2019','2018','2017','2016','2010']:
 options=[r for r in m['documentos'] if r['QA']['data'].startswith(year)];selected.append(max(options,key=lambda r:r['QA']['total_paginas']))
selected.append(next(r for r in m['documentos'] if r['QA']['data'].startswith('2019') and r['QA']['total_paginas']==1 and r not in selected));(base/'selecao-visual.json').write_text(json.dumps([dict(path=r['path'],id_ALETO=r['captura']['item']['id_ALETO'],paginas=r['QA']['total_paginas']) for r in selected],ensure_ascii=False,indent=2)+'\n')
for r in selected:
 id=r['captura']['item']['id_ALETO'];p=base/(id+'.pdf');p.write_bytes(gzip.decompress(Path(r['captura']['cache']).read_bytes()));subprocess.run(['/opt/homebrew/bin/pdftoppm','-scale-to','1300','-png',str(p),str(base/id)],check=True,capture_output=True)
