from pathlib import Path
src=Path('scripts/estados/snapshots/ac_legis_promocao_20261027_006/promover_legis_ac_privado.py').read_text().replace('LEGIS/AC HTML','ALETO PDF').replace('LEGIS/AC','ALETO').replace('LEGIS-AC','ALETO').replace('SAPL-AC','SAPL-TO').replace('estaduais/AC','estaduais/TO').replace("'AC'","'TO'").replace('auditoria AC','auditoria TO').replace('legis_ac','to_pdf').replace('.ac-legis-','.to-pdf-')
a=src.index('def id_oficial(');b=src.index('\ndef arquivo(',a)
src=src[:a]+'''def id_oficial(meta):
 u=urlsplit(str(meta.get('fonte','')))
 if u.hostname in ['www.al.to.leg.br','al.to.leg.br']:
  match=re.fullmatch(r'/arquivo/(\\d+)',u.path)
  return ('ALETO',match[1]) if match else None
 if u.hostname=='sapl.al.to.leg.br':
  match=re.fullmatch(r'/(?:norma|normajuridica)/(\\d+)/?',u.path)
  return ('SAPL-TO',match[1]) if match else None
 return None
''' + src[b:]
a=src.index('def validar(');b=src.index('\ndef publicar_sem_substituir(',a)
src=src[:a]+'''def validar(root,manifesto,hashes,total_esperado):
 from auditar_to_pdf_simples import auditar
 from metadados_to_pdf import criar
 m=json.loads(manifesto.read_text());maps=json.loads(hashes.read_text())
 if maps.get(str(manifesto.relative_to(root)))!=digest(manifesto):raise ValueError('manifesto não confere com mapa SHA')
 for path,sha in maps.items():
  if digest(relpath(root,path))!=sha:raise ValueError('dependência SHA divergente: '+path)
 for path,sha in m['codigo'].items():
  if digest(relpath(root,path))!=sha or maps.get(path)!=sha:raise ValueError('código congelado divergente')
 candidates=[]
 for r in m['documentos']:
  blob=relpath(root,r['privado']).read_bytes()
  if SHA(blob)!=r['sha256_md']:raise ValueError('candidato SHA divergente')
  meta,body=metadata(blob);verificar_metadados(meta,r['captura']);title,sep,norm=body.partition('\\n\\n')
  if not sep or title!='# '+meta['titulo']:raise ValueError('H1 divergente')
  native,q=auditar(r['captura'],norm)
  if q!=r['QA'] or q['contextos_objetos'] or criar(r['captura'],q,native)!=blob:raise ValueError('replay fonte/candidato/contextos diverge')
  it=r['captura']['item'];expected=f"estaduais/TO/{it['pasta']}/{q['data'][:4]}/{'lc' if it['pasta']=='leis-complementares' else 'l'}-{q['numero']}-{q['data'][:4]}-aleto{it['id_ALETO']}.md"
  if r['path']!=expected or it['pasta'] not in ['leis-ordinarias','leis-complementares']:raise ValueError('destino diverge da identidade oficial')
  if os.path.lexists(relpath(root,r['path'])):raise ValueError('destino já existe em disco: '+r['path'])
  candidates.append(dict(path=r['path'],privado=r['privado'],sha256_md=r['sha256_md'],meta=meta))
 if len(candidates)!=m['total'] or m['total']!=total_esperado:raise ValueError('contagem fora do escopo ALETO PDF')
 return m,candidates
''' + src[b:]
src=src.replace('Blobs integrais do HEAD atual: ID no namespace LEGIS/SAPL AC','Blobs integrais do HEAD atual: ID no namespace ALETO/SAPL TO')
p=Path('scripts/estados/snapshots/to_promocao_20261028_001');p.mkdir(exist_ok=False);(p/'promover_to_pdf_privado.py').write_text(src)
tests=Path('scripts/estados/snapshots/ac_legis_promocao_20261027_006/test_promover_legis_ac_privado.py').read_text().replace('promover_legis_ac_privado','promover_to_pdf_privado').replace('estaduais/AC','estaduais/TO').replace('https://legis.ac.gov.br/detalhar/','https://www.al.to.leg.br/arquivo/').replace('https://legis.ac.gov.br/Arquivo/','https://www.al.to.leg.br/arquivos/').replace('http://legis.ac.gov.br/Arquivo/','http://www.al.to.leg.br/arquivos/').replace('https://sapl.al.ac.leg.br/','https://sapl.al.to.leg.br/');(p/'test_promover_to_pdf_privado.py').write_text(tests)
