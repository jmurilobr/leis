import sys,json,hashlib,datetime,traceback
from pathlib import Path
from collections import Counter
profile=Path('scripts/estados/snapshots/to_pdf_simples_20261028_001');sys.path.insert(0,str(profile.resolve()))
from auditar_to_pdf_simples import auditar
base=Path('estaduais/TO/_fonte/auditorias/portal-QA-500-20261028-003');mp=Path('scripts/estados/manifestos/to-portal-fontes-500-20261028-002.json');m=json.loads(mp.read_text());SHA=lambda b:hashlib.sha256(b).hexdigest();rows=[]
with (base/'resultados.jsonl').open('x') as f:
 for row in m['capturas']:
  r=dict(captura=row)
  try:
   body,q=auditar(row);r.update(QA=q,apto_automatico=not q['contextos_objetos']);p=base/'corpos'/str(row['item']['id_ALETO']+'.md');p.parent.mkdir(exist_ok=True);p.write_text(body);r['corpo']=str(p);r['sha256_corpo']=SHA(body.encode())
   if q['contextos_objetos']:r['motivo']='Referência a objeto/anexo exige contexto individual'
  except Exception as e:r.update(apto_automatico=False,motivo=type(e).__name__+': '+str(e))
  rows.append(r);f.write(json.dumps(r,ensure_ascii=False)+'\n');f.flush()
  if len(rows)%25==0:print(json.dumps(dict(total=len(rows),aptos=sum(r['apto_automatico'] for r in rows))),flush=True)
result=dict(preparado_em=datetime.datetime.now().astimezone().isoformat(),total=len(rows),aptos=sum(r['apto_automatico'] for r in rows),retidos=sum(not r['apto_automatico'] for r in rows),motivos=dict(Counter(r.get('motivo','apto') for r in rows)),fonte_manifesto=str(mp),sha256_manifesto=SHA(mp.read_bytes()),codigo={str(p):SHA(p.read_bytes()) for p in profile.iterdir() if p.is_file()},sem_promocao=True,sem_mascara=True,metas_inalteradas=True)
(base/'resumo.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False))
