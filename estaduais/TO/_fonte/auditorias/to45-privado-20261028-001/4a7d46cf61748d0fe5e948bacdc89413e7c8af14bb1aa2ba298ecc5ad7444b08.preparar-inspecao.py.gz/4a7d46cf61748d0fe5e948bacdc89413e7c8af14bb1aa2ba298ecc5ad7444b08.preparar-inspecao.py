import json,gzip,subprocess
from pathlib import Path
m=json.loads(Path('scripts/estados/manifestos/to45-proposta-privada-20261028-001.json').read_text());base=Path('estaduais/TO/_fonte/auditorias/to45-privado-20261028-001/inspecao');base.mkdir(exist_ok=False)
for r in m['documentos']:
 id=r['captura']['item']['id_ALETO']
 if id not in ['7601','7597','7876','7963','7950']:continue
 p=base/(id+'.pdf');p.write_bytes(gzip.decompress(Path(r['captura']['cache']).read_bytes()));subprocess.run(['/opt/homebrew/bin/pdftoppm','-scale-to','1300','-png',str(p),str(base/id)],check=True,capture_output=True)
