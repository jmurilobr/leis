var EDICAO_ID = 0;
var PAGINA_ATUAL = 1;
var PAGINAS = 0;
var params = '';
$(document).ready(function() {
    params = document.location.toString().split('?')[1];
    var tmpAlvo = document.location.toString().split('?')[0].split('#')[1].split('/');
    for (var g in tmpAlvo) {
        var val = tmpAlvo[g].split(':');
        if (val[0] == 'e') {
            EDICAO_ID = val[1];
        }
        if (val[0] == 'p') {
            PAGINA_ATUAL = val[1];
        }
    }
    carregarPaginas();
    $(".select-pagina").change(function() {
        carregarDiario(EDICAO_ID, $(this).val());
    });
    $(".btn-primeira").click(function() {
        carregarDiario(EDICAO_ID, 1);
        $(".select-pagina").val(1)
    });
    $(".btn-ultima").click(function() {
        carregarDiario(EDICAO_ID, PAGINAS);
        $(".select-pagina").val(PAGINAS)
    });
    $(".btn-anterior").click(function() {
        if (PAGINA_ATUAL > 1) {
            PAGINA_ATUAL = PAGINA_ATUAL - 1;
            carregarDiario(EDICAO_ID, PAGINA_ATUAL);
            $(".select-pagina").val(PAGINA_ATUAL);
        }
    });
    $(".btn-proxima").click(function() {
        if (PAGINA_ATUAL < PAGINAS) {
            PAGINA_ATUAL = +PAGINA_ATUAL + 1;
            carregarDiario(EDICAO_ID, PAGINA_ATUAL);
            $(".select-pagina").val(PAGINA_ATUAL);
        }
    });
    carregarDiario(EDICAO_ID, PAGINA_ATUAL);
    if ($('.full-download').length > 0) {
        $('.full-download').attr("href", $('.full-download').attr("href").substr(0, $('.full-download').attr("href").lastIndexOf('/')) + '/' + EDICAO_ID);
    }
    setTimeout(function() {
        doSize()
    }, 500);
});

function carregarPaginas() {
    $.ajax({
        url: (CDN_URL != '' ? CDN_URL : BASE_URL) + '/apifront/portal/edicoes/edicao_imagens/' + EDICAO_ID,
    }).done(function(data) {
        if (console && console.log) {
            //console.log("Sample of data:", data.slice(0, 100));
        }
        var obj = jQuery.parseJSON(data);
        if (obj.erro) {
            return;
        }
        PAGINAS = obj.itens.length;
        if (obj.itens.length > 0) {
            var pgs = '';
            for (var i in obj.itens) {
                var sel = (obj.itens[i].pagina == PAGINA_ATUAL) ? 'selected="selected"' : '';
                pgs += "<option value=" + obj.itens[i].pagina + " " + sel + ">" + obj.itens[i].pagina + "</option>";
            }
            $(".select-pagina").html(pgs)
        }
    });
}

function carregarDiario(edicao_id, pagina) {
    PAGINA_ATUAL = pagina;
    var link = BASE_URL + '/cleanpdf/?file=' + (CDN_URL != '' ? CDN_URL : BASE_URL) + '/apifront/portal/edicoes/pdf_diario/' + edicao_id + '/' + pagina + ($.urlParam('find') ? '&find=' + $.urlParam('find') : '');
    $("#pdfJornal").html('<iframe src="' + link + '" style="width:100%;height:100%;"></iframe');
    $("#selectPaginas").val(pagina);
    document.location = '#/p:' + pagina + '/e:' + edicao_id + ((params) ? '?' + params : '');
    updateLinks();
}
$(window).resize(function() {
    doSize();
});
$.urlParam = function(name) {
    var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.href);
    return (results) ? results[1] || 0 : 0;
}

function doSize() {
    var altura = $(window).height() - $('#header').height() - 51;
    $("#pdfJornal").height(altura);
}

function updateLinks() {
    $('.pdf, .html, .jornal').each(function() {
        $(this).attr('href', ($(this).attr('href').split('#')[0] + '/' + document.location.hash).replace('//', '/'));
    });
}
