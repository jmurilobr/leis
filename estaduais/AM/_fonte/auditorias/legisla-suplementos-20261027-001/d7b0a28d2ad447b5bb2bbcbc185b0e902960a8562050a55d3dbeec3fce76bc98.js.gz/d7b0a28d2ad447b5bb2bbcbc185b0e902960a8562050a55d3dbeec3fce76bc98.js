$(document).ready(function() {
    $('.pdf, .html, .jornal').tooltip(function() {
        placement: 'bottom';
        show: true;
    });
});
