from pathlib import Path
import json,gzip,hashlib,datetime
from collections import defaultdict
base=Path('estaduais/AC/_fonte/auditorias/ac679-privado-20261028-002');control=Path('estaduais/AC/_fonte/auditorias/ac679-promocao-dry-run-20261028-002');mp=Path('scripts/estados/manifestos/ac679-proposta-privada-20261028-002.json');load=lambda p:json.loads(Path(p).read_text());SHA=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();m=load(mp);heads=[json.loads(l) for l in gzip.decompress((control/'HEAD-inventario.jsonl.gz').read_bytes()).decode().splitlines()];by=defaultdict(list)
for r in heads:
 meta=r['meta'];by[(r['path'].split('/')[2],str(meta.get('numero','')).replace('.','').upper())].append(r)
coinc=[]
for r in m['documentos']:
 it=r['captura']['item'];match=by.get((it['pasta'],it['numero']))
 if match:coinc.append(dict(candidato=r['path'],sha256=r['sha256_md'],HEAD=match))
p=base/'final/coincidencias-numero-sem-ano.json';p.write_text(json.dumps(dict(total_candidatos=679,total_HEAD=len(heads),coincidencias=coinc,limite='Coincidência é alerta contextual, não duplicação automática.',HEAD=load(control/'resultado.json')['HEAD']),ensure_ascii=False,indent=2)+'\n');assert not coinc
proof=load(base/'provas-portabilidade/prova-isolamento.json');assert proof['testes']==85 and not proof['falhas'] and not proof['erros'] and not proof['bloqueios_fora_exportacao'];replay=load(base/'final/replay.json');dry=load(control/'resultado.json');receipt=Path('scripts/estados/manifestos/ac679-recibo-final-20261028-002.json');receipt.write_text(json.dumps(dict(preparado_em=datetime.datetime.now().astimezone().isoformat(),total=679,leis_ordinarias=sum(r['captura']['item']['tipo']=='Lei Ordinária' for r in m['documentos']),leis_complementares=sum(r['captura']['item']['tipo']=='Lei Complementar' for r in m['documentos']),retidos=294,manifesto=str(mp),sha256_manifesto=SHA(mp),mapa_replay=str(base/'final/hashes.json'),sha256_mapa_replay=SHA(base/'final/hashes.json'),replay=replay,portabilidade=proof,dry_run=dry,diff_check=load(base/'final/diff-check.json'),sem_Git_escrita=True,nenhum_apply_executado=True,metas_inalteradas=True,esquema='versao_texto obrigatória; baixado_em somente YYYY-MM-DD da captura UTC-03; timestamp integral no recibo; ordem README.',diagnostico_sem_ano=str(p),codigo=m['codigo'],comandos=dict(replay='PYTHONPATH="$PWD/scripts/bin/qa-20261027/python" python3 -B scripts/estados/snapshots/ac_legis_html_20261027_006/reexecutar_legis_ac.py --manifesto '+str(mp)+' --hashes '+str(base/'final/hashes.json')+' --recibo RECIBO_NOVO.json',dry_run='PYTHONPATH="$PWD/scripts/bin/qa-20261027/python" python3 -B scripts/estados/snapshots/ac_legis_promocao_20261027_006/promover_legis_ac_privado.py --manifesto '+str(mp)+' --hashes '+str(base/'final/hashes.json')+' --total-esperado 679 --controle CONTROLE_PRIVADO_NOVO')),ensure_ascii=False,indent=2)+'\n')
files=set(load(base/'final/hashes.json'))|{str(receipt)}
for folder in [base/'final',base/'provas-portabilidade',control]:
 files|={str(p) for p in folder.rglob('*') if p.is_file()}
# Helpers operacionais preservados como dados; não ampliar código ativo do mapa.
for name in ['preparar-privado.py','validar-portabilidade.py','fechar-recibo.py']:
 p=base/name;raw=p.read_bytes();dest=base/(hashlib.sha256(raw).hexdigest()+'.'+name+'.gz');dest.write_bytes(gzip.compress(raw,mtime=0));files.add(str(dest))
delivery=base/'entrega';delivery.mkdir(exist_ok=False);maps={p:SHA(p) for p in sorted(files)};(delivery/'hashes.json').write_text(json.dumps(maps,ensure_ascii=False,indent=2)+'\n');(delivery/'paths.txt').write_text('\n'.join(maps)+'\n');print(json.dumps(dict(manifesto=SHA(mp),recibo=SHA(receipt),mapa=SHA(delivery/'hashes.json'),arquivos=len(maps),total=679)))
