from pathlib import Path
import sys,json,gzip,hashlib,datetime,copy
sys.path.insert(0,str(Path('scripts/estados/snapshots/ac_legis_html_20261027_006').resolve()))
from metadados_legis_ac import acrescentar,ler,verificar
SHA=lambda b:hashlib.sha256(b).hexdigest();root=Path.cwd();stamp=datetime.datetime.now().astimezone().isoformat();globalbase=Path('estaduais/AC/_fonte/auditorias/metadados-sucessores-20261027-030')
cohorts=[(440,'scripts/estados/manifestos/ac440-proposta-privada-20261027-005.json','estaduais/AC/_fonte/auditorias/ac440-suplemento-publicacao-20261027-001/hashes.json',True),(458,'scripts/estados/manifestos/ac458-proposta-privada-20261027-001.json','estaduais/AC/_fonte/auditorias/ac458-privado-20261027-001/final002/hashes.json',False),(761,'scripts/estados/manifestos/ac761-proposta-privada-20261027-001.json','estaduais/AC/_fonte/auditorias/ac761-privado-20261027-001/final/hashes.json',False)]
for total,oldmanifest,oldmap,ispatch in cohorts:
 oldpath=Path(oldmanifest);old=oldpath.read_bytes();m=json.loads(old);assert m['total']==total;previous_maps=json.loads(Path(oldmap).read_text());base=Path(f'estaduais/AC/_fonte/auditorias/ac{total}-metadados-privado-20261027-002');base.mkdir(exist_ok=False);docs=[];proofs=[]
 for r in m['documentos']:
  before=Path(r['path'] if ispatch else r['privado']).read_bytes();assert SHA(before)==r['sha256_md']
  if not ispatch:assert not Path(r['path']).exists(),'destino novo inesperadamente existe: '+r['path']
  new,proof=acrescentar(before,r['captura']);assert proof['chaves_adicionadas']==['baixado_em','versao_texto'] and proof['corpo_com_H1_byte_identico'];pre=base/'preimagens'/r['path'];candidate=base/'candidatos'/r['path'];pre.parent.mkdir(parents=True,exist_ok=True);candidate.parent.mkdir(parents=True,exist_ok=True);pre.write_bytes(before);candidate.write_bytes(new)
  rr=copy.deepcopy(r);rr.update(privado=str(candidate),sha256_md=SHA(new),preimagem=str(pre),sha256_preimagem=SHA(before),prova_metadados=proof,origem_preimagem='Canônico aplicado ROOT, lido do disco' if ispatch else 'Candidato privado congelado anterior');docs.append(rr);proofs.append(dict(path=r['path'],**proof))
 code={}
 for profile in [Path('scripts/estados/snapshots/ac_legis_html_20261027_006'),Path('scripts/estados/snapshots/ac_legis_metadados_patch_20261027_002' if ispatch else 'scripts/estados/snapshots/ac_legis_promocao_20261027_006')]:
  for p in profile.iterdir():
   if p.is_file():code[str(p)]=SHA(p.read_bytes())
 # Somente código ativo fica bruto. Versões anteriores permanecem gzip+índice.
 files={};archived=[]
 for p,sha in previous_maps.items():
  raw=Path(p).read_bytes();assert SHA(raw)==sha
  if p.endswith('.py') and p not in code:
   z=gzip.compress(raw,mtime=0);dest=base/'codigo-anterior-gzip'/(SHA(raw)+'.py.gz');dest.parent.mkdir(exist_ok=True);dest.write_bytes(z);assert gzip.decompress(z)==raw;files[str(dest)]=SHA(z);archived.append(dict(caminho_original=p,sha256_original=sha,gzip=str(dest),sha256_gzip=SHA(z)))
  else:files[p]=sha
 archive_index=base/'indice-codigo-anterior.json';archive_index.write_text(json.dumps(dict(total=len(archived),arquivos=archived,originais_intactos=True,instrucao='Reconstruir apenas em diretório privado separado; nunca necessário ao replay ativo.'),ensure_ascii=False,indent=2)+'\n');files[str(archive_index)]=SHA(archive_index.read_bytes())
 report=base/'provas-cabecalho.json';report.write_text(json.dumps(dict(total=total,corpos_H1_byte_identicos=total,apenas_duas_chaves_adicionadas=True,sem_chaves_removidas=True,sem_valores_antigos_alterados=True,ordem_README=True,documentos=proofs),ensure_ascii=False,indent=2)+'\n');files[str(report)]=SHA(report.read_bytes())
 m.update(preparado_em=stamp,documentos=docs,codigo=code,novas_normas=0 if ispatch else total,tipo_operacao='patch de cabeçalho por preimagem, exclusivo ROOT' if ispatch else 'sucessor de proposta ausente com esquema obrigatório',esquema_metadados='README: versao_texto precisa e baixado_em apenasYYYY-MM-DD da captura real emUTC-03:00; timestamp integral no recibo; extensões após campos canônicos',sucessao_metadados=dict(manifesto=oldmanifest,sha256_manifesto=SHA(old),mapa=oldmap,sha256_mapa=SHA(Path(oldmap).read_bytes()),apenas_cabecalho=True,corpo_H1_byte_identico=True,edicao_e_demais_chaves_preservadas=True,provas=str(report),sha256_provas=SHA(report.read_bytes())))
 manifest=Path(f'scripts/estados/manifestos/ac{total}-metadados-proposta-privada-20261027-002.json');manifest.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n');files[str(manifest)]=SHA(manifest.read_bytes());files[str(oldpath)]=SHA(old)
 for r in docs:files[r['privado']]=r['sha256_md'];files[r['preimagem']]=r['sha256_preimagem']
 files.update(code)
 # Preparador fica como prova reconstruível, não como código de execução.
 raw=Path(__file__).read_bytes();z=gzip.compress(raw,mtime=0);dest=base/'codigo-anterior-gzip'/(SHA(raw)+'.preparador.py.gz');dest.write_bytes(z);files[str(dest)]=SHA(z)
 final=base/'final';final.mkdir(exist_ok=False);(final/'hashes.json').write_text(json.dumps(dict(sorted(files.items())),ensure_ascii=False,indent=2)+'\n');(final/'paths.txt').write_text('\n'.join(sorted(files))+'\n');(final/'canonicos.txt').write_text('\n'.join(r['path'] for r in docs)+'\n');(final/'candidatos.txt').write_text('\n'.join(r['privado'] for r in docs)+'\n');assert {p for p in files if p.endswith('.py')}=={p for p in code if p.endswith('.py')};print(json.dumps(dict(total=total,patch=ispatch,manifesto=str(manifest),sha256=SHA(manifest.read_bytes()),mapa=SHA((final/'hashes.json').read_bytes()),arquivos=len(files),codigo_anterior_gzip=len(archived))),flush=True)
