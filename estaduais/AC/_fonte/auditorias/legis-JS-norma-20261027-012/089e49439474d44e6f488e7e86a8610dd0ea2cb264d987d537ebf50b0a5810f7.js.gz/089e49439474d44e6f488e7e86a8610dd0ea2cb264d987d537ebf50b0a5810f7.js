String.prototype.stripHTML = function () {
    return this.replace(/<.*?>/g, '');
}

history.pushState(null, document.title, location.href);
window.addEventListener('popstate', function (event)
{
    history.pushState(null, document.title, location.href);
});

$('p').find('span').find('span').each(function () {
    //if ($(this).attr('style') == 'font-family: Verdana,Geneva,sans-serif;' || $(this).attr('style') == 'font-family: Verdana,Geneva,sans-serif') {
    $(this).removeAttr('font-family');
    //}
});

$('table').each(function () {
    if ($(this).find('tbody').find('tr').find('td').find('p').find('span').find('span').attr('style') == 'text-decoration: line-through; display: none;') {
        $(this).find('tbody').find('tr').find('td').remove();
    }
});

$('div#exportacao').bind('cut copy paste', function (event) {

    var selectedText = window.getSelection().toString();

    if (selectedText != undefined) {
        const el = document.createElement('textarea');
        el.value = selectedText.stripHTML();
        document.body.appendChild(el);
        el.select();
        document.execCommand('copy');
        document.body.removeChild(el);
    }
});

function deslizar(elemento) {
    var topPosition = $('div#' + elemento).offset().top - 235;
    $('html, body').animate({
        scrollTop: topPosition
    }, 800);
}

function romanize(num) {
    if (!+num)
        return NaN;
    var digits = String(+num).split(""),
            key = ["", "C", "CC", "CCC", "CD", "D", "DC", "DCC", "DCCC", "CM",
                "", "X", "XX", "XXX", "XL", "L", "LX", "LXX", "LXXX", "XC",
                "", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX"],
            roman = "",
            i = 3;
    while (i--)
        roman = (key[+digits.pop() + (i * 10)] || "") + roman;
    return Array(+digits.join("") + 1).join("M") + roman;
}

$(document).ready(function () {

    $('button#pesquisar_lei').click(function () {
        if ($("select#tipo_lei").val() == 4) {
            $("form#form_pesquisar").attr("action", PORTAL_URL + "detalhar_constituicao");
        } else if ($("select#tipo_lei").val() == 9) {
            $("form#form_pesquisar").attr("action", PORTAL_URL + "principal/9");
        } else if ($("select#tipo_lei").val() == 40) {
            $("form#form_pesquisar").attr("action", PORTAL_URL + "covid19");
        } else {
            $("form#form_pesquisar").attr("action", PORTAL_URL + "principal");
        }
    });

    $(document).click(function () {
        if ($('#busca_serach').attr('class') == 'search') {

        } else if ($('#busca_serach').attr('class') == 'search on') {
            $('#busca_serach').removeClass('on');
        }

        if ($('#busca_serach').attr('class') == 'search2') {

        } else if ($('#busca_serach').attr('class') == 'search2 on2') {
            $('#busca_serach').removeClass('on2');
        }

        if ($('#busca_serach').attr('class') == 'search3 on3') {
            $('#busca_serach').removeClass('search3 on3');
            $('#busca_serach').addClass('search2');
        }
    });


    $("div#busca_serach").click(function (e) {

        var div = $("#pesquisar_lei");
        if (!div.is(e.target) && div.has(e.target).length === 0)
        {
            e.stopPropagation(); // This is the preferred method.
            return false;        // This should not be used unless you do not want
            // any click events registering inside the div
        }

    });

    $(".btn-search").click(function (e) {
        e.stopPropagation(); // This is the preferred method.
        return false;        // This should not be used unless you do not want
        // any click events registering inside the div
    });

    $('select#tipo_lei').change(function () {
        if ($("select#tipo_lei").val() == 4) {
            $("div#buscar_constituicao").show();
            $("div#div_autoria").hide();
            $("div#buscar_leis_2").hide();
            $("div#div_data").hide();
            $("div#div_numero").hide();
        } else if ($("select#tipo_lei").val() == 3) {
            $("div#buscar_constituicao").hide();
            $("div#div_autoria").hide();
            $("div#buscar_leis_2").show();
            $("div#div_data").show();
            $("div#div_numero").show();
        } else if ($("select#tipo_lei").val() == 9) {
            $("div#buscar_constituicao").show();
            $("div#div_autoria").hide();
            $("div#buscar_leis_2").hide();
            $("div#div_data").hide();
            $("div#div_numero").hide();
        } else if ($("select#tipo_lei").val() == 10) {
            $("div#buscar_constituicao").hide();
            $("div#div_autoria").hide();
            $("div#buscar_leis_2").show();
            $("div#div_data").show();
            $("div#div_numero").show();
        } else {
            $("div#buscar_constituicao").hide();
            $("div#div_autoria").show();
            $("div#buscar_leis_2").show();
            $("div#div_data").show();
            $("div#div_numero").show();
        }
    });

    var resultado_busca = $('input#resultado_busca').val();
    var qtd_leis_revogadas = $('input#leis_revogadas_guard').val();

    if (qtd_leis_revogadas > 0) {
        $('div#body-law').attr('style', 'text-decoration: line-through;');
    }

    if (resultado_busca != "") {
        var div = $('div#exportacao').html();

        var elemento2 = div.indexOf(resultado_busca);
        var elemento3 = div.toUpperCase().indexOf(resultado_busca.toUpperCase());

        if (elemento2 != -1) {
            elemento = elemento2;
            resultado_busca = resultado_busca;
        } else {
            elemento = elemento3;
            resultado_busca = resultado_busca.toUpperCase();
        }

        if (elemento != -1) {

            $('div#exportacao').html(div.replace(resultado_busca, "<a id='codigo_elemento'>" + resultado_busca + "</a>"));

            var topPosition = $('a#codigo_elemento').offset().top - 135;

            $('html, body').animate({
                scrollTop: topPosition
            }, 800);
        }
    }

    $('a#habilitar_menu').click(function () {
        if ($(this).find('i#cetas').attr('class') == 'far fa-chevron-left') {
            $('div#menu_sumario').removeClass('off');
            $('div#menu_sumario').addClass('on');
            $(this).find('i#cetas').attr('class', 'far fa-chevron-right');
        } else {
            $('div#menu_sumario').removeClass('on');
            $('div#menu_sumario').addClass('off');
            $(this).find('i#cetas').attr('class', 'far fa-chevron-left');
        }
    });

    String.prototype.stripHTML = function () {
        return this.replace(/<.*?>/g, '');
    }

    var cont = 1;
    var cont1 = 1;
    var cont2 = 1;
    var cont3 = 1;
	var cont4 = 1;

    $('div#exportacao').find('p').each(function () {
        try {
            if (typeof $(this).find('span').html().stripHTML() != 'undefined') {

//                if ($(this).find('span').html().stripHTML().indexOf('Art. ' + cont + 'º') != -1) {//ARTIGO
//                    var anterior = $('div#div_indices').html();
//                    $('div#div_indices').html(anterior + '<a href="#" onclick="deslizar(' + "'artigo_" + cont + "'" + ')">Art. ' + cont + 'º ' + '</a>');
//                    $(this).find('span').first().html('<div id="artigo_' + cont + '">' + $(this).find('span').html() + '</div>');
//                    cont++;
//                }

                if ($(this).find('span').html().stripHTML() == 'TÍTULO ' + romanize(cont1)) {//TÍTULO
                    var anterior = $('div#div_indices').html();
                    $('div#div_indices').html(anterior + '<a href="#" onclick="deslizar(' + "'titulo_" + cont1 + "'" + ')">' + 'TÍTULO ' + romanize(cont1) + '</a>');
                    $(this).html('<b id="titulo_' + cont1 + '">' + 'TÍTULO ' + romanize(cont1) + '</b>');

                    cont1++;
                    cont2 = 1;
                    cont3 = 1;
                }

                if ($(this).find('span').html().stripHTML() == 'CAPÍTULO ' + romanize(cont2)) {//CAPÍTULO
                    var anterior2 = $('div#div_indices').html();
                    $('div#div_indices').html(anterior2 + '<a href="#" onclick="deslizar(' + "'" + cont + "_capitulo_" + cont2 + "'" + ')">CAPÍTULO ' + romanize(cont2) + '' + ($(this).find('span').parents('p').next().html() != undefined && $(this).find('span').parents('p').next().html().indexOf("TÍTULO") == -1 && $(this).find('span').parents('p').next().html().indexOf("SEÇÃO") == -1 ? '  ' + $(this).find('span').parents('p').next().html() : '') + '</a>');
                    $(this).html('<div id="' + cont + '_capitulo_' + cont2 + '">' + 'CAPÍTULO ' + romanize(cont2) + '</div>');

                    cont2++;
                    cont3 = 1;
                } 

                if ($(this).find('span').html().stripHTML() == 'Seção ' + romanize(cont3)) {//SEÇÃO
                    var anterior3 = $('div#div_indices').html();
                    $('div#div_indices').html(anterior3 + '<a href="#" onclick="deslizar(' + "'" + cont + "_" + cont2 + "_secao_" + cont3 + "'" + ')">SEÇÃO ' + romanize(cont3) + '' + ($(this).find('span').parents('p').next().html() != undefined && $(this).find('span').parents('p').next().html().indexOf("TÍTULO") == -1 && $(this).find('span').parents('p').next().html().indexOf("CAPÍTULO") == -1 ? '  ' + $(this).find('span').parents('p').next().html() : '') + '</a>');
                    $(this).html('<div id="' + cont + '_' + cont2 + '_secao_' + cont3 + '">' + 'SEÇÃO ' + romanize(cont3) + '</div>');

                    cont3++;
                }
				
				if ($(this).find('span').html().stripHTML() == 'ANEXO ' + romanize(cont4)) {//ANEXO
                    var anterior4 = $('div#div_indices').html();
                    $('div#div_indices').html(anterior4 + '<a href="#" onclick="deslizar(' + "'" + cont + "_" + cont2 + "_secao_" + cont3 + "_anexo_" + cont4 + "'" + ')">ANEXO ' + romanize(cont4) + '' + ($(this).find('span').parents('p').next().html() != undefined && $(this).find('span').parents('p').next().html().indexOf("TÍTULO") == -1 && $(this).find('span').parents('p').next().html().indexOf("CAPÍTULO") == -1 ? '  ' + $(this).find('span').parents('p').next().html() : '') + '</a>');
                    $(this).html('<div id="' + cont + '_' + cont2 + '_secao_' + cont3 + '_anexo_' + cont4 + '">' + 'ANEXO ' + romanize(cont4) + '</div>');

                    cont4++;
                }

            }
//            else if (typeof $(this).html().stripHTML() != 'undefined') {
//
//                if ($(this).html().stripHTML().indexOf('Art. ' + cont + 'º') != -1) {//ARTIGO
//                    var anterior = $('div#div_indices').html();
//                    $('div#div_indices').html(anterior + '<a href="#" onclick="deslizar(' + "'artigo_" + cont + "'" + ')">Art. ' + cont + 'º ' + '</a>');
//                    $(this).find('span').first().html('<div id="artigo_' + cont + '">' + $(this).html() + '</div>');
//                    cont++;
//                }
//
//            }
        } catch (e) {

        }
    });

    $('div#modal_impressao').click(function () {
        if ($(this).attr('class') == 'fab') {
            $(this).addClass('show');
        } else {
            $(this).removeClass('show');
        }
    });

    $('button#opcao1').click(function () {//PDF

        var codigo = $("#codigo").val();
        var opcao_compilacao = $("input#opcao_compilacao").val();

        if (navigator.userAgent.match(/Android/i)
                || navigator.userAgent.match(/webOS/i)
                || navigator.userAgent.match(/iPhone/i)
                || navigator.userAgent.match(/iPad/i)
                || navigator.userAgent.match(/iPod/i)
                || navigator.userAgent.match(/BlackBerry/i)
                || navigator.userAgent.match(/Windows Phone/i)) {
            if (opcao_compilacao == 0) {
                window.open(PORTAL_URL + 'detalhar_imprimir_mobile/' + codigo + '-0', '_blank');
            } else {
                window.open(PORTAL_URL + 'detalhar_imprimir_mobile/' + codigo, '_blank');
            }
        } else {
            if (opcao_compilacao == 0) {
                window.open(PORTAL_URL + 'detalhar_imprimir/' + codigo + '-0', '_blank');
            } else {
                window.open(PORTAL_URL + 'detalhar_imprimir/' + codigo, '_blank');
            }
        }
    });

    $('button#opcao2').click(function () {//WORD

        var codigo = $("#codigo").val();

        window.open(PORTAL_URL + 'detalhar_imprimir_doc/' + codigo, '_blank');
    });

    $('button#opcao3').click(function () {//COPIAR
        var nome_arquivo = $('input#nome_arquivo').val() == '' || $('input#nome_arquivo').val() == null ? 'resultado' : $('input#nome_arquivo').val();

        var header = "";
        var footer = "";
        var sourceHTML = header + document.getElementById("exportacaotxt").innerHTML + footer;

        var source = 'data:application/vnd.txt;charset=utf-8,' + encodeURIComponent(sourceHTML);
        var fileDownload = document.createElement("a");
        document.body.appendChild(fileDownload);
        fileDownload.href = source;
        fileDownload.download = nome_arquivo + '.txt';
        fileDownload.click();
        document.body.removeChild(fileDownload);
    });

    $('button#opcao4').click(function () {//IMPRIMIR
        var divContents = $('div#exportacao').html();
        var printWindow = window.open('', '', 'height=400,width=800');
        printWindow.document.write('<html><head>');
        printWindow.document.write('</head><style>.topo-lei{display: block; position: relative; margin: 0 auto 20px; width: 370px; height: 70px; clear: both;} .topo-lei .brasao{ display: block; float: left; width: 80px; } .topo-lei .text-top{ display: block; float: left; width: calc(100% - 80px); } .topo-lei img{ width: 76px; float: right; top: -10px; position: relative; }.topo-lei h2{ font-size: 12px; font-weight: bold; margin: 3px 0 0; text-align: center; } .topo-lei h2:last-child{ font-weight: 300; }</style><body >');
        printWindow.document.write(divContents);
        printWindow.document.write('</body></html>');
        printWindow.document.close();
        printWindow.print();
    });

    $('div#button_top').click(function () {
        $('html, body').animate({
            scrollTop: 0
        }, 200);
    });

    $('input#data_doe').datepicker();

    $('select.select2').each(function () {

        $(this).select2({
            placeholder: "Escolha o ano",
            allowClear: true
        });

        $('.select2').attr('style', 'width: 100%; heigth: 50px;');

    });

    $('select#quem_sancionou').select2({
        placeholder: "Quem sancionou ou promulgou",
        allowClear: true
    });

    $('select#quem_sancionou').attr('style', 'width: 100%; heigth: 50px;');


});
//--------------------------------------------------------------------------------------------
function myFunction() {

    if ($(window).scrollTop() < 112) {

        if ($('div#busca_serach').attr('class') == 'search2' || $('div#busca_serach').attr('class') == 'search3') {

            $('#busca_serach').removeClass('search3');
            $('div#busca_serach').removeClass('search2');
            $('div#busca_serach').addClass('search');

        } else if ($('div#busca_serach').attr('class') == 'search2 on2' || $('div#busca_serach').attr('class') == 'search3 on3') {
            $('div#busca_serach').removeClass('search3 on3');
            $('div#busca_serach').removeClass('search2 on2');
            $('div#busca_serach').addClass('search on');
        }

        $('div.top').removeClass('onn');

        $('#header_no_fixed').removeAttr('style');
        $('#header_no_fixed').attr('style', 'position: fixed; top: 25px; z-index: 50;');

        $('#header_no_fixed').addClass('header-fixed');
        $('#header_no_fixed').removeClass('header-fixed-on');
    } else {
        $('#header_no_fixed').removeAttr('style');
        $('#header_no_fixed').attr('style', 'position: fixed; top: 0px; z-index: 50;');

        $('div.top').addClass('onn');

        $('#header_no_fixed').addClass('header-fixed-on');
        $('#header_no_fixed').removeClass('header-fixed');

        if ($('div#busca_serach').attr('class') == 'search') {
            $('div#busca_serach').removeClass('search');
            $('div#busca_serach').addClass('search2');
        } else if ($('div#busca_serach').attr('class') == 'search on') {
            $('div#busca_serach').removeClass('search on');
            $('div#busca_serach').addClass('search3 on3');
        }

    }
}
//------------------------------------------------------------------------------
function ordinarias() {
    $('div#lei_ordinarias').show();
    $('div#lei_complementares').hide();
    $('div#lei_constituicao').hide();
    $('div#lei_decretos').hide();
    $('div#emendas').hide();

    $('select').each(function () {
//        $(this).select2({
//            placeholder: "Escolha o ano",
//            allowClear: true
//        });

        $('.select2').attr('style', 'width: 100%');


        $('select#quem_sancionou').select2({
            placeholder: "Quem sancionou ou promulgou",
            allowClear: true
        });

        $('select#iniciativa_busca').attr('style', 'width: 100%; heigth: 50px;');

        $('select#iniciativa_busca').select2({
            placeholder: "Qual a iniciativa",
            allowClear: true
        });

        $('select#uo_busca').attr('style', 'width: 100%; heigth: 50px;');

        $('select#uo_busca').select2({
            placeholder: "Qual o órgão de origem",
            allowClear: true
        });
    });
    $('input#pagina_menu').val(1);
}
//------------------------------------------------------------------------------
function complementar() {
    $('div#lei_ordinarias').hide();
    $('div#lei_complementares').show();
    $('div#lei_constituicao').hide();
    $('div#lei_decretos').hide();
    $('div#emendas').hide();

    $('select').each(function () {
//        $(this).select2({
//            placeholder: "Escolha o ano",
//            allowClear: true
//        });

        $('.select2').attr('style', 'width: 100%');


        $('select#quem_sancionou').select2({
            placeholder: "Quem sancionou ou promulgou",
            allowClear: true
        });

        $('select#iniciativa_busca').attr('style', 'width: 100%; heigth: 50px;');

        $('select#iniciativa_busca').select2({
            placeholder: "Qual a iniciativa",
            allowClear: true
        });

        $('select#uo_busca').attr('style', 'width: 100%; heigth: 50px;');

        $('select#uo_busca').select2({
            placeholder: "Qual o órgão de origem",
            allowClear: true
        });
        $('input#pagina_menu').val(2);
    });

}
//------------------------------------------------------------------------------
function decreto() {
    $('div#lei_ordinarias').hide();
    $('div#lei_complementares').hide();
    $('div#lei_constituicao').hide();
    $('div#lei_decretos').show();
    $('div#emendas').hide();

    $('select').each(function () {
//        $(this).select2({
//            placeholder: "Escolha o ano",
//            allowClear: true
//        });

        $('.select2').attr('style', 'width: 100%');
    });

    $('input#pagina_menu').val(3);
}
//------------------------------------------------------------------------------
$('label#lei_ordinarias').click(function () {
    postToURL(PORTAL_URL + 'principal/1');
});
//------------------------------------------------------------------------------
$('label#leis_complemantares').click(function () {
    postToURL(PORTAL_URL + 'principal/2');
});
//------------------------------------------------------------------------------
$('label#decreto').click(function () {
    postToURL(PORTAL_URL + 'principal/3');
});
//------------------------------------------------------------------------------
$('label#leis_ementarios_ordinarias').click(function () {
    postToURL(PORTAL_URL + 'principal/4');
});
//------------------------------------------------------------------------------
$('label#leis_ementarios_complementares').click(function () {
    postToURL(PORTAL_URL + 'principal/5');
});
//------------------------------------------------------------------------------
$('label#ementarios_publica').click(function () {
    postToURL(PORTAL_URL + 'principal/6');
});
//--------------------------------------------------------------------------------------------
function mostrar_search() {

    if ($('#busca_serach').attr('class') == 'search') {
        $('#busca_serach').addClass('on');
    } else if ($('#busca_serach').attr('class') == 'search on') {
        $('#busca_serach').removeClass('on');
    }

    if ($('#busca_serach').attr('class') == 'search2') {
        $('#busca_serach').addClass('on2');
    } else if ($('#busca_serach').attr('class') == 'search2 on2') {
        $('#busca_serach').removeClass('on2');
    }

    if ($('#busca_serach').attr('class') == 'search3 on3') {
        $('#busca_serach').removeClass('search3 on3');
        $('#busca_serach').addClass('search2');
    }
}
//------------------------------------------------------------------------------
function ordinarias() {
    $.post(PORTAL_URL + "utils/combo_session.php",
            {codigo: 1},
            function (valor) {
                postToURL(PORTAL_URL + 'principal/1');
                $('input#pagina_menu').val(1);
            });
}
//------------------------------------------------------------------------------
function complementar() {
    $.post(PORTAL_URL + "utils/combo_session.php",
            {codigo: 2},
            function (valor) {
                postToURL(PORTAL_URL + 'principal/2');
            });
}
//------------------------------------------------------------------------------
function decreto() {
    $.post(PORTAL_URL + "utils/combo_session.php",
            {codigo: 3},
            function (valor) {
                postToURL(PORTAL_URL + 'principal/3');
            });
}
//------------------------------------------------------------------------------