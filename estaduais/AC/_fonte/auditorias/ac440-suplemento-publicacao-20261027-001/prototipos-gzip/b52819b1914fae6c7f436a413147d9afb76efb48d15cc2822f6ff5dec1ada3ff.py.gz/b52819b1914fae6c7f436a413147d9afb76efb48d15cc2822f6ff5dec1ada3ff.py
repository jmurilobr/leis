import sys,json,datetime,traceback
from pathlib import Path
sys.path.insert(0,str(Path('scripts/estados/snapshots/ac_legis_html_20261027_001').resolve()))
from auditar_legis_ac import AuditorAC
p=Path('estaduais/AC/_fonte/auditorias/legis-QA-500-20261027-013');(p/'corpos').mkdir(exist_ok=True)
load=lambda x:json.loads(Path(x).read_text())
a=AuditorAC(load('estaduais/AC/_fonte/auditorias/legis-CSS-20261027-008/recibos-normalizados-18.json'),load('estaduais/AC/_fonte/auditorias/legis-JS-norma-20261027-012/recursos-observados.json')[0])
rows=load('scripts/estados/manifestos/ac-legis-fontes-500-20261027-010.json')['capturas'];out=[]
with (p/'resultados.jsonl').open('x') as f:
 for i,r in enumerate(rows):
  result=dict(item=r['item'],fonte=r['cache'],sha256_fonte=r['sha256_fonte'])
  try:
   body,q=a.auditar(r);dest=p/'corpos'/(r['item']['id_LEGIS']+'.html');dest.write_text(body);result.update(apto_automatico=True,corpo=str(dest),QA=q)
  except Exception as e:result.update(apto_automatico=False,motivo=type(e).__name__+': '+str(e))
  out.append(result);f.write(json.dumps(result,ensure_ascii=False)+'\n');f.flush()
  if (i+1)%25==0:print(i+1,sum(x['apto_automatico'] for x in out),flush=True)
(p/'resumo.json').write_text(json.dumps(dict(preparado_em=datetime.datetime.now().astimezone().isoformat(),total=len(out),aptos_automaticos=sum(x['apto_automatico'] for x in out),retidos=[dict(id=x['item']['id_LEGIS'],numero=x['item']['numero'],motivo=x['motivo']) for x in out if not x['apto_automatico']]),ensure_ascii=False,indent=2)+'\n')
