from pathlib import Path
import json,gzip,hashlib,datetime
SHA=lambda b:hashlib.sha256(b).hexdigest()
load=lambda p:json.loads(Path(p).read_text())
base=Path('estaduais/AC/_fonte/auditorias/ac440-privado-20261027-001');final=base/'final';final.mkdir(exist_ok=False)
profile=Path('scripts/estados/snapshots/ac_legis_html_20261027_002');source_manifest=Path('scripts/estados/manifestos/ac-legis-fontes-500-20261027-010.json');src=load(source_manifest)
rows=[json.loads(l) for l in Path('estaduais/AC/_fonte/auditorias/legis-QA-500-20261027-013/resultados.jsonl').read_text().splitlines()];byid={r['item']['id_LEGIS']:r for r in src['capturas']};out=[];held=[]
edition='Transcrição digital do campo body-law fornecido pelo portal oficial LEGIS/AC no modo de interface Padrão, capturada em 27/10/2026. Não equivale a certificação da edição original do DOE nem da redação vigente. O portal pode incorporar alterações posteriores mesmo nesse modo; candidatos com indicação literal de consolidação ficam fora deste subconjunto.'
for r in rows:
 it=r['item'];reason=None
 if not r['apto_automatico']:reason=r['motivo']
 elif r['QA']['contextos_objetos'] or r['QA']['epigrafes_contextuais']:reason='Revisão contextual pendente das remissões a objetos/anexos ou epígrafes; retenção conservadora, sem concluir ausência ou defeito.'
 elif it['id_LEGIS'] in ['6217','6207']:reason='Inclusão legislativa posterior explícita no campo; edição/rotulagem deve ser qualificada individualmente antes de nova proposta.'
 if reason:
  held.append(dict(item=it,captura=byid[it['id_LEGIS']],motivo=reason,QA=r.get('QA'),sem_mascara=True,sem_inferencia_revogacao=True));continue
 body=Path(r['corpo']).read_text();title=it['titulo_indice'];meta=dict(titulo=title,tipo=it['tipo'],numero=it['numero'],data=it['data'],ementa=r['QA']['ementa_indice'],uf='AC',fonte=it['fonte'],arquivo=it['fonte'],id_fonte='LEGIS-AC:'+it['id_LEGIS'],situacao=None,revogada=None,representacao_corpo='html-nativo-body-law-legis-ac-v1',edicao=edition,sha256_texto=SHA(body.encode()),observacao_fonte='Fonte HTML integral oficial, índice, 18 folhas CSS e JavaScript preservados. Texto/atributos/células preservados, CRLF normalizado a LF e whitespace de nós textuais representado por entidades equivalentes para CommonMark. UI vazia posterior ao rodapé excluída somente por prova estrutural. Não houve correção presumida de OCR, nomes ou vigência.')
 dest=f"estaduais/AC/{it['pasta']}/{it['data'][:4]}/{'lc' if it['pasta']=='leis-complementares' else 'l'}-{it['numero']}-{it['data'][:4]}-legis{it['id_LEGIS']}.md";priv=base/'candidatos'/dest;priv.parent.mkdir(parents=True,exist_ok=True)
 blob=('---\n'+''.join(k+': '+json.dumps(v,ensure_ascii=False)+'\n' for k,v in meta.items())+'---\n# '+title+'\n\n'+body).encode();priv.write_bytes(blob)
 out.append(dict(path=dest,privado=str(priv),sha256_md=SHA(blob),captura=byid[it['id_LEGIS']],QA=r['QA']))
assert len(out)==440 and len(held)==60
hold=Path('scripts/estados/manifestos/ac60-retencoes-contextuais-20261027-001.json');hold.write_text(json.dumps(dict(preparado_em=datetime.datetime.now().astimezone().isoformat(),total=60,novas_normas=0,sem_mascara=True,sem_promocao=True,limite='Motivos de triagem conservadora; não declarar todos incompletos/incorretos. Caso tachado integral exige preservação histórica e contexto, não presume revogação.',documentos=held),ensure_ascii=False,indent=2)+'\n')
cssfile=Path('estaduais/AC/_fonte/auditorias/legis-CSS-20261027-008/recibos-normalizados-18.json');jsfile=Path('estaduais/AC/_fonte/auditorias/legis-JS-norma-20261027-012/recursos-observados.json');css=load(cssfile);js=load(jsfile)[0];code={str(p):SHA(p.read_bytes()) for p in profile.iterdir() if p.is_file()};m=dict(preparado_em=datetime.datetime.now().astimezone().isoformat(),total=440,total_entrada=500,total_retido=60,sem_promocao=True,metas_inalteradas=True,edicao=edition,representacao_corpo='html-nativo-body-law-legis-ac-v1',CSS=css,JS=js,codigo=code,documentos=out,retencoes=str(hold),sha256_retencoes=SHA(hold.read_bytes()),fonte_capturas=str(source_manifest),sha256_fonte_capturas=SHA(source_manifest.read_bytes()),limites='Somente o subconjunto sem remissões contextuais pendentes, sem CSS/JS ocultador, tachados ou visuais no campo normativo. Identidade digital cartão/epígrafe/fecho, sinais e matrizes de tabelas conferidos; não certifica DOE, vigência global ou ausência de erro editorial da transcrição oficial.')
manifest=Path('scripts/estados/manifestos/ac440-proposta-privada-20261027-001.json');manifest.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n')
files=set(code)|{str(manifest),str(hold),str(source_manifest),str(cssfile),str(jsfile),str(base/'preparar.py'),src['selecao']}
# Todos os 500 originais também sustentam os 60 controles de retenção; recibos
# públicos já omitem headers de sessão. Nenhum arquivo privado *.headers/body.
for row in src['capturas']:files.add(row['cache']);files.add(row['item']['indice']['cache'])
for row in css+[js]:files.add(row['cache'])
files|={r['privado'] for r in out}
for s in ['resumo.json','contextos.json','contextos-complementares.json','executar.py']:
 files.add(str(Path('estaduais/AC/_fonte/auditorias/legis-QA-500-20261027-013')/s))
# Inventário de granularidade contextual congelado e preimagens, separado de
# inferências de duplicação. Confere namespace entre fontes e corpo HEAD integral.
oldmaps=load('estaduais/AC/_fonte/auditorias/epigrafes-secundarias-HEAD-20261027-009/hashes.json')
for p,sha in oldmaps.items():
 assert SHA(Path(p).read_bytes())==sha;files.add(p)
files.add('scripts/estados/manifestos/ac-inventario-epigrafes-HEAD-20261027-001.json')
for p in files:
 assert not Path(p).is_absolute() and '..' not in Path(p).parts
maps={p:SHA(Path(p).read_bytes()) for p in sorted(files)}
(final/'hashes.json').write_text(json.dumps(maps,ensure_ascii=False,indent=2)+'\n');(final/'paths.txt').write_text('\n'.join(maps)+'\n');(final/'canonicos.txt').write_text('\n'.join(r['path'] for r in out)+'\n');(final/'candidatos.txt').write_text('\n'.join(r['privado'] for r in out)+'\n')
print(json.dumps(dict(manifesto=str(manifest),sha256=SHA(manifest.read_bytes()),total=len(out),retidos=len(held),arquivos=len(maps),bytes=sum(Path(p).stat().st_size for p in files)),ensure_ascii=False))
