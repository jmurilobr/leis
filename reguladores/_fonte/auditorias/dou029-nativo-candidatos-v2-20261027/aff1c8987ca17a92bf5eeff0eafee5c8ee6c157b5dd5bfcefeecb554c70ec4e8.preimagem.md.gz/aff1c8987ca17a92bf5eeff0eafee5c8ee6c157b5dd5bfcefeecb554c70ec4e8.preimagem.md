---
titulo: "PORTARIA Nº 2.355, DE 26 DE NOVEMBRO DE 2019"
orgao: "Presidência da República/Casa Civil"
tipo: "Portaria"
numero: "2355"
data: 2019-11-26
revogada: null
versao_texto: "publicação original"
publicacao: "DOU de 27/11/2019, seção 1, p. 5"
data_publicacao: 2019-11-27
edicao: "229"
fonte: "https://www.in.gov.br/web/dou/-/portaria-n-2.355-de-26-de-novembro-de-2019-229902699"
sha256_html_fonte: 886bf6f3541cb7018a9d2b910bb54ad8470beb77a21a5455b6ff8010b530df86
baixado_em: 2026-10-27
---
# PORTARIA Nº 2.355, DE 26 DE NOVEMBRO DE 2019

PORTARIA Nº 2.355, DE 26 DE NOVEMBRO DE 2019

Dispõe sobre a designação de Unidade de Gestão de Integridade no âmbito da Casa Civil da Presidência da República.

**O MINISTRO DE ESTADO CHEFE DA CASA CIVIL DA PRESIDÊNCIA DA REPÚBLICA,**substituto,no uso das atribuições que lhe conferem os incisos I e IV do parágrafo único do art. 87 da Constituição, e tendo em vista o disposto no art. 12 da Lei nº 9.784, de 29 de janeiro de 1999, e no Decreto nº 7.689, de 2 de março de 2012, no art. 19 do Decreto nº 9.203, de 22 de novembro de 2017, no Decreto nº 9.979, de 20 de agosto de 2019, e no art. 4º da Portaria CGU nº 57, de 4 de janeiro de 2019, resolve:

**Art. 1º** Designar a Diretoria de Governança, Inovação e Conformidade como Unidade de Gestão de Integridade (UGI) da Secretaria-Executiva da Casa Civil da Presidência da República.

**Art. 2º** Compete à Unidade de Gestão de Integridade da Casa Civil:

I - coordenar a estruturação, execução e monitoramento do Programa de Integridade da Casa Civil da Presidência da República;

II - orientar e proporcionar treinamento aos servidores com relação aos temas atinentes ao Programa de Integridade da Casa Civil da Presidência da República; e

III - promover outras ações relacionadas à implementação do Programa de Integridade da Casa Civil da Presidência República, em conjunto com as demais unidades da Presidência da República.

**Art. 3º** Esta Portaria entra em vigor na data de sua publicação.

FERNANDO WANDSCHEER DE MOURA ALVES
