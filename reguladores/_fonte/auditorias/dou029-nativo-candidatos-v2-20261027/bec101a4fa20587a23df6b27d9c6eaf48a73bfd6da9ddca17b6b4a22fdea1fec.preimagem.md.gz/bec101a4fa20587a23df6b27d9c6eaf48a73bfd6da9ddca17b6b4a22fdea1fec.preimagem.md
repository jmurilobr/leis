---
titulo: "RESOLUÇÃO Nº 10, DE 25 DE NOVEMBRO DE 2020"
orgao: "Presidência da República/Casa Civil/Comitê de Crise para Supervisão e Monitoramento dos Impactos da Covid-19"
tipo: "Resolução"
numero: "10"
data: 2020-11-25
revogada: null
versao_texto: "publicação original"
publicacao: "DOU de 26/11/2020, seção 1, p. 1"
data_publicacao: 2020-11-26
edicao: "226"
fonte: "https://www.in.gov.br/web/dou/-/resolucao-n-10-de-25-de-novembro-de-2020-290312742"
sha256_html_fonte: bc87ab3ee222220d4aa4b758cb28751395ba33813f26804a23ceb9e1e84311aa
baixado_em: 2026-10-21
---
# RESOLUÇÃO Nº 10, DE 25 DE NOVEMBRO DE 2020

RESOLUÇÃO Nº 10, DE 25 DE NOVEMBRO DE 2020

Dispõe sobre a definição de responsabilidades entre o Ministério da Economia, o Ministério da Cidadania e o Ministério da Saúde em relação às demandas por proteção social no combate à covid-19.

**O COMITÊ DE CRISE PARA SUPERVISÃO E MONITORAMENTO DOS IMPACTOS DA COVID-19, no uso da atribuição que lhe confere o art. 2º do Decreto nº 10.277, de 16 de março de 2020, resolve:**

**Art. 1º** Esta Resolução regulamenta as responsabilidades do Ministério da Economia, do Ministério da Cidadania e do Ministério da Saúde na avaliação de cenários e proposição de medidas de proteção social no combate à pandemia da**covid-19**.

**Art. 2º** Compete ao Ministério da Economia:

I - propor meios de financiamento das medidas de proteção social;

II - produzir informações sobre a retomada da economia;

III - articular com o Ministério da Cidadania a instituição de instrumento específico que possibilite o cruzamento de dados de potenciais beneficiários das medidas de proteção social.

**Art. 3º** Compete ao Ministério da Cidadania:

I - propor, a partir de estudos, pesquisas, manifestações de outros órgãos e análises próprias, medidas de proteção social para mitigação dos impactos da pandemia da**covid-19,**no âmbito das políticas coordenadas pelo Ministério da Cidadania;

II - formular, gerir, apoiar e implementar as ações previstas no inciso I, relativas à área de assistência social, em articulação com os demais entes federados;

III - implementar e gerir os canais de cadastramento dos beneficiários das medidas de que trata o inciso I;

IV - gerir os auxílios emergenciais instituídos pelo art. 2º da Lei nº 13.982, de 2 de abril de 2020, e pelo art. 1º da Medida Provisória nº 1.000, de 2 de setembro de 2020; e

V - avaliar e articular com outros órgãos e entidades da Administração Pública, quando necessário, a instituição de instrumento específico que possibilite o cruzamento de dados de potenciais beneficiários das medidas de proteção social, sem prejuízo do previsto no Decreto nº 10.046, de 9 de outubro de 2019.

**Art. 4º** Compete ao Ministério da Saúde:

I - disponibilizar informações e estudos sobre a adoção de protocolos sanitários;

II - prover subsídios técnicos para avaliação do risco sanitário nacional da**covid-19**, conforme o Regulamento Sanitário Internacional (RSI);

III - coordenar, em nível nacional, a coleta, o tratamento e a disseminação de dados dos sistemas de informação em saúde destinados à vigilância de síndrome gripal e síndrome respiratória aguda grave por**covid-19**, no que se refere a indivíduos em situação de risco e vulnerabilidade pessoal e social;

IV - promover análises de situação de saúde da**covid-19**no Brasil, com foco no perfil de morbimortalidade de indivíduos em situação de risco e vulnerabilidade pessoal e social;

V - definir plano para operacionalização de vacinação contra a**covid-19**e estabelecer grupos prioritários, a serem definidos, a partir da situação epidemiológica da doença, das evidências científicas existentes sobre as vacinas e suas especificações, além da disponibilidade de vacinas; e

VI - realizar a vigilância laboratorial de**covid-19**.

**Art. 5º** Os casos omissos deverão ser submetidos ao Comitê de Crise para Supervisão e Monitoramento dos Impactos da**covid-19**.

**Art. 6º** Esta Resolução entra em vigor na data de sua publicação.

WALTER SOUZA BRAGA NETTO

Coordenador do Comitê
